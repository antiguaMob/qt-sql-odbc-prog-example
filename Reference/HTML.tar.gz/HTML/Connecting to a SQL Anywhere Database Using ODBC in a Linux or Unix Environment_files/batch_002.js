;try {
/* module-key = 'com.atlassian.confluence.plugins.share-page:mail-page-resources', location = 'templates/sharepage/share-dialog.soy' */
// This file was automatically generated from share-dialog.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Share == 'undefined') { Confluence.Templates.Share = {}; }
if (typeof Confluence.Templates.Share.Dialog == 'undefined') { Confluence.Templates.Share.Dialog = {}; }


Confluence.Templates.Share.Dialog.shareContentPopup = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" class="aui share-content-popup"><div class="field-group"><div class="autocomplete-user-target"><input class="text autocomplete-sharepage" id="users" data-max="10" data-dropdown-target=".autocomplete-user-target" data-none-message="', soy.$$escapeHtml("No matches"), '" placeholder="', soy.$$escapeHtml("User name, group or email"), '"/></div><ol class="recipients"></ol></div><div class="field-group"><textarea class="textarea" id="note" placeholder="', soy.$$escapeHtml("Add an optional note"), '"/></div><div class="field-group button-panel"><div class="progress-messages-icon"></div><div class="progress-messages"></div><input class="button submit" type="submit" value="', soy.$$escapeHtml("Share"), '" disabled/><a class="close-dialog" href="#">', soy.$$escapeHtml("Cancel"), '</a></div></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Share.Dialog.recipientUser = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li data-userkey="', soy.$$escapeHtml(opt_data.userKey), '" style="display: none" class="recipient-user"><img src="', soy.$$escapeHtml(opt_data.thumbnailLink.href), '" title="', soy.$$escapeHtml(opt_data.title), '"/><span class="title" title="', soy.$$escapeHtml(opt_data.title), '">', soy.$$escapeHtml(opt_data.title), '</span><span class="remove-recipient"/></li>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Share.Dialog.recipientEmail = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li data-email="', soy.$$escapeHtml(opt_data.email), '" style="display: none" class="recipient-email"><img src="', soy.$$escapeHtml(opt_data.icon), '" title="', soy.$$escapeHtml(opt_data.email), '"/><span class="title" title="', soy.$$escapeHtml(opt_data.email), '">', soy.$$escapeHtml(opt_data.email), '</span><span class="remove-recipient"/></li>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Share.Dialog.recipientGroup = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li data-group="', soy.$$escapeHtml(opt_data.title), '" style="display: none" class="recipient-group"><span><img src="', soy.$$escapeHtml(opt_data.thumbnailLink.href), '" title="', soy.$$escapeHtml(opt_data.title), '"/><span>', soy.$$escapeHtml(opt_data.title), '</span><span class="remove-recipient"/></span></li>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.share-page:mail-page-resources', location = 'js/mailpage.js' */
AJS.Confluence.SharePage={};AJS.Confluence.SharePage.autocompleteUser=function(d){d=d||document.body;var e=AJS.$,a=/^([a-zA-Z0-9_\.\-\+\!#\$%&'\*/=\?\^_`{|}~])+\@.*/;var c=function(j){if(!j||!j.result){throw new Error("Invalid JSON format")}var f=[];for(var g=0;g<j.result.length;g++){var h=j.result[g];if(h.type=="group"){h=b(h)}}f.push(j.result);return f};function b(f){if(f.name=="confluence-users"||f.name=="confluence-administrators"){return f}f.title=f.name;f.group=f.name;f.thumbnailLink={href:Confluence.getContextPath()+"/download/resources/com.atlassian.confluence.plugins.share-page:mail-page-resources/images/group.png",type:"image/png",rel:"thumbnail"};f.link=[{href:Confluence.getContextPath(),rel:"self"}];return f}e("input.autocomplete-sharepage[data-autocomplete-user-bound!=true]",d).each(function(){var h=e(this).attr("data-autocomplete-sharepage-bound","true").attr("autocomplete","off");var g=h.attr("data-max")||10,j=h.attr("data-alignment")||"left",i=h.attr("data-dropdown-target"),f=null;if(i){f=e(i)}else{f=e("<div></div>");h.after(f)}f.addClass("aui-dd-parent autocomplete");h.quicksearch(AJS.REST.getBaseUrl()+"search/user-or-group.json",function(){h.trigger("open.autocomplete-sharepage")},{makeParams:function(k){return{"max-results":g,query:k.replace("{|}","")}},dropdownPlacement:function(k){f.append(k)},makeRestMatrixFromData:c,addDropdownData:function(l){var k=e.trim(h.val());if(a.test(k)){l.push([{name:k,email:k,href:"#",icon:Confluence.getContextPath()+"/download/resources/com.atlassian.confluence.plugins.share-page:mail-page-resources/images/envelope.png"}])}if(!l.length){var m=h.attr("data-none-message");if(m){l.push([{name:m,className:"no-results",href:"#"}])}}return l},ajsDropDownOptions:{alignment:j,displayHandler:function(k){if(k.restObj&&k.restObj.username){return k.name+" ("+k.restObj.username+")"}return k.name},selectionHandler:function(m,l){if(l.find(".search-for").length){h.trigger("selected.autocomplete-sharepage",{searchFor:h.val()});return}if(l.find(".no-results").length){this.hide();m.preventDefault();return}var k=e("span:eq(0)",l).data("properties");if(!k.email){k=k.restObj}h.trigger("selected.autocomplete-sharepage",{content:k});this.hide();m.preventDefault()}}})})};(function(a){jQuery.fn.extend({elastic:function(){var b=["paddingTop","paddingRight","paddingBottom","paddingLeft","fontSize","lineHeight","fontFamily","width","fontWeight","border-top-width","border-right-width","border-bottom-width","border-left-width","borderTopStyle","borderTopColor","borderRightStyle","borderRightColor","borderBottomStyle","borderBottomColor","borderLeftStyle","borderLeftColor"];return this.each(function(){if(this.type!=="textarea"){return false}var g=jQuery(this),c=jQuery("<div />").css({position:"absolute",display:"none","word-wrap":"break-word","white-space":"pre-wrap"}),j=parseInt(g.css("line-height"),10)||parseInt(g.css("font-size"),"10"),l=parseInt(g.css("height"),10)||j*3,k=parseInt(g.css("max-height"),10)||Number.MAX_VALUE,d=0;if(k<0){k=Number.MAX_VALUE}c.appendTo(g.parent());var f=b.length;while(f--){c.css(b[f].toString(),g.css(b[f].toString()))}function h(){var i=Math.floor(parseInt(g.width(),10));if(c.width()!==i){c.css({width:i+"px"});e(true)}}function m(i,o){var n=Math.floor(parseInt(i,10));if(g.height()!==n){g.css({height:n+"px",overflow:o})}}function e(p){var o=g.val().replace(/&/g,"&amp;").replace(/ {2}/g,"&nbsp;").replace(/<|>/g,"&gt;").replace(/\n/g,"<br />");var i=c.html().replace(/<br>/ig,"<br />");if(p||o+"&nbsp;"!==i){c.html(o+"&nbsp;");if(Math.abs(c.height()+j-g.height())>3){var n=c.height()+j;if(n>=k){m(k,"auto")}else{if(n<=l){m(l,"hidden")}else{m(n,"hidden")}}}}}g.css({overflow:"hidden"});g.bind("keyup change cut paste",function(){e()});a(window).bind("resize",h);g.bind("resize",h);g.bind("update",e);g.bind("input paste",function(i){setTimeout(e,250)});e()})}})})(AJS.$);(function(f){var e,c={hideCallback:a,width:250,hideDelay:3600000,calculatePositions:function(h,o,w,s){var p;var y;var u;var l=-7;var m;var q;var x=o.target.offset();var g=o.target.outerWidth();var j=x.left+g/2;var t=(window.pageYOffset||document.documentElement.scrollTop)+f(window).height();var k=10;u=x.top+o.target.outerHeight()+s.offsetY;p=x.left+s.offsetX;var n=x.top>h.height();var i=(u+h.height())<t;q=(!i&&n)||(s.onTop&&n);var r=f(window).width()-(p+s.width+k);if(q){u=x.top-h.height()-8;var v=s.displayShadow?(AJS.$.browser.msie?10:9):0;l=h.height()-v}m=j-p+s.arrowOffsetX;if(s.isRelativeToMouse){if(r<0){y=k;p="auto";m=w.x-(f(window).width()-s.width)}else{p=w.x-20;y="auto";m=w.x-p}}else{if(r<0){y=k;p="auto";m=j-(f(window).width()-h.outerWidth())}else{if(s.width<=g/2){m=s.width/2;p=j-s.width/2}}}return{displayAbove:q,popupCss:{left:p,right:y,top:u},arrowCss:{position:"absolute",left:m,right:"auto",top:l}}}};var a=function(){f(".dashboard-actions .explanation").hide()};var d=function(j,h,i){if(j.find("input").length){i();return}j.append(Confluence.Templates.Share.Dialog.shareContentPopup());AJS.Confluence.SharePage.autocompleteUser();var k=function(m){AJS.Confluence.SharePage.current.hide();if(m){setTimeout(function(){j.empty()},300)}return false};f(document).keyup(function(m){if(m.keyCode==27){k(true);f(document).unbind("keyup",arguments.callee);return false}return true});j.find(".close-dialog").click(function(){k(true)});j.find("#note").elastic();j.find("form").submit(function(){var r=[];j.find(".recipients li").each(function(s,t){r.push(f(t).attr("data-userKey"))});if(r.length<=0){return false}f("button,input,textarea",this).attr("disabled","disabled");j.find(".progress-messages-icon").removeClass("error");j.find(".progress-messages").text("Sending");j.find(".progress-messages").attr("title","Sending");var o=Raphael.spinner(j.find(".progress-messages-icon")[0],7,"#666");j.find(".progress-messages-icon").css("position","absolute").css("left","0").css("margin-top","3px");j.find(".progress-messages").css("padding-left",j.find(".progress-messages-icon").innerWidth()+5);var r=[];j.find(".recipients li[data-userKey]").each(function(s,t){r.push(f(t).attr("data-userKey"))});var q=[];j.find(".recipients li[data-email]").each(function(s,t){q.push(f(t).attr("data-email"))});var m=[];j.find(".recipients li[data-group]").each(function(s,t){m.push(f(t).attr("data-group"))});var n=j.find("#note");var p={users:r,emails:q,groups:m,note:n.hasClass("placeholded")?"":n.val(),entityId:AJS.params.pageId};f.ajax({type:"POST",contentType:"application/json; charset=utf-8",url:Confluence.getContextPath()+"/rest/share-page/latest/share",data:JSON.stringify(p),dataType:"text",success:function(){setTimeout(function(){o();j.find(".progress-messages-icon").addClass("done");j.find(".progress-messages").text("Sent");j.find(".progress-messages").attr("title","Sent");setTimeout(function(){j.find(".progress-messages").text("");j.find(".progress-messages-icon").removeClass("done");j.find("#note").val("");f("button,input,textarea",j).removeAttr("disabled");k(false)},1000)},500)},error:function(t,s){o();j.find(".progress-messages-icon").addClass("error");j.find(".progress-messages").text("Error sending");j.find(".progress-messages").attr("title","Error sending"+": "+s);f("button,input,textarea",j).removeAttr("disabled")}});return false});var l=j.find("#users");var g=j.find("input.submit");l.bind("selected.autocomplete-sharepage",function(n,m){var o=function(r,q,s){var u=j.find(".recipients"),t,p;t="li[data-"+r+'="'+s.content[r]+'"]';if(u.find(t).length>0){u.find(t).hide()}else{u.append(q(s.content))}p=u.find(t);p.find(".remove-recipient").click(function(){p.remove();if(u.find("li").length==0){g.attr("disabled","true")}AJS.Confluence.SharePage.current.refresh();l.focus();return false});p.fadeIn(200)};if(m.content.email){o("email",Confluence.Templates.Share.Dialog.recipientEmail,m)}else{if(m.content.type=="group"){o("group",Confluence.Templates.Share.Dialog.recipientGroup,m)}else{o("userKey",Confluence.Templates.Share.Dialog.recipientUser,m)}}AJS.Confluence.SharePage.current.refresh();g.removeAttr("disabled");l.val("");return false});l.bind("open.autocomplete-sharepage",function(n,m){if(f("a:not(.no-results)",AJS.dropDown.current.links).length>0){AJS.dropDown.current.moveDown()}});l.keypress(function(m){return m.keyCode!=13});f(document).bind("showLayer",function(o,n,m){if(n=="inlineDialog"&&m.popup==AJS.Confluence.SharePage.current){m.popup.find("#users").focus()}});f(h).parents().filter(function(){return this.scrollTop>0}).scrollTop(0);i()};var b=function(g){var h=f("#splitter-content");if(h.length!==0){g.container=h;g.offsetY=AJS.InlineDialog.opts.offsetY-h.offset().top}return g};AJS.Confluence.SharePage.initDialog=function(g,i,h){if(g.length){var j=f.extend(false,b(c),h);AJS.Confluence.SharePage.current=AJS.InlineDialog(g,i,d,j)}};AJS.toInit(function(g){AJS.Confluence.SharePage.initDialog(g("#shareContentLink"),"shareContentPopup")})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.editor.confluence-source-editor:atlassian-source-editor-view-storage-javascript', location = 'jscripts/source-editor/view-source.js' */
AJS.toInit(function(A){if(A("#action-view-storage-link").length){A("#action-source-editor-view-storage-link").closest("li").hide()
}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-amd-resources', location = '/js/amd/confluence-amd.js' */
define("confluence",function(){return Confluence});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-amd-resources', location = '/js/amd/tinymce-amd.js' */
define("tinymce",function(){return tinymce});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:common', location = '/js/view-file-macro-utils.js' */
define("vfm/view-file-macro-utils",[],function(){var a={DEFAULT_HEIGHT:"250",DEFAULT_HEIGHT_IN_COMMENT:"150",THUMBNAIL_STATUS_IN_PROGRESS:202,THUMBNAIL_STATUS_CONVERTED:200,THUMBNAIL_STATUS_ERROR:415,THUMBNAIL_STATUS_BUSY:429,THUMBNAIL_POLLING_PERIOD:1000,THUMBNAIL_POLLING_BACKOFF_RATIO:1.25,MAP_NICE_TYPE_TO_TEXT:{"pdf document":"PDF","word document":"Document","excel spreadsheet":"Spreadsheet","powerpoint presentation":"Presentation","generic file":"File"},getFileNameFromUrl:function(b){if(!b){return""}var c=b.indexOf("#");c=(c>=0)?c:b.length;b=b.substring(0,c);c=b.indexOf("?");c=(c>=0)?c:b.length;b=b.substring(0,c);c=b.lastIndexOf("/");b=b.substring(c+1,b.length);return decodeURIComponent(b)},isSupportPointerEvents:function(){var b=document.createElement("x");b.style.cssText="pointer-events:auto";return b.style.pointerEvents==="auto"},getParameterByName:function(d,c){var e=d.indexOf("#");if(e>=0){d=d.substring(0,e)}var b=new RegExp(c+"=([^&]*)","i").exec(d);return b?decodeURIComponent(b[1]):null},addParamsToUrl:function(b,h){var f="";if(b.indexOf("?")===-1){f="?"}else{f="&"}var e=Object.keys(h);for(var d=0;d<e.length;d++){var c=e[d];var g=h[c];if(d>0){f+="&"}f+=c+"="+g}return b+f},getFileTypeTextFromNiceType:function(b){b=b?b.toLowerCase():"";return this.MAP_NICE_TYPE_TO_TEXT[b]?this.MAP_NICE_TYPE_TO_TEXT[b]:b}};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:common', location = '/js/services/conversion-service.js' */
define("vfm/services/conversion-service",["ajs","jquery"],function(a,b){return{postThumbnailConversionResults:function(c){var d=a.contextPath()+"/rest/documentConversion/latest/conversion/thumbnail/results";var e=Object.keys(c);var f=_.map(e,function(g){return{id:g,v:c[g].version}});return b.ajax({type:"POST",url:d,contentType:"application/json",data:JSON.stringify(f)})},getThumbnailUrl:function(d,c){return a.contextPath()+"/rest/documentConversion/latest/conversion/thumbnail/"+d+"/"+c}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.editor:file-types-utils-resources', location = 'utils/file-types-utils.js' */
(function(){var e={"aui-iconfont-file-image":"image/gif image/jpeg image/pjpeg image/png image/tiff image/bmp".split(" "),"aui-iconfont-file-pdf":["application/pdf"],"aui-iconfont-file-video":"audio/mpeg audio/x-wav audio/mp3 audio/mp4 video/mpeg video/quicktime video/mp4 video/x-m4v video/x-flv video/x-ms-wmv video/avi video/webm video/vnd.rn-realvideo".split(" "),"aui-iconfont-file-code":["text/html","text/xml","text/x-java-source"],"aui-iconfont-file-doc":["application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
"aui-iconfont-file-xls":["application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],"aui-iconfont-file-ppt":["application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation"],"aui-iconfont-file-txt":["text/plain"],"aui-iconfont-file-zip":["application/zip"]},b={},c;for(c in e)for(var f=e[c],d=0,g=f.length;d<g;d++)b[f[d]]=c;AJS.Confluence.FileTypesUtils={getAUIIconFromMime:function(a){return b[a]||"aui-iconfont-file-generic"},
isImage:function(a){return b[a]&&0===a.indexOf("image/")}}})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-embedded-file-view-soy-resources', location = '/templates/embedded-file-view.soy' */
// This file was automatically generated from embedded-file-view.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.ViewFileMacro == 'undefined') { Confluence.ViewFileMacro = {}; }
if (typeof Confluence.ViewFileMacro.Templates == 'undefined') { Confluence.ViewFileMacro.Templates = {}; }


Confluence.ViewFileMacro.Templates.embeddedFile = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="confluence-embedded-file-wrapper"><a class="confluence-embedded-file" href="', soy.$$escapeHtml(opt_data.fileSrc), '" data-nice-type="', soy.$$escapeHtml(opt_data.niceType), '" data-file-src="', soy.$$escapeHtml(opt_data.fileSrc), '" data-linked-resource-id="', soy.$$escapeHtml(opt_data.attachmentId), '" data-linked-resource-type="attachment" data-linked-resource-container-id="', soy.$$escapeHtml(opt_data.containerId), '" data-linked-resource-default-alias="', soy.$$escapeHtml(opt_data.fileName), '" data-mime-type="', soy.$$escapeHtml(opt_data.mimeType), '" data-has-thumbnail="', (opt_data.hasThumbnail) ? 'true' : 'false', '" data-linked-resource-version="', soy.$$escapeHtml(opt_data.attachmentVersion), '"', (opt_data.unresolvedCommentCount && opt_data.unresolvedCommentCount >= 0) ? 'data-unresolved-comment-count=' + soy.$$escapeHtml(opt_data.unresolvedCommentCount) : '', '><img src="', soy.$$escapeHtml(opt_data.placeholderSrc), '" height="', soy.$$escapeHtml(opt_data.height), '">', (! opt_data.hasThumbnail) ? '<span class="title">' + soy.$$escapeHtml(opt_data.fileName) + '</span>' : '', '</a></span>');
  return opt_sb ? '' : output.toString();
};


Confluence.ViewFileMacro.Templates.embeddedUnknownFile = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="confluence-embedded-file-wrapper"><img class="confluence-embedded-file unknown-attachment" src="', soy.$$escapeHtml(opt_data.placeholderSrc), '" /></span>');
  return opt_sb ? '' : output.toString();
};


Confluence.ViewFileMacro.Templates.overlayEmbeddedFile = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="overlay"></span>');
  return opt_sb ? '' : output.toString();
};


Confluence.ViewFileMacro.Templates.overlayEmbeddedFileCommentCount = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="comment-count-overlay"><span class="content">', soy.$$escapeHtml(opt_data.commentCountRep), '</span></span>');
  return opt_sb ? '' : output.toString();
};


Confluence.ViewFileMacro.Templates.overlayEmbeddedFileFileTypeDesc = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="file-type-desc-overlay"><i class="aui-icon aui-icon-small ', soy.$$escapeHtml(opt_data.iconClass), '"></i><span class="content"> ', soy.$$escapeHtml(opt_data.fileType), '</span></span>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-embedded-file-view-resources', location = '/js/services/file-service.js' */
define("vfm/services/file-service",["ajs","jquery"],function(a,b){return{getCommentCount:function(c,e){var d="/rest/files/1.0/files/content/{0}/commentCount?attachmentId={1}";d=a.contextPath()+a.format(d,c,e);return b.get(d)}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-embedded-file-view-resources', location = '/js/components/embedded-file-view.js' */
define("vfm/components/embedded-file-view",["jquery","backbone","ajs","confluence","vfm/view-file-macro-utils"],function(d,f,b,e,a){var c=function(i){var j=d(i.el);var l=j.find(".confluence-embedded-image, .confluence-embedded-file");var m=function(){if(l.hasClass("unknown-attachment")||(l.attr("src")&&l.attr("src").indexOf("/confluence/plugins/servlet/confluence/placeholder/unknown-attachment")>=0)){return this}var p={mimeType:"",niceType:""};var o=l.hasClass("confluence-embedded-image");var s=j.parent().is("a");var r=l.attr("data-has-thumbnail")==="true";if(o){p.mimeType="image/png"}else{p.mimeType=l.attr("data-mime-type");p.niceType=l.attr("data-nice-type")!=="null"?l.attr("data-nice-type"):"generic file"}var q=!s?g():"";var t=(!o&&r)?h(p):"";if(q||t){var n=e.ViewFileMacro.Templates.overlayEmbeddedFile();j.append(d(n).append(q).append(t));if(t){j.addClass("has-comment-overlay")}}};var k=function(n){n=parseInt(n,10);n=d.isNumeric(n)?n:0;return n>9?"9+":n+""};var g=function(){var n="",o=l.attr("data-linked-resource-container-id"),q=l.attr("data-linked-resource-id");if(o&&q){var r=l.attr("data-unresolved-comment-count");var p=k(r);if(p!=="0"){n=e.ViewFileMacro.Templates.overlayEmbeddedFileCommentCount({commentCountRep:p})}}return n};var h=function(n){return e.ViewFileMacro.Templates.overlayEmbeddedFileFileTypeDesc({fileType:a.getFileTypeTextFromNiceType(n.niceType),iconClass:b.Confluence.FileTypesUtils.getAUIIconFromMime(n.mimeType)})};return{render:m,$el:j}};return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-resources', location = '/js/vfm.js' */
require(["jquery","ajs","vfm/components/embedded-file-view"],function(c,a,b){a.toInit(function(){c(".confluence-embedded-file.unknown-attachment").on("click",function(d){d.preventDefault()});c(".confluence-embedded-file-wrapper").each(function(){var d=new b({el:this});d.render()})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/models.js' */
(function(b,a){a.Watch=Backbone.Model.extend({saveSettings:function(d,e){this.trigger("request");var c=this;return AJS.safe.ajax({url:d,type:"POST",dataType:"json",data:e}).done(function(){c.trigger("sync",c)}).fail(function(){c.trigger("error")})},saveWatchPage:function(d){var c=AJS.contextPath()+"/users/"+(d?"add":"remove")+"pagenotificationajax.action";this.set("watchingPage",d);return this.saveSettings(c,{pageId:this.get("pageId")})},saveWatchBlogs:function(d){var c=AJS.contextPath()+"/users/"+(d?"add":"remove")+"spacenotificationajax.action";this.set("watchingBlogs",d);return this.saveSettings(c,{spaceKey:this.get("spaceKey"),contentType:"blogpost"})},saveWatchSpace:function(d){var c=AJS.contextPath()+"/users/"+(d?"add":"remove")+"spacenotificationajax.action";this.set("watchingSpace",d);return this.saveSettings(c,{spaceKey:this.get("spaceKey")})}})}(AJS.$,CW=window.CW||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/views.js' */
(function(b,a){a.WatchView=Backbone.View.extend({events:{"change #cw-watch-page":"changeWatchPage","change #cw-watch-blogs":"changeWatchBlogs","change #cw-watch-space":"changeWatchSpace"},initialize:function(){_.bindAll(this,"render","initTooltips","changeWatchPage","changeWatchBlogs","changeWatchSpace","togglePageEnabledState","toggleBlogsEnabledState","startLoading","stopLoading","setTitle");this.model.on("sync change:watchingSpace",this.togglePageEnabledState,this);this.model.on("change:watchingSpace",this.toggleBlogsEnabledState,this);this.model.on("request",this.startLoading,this);this.model.on("sync",this.setTitle,this);this.model.on("sync",this.stopLoading,this)},render:function(){this.$el.html(Confluence.Watch.Templates.dialogBody(this.model.toJSON()));this.initTooltips();this.setTitle(this.model);return this},initTooltips:function(){this.$(".cw-tooltip").tooltip({gravity:"e",offset:5,delayIn:0});this.togglePageEnabledState(this.model);this.toggleBlogsEnabledState(this.model)},changeWatchPage:function(d){var c=b(d.target).is(":checked");this.model.saveWatchPage(c)},changeWatchBlogs:function(d){var c=b(d.target).is(":checked");this.model.saveWatchBlogs(c)},changeWatchSpace:function(d){var c=b(d.target).is(":checked");this.model.saveWatchSpace(c)},togglePageEnabledState:function(c){var d=c.get("watchingPage");var f=c.get("watchingSpace");this.$("#cw-watch-page").prop("disabled",f);this.$("#cw-watch-page").prop("checked",d||f);var e=f?"You will receive updates for this page because you are watching this space.":"";this.$(".cw-tooltip-watch-page").attr("original-title",e)},toggleBlogsEnabledState:function(c){var f=c.get("watchingBlogs");var e=c.get("watchingSpace");this.$("#cw-watch-blogs").prop("disabled",e);this.$("#cw-watch-blogs").prop("checked",f||e);var d=e?"You are subscribed to all blog posts because you are watching this space.":"";this.$(".cw-tooltip-watch-blogs").attr("original-title",d)},startLoading:function(){this.$(".cw-status").addClass("loading")},stopLoading:function(){this.$(".cw-status").removeClass("loading")},setTitle:function(){var d=this.model.get("watchingPage");var h=this.model.get("watchingBlogs");var f=this.model.get("watchingSpace");var c=this.model.get("isBlogPost");function g(){if(f){return{title:"You are watching this space",description:"Receiving email updates for all content in this space.",}}if(d&&c&&h){return{title:"You are watching this blog post",description:"Receiving email updates about changes to this blog post and all new blog posts in this space.",}}if(d&&c){return{title:"You are watching this blog post",description:"Receiving email updates about changes to this blog post.",}}if(d){return{title:"You are watching this page",description:"Receiving email updates about changes to this page.",}}if(c&&h){return{title:"You are watching for new blog posts",description:"Receiving email updates for new blog posts in this space.",}}if(c){return{title:"You are not watching this blog",description:"Start watching to receive email updates about changes to this blog.",}}return{title:"You are not watching this page",description:"Start watching to receive email updates about changes to this page.",}}var e=g();this.$(".cw-title").text(e.title);this.$(".cw-title-description").text(e.description)}})}(AJS.$,CW=window.CW||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/watch.js' */
(function(e,a){AJS.toInit(function(){var f=e("#watch-content-button");if(!f.length){return}var m=b(f);var i=AJS.Meta.get("page-id");var j=AJS.Meta.get("space-key");var h=AJS.Meta.get("space-name");_.extend(m,{pageId:i,spaceKey:j,spaceName:h});c(f,m);var l=new a.Watch(m);var k=new a.WatchView({model:l});AJS.InlineDialog(f,"confluence-watch",function(o,n,p){k.setElement(o);k.render();p()},{width:325,offsetX:-180,cacheContent:false,hideDelay:null,hideCallback:function(){e(".tipsy").hide()}});l.on("change:watchingPage change:watchingBlogs change:watchingSpace",function(n){c(f,n.toJSON())});a.registerAnalytics(l);d(l);var g=false;e(document).on("keyup",function(){g=false});window.CW_watchPage=function(){if(g){return}g=true;var p=l.get("watchingSpace");var o=l.get("watchingPage");if(p){e("body, #splitter-content").animate({scrollTop:0},300,function(){f.click();setTimeout(function(){e(".cw-tooltip-watch-page").tipsy("show")},50)})}else{var q=!o;l.saveWatchPage(q);var n=q?"You started watching this page.":"You stopped watching this page.";a.Notification.notify("success",n)}}});function c(g,j){var h=j.watchingPage;var f=j.isBlogPost&&j.watchingBlogs;var i=j.watchingSpace;if(h||f||i){g.find(".aui-icon").removeClass("aui-iconfont-unwatch").addClass("aui-iconfont-watch")}else{g.find(".aui-icon").removeClass("aui-iconfont-watch").addClass("aui-iconfont-unwatch")}}function d(f){f.on("change:watchingPage",function(g,i){var h=i?"watchpage.pageoperation":"unwatchpage.pageoperation";AJS.trigger(h)})}function b(h){var i=h.prop("search");var g=/[?&;]*(.*?)=([^&;]*)/g;var f;var j={};if(i){while(f=g.exec(i)){j[f[1]]=decodeURIComponent(f[2]).replace(/\+/g," ")}}_.each(j,function(l,k){if(l=="true"){j[k]=true}else{if(l=="false"){j[k]=false}}});return j}}(AJS.$,CW=window.CW||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/watch-analytics.js' */
var CW=CW||{};CW.registerAnalytics=function(a){a.on("change:watchingPage",function(b,d){var c=d?"watch-page":"unwatch-page";AJS.trigger("analytics",{name:c})});a.on("change:watchingBlogs",function(b,d){var c=d?"watch-blogs":"unwatch-blogs";AJS.trigger("analytics",{name:c})});a.on("change:watchingSpace",function(b,d){var c=d?"watch-space":"unwatch-space";AJS.trigger("analytics",{name:c})})};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/notification.js' */
(function(b,a){b(function(){var c="cw-notification-container";var d=b("<div></div>",{id:c});b("body").append(d);a.Notification={notify:function(e,f,h){AJS.messages[e]("#"+c,{body:f,closeable:true,insert:"prepend"});var g=b(".aui-message",d).first();if(!h){h=5000}else{h*=1000}setTimeout(function(){g.fadeOut("fast",function(){g.closeMessage();g=null})},h)}}})}(AJS.$,CW=window.CW||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'templates/watch.soy' */
// This file was automatically generated from watch.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Watch == 'undefined') { Confluence.Watch = {}; }
if (typeof Confluence.Watch.Templates == 'undefined') { Confluence.Watch.Templates = {}; }


Confluence.Watch.Templates.dialogBody = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="cw-status"><h2 class="cw-title"></h2><p class="cw-title-description"></p></div><form class="aui cw-dialog"><div class="cw-tooltip cw-tooltip-watch-page"><div class="checkbox"><input class="checkbox" type="checkbox" id="cw-watch-page" ', (opt_data.watchingPage) ? 'checked' : '', '><label for="cw-watch-page">', (opt_data.isBlogPost) ? soy.$$escapeHtml("Watch blog post") : soy.$$escapeHtml("Watch page"), '</label></div></div>', (opt_data.isBlogPost) ? '<div class="cw-tooltip cw-tooltip-watch-blogs"><div class="checkbox"><input class="checkbox" type="checkbox" id="cw-watch-blogs" ' + ((opt_data.watchingBlogs) ? 'checked' : '') + '><label for="cw-watch-blogs">' + soy.$$escapeHtml("Watch for new blog posts in this space") + '</label></div></div>' : '', '<div class="checkbox"><input class="checkbox" type="checkbox" id="cw-watch-space" ', (opt_data.watchingSpace) ? 'checked' : '', '><label for="cw-watch-space">', soy.$$escapeHtml("Watch all content in this space"), '</label></div></form>', (opt_data.isAdmin) ? '<div class="cw-manage-watchers-wrapper"><button class="aui-button aui-button-link cw-manage-watchers">' + soy.$$escapeHtml("Manage Watchers") + '</button></div>' : '');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.view-source:view-source-menu-resources', location = 'com/atlassian/confluence/plugins/viewsource/js/viewsource.js' */
AJS.toInit(function(a){a("#action-view-source-link").click(function(a){window.open(this.href,(this.id+"-popupwindow").replace(/-/g,"_"),"width=800, height=600, scrollbars, resizable");a.preventDefault();return!1})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.view-storage-format:view-storage-menu-resources', location = 'com/atlassian/confluence/plugins/viewstorage/js/viewstorage.js' */
AJS.toInit(function(a){a(".view-storage-link, .view-storage-link a").click(function(a){window.open(this.href,(this.id+"-popupwindow").replace(/-/g,"_"),"width=800, height=600, scrollbars, resizable");a.preventDefault();return!1})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/doctheme-utils.js' */
Confluence.DocThemeUtils=Confluence.DocThemeUtils||(function(f){var e;function c(){return(a().length)?true:false}function a(){if(!e){e=f("#splitter-content")}return e}function g(i){var h=f(i);f(i).appendTo(c()?a():f("body"));return h}function b(){return c()?a().scrollTop():f(document).scrollTop()}function d(){return c()?a().scrollLeft():f(document).scrollLeft()}return{isDocTheme:c,appendAbsolutePositionedElement:g,getMainContentScrollTop:b,getMainContentScrollLeft:d,getDocThemeContentElement:a}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/scrolling-inline-dialog.js' */
Confluence.ScrollingInlineDialog=function(a,d,c,b){var g=Confluence.DocThemeUtils.getDocThemeContentElement();var e=Confluence.DocThemeUtils.isDocTheme();b=b||{};if(!b.container&&e){b.container=g}var f=function(k,s,J,z){var v;var L="auto";var G;var p=-7;var q;var w;var u=e?g.width():AJS.$(window).width();var K=s.target.position();K.top+=e?g.scrollTop():0;K.left+=e?g.scrollLeft():0;var i=s.target.outerWidth();var m=K.left+i/2;var C=e?g.scrollTop()+AJS.$(window).height()-AJS.$("#footer").outerHeight():(window.pageYOffset||document.documentElement.scrollTop)+AJS.$(window).height();var n=10;var o=20;G=K.top+s.target.outerHeight()+z.offsetY;var H=k.find(".arrow").outerWidth();var j=k.outerWidth();var D=s.target.outerWidth();if(z.centerOnHighlight){if(j>D){v=K.left-(j-D)/2;q=m-v-H/2}else{v=K.left+z.offsetX;q=(j-H)/2}}else{v=K.left+z.offsetX;if(j>D){q=m-v-H/2}else{q=(j-H)/2}}q=(q<0)?0:q;var h=(e)?(K.top-g.scrollTop()):(K.top-(window.pageYOffset||document.documentElement.scrollTop));var A=z.maxHeight||0;var t=k.height();var r=h>Math.max(t,A);var l=(G+k.height())<C;w=(!l&&r)||z.onTop;z.onTop=w;var y=u-(v+j+n);if(w){G=K.top-t-8;p=t}if(w===false&&l===false){var x=(G+t)-C;var E=e?g.scrollTop()+x+AJS.$("#footer").outerHeight():(window.pageYOffset||document.documentElement.scrollTop)+x+o;var F=e?g:AJS.$("html, body");F.stop().animate({scrollTop:E},500)}if(z.isRelativeToMouse){if(y<0){L=n;v="auto";q=J.x-(AJS.$(window).width()-z.width)}else{v=J.x-20;q=J.x-v}}else{if(y<0){L=n;v="auto";var I=u-L;var B=I-j;q=m-B-H/2}}return{displayAbove:w,popupCss:{left:v,right:L,top:G},arrowCss:{position:"absolute",left:q,right:"auto",top:p}}};if(!b.calculatePositions){b.calculatePositions=f}return AJS.InlineDialog.call(this,a,d,c,b)};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/highlight-panel.js' */
Confluence.HighlightAction=(function(f){var d={};var c;var b={MAINCONTENT_AND_COMMENT:function(o){return Confluence.HighlightAction.RangeHelper.isSelectionInsideContent(f(".wiki-content"),o)},MAINCONTENT_ONLY:function(o){c=c||f(".wiki-content").first();return Confluence.HighlightAction.RangeHelper.isSelectionInsideContent(c,o)},COMMENT_ONLY:function(o){return Confluence.HighlightAction.RangeHelper.isSelectionInsideContent(f(".comment-content"),o)}};function a(p,q){var o={onClick:function(){},shouldDisplay:b.MAINCONTENT_AND_COMMENT};d[p]=f.extend(o,q)}function l(o){var p=d[o];if(!p){p=function(){AJS.logError("The button with key "+o+" doesn't have a registered handler")}}return p}function e(p){var o=Confluence.getContextPath()+"/rest/highlighting/1.0/insert-storage-fragment";return f.ajax({type:"POST",contentType:"application/json",url:o,data:JSON.stringify(p)})}function g(o){var p=Confluence.getContextPath()+"/rest/highlighting/1.0/insert-storage-column-table";return f.ajax({type:"POST",contentType:"application/json",url:p,data:JSON.stringify(o)})}function k(q,p,r){var o=i(r);o.tableColumnIndex=p;o.cellModifications=q;return o}function h(o,q){var p=i(q);p.xmlModification=o[0].xmlInsertion;return p}function j(o,q){var p=i(q);p.xmlModification=o;return p}function m(){if(window.getSelection){window.getSelection().empty&&window.getSelection().empty();window.getSelection().removeAllRanges&&window.getSelection().removeAllRanges()}else{window.document.selection&&window.document.selection.empty()}}function i(p){var o={};o.pageId=p.pageId;o.selectedText=p.selectedText;o.index=p.index;o.numMatches=p.numMatches;o.lastFetchTime=n();return o}function n(){return f("meta[name='confluence-request-time']").attr("content")}return{registerButtonHandler:a,getButtonHandler:l,insertContentAtSelectionEnd:e,insertContentsInTableColumnCells:g,createTableInsertionBean:k,createInsertionBean:h,createXMLModificationBean:j,clearTextSelection:m,WORKING_AREA:b}})(AJS.$);Confluence.HighlightAction.RangeHelper=(function(h){function i(n){return{area:c(n),text:j(n),html:l(n),containingElement:d(n),range:n}}function c(o){var p=Confluence.DocThemeUtils.getMainContentScrollTop();var q=Confluence.DocThemeUtils.getMainContentScrollLeft();var u=o.getClientRects();if(!u.length&&o.parentElement()){var v=h(o.parentElement());var n=v.offset();u=[{top:n.top-((Confluence.DocThemeUtils.isDocTheme())?0:p),left:n.left-((Confluence.DocThemeUtils.isDocTheme())?0:q),bottom:n.top+v.height(),right:n.left+v.width()}]}var x=g(o,u);var s=function(C,B){var A={};A.top=C.top;A.left=C.left+q;A.bottom=B.bottom;if(C.left>=B.right){A.right=C.right}else{A.right=B.right}A.right=A.right+q;A.top=A.top+p;A.bottom=A.bottom+p;A.width=A.right-A.left;A.height=A.bottom-A.top;return A};var r=function(B){var A={};A.width=B.right-B.left;A.height=B.bottom-B.top;A.left=B.left+q;A.right=B.right+q;A.top=B.top+p;A.bottom=B.bottom+p;return A};var z=function(A){if(Confluence.DocThemeUtils.isDocTheme()){var B=Confluence.DocThemeUtils.getDocThemeContentElement().offset();A.left=A.left-B.left;A.right=A.right-B.left;A.top=A.top-B.top;A.bottom=A.bottom-B.top}return A};var y=z(s(x.first,x.last));var t=z(r(x.first));if(Confluence.HighlightAction.debug){var w=h("<div>").attr("id","highlight-actions-debug-helper");Confluence.DocThemeUtils.appendAbsolutePositionedElement(w).css(h.extend({position:"absolute",outline:"1px solid red"},y))}return{first:t,average:y}}function j(n){return(n.text!=undefined)?n.text:n.toString()}function l(n){return(n.cloneContents)?h("<div>").append(n.cloneContents()).html():n.htmlText}function d(o){if(o.commonAncestorContainer){var n=o.commonAncestorContainer;if(n.nodeType==3){return n.parentNode}return n}else{if(o.parentElement){return o.parentElement()}}}function g(p,o){var n={};n.first=o[0];n.last=o[o.length-1];if(p.endOffset!=="undefined"){if(p.endOffset==0){n.last=o[o.length-2]}}return n}function e(){if(window.getSelection&&window.getSelection().isCollapsed){return false}if(document.selection&&(document.selection.type=="None"||document.selection.createRange().htmlText=="")){return false}var q;if(window.getSelection){var n=window.getSelection();q=n.getRangeAt(n.rangeCount-1)}else{if(document.selection){q=document.selection.createRange()}}if(/^\s*$/.test(j(q))){var o=l(q);if(!o){return false}var p=o.toLowerCase().indexOf("<img ")!=-1;if(!p){return false}}if(!k(h(".wiki-content"),q)){return false}return q}function k(n,q){var o=d(q);var p=function(){var r=false;h.each(n,function(s,t){if(t===o||h.contains(t,o)){r=true;return false}});return r};return p()}function b(q,p){var o=f(q);var n=j(m(q,p));var s=j(p);var r;if(h.browser.msie){r=a(o.replace(/\u0020/g,"\u00a0"),s.replace(/\u0020/g,"\u00a0"))}else{r=a(o,s)}return{pageId:AJS.Meta.get("page-id"),selectedText:s,index:h.inArray(n.length-s.length,r),numMatches:r.length}}function f(n){if(document.createRange){return n.text()}else{range=document.body.createTextRange();range.moveToElementText(n.get(0));return range.text}}function m(p,o){var n;if(document.createRange){n=document.createRange();n.setStart(p.get(0),0);n.setEnd(o.endContainer,o.originalEndOffset)}else{n=document.body.createTextRange();n.moveToElementText(p.get(0));n.setEndPoint("EndToEnd",o)}return n}function a(q,o){var r=0;var p=-1;var n=[];while((p=q.indexOf(o,r))>-1){n.push(p);r=p+1}return n}return{getRangeOption:i,getUserSelectionRange:e,getSelectionRects:c,getSelectionText:j,getSelectionHTML:l,getContainingElement:d,getFirstAndLastSelectionRect:g,isSelectionInsideContent:k,computeSearchTextObject:b}})(AJS.$);AJS.toInit(function(f){var i=f(".wiki-content").first();var g={ELEMENT_NODE:1,TEXT_NODE:3};var k={IMAGE:"IMG"};var a=f("<div>").attr("id","action-dialog-target");var d;var j="selection-action-panel";var b;var e;function p(){var s=Confluence.getContextPath()+"/rest/highlighting/1.0/panel-items";var r=AJS.Meta.get("page-id");if(r!=undefined){s=s+"?pageId="+r}f.get(s,function(t){if(t.length){m(t);h()}})}var o=function(){if(f.browser.msie&&f.browser.version<=8){var r=document.getElementsByTagName("head")[0];var s=document.createElement("style");s.type="text/css";s.styleSheet.cssText=" #inline-dialog-"+j+" :before, #inline-dialog-"+j+" :after { content:none !important;}";r.appendChild(s);setTimeout(function(){r.removeChild(s)},0)}};function m(w){var z=c();var r=29;var A=false;var C=w.length*r;var B=Confluence.HighlightPanel.Templates.panelContent({webItems:w});var y=false;var t=function(E,D,F){if(!y){E.append(B);E.find(".aui-button").tooltip({gravity:"s"});l(E.parent());E.find("button").click(function(I){var G=f(this).attr("data-key");var J=Confluence.HighlightAction.getButtonHandler(G);A=true;d.hide();var H=Confluence.HighlightAction.RangeHelper.getRangeOption(b);if(f.trim(H.text)!==""){H.searchText=Confluence.HighlightAction.RangeHelper.computeSearchTextObject(i,b)}J.onClick(H)})}F();if(!y){setTimeout(o,0)}y=true;return false};var x=function(D){var E=false;D.find("button").each(function(F){var H=f(this);var G=H.attr("data-key");var J=Confluence.HighlightAction.getButtonHandler(G);var I=J.shouldDisplay(b);H.css("display",I?"inline-block":"none");E=E||I});if(!E){d.hide()}else{D.find(".contents").width("auto")}};var s=function(){Confluence.HighlightAction.Analytics.sendAnalyticsForOpeningHighlightOptionPanel();x(this.popup);z.bindHideEvents();a.show()};var v=function(){z.unbindHideEvents();a.hide()};var u={centerOnHighlight:true,onTop:true,fadeTime:0,width:C,persistent:true,initCallback:s,hideCallback:v};d=Confluence.ScrollingInlineDialog(a,j,t,u)}function l(r){r.children().attr("unselectable","on").on("selectstart",false)}function h(){var r;var s=0;var t=1000;f(document).mouseup(function(v){var u=f(v.target);if(u.closest(".aui-inline-dialog").length!==0){return}setTimeout(function(){clearTimeout(r);var w=t;if(f(d[0]).is(":visible")){w=s}r=setTimeout(function(){n()},w)},s)});AJS.bind("quickedit.success",function(){d.hide()})}function n(){b=Confluence.HighlightAction.RangeHelper.getUserSelectionRange();var r=function(u){return f.trim(u.toString())!==""};b.originalEndOffset=b.endOffset;if(!b||!r(b)){d.hide();return}var t=Confluence.HighlightAction.RangeHelper.getSelectionRects(b);if(!t){return}var s=q(t);if(s||!f(d[0]).is(":visible")){f(d[0]).hide();d.show()}}function c(){var u=function(){w();t()};var x=function(){r();z()};var s=false;var y=j+".inline-dialog-check";var w=function(){if(!s){f("body").bind("click."+y,function(B){var A=f(B.target);if(A.closest("#inline-dialog-"+j+" .contents").length===0){if(!b){d.hide()}}});s=true}};var r=function(){if(s){f("body").unbind("click."+y)}s=false};var v=function(A){if(A.keyCode===27){d.hide()}};var t=function(){f(document).on("keydown",v)};var z=function(){f(document).off("keydown",v)};return{bindHideEvents:u,unbindHideEvents:x}}function q(s){Confluence.DocThemeUtils.appendAbsolutePositionedElement(a);var r=false;if(!e||s.first.top!=e.first.top||s.first.height!=e.first.height||s.first.left!=e.first.left||s.first.width!=e.first.width){a.css({top:s.first.top,height:s.first.height,left:s.first.left,width:s.first.width});e=s;r=true}return r}p()});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/quote-in-comment.js' */
AJS.toInit(function(f){var a=true;var h=false;var d="com.atlassian.confluence.plugins.confluence-highlight-actions:quote-comment";function b(l){var k=l.getBody().createTextRange();k.moveToElementText(l.getBody());k.collapse(false);k.select()}function e(){var k=40;if(Confluence.DocThemeUtils.isDocTheme()){var l=Confluence.DocThemeUtils.getDocThemeContentElement();var m=l.scrollTop()-f("#header").height()+f("#rte-toolbar").offset().top;l.scrollTop(m-k)}else{var m=f("#rte-toolbar").offset().top;f(document).scrollTop(m-k)}}function j(l,m){var n="<p><br/></p>";if(f.browser.msie&&!h){b(l);n="<p></p>"}var k="<blockquote><p>"+m.html+"</p></blockquote>"+n;l.execCommand("mceInsertContent",false,k);h=false}function i(k){Confluence.HighlightAction.clearTextSelection();setTimeout(function(){var l=AJS&&AJS.Rte&&AJS.Rte.getEditor&&AJS.Rte.getEditor();if(l){Confluence.HighlightAction.Analytics.sendAnalyticsForQuoteInComment();e();j(l,k)}else{Confluence.HighlightAction.Analytics.sendAnalyticsForQuoteInComment(a);h=true;var m=function(){j(AJS.Rte.getEditor(),k);AJS.unbind("quickedit.visible",m)};AJS.bind("quickedit.visible",m);c(g(k.containingElement))}},0)}function g(k){var l=f(k).closest("div.comment");return l}function c(k){if(!k.length>0){f(".quick-comment-prompt").click()}else{k.find(".comment-actions .action-reply-comment").click()}}Confluence&&Confluence.HighlightAction&&Confluence.HighlightAction.registerButtonHandler(d,{onClick:i,shouldDisplay:Confluence.HighlightAction.WORKING_AREA.MAINCONTENT_AND_COMMENT})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/highlight-analytics.js' */
Confluence.HighlightAction.Analytics=(function(c){var b="confluence.highlight.actions.open";var e="confluence.quote.in.comment.insert";var g="confluence.quote.in.comment.append";function d(h,i){AJS.trigger("analytics",{name:h,data:i})}function a(){d(b)}function f(h){if(h){d(e)}else{d(g)}}return{sendAnalyticsForOpeningHighlightOptionPanel:a,sendAnalyticsForQuoteInComment:f}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/soy/templates.soy' */
// This file was automatically generated from templates.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.HighlightPanel == 'undefined') { Confluence.HighlightPanel = {}; }
if (typeof Confluence.HighlightPanel.Templates == 'undefined') { Confluence.HighlightPanel.Templates = {}; }


Confluence.HighlightPanel.Templates.panelContent = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var webItemList3 = opt_data.webItems;
  var webItemListLen3 = webItemList3.length;
  for (var webItemIndex3 = 0; webItemIndex3 < webItemListLen3; webItemIndex3++) {
    var webItemData3 = webItemList3[webItemIndex3];
    output.append('<button data-key="', soy.$$escapeHtml(webItemData3.key), '" class="aui-button aui-button-compact aui-button-subtle" title="', soy.$$escapeHtml(webItemData3.label), '"><span class="aui-icon aui-icon-small ', soy.$$escapeHtml(webItemData3.styleClass), '"/></button>');
  }
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:soy-resources', location = 'soy/sidebar.soy' */
// This file was automatically generated from sidebar.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Sidebar == 'undefined') { Confluence.Templates.Sidebar = {}; }


Confluence.Templates.Sidebar.headerStyles = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.sidebarWidth) ? '<style>.ia-fixed-sidebar, .ia-splitter-left {width: ' + soy.$$escapeHtml(opt_data.sidebarWidth) + 'px;}.theme-default .ia-splitter #main {margin-left: ' + soy.$$escapeHtml(opt_data.sidebarWidth) + 'px;}.ia-fixed-sidebar {visibility: hidden;}</style>' : '');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.sidebar = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="acs-side-bar ia-scrollable-section"><div class="acs-side-bar-space-info tipsy-enabled" data-configure-tooltip="', soy.$$escapeHtml("Edit space details"), '"><div class="avatar"><div class="space-logo ', (false == true) ? 'project-shortcut-dialog-trigger' : '', '" data-key="', soy.$$escapeHtml(opt_data.space.key), '" data-name="', soy.$$escapeHtml(opt_data.space.name), '" data-entity-type="confluence.space"><div class="avatar-img-container"><div class="avatar-img-wrapper"><a href="', soy.$$escapeHtml(opt_data.space.homeUrl), '" title="', soy.$$escapeHtml(opt_data.space.name), '"><img class="avatar-img" src="', soy.$$escapeHtml(opt_data.space.logoUrl), '" alt="', soy.$$escapeHtml(opt_data.space.name), '"></a></div></div></div></div><div class="name"><a href="', soy.$$escapeHtml(opt_data.space.homeUrl), '" title="', soy.$$escapeHtml(opt_data.space.name), '">', soy.$$escapeHtml(opt_data.space.name), '</a></div><div class="flyout-handle icon"></div></div><div class="acs-side-bar-content"><div class="acs-nav-wrapper"><div class="acs-nav" data-has-create-permission="', soy.$$escapeHtml(opt_data.hasCreatePermission), '" data-quick-links-state="', soy.$$escapeHtml(opt_data.quickLinksState), '" data-nav-type="', soy.$$escapeHtml(opt_data.navType), '">');
  Confluence.Templates.Sidebar.renderLinks(opt_data, output);
  output.append('</div></div>');
  if (opt_data.contextualNav) {
    Confluence.Templates.Sidebar.contextualNav(opt_data, output);
  }
  output.append('</div><div class="hidden"><a href="', soy.$$escapeHtml(opt_data.space.browseSpaceUrl), '" id="space-pages-link"></a><script type="text/x-template" title="logo-config-content"><h2>', soy.$$escapeHtml("Space Details"), '</h2><div class="personal-space-logo-hint">', AJS.format("Your profile picture is used as the logo for your personal space. \x3ca href\x3d\x22{0}\x22 target\x3d\x22_blank\x22\x3eChange your profile picture\x3c/a\x3e.","/wiki" + '/users/profile/editmyprofilepicture.action'), '</div><\/script></div></div>');
  Confluence.Templates.Sidebar.renderSpaceToolsSection({advancedLinks: opt_data.advancedLinks, hasConfigurePermission: opt_data.hasConfigurePermission, currentlyViewed: opt_data.collectorToHighlight == 'spacebar-advanced'}, output);
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.renderLinks = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="acs-nav-sections">');
  if (opt_data.mainLinks.length) {
    Confluence.Templates.Sidebar.renderLinksSection({links: opt_data.mainLinks, sectionClass: 'main-links-section', collectorToHighlight: opt_data.collectorToHighlight}, output);
  }
  if (opt_data.quickLinksState != 'hide') {
    output.append('<div class="quick-links-wrapper">');
    if (opt_data.quickLinks.length) {
      output.append('<h5 class="ia-quick-links-header-title">', soy.$$escapeHtml("Space shortcuts"), '</h5>');
      Confluence.Templates.Sidebar.renderLinksSection({links: opt_data.quickLinks, sectionClass: 'quick-links-section tipsy-enabled', collectorToHighlight: null}, output);
    } else if (opt_data.hasConfigurePermission) {
      output.append('<h5 class="ia-quick-links-header-title">', soy.$$escapeHtml("Space shortcuts"), '</h5><p class="tip">', AJS.format("Here you can add shortcut links to the most important content for your team or project. \x3ca href\x3d\x22{0}\x22 class\x3d\x22{1}\x22\x3eConfigure sidebar\x3c/a\x3e.",'','configure-sidebar'), '</p>');
    }
    output.append('</div>');
  }
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.renderLinksSection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.links.length) {
    output.append('<div class="', soy.$$escapeHtml(opt_data.sectionClass), ' ', (opt_data.highlightSection) ? ' current-section' : '', '"><ul class="acs-nav-list">');
    var linkList103 = opt_data.links;
    var linkListLen103 = linkList103.length;
    for (var linkIndex103 = 0; linkIndex103 < linkListLen103; linkIndex103++) {
      var linkData103 = linkList103[linkIndex103];
      output.append('<li class="acs-nav-item ', soy.$$escapeHtml(linkData103.styleClass), (opt_data.collectorToHighlight && linkData103.collectorKey == opt_data.collectorToHighlight) ? ' current-item' : '', '"', (linkData103.collectorKey) ? 'data-collector-key="' + soy.$$escapeHtml(linkData103.collectorKey) + '"' : '', '><a class="acs-nav-item-link tipsy-enabled" href="', soy.$$escapeHtml(linkData103.url), '" data-collapsed-tooltip="', soy.$$escapeHtml(linkData103.tooltip), '"><span class="icon"></span><span class="acs-nav-item-label">', soy.$$escapeHtml(linkData103.title), '</span></a></li>');
    }
    output.append('</ul></div>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.contextualNav = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ia-secondary-container tipsy-enabled" data-tree-type="', (opt_data.forBlogs) ? 'blogs' : (opt_data.forSettings) ? 'settings' : soy.$$escapeHtml(opt_data.navType), '">');
  if (opt_data.forBlogs) {
    output.append('<div class="ia-secondary-header"><h5 class="ia-secondary-header-title blog"><span class="icon"></span><span class="label">', soy.$$escapeHtml("Blog"), '</span></h5></div><div class="ia-secondary-content">');
    Confluence.Templates.Sidebar.pagetreeList({pagetree: opt_data.contextualNav}, output);
    output.append('</div>');
  } else if (opt_data.forSettings) {
    output.append('<div class="ia-secondary-header"><h5 class="ia-secondary-header-title settings"><span class="label">', soy.$$escapeHtml("Advanced"), '</span></h5></div><div class="ia-secondary-content">');
    Confluence.Templates.Sidebar.pagetreeList({pagetree: opt_data.contextualNav}, output);
    output.append('</div>');
  } else if (opt_data.navType == 'page-tree') {
    output.append('<div class="ia-secondary-header"><h5 class="ia-secondary-header-title page-tree"><span class="icon"></span><span class="label">', soy.$$escapeHtml("Page tree"), '</span></h5></div>', (opt_data.pageTreeEmpty) ? '<p class="tip">' + AJS.format("Get started by adding some pages to this space. \x3ca href\x3d\x22{0}\x22 class\x3d\x22{1}\x22\x3eCreate page\x3c/a\x3e.","/wiki" + '/pages/createpage.action?spaceKey=' + opt_data.space.key,'page-tree-create-child-page-link') + '</p>' : '<div class="ia-secondary-content">' + opt_data.contextualNav + '</div>');
  } else {
    Confluence.Templates.Sidebar.Pages.renderPageContextualNav({pageContextualNav: opt_data.contextualNav, hasCreatePermission: opt_data.hasCreatePermission}, output);
  }
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.pagetreeList = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ul class="', (opt_data.isSubtree) ? 'ia-subpagetree' : 'ia-pagetree', '">');
  var itemList177 = opt_data.pagetree;
  var itemListLen177 = itemList177.length;
  for (var itemIndex177 = 0; itemIndex177 < itemListLen177; itemIndex177++) {
    var itemData177 = itemList177[itemIndex177];
    Confluence.Templates.Sidebar.pagetreeItem(itemData177, output);
  }
  output.append('</ul>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.throbber = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="content-container"><div class="throbber-container"><div class="throbber"><div class="spinner"></div><span>', soy.$$escapeHtml("Loading..."), '</span></div></div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.treeThrobber = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('\t<ul class="ia-subpagetree"><li class="acs-tree-item leaf"><span class="node-title">', soy.$$escapeHtml("Loading..."), '</span></li></ul>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.pagetreeItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li class="acs-tree-item', (opt_data.hasChildren) ? (opt_data.children.length) ? ' opened' : ' closed' : ' leaf', (opt_data.groupType) ? ' grouping' : '', (opt_data.active) ? ' current-item' : '', '"', (opt_data.pageId) ? ' data-page-id="' + soy.$$escapeHtml(opt_data.pageId) + '"' : '', (opt_data.groupType) ? ' data-group-type="' + soy.$$escapeHtml(opt_data.groupType) + '" data-group-value="' + soy.$$escapeHtml(opt_data.groupValue) + '"' : '', '>', (! opt_data.groupType) ? '<a href="' + soy.$$escapeHtml(opt_data.url) + '">' : '', '<span class="icon ', (opt_data.hasChildren) ? (opt_data.children.length) ? 'icon-section-opened' : 'icon-section-closed' : '', '"></span><span class="node-title navigation-pseudo-link">', soy.$$escapeHtml(opt_data.title), '</span>', (! opt_data.groupType) ? '</a>' : '');
  if (opt_data.children && opt_data.children.length > 0) {
    Confluence.Templates.Sidebar.pagetreeList({pagetree: opt_data.children, isSubtree: true}, output);
  }
  output.append('</li>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.renderSpaceToolsSection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="space-tools-section"><div id="space-tools-menu-additional-items" class="hidden">');
  var linkList247 = opt_data.advancedLinks;
  var linkListLen247 = linkList247.length;
  for (var linkIndex247 = 0; linkIndex247 < linkListLen247; linkIndex247++) {
    var linkData247 = linkList247[linkIndex247];
    output.append('<div data-label="', soy.$$escapeHtml(linkData247.title), '" data-class="', soy.$$escapeHtml(linkData247.styleClass), '" data-href="', soy.$$escapeHtml(linkData247.url), '">', soy.$$escapeHtml(linkData247.title), '</div>');
  }
  output.append((opt_data.hasConfigurePermission) ? '<div data-label="' + soy.$$escapeHtml("Configure sidebar") + '" data-class="configure-sidebar" data-href="">' + soy.$$escapeHtml("Configure sidebar") + '</div>' : '', '</div><div id="space-tools-dd-dummy"></div><a id="space-tools-menu-trigger" class="aui-button aui-button-subtle aui-dropdown2-trigger tipsy-enabled', (opt_data.currentlyViewed) ? ' current-item' : '', '" aria-owns="space-tools-dd-dummy"><span class="aui-icon aui-icon-small aui-iconfont-configure">Configure</span><span class="label">', soy.$$escapeHtml("Space tools"), '</span></a><a class="expand-collapse-trigger"></a></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.spaceToolsMenu = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="space-tools-menu"><div class="aui-dropdown2-section"><ul class="space-tools-navigation">');
  var linkList274 = opt_data.spaceToolLinks;
  var linkListLen274 = linkList274.length;
  for (var linkIndex274 = 0; linkIndex274 < linkListLen274; linkIndex274++) {
    var linkData274 = linkList274[linkIndex274];
    output.append('<li><a href="', soy.$$escapeHtml(linkData274.href), '" title="', soy.$$escapeHtml(linkData274.label), '">', soy.$$escapeHtml(linkData274.label), '</a></li>');
  }
  output.append('</ul></div>');
  if (opt_data.spaceLinks.length > 0) {
    output.append('<div class="aui-dropdown2-section"><ul class="space-operations">');
    var linkList287 = opt_data.spaceLinks;
    var linkListLen287 = linkList287.length;
    for (var linkIndex287 = 0; linkIndex287 < linkListLen287; linkIndex287++) {
      var linkData287 = linkList287[linkIndex287];
      output.append('<li><a class="', soy.$$escapeHtml(linkData287.className), '" href="', soy.$$escapeHtml(linkData287.href), '" title="', soy.$$escapeHtml(linkData287.label), '">', soy.$$escapeHtml(linkData287.label), '</a></li>');
    }
    output.append('</ul></div>');
  }
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.configure = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="acs-nav-sections"><table id="acs-nav-list-main" class="acs-nav-list"></table><div class="acs-nav-list-quick-section', (opt_data.quickLinksState == 'hide') ? ' hidden-section' : '', '"><div class="quick-links-header"><h5>', soy.$$escapeHtml("Space shortcuts"), '</h5><a href="#" class="aui-icon aui-icon-small toggle-link" data-tooltip="', soy.$$escapeHtml("Hide/Show space shortcuts"), '"/></div><table id="acs-nav-list-quick" class="acs-nav-list"></table><p class="tip">', soy.$$escapeHtml("Click \x22Add link\x22 to add links to the sidebar."), '</p><a class="acs-add-link" href="#"><span class="icon"></span><span class="label">', soy.$$escapeHtml("Add link"), '</span></a></div><h5>', soy.$$escapeHtml("Navigation display options"), '</h5><form class="aui"><div class="radio"><input class="radio acs-nav-type" type="radio" name="nav-type" value="pages" id="nav-type-pages" ', (! opt_data.pageTree) ? 'checked' : '', '><label for="nav-type-pages">', soy.$$escapeHtml("Child pages"), '</label></div><div class="radio"><input class="radio acs-nav-type" type="radio" name="nav-type" value="page-tree" id="nav-type-tree" ', (opt_data.pageTree) ? 'checked' : '', '><label for="nav-type-tree">', soy.$$escapeHtml("Page tree"), '</label></div></form><button class="aui-style aui-button acs-done-link">', soy.$$escapeHtml("Done"), '</button></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:soy-resources', location = 'soy/sidebar-pages.soy' */
// This file was automatically generated from sidebar-pages.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Sidebar == 'undefined') { Confluence.Templates.Sidebar = {}; }
if (typeof Confluence.Templates.Sidebar.Pages == 'undefined') { Confluence.Templates.Sidebar.Pages = {}; }


Confluence.Templates.Sidebar.Pages.renderPageContextualNav = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ia-secondary-header"><h5 class="ia-secondary-header-title pages"><span class="label">', soy.$$escapeHtml("Child pages"), '</span></h5></div><div class="ia-secondary-parent-content">');
  Confluence.Templates.Sidebar.Pages.parentPage({parentPage: opt_data.pageContextualNav.parentPage}, output);
  output.append('</div><div class="ia-secondary-current-content">');
  Confluence.Templates.Sidebar.Pages.currentPage({currentPage: opt_data.pageContextualNav.currentPage}, output);
  output.append('</div><div class="ia-secondary-content">');
  Confluence.Templates.Sidebar.Pages.childPages({children: opt_data.pageContextualNav, createPermission: opt_data.hasCreatePermission}, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.Pages.childPages = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="contextual-nav-child-pages">');
  if (opt_data.children.initialChildPages.length) {
    output.append('<ul class="children">');
    Confluence.Templates.Sidebar.Pages.renderChildren({children: opt_data.children.initialChildPages}, output);
    output.append('</ul>');
    if (opt_data.children.remainingChildPages.length) {
      output.append('<ul class="more-children">');
      Confluence.Templates.Sidebar.Pages.renderChildren({children: opt_data.children.remainingChildPages}, output);
      output.append('</ul><a class="more-children-link" href=""><span class="icon"></span><span class="label">', soy.$$escapeHtml(AJS.format("{0} more child pages",opt_data.children.remainingChildPages.length)), '</span></a>');
    }
  }
  output.append((opt_data.createPermission && opt_data.children.createLink) ? '<a class="create-child-page-link" href="' + soy.$$escapeHtml(opt_data.children.createLink) + '"><span class="icon"></span><span class="label">' + soy.$$escapeHtml("Create child page") + '</span></a>' : '', '</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.Pages.currentPage = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.currentPage) ? '<ul class="ia-secondary-currentPage-title wiki' + ((opt_data.currentPage.active) ? ' current-item' : '') + '"><li><span class="icon"></span><span class="label">' + soy.$$escapeHtml(opt_data.currentPage.title) + '</span></li></ul>' : '');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.Pages.parentPage = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.parentPage) ? '<ul class="parent ia-secondary-header-title wiki' + ((opt_data.parentPage.active) ? ' current-item' : '') + '"><li class="parent-item"><a class="parent-item-link" href="' + soy.$$escapeHtml(opt_data.parentPage.url) + '" title="' + soy.$$escapeHtml(opt_data.parentPage.title) + '"><span class="icon"></span><span class="label">' + soy.$$escapeHtml(opt_data.parentPage.title) + '</span></a></li></ul>' : '');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Sidebar.Pages.renderChildren = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var childList65 = opt_data.children;
  var childListLen65 = childList65.length;
  for (var childIndex65 = 0; childIndex65 < childListLen65; childIndex65++) {
    var childData65 = childList65[childIndex65];
    output.append('<li class="child-item" data-page-id="', soy.$$escapeHtml(childData65.pageId), '"><span class="icon"></span><a href="', soy.$$escapeHtml(childData65.url), '" title="', soy.$$escapeHtml(childData65.title), '"><span class="label">', soy.$$escapeHtml(childData65.title), '</span></a></li>');
  }
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.editor-loader:background-loading-editor', location = 'jscripts/editor-loader.js' */
AJS.Confluence.EditorLoader = (function($) {

    var DEFAULT_LOADING_TIMEOUT = 12000; // ms

    var editorLoadingStatus = {
        loaded: false,
        inProgress: false,
        errorMessage: null,
        
        started: function() {
            this.inProgress = true;
        },
        
        successful: function() {
            this.inProgress = false;
            this.loaded = true;
        },
        
        error: function(message) {
            this.inProgress = false;
            this.errorMessage = message;
        },
        
        /**
         * Should we attempt to load or is there a load already in progress, already completed 
         * or previously failed?
         * 
         * @return true if loading should be attempted.
         */
        allowLoad : function() {
            return !this.loaded
                && !this.inProgress
                && this.errorMessage == null;
        }
    };
    
    /**
     * An object that tracks events that should change the state of the editor which occur
     * when the editor is deactivated. These changes will apply to the editor when it is
     * next activated.
     */
    var stateChangeEventListener = {
        _listening: false,
            
        _queuedHandlers: [],
            
        _watchHandler: function() {
            Confluence.Editor.UI.toggleWatchPage(false);            
        },
        
        _unwatchHandler: function() {
            Confluence.Editor.UI.toggleWatchPage(true);
        },
        
        _createQueueAdder: function(handler) {
            return function() {
                if (stateChangeEventListener._listening) {
                    stateChangeEventListener._queuedHandlers.push(handler);
                }
            }  
        },
            
        /**
         * bind to all the relevant events. 
         */
        bind: function() {
            AJS.bind("watchpage.pageoperation", this._createQueueAdder(this._watchHandler));
            AJS.bind("unwatchpage.pageoperation", this._createQueueAdder(this._unwatchHandler));
        },
        
        /**
         * @param listening if true then listen and queue handlers (i.e. the editor is deactivated). If false
         * then ignore any events. The editor is active and will handle them itself.
         */
        setListening: function(listening) {
            this._listening = listening;
        },
        
        /**
         * Apply and then clear all the queued handlers. 
         */
        applyHandlers: function() {
            var handler = this._queuedHandlers.pop();
            while (handler) {
                handler();
                handler = this._queuedHandlers.pop();
            }
        }
    };
    
    stateChangeEventListener.setListening(true);
    stateChangeEventListener.bind();
    
    /** An array of functions to be called when an Editor load completes successfully. */
    var onLoadSuccess = [];

    /** An array of functions to be called when an Editor load fails. */
    var onLoadError = [];
            
    /**
     * Check if a _load should be allowed and make the appropriate callback if it shouldn't.
     * 
     * @return true if load is guarded (shouldn't be allowed); false if a load should be permitted.
     */
    var loadGuard = function(successCallback, errorCallback) {
        if (!editorLoadingStatus.allowLoad()) {
            if (editorLoadingStatus.errorMessage) {
                if (errorCallback) {
                    errorCallback(editorLoadingStatus.errorMessage);
                } else {
                    AJS.trigger('analyticsEvent', { name: 'rte.editor-loader.previous-load-failed' });
                    AJS.log("EditorLoader: loadGuard - previous load failed.");
                }
            } else if (editorLoadingStatus.inProgress) {
                // record the other callbacks for later (if they were supplied)
                if (successCallback) {
                    onLoadSuccess.push(successCallback);                        
                }
                
                if (errorCallback) {
                    onLoadError.push(errorCallback);
                }
            } else if (editorLoadingStatus.loaded) {
                if (successCallback) {
                    //So that the promise has time to have callbacks registered.
                    setTimeout(successCallback, 0);
                } else {
                    AJS.trigger('analyticsEvent', { name: 'rte.editor-loader.editor-already-loaded' });
                    AJS.log("EditorLoader: loadGuard - editor is already loaded.");
                }
            }
            
            return true;
        }            
    };
    
    /**
     * @return an object with two properties; jsUrls is an array of Javascript URLs and cssTags is an array of HTML formatted CSS
     * Link elements (including conditional comments)
     */
    var getResources = function() {
        // TODO conditionals are basically comments - is inserting comment nodes into the DOM 
        // a valid way to load them. Test on IE, etc
        var resourceTags = AJS.Meta.get("editor.loader.resources");
        var $resources = $(resourceTags);
        var jsUrls = [];
        var cssTags = []; // link elements and comments containing conditional CSS
        
        // Separate the resources into CSS tags and JS urls.
        for (var i = 0; i < $resources.length; i++) {
            var resource = $resources[i];
            // nodeType 8 is Node.COMMENT_NODE
            if (resource.nodeType == 8 && resource.nodeValue.indexOf("text/css") != -1) {
                cssTags.push(resource);
            } else if (resource.nodeType == 1) {
                if (resource.nodeName == "LINK") {
                    cssTags.push(resource);
                } else if (resource.nodeName == "SCRIPT" && resource.getAttribute("type") == "text/javascript") {
                    jsUrls.push(resource.src);
                }
            }
        }
        
        return {
            "jsUrls": jsUrls,
            "cssTags" : cssTags
        };
    };
    
    /**
     * Derive the base url for the Editor based on the array of urls provided.
     * 
     * @param urls an array of Javascript urls for the Editor
     * @return the baseUrl.
     */
    var getBaseUrl = function(urls) {
        var baseUrl = null;
        for (var i = 0; i < urls.length && baseUrl == null; i++) {
            var url = urls[i];
            // try to use part of a URL that would indicate this is definitely the editor scripts (but which couldn't be
            // confused with context part, etc)
            if (/editor,/.test(url)) {
                baseUrl = url;
            }
        }
        
        return baseUrl;
    };
    
    /**
     * Load the HTML and resources required by the Editor. (Note that the Editor is not necessarily initialised unless
     * the provided callback does it.)
     * 
     * @param successCallback a function called if the Editor is successfully loaded.
     * @param errorCallback a function called if there is a failure while loading the Editor (takes a message string parameter).
     */
    var loadEditor = function(successCallback, errorCallback) {

        if (loadGuard(successCallback, errorCallback)) {
            return;
        }

        editorLoadingStatus.started();
        
        if (successCallback) {
            onLoadSuccess.push(successCallback);                        
        }
        
        if (errorCallback) {
            onLoadError.push(errorCallback);
        }            
        
        var resources = getResources();
            
        AJS.Meta.set("rte.src.url", getBaseUrl(resources.jsUrls));

        // An object providing tracking of the various AJAX requests involved in loading
        var loadTracker = {
            countDown: resources.jsUrls.length + 1, // the number of scripts to be loaded plus the template
            errorMessages: [],
            success: function() {
                this.loaded();
            },
            
            error: function(message) {
                this.errorMessages.push(message);
                this.loaded();
            },
            
            loaded: function() {
                this.countDown--;
                if (this.countDown == 0) {
                    if (this.errorMessages.length == 0) {
                        editorLoadingStatus.successful();
                        
                        $.each(onLoadSuccess, function(i, func) {
                            func();
                        });                                            
                    } else {
                        var joinedMessages = this.errorMessages.join();
                        editorLoadingStatus.error(joinedMessages);   

                        $.each(onLoadError, function(i, func) {
                            func(joinedMessages);
                        });                                        
                    }

                    // can clear callback arrays - we don't need them any more
                    onLoadSuccess = null;
                    onLoadError = null;                        
                }
            } 
        };
        
        var loadCallback = function() {
            loadTracker.success();
        };
        
        var loadErrorCallback = function(jqXHR, textStatus, errorThrown) {
            var message = "";
            if (textStatus) {
                message = textStatus;
            }
            
            if (errorThrown) {
                message = message + ": " + errorThrown;                    
            }
            
            loadTracker.error(message);
        };
        
        var originalTimeout = $.ajaxSetup().timeout;
        $.ajaxSetup({ timeout: AJS.Confluence.EditorLoader.loadingTimeout });
        
        // Create a hidden container to load the Editor DOM into
        var $preloadContainer = AJS.Confluence.EditorLoader.getPreloadContainer();
        $("body").append($preloadContainer);

        // Load the Editor template if on a page
        if (AJS.Meta.get("page-id")) {
            var onLoadCallback = function(response, status, xhr) {
                if (status == "success" || status == "notmodified") {
                    //Put markup into dom
                    $preloadContainer.append(response);
                    // move any metadata into the head (which is the only legal place for meta tags).
                    var metadataTemplate = AJS.renderTemplate("dynamic-editor-metadata");
                    $("head").append(metadataTemplate);
                    AJS.populateParameters();
                    loadCallback();
                } else {
                    AJS.trigger('analyticsEvent', { name: 'rte.editor-loader.editor-action-xhr-failed' });
                    loadErrorCallback(xhr, "Error loading the Editor template: " + xhr.status + " - " + xhr.statusText, null);
                }
            };

            this.getEditorPreloadMarkup().done(onLoadCallback);
        } else {
            loadCallback();
        }
        
        AJS.debug("EditorLoader: " + resources.jsUrls.length + " scripts to be loaded.");

        var originalCacheSetting = $.ajaxSetup().cache;
        $.ajaxSetup({ cache: true });

        dispatchScriptLoader(loadCallback, loadErrorCallback, resources);

        $.ajaxSetup({
            cache: originalCacheSetting,
            timeout: originalTimeout 
        });
        
        // TODO don't append the CSS until the Editor is actually activated to avoid risk of style clashes
        $.each(resources.cssTags, function(index, tag) {
            $("head").append(tag);
        });
    };

    /**
     * Load the scripts for the editor. If the dark feature is enabled it uses a new approach where we fetch the scripts
     * via ajax and then eval them in order when they all returned. Otherwise we fall back to the old approach where we
     * would fetch the scripts via ajax when there is only 1, otherwise append them via scripts tags to the DOM.
     *
     * @param loadCallback
     * @param loadErrorCallback
     * @param resources
     */
    var dispatchScriptLoader = function(loadCallback, loadErrorCallback, resources) {

        if (AJS.DarkFeatures.isEnabled("editor.async-script-loading")) {
            AJS.trigger('analyticsEvent', { name: 'rte.editor-loader.dispatch-script-loader.eval' });
            loadScripts(resources.jsUrls, loadCallback, loadErrorCallback);
        } else {

            AJS.trigger('analyticsEvent', { name: 'rte.editor-loader.dispatch-script-loader.script-tag' });

            var ajaxSettings = {
                dataType: "script",
                error: loadErrorCallback,
                success: loadCallback
            };

            if ($.browser.msie) {
                // without this setting window.execScript would be used which makes debugging
                // very difficult.
                ajaxSettings.crossDomain = true;
            }

            if (resources.jsUrls.length > 1) {
                var $head = $("head");
                $.each(resources.jsUrls, function(index, jsUrl) {
                    var $script = $("<script></script>");
                    $script.attr("src", jsUrl);
                    $head.append($script);
                    setTimeout(loadCallback); // calling loadCallback in the same 'event' seems to cause weird problems in Firefox on Linux.
                });
            } else {
                // To avoid CONFDEV-8038 prefer this mechanism for the normal (single batched resource) case.
                $.each(resources.jsUrls, function(index, jsUrl) {
                    ajaxSettings.url = jsUrl;
                    $.ajax(ajaxSettings);
                });
            }
        }
    };

    /**
     * Loads a list of scripts via XHR asynchronously but evaluates them in the order passed into the function.
     * Solves CONFDEV-7632 and CONF-27796 at the same time.
     *
     */
    var loadScripts = function(urls, loadCallback, loadErrorCallback) {
        AJS.debug('EditorLoader: Loading scripts via dark feature "editor.async-script-loading"', urls, urls.length);
        var countdown = urls.length;
        var scripts = [];
        var ajaxSettings = {
            dataType: "text",
            timeout: 30 * 1000
        };

        $.each(urls, function(index, url) {
            $.ajax(url, ajaxSettings)
                .done(function (data) {
                    scripts[index] = data;
                })
                .always(function () {
                    countdown--;

                    if (countdown === 0) {
                        evalScripts(scripts);
                    }
                })
                .done(loadCallback)
                .error(loadErrorCallback);
        });

        function evalScripts(scripts) {
            $.each(scripts, function(i, script) {
                try {
                    $.globalEval(script);
                } catch (e) {
                    AJS.log("Error evaling script in editor-loader", urls[i], e);
                }
            });
        }
    };

    var cachedGetPreloadContentDeferred;

    return {

        /**
         * @returns the jQuery wrapped Element that contains the editor DOM, or create and return a new hidden div
         * if there is none found
         */
        getPreloadContainer : function () {
            var $container = $("#editor-preload-container");
            if (!$container.length) {
                $container = $("<div id=\"editor-preload-container\" style=\"display: none;\"></div>");
            }
            return $container;
        },

        getEditorPreloadMarkup: function (){
            if (cachedGetPreloadContentDeferred) {
                return cachedGetPreloadContentDeferred;
            }
            var url = Confluence.getContextPath() + "/plugins/editor-loader/editor.action";
            // cache deferred.
            cachedGetPreloadContentDeferred = $.get(url, {
                pageId: AJS.Data.get("page-id"),
                spaceKey: AJS.Data.get("space-key"),
                atl_after_login_redirect: window.location.pathname // the URL that an anonymous user will be redirect to after logging in
            });
            return cachedGetPreloadContentDeferred;
        },

        /**
         * Check if the resources need to load the editor have been already loaded in the page.
         */
        resourcesLoaded: function (){ return editorLoadingStatus.loaded },

        /** The maximum wait in milliseconds for the Editor to load */
        loadingTimeout: DEFAULT_LOADING_TIMEOUT,
        
        /**
         * @returns true if there is already an active editor; otherwise false
         */
        isEditorActive: function() {
           var $container = $("#editor-preload-container");
           return $container.length && $container.is(":visible");
        },
        
        /**
         * Load the Editor into a hidden Element on the page if it hasn't already been loaded. 
         * The Editor is not initialised, its HTML, CSS and Javascript is simply loaded ready for
         * later activation.
         */
        load: loadEditor,

        /**
         * @return the immediate parent of the currently active editor as a jQuery wrapped Element. If an editor is not
         * currently active then null will be returned.
         */
        getEditorForm: function() {
            if (this.isEditorActive()) {
                return $(tinymce.activeEditor.getContainer()).closest('form');
            } else {
                return null;
            }
        }        
    };

})(AJS.$);


} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.editor-loader:background-loading-editor', location = 'jscripts/block-and-buffer-keys.js' */
// TODO Move this to core Confluence and modify it to also take a TinyMCE Editor as a block object
// This could then also be used by the find and replace plugin (which is currently duplicating
// most of this).
AJS.Confluence.BlockAndBuffer = {
        
        _cancelKeyboardFunction: function(e) {
            e.preventDefault();
            e.stopPropagation();
        },
        
        /* Handle UTF-16 surrogate pair character codes */
        _surrogatePairFixedFromCharCode: function(code) {  
            if (code > 0xFFFF) {  
                code -= 0x10000;  
                return String.fromCharCode(0xD800 + (code >> 10), 0xDC00 +  (code & 0x3FF));  
            }  
            else {  
                return String.fromCharCode(code);  
            }  
        },
        
        /*
         * Buffer any character codes being typed and also prevent
         * the event that is instigating them. 
         */
        _bufferTextFunction: function(e, buffer) {
            AJS.Confluence.BlockAndBuffer._cancelKeyboardFunction(e);
            
            var keyCode = e.which;
            // IE8 doesn't have charCode for keypress event
            if (!keyCode) {
                keyCode = e.charCode ? e.charCode : e.keyCode;
            }

            // Firefox and Opera wrongly raise keypress for control characters
            if (keyCode !== 13 && keyCode < 48) {
                return;
            }

            buffer.push(keyCode);
        },
        
        
        /**
         * @return the buffered text the user may have entered
         */
        _unblock: function($jq, keycodeBuffer, blockFunc) {
            
            $jq.unbind("keypress", blockFunc);
            
            var bufferedText = "";
            for (var i = 0; i < keycodeBuffer.length; i++) {
                bufferedText += AJS.Confluence.BlockAndBuffer._surrogatePairFixedFromCharCode(keycodeBuffer[i]);
            }

            return bufferedText;
        },
        
        /* -------------------------- Public API -------------------------- */
        
        /**
         * Block keys on the supplied jQuery DOM object. 
         * 
         * @param $jq jQuery wrapped Element.
         * @return the zero argument unblock function you should run when you want to cancel the block. This will return
         * the buffer as a String.
         */
        block: function($jq) {
            var keycodeBuffer = [];

            var bufferText = function(e) {
                AJS.Confluence.BlockAndBuffer._bufferTextFunction(e, keycodeBuffer);
                e.preventDefault();
            };
            
            $jq.keypress(bufferText);
            
            return function() {
                return AJS.Confluence.BlockAndBuffer._unblock($jq, keycodeBuffer, bufferText);
            };
        }
};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/linkbrowser-editor-adapter.js' */
AJS.$(function(){if(!$("body").hasClass("with-space-sidebar")){return}Confluence=Confluence||{};Confluence.Editor=Confluence.Editor||{};AJS.Rte=AJS.Rte||{};AJS.Rte.BookmarkManager=AJS.Rte.BookmarkManager||{};AJS.Rte.BookmarkManager.storeBookmark=AJS.$.noop;AJS.Rte.BookmarkManager.restoreBookmark=AJS.$.noop});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-ia.js' */
(function(a){Confluence.Sidebar={};AJS.toInit(function(g){var s=g(window);var F=g(document);var w=Math.min(285,s.width()/3);var G=285;var E=150;var t=55;var q=AJS.contextPath();var m=q.length?q:"/";var p=AJS.Meta.get("space-key");var c=AJS.Meta.get("use-keyboard-shortcuts")?" "+"(\u2009[\u2009)":"";Confluence.Sidebar.collapseTooltip="Collapse sidebar"+c;Confluence.Sidebar.expandTooltip="Expand sidebar"+c;var f=g(".ia-splitter").children();var H=g(".ia-splitter-left");if(H.length<1){return}var n=g(".acs-side-bar");var y=H.find(".ia-fixed-sidebar");var d=g("<div>",{"class":"ia-splitter-handle tipsy-enabled","data-tooltip":Confluence.Sidebar.collapseTooltip}).appendTo(y);g("<div>",{"class":"ia-splitter-handle-highlight"}).appendTo(d);var h=g(".ia-secondary-container");var A=g("#footer, #studio-footer");Confluence.Sidebar.throbberDiv=i;h.length&&D(h.attr("data-tree-type"));s.scroll(x);s.resize(x);s.on("touchend",x);F.ready(x);AJS.bind("confluence.header-resized",x);g("#header-precursor img").load(x);Confluence.Sidebar.applyTooltip=u;l();AJS.bind("sidebar.exit-configure-mode",l);var j=g.cookie("confluence-sidebar.width")||w,e=j>E?j:t;k(e);v();y.css("visibility","visible");x();o();Confluence.Sidebar.createFlyouts(n);AJS.trigger("sidebar.finished-loading");s.one("pagetree-children-loaded",function(){var J=g(".plugin_pagetree_current");if(J.length){var K=J.offset();if(K.top>n.height()/2){n.scrollTop(K.top-n.height()/3)}if(K.left>n.width()/2){n.scrollLeft(K.left-n.width()/2)}}});AJS.bind("sidebar.enter-configure-mode",function(){b();I();y.addClass("configure-mode")});AJS.bind("sidebar.exit-configure-mode",function(){b();z();y.removeClass("configure-mode")});function b(){AJS.trigger("sidebar.hide-overlays")}function u(J,L){var K={live:true,gravity:"w",title:"data-tooltip",delayIn:500,delayOut:0,offset:5};g(J).tooltip(L?g.extend(K,L):K)}function l(){g(".acs-side-bar .quick-links-section").attr("data-collapsed-tooltip","Space shortcuts");g("#space-tools-menu-trigger").attr("data-collapsed-tooltip","Space tools");if(h.attr("data-tree-type")=="pages"){g(".acs-side-bar .ia-secondary-container").attr("data-collapsed-tooltip","Child pages");u(".collapsed .ia-secondary-container.tipsy-enabled",{title:"data-collapsed-tooltip"})}u(".expand-collapse-trigger");u(".ia-splitter-handle.tipsy-enabled");u(".collapsed .quick-links-section.tipsy-enabled, .collapsed .acs-nav-item > a.tipsy-enabled, .collapsed #space-tools-menu-trigger.tipsy-enabled",{title:"data-collapsed-tooltip"});u(".configure-mode .acs-side-bar-space-info.tipsy-enabled",{title:"data-configure-tooltip"});n.on("mousedown click scroll",b);g(window).on("scroll resize",b);AJS.bind("sidebar.hide-overlays",K);AJS.bind("sidebar.disable-tooltip",L);AJS.bind("sidebar.enable-all-tooltips",J);function L(P,O){var M=g(O).closest(".tipsy-enabled");if(M.size()!=1){return}M.removeClass("tipsy-enabled").addClass("tipsy-disabled").attr("title","");var N=M.data("tipsy");if(N){N.hoverState="out"}K()}function J(){g(".tipsy-disabled").removeClass("tipsy-disabled").addClass("tipsy-enabled")}function K(){g(".tipsy").remove()}}function v(){F.on("mousewheel",".ia-scrollable-section",function(M,N){var L=g(this).scrollTop();var K=g(this).get(0).scrollHeight-g(this).innerHeight()-1;if((N>0&&L<=0)||(N<0&&L>=K)){M.preventDefault()}else{if(g.browser.msie){M.preventDefault();var J=30;g(this).scrollTop(L+(-1*N*J))}}M.stopPropagation()})}function i(){var K=g(Confluence.Templates.Sidebar.throbber()),L=K.find(".spinner"),J=Raphael.spinner(L[0],10,"#666");K.find(".throbber").bind("remove",function(){J()});return K}function D(J){if(J==="blogs"){C(n,r)}else{if(J==="pages"){Confluence.Sidebar.Pages.installHandlers(n)}}}function r(M,N){var L=M.attr("data-group-type");var J=M.attr("data-group-value");var K=q+"/rest/ia/1.0/pagetree/blog/subtree";g.get(K,{spaceKey:p,groupType:L,groupValue:J}).done(N)}function C(J,K){J.delegate(".acs-tree-item > .icon, .acs-tree-item > .node-title","click",function(){var P=g(this);var O=P.parent();var L=O.find("> .icon");if(O.hasClass("opened")){O.children("ul").hide();O.removeClass("opened").addClass("closed");L.removeClass("icon-section-opened").addClass("icon-section-closed")}else{if(O.hasClass("closed")){var M=O.children("ul");if(M.length){M.show()}else{var N=g(Confluence.Templates.Sidebar.treeThrobber());O.append(N);K(O,function(R){var Q=g(Confluence.Templates.Sidebar.pagetreeList({pagetree:R,isSubtree:true}));N.remove();Q.appendTo(O)})}O.removeClass("closed").addClass("opened");L.removeClass("icon-section-closed").addClass("icon-section-opened")}}})}function x(){var J=H.offset().top,K=s.scrollTop(),L=s.scrollLeft();if(K<0){return}if(K>(F.height()-s.height())){return}if(L<0){return}if(L>(F.width()-s.width())){return}y.css({top:Math.max(J-K,0)+"px",left:Math.min(L*-1,0)+"px"})}function B(){A.css("margin-left",y.outerWidth()+"px")}function o(){var M=g("body");var K=false;var L=false;var N=function(O){L=true;O.preventDefault();f.one("selectstart",function(Q){Q.preventDefault()});var P=function(){if(y.width()<=E){k(t)}else{w=y.width()}L=false;M.off("mousemove.ia-splitter")};K=false;M.on("mousemove.ia-splitter",function(Q){if(Confluence.Sidebar.Configure.mode&&Q.pageX<G){return}k(Q.pageX);K=true});M.one("mouseup mouseleave",P)};d.on("mousedown.ia-splitter",function(O){N(O);b()}).click(function(){if(!K){J()}else{K=false}});Confluence.Sidebar.toggle=J;function J(){if(Confluence.Sidebar.Configure.mode){return}var O=y.width();if(O>t){if(O<=E){w=G;k(w)}else{w=O;k(t)}}else{k(w)}}}function k(J){J=Math.max(J,t);g.cookie("confluence-sidebar.width",J,{path:m,expires:365});if(J<=E){y.addClass("collapsed");d.attr("data-tooltip",Confluence.Sidebar.expandTooltip);AJS.trigger("sidebar.collapsed")}else{if(y.hasClass("collapsed")){y.removeClass("collapsed");d.attr("data-tooltip",Confluence.Sidebar.collapseTooltip);AJS.trigger("sidebar.expanded")}}y.width(J);f.eq(1).css("margin-left",J+"px");B()}function I(){if(y.width()<G){Confluence.Sidebar.widthBeforeConfiguring=y.width();k(G)}}function z(){if(Confluence.Sidebar.widthBeforeConfiguring){k(Confluence.Sidebar.widthBeforeConfiguring);Confluence.Sidebar.widthBeforeConfiguring=undefined}}})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/configurable-nav.js' */
(function(a){AJS.Confluence.ConfigurableNav=AJS.RestfulTable.extend({initialize:function(c){var b=this;b.options=a.extend(true,c,{model:AJS.RestfulTable.EntryModel,Collection:Backbone.Collection.extend({url:c.resources.self,model:AJS.RestfulTable.EntryModel}),columns:[{id:"title"}]});b._events=b._events||AJS.RestfulTable.Events;b._event=b._event||AJS.RestfulTable.Events;b.classNames=AJS.RestfulTable.ClassNames;b.dataKeys=AJS.RestfulTable.DataKeys;b.$table=c.$el.addClass(this.classNames.RESTFUL_TABLE).addClass(this.classNames.ALLOW_HOVER).addClass("aui").addClass(b.classNames.LOADING);b.$table.prepend('<colgroup><col span="1" class="aui-restfultable-order"><col span="1"><col span="1" class="aui-restfultable-operations"></colgroup>');b.$tbody=a("<tbody/>");b._models=this._createCollection();b._rowClass=AJS.Confluence.ConfigurableNav.Row;b.editRows=[];b.enableReordering();b._models.bind("remove",function(d){a.each(b.getRows(),function(e,f){if(f.model===d){if(f.hasFocus()&&b._createRow){b._createRow.trigger(b._event.FOCUS)}b.removeRow(f)}})});a.get(b.options.resources.all,function(d){b.populate(d)});Confluence.Sidebar.applyTooltip(".hide-link, .show-link, .delete-link, .toggle-link",{gravity:"ne"})},enableReordering:function(){var b=this;this.$tbody.sortable({handle:"."+this.classNames.DRAG_HANDLE,helper:function(f,c){var d=c.clone(true).addClass(b.classNames.MOVEABLE);d.children().each(function(e){a(this).width(c.children().eq(e).width())});return d},start:function(c,d){var e=d.placeholder.find("td");d.item.addClass(b.classNames.MOVEABLE).children().each(function(f){a(this).width(e.eq(f).width())});d.placeholder.html('<td colspan="'+b.getColumnCount()+'">&nbsp;</td>').css("visibility","visible");b.getRowFromElement(d.item[0]).trigger(b._event.MODAL)},stop:function(c,d){if(jQuery(d.item[0]).is(":visible")){d.item.removeClass(b.classNames.MOVEABLE).children().attr("style","");d.placeholder.removeClass(b.classNames.ROW);b.getRowFromElement(d.item[0]).trigger(b._event.MODELESS)}},update:function(e,g){var c,d,f={},h=b.getRowFromElement(g.item[0]);if(h){if(b.options.reverseOrder){d=g.item.next();if(!d.length){f.position="First"}else{c=b.getRowFromElement(d).model;f.after=c.url()}}else{d=g.item.prev();if(!d.length){f.position="First"}else{c=b.getRowFromElement(d).model;f.after=c.url()}}f.spaceKey=AJS.Meta.get("space-key");a.ajax({url:h.model.url()+"/move",type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify(f),complete:function(){h.hideLoading()},success:function(i){AJS.triggerEvtForInst(b._event.REORDER_SUCCESS,b,[i])},error:function(j){var i=a.parseJSON(j.responseText||j.data);AJS.triggerEvtForInst(b._event.SERVER_ERROR,b,[i,j])}});h.showLoading()}},axis:"y",delay:0,containment:"document",cursor:"move",scroll:true,zIndex:8000});this.$tbody.bind("selectstart mousedown",function(c){return !a(c.target).is("."+b.classNames.DRAG_HANDLE)})}});AJS.Confluence.ConfigurableNav.ReadView=AJS.RestfulTable.CustomReadView.extend({render:function(b){return _.template('<span class="acs-nav-item-link" title="<%=title%>"><span class="icon"></span><span class="acs-nav-item-label"><%=title%></span></span>',{title:AJS.escapeHtml(b.title)})}});AJS.Confluence.ConfigurableNav.Row=AJS.RestfulTable.Row.extend({render:function(){var b=this,d=this.model.toJSON(),e=a("<td class='aui-restfultable-operations' />").append(this.renderOperations(d.canHide,d.hidden)),c=a('<td class="'+this.classNames.ORDER+'"/>').append(this.renderDragHandle());b._event=b._event||b._events;b.$el.attr("data-id",this.model.id);b.$el.append(c);a.each(b.columns,function(f,g){var h,k=a("<td />"),j=d[g.id];if(j){b.$el.attr("data-"+g.id,j)}h=new AJS.Confluence.ConfigurableNav.ReadView().render(d);k.append(h);b.$el.append(k)});b.$el.append(e);d.canHide&&d.hidden&&b.$el.addClass("hidden-link");b.$el.addClass(this.classNames.ROW+" "+b.classNames.READ_ONLY+" acs-nav-item "+d.styleClass);b.trigger(this._event.RENDER,this.$el,d);b.$el.trigger(this._event.CONTENT_REFRESHED,[b.$el]);return b},renderOperations:function(f,e){var c=this,b=a('<a href="#" class="aui-icon aui-icon-small"/>');if(f){function d(g){if(g.hasClass("hide-link")){g.attr("data-tooltip","Hide link")}else{g.attr("data-tooltip","Show link")}}b.addClass(e?"show-link":"hide-link").click(function(g){g.preventDefault();a.ajax({url:c.model.url()+(e?"/show":"/hide"),type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:AJS.Meta.get("space-key")})}).done(function(){b.closest(".acs-nav-item").toggleClass("hidden-link");b.toggleClass("hide-link").toggleClass("show-link");d(b)})});d(b)}else{b.addClass("delete-link tipsy-enabled").click(function(g){g.preventDefault();if(a(".acs-nav").data("quick-links-state")!="hide"){AJS.trigger("sidebar.disable-tooltip",this);c.destroy()}}).attr("data-tooltip","Remove link")}return b},destroy:function(){this.model.destroy({data:{spaceKey:AJS.Meta.get("space-key")}})}})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-pages.js' */
(function(b){var a=AJS.Meta.get("context-path");Confluence.Sidebar.Pages={installHandlers:function(d){d.find(".more-children-link").click(function(f){f.preventDefault();d.find("ul.more-children").show();b(this).hide()})},quickLinksContent:function(){return new b.Deferred().resolve(b(".acs-side-bar .quick-links-wrapper").html())},childPageCollapsedContent:function(){var e=b(".acs-side-bar .ia-secondary-header");var d=b(".acs-side-bar .ia-secondary-parent-content");var g=b(".acs-side-bar .ia-secondary-current-content");var f=b(".acs-side-bar .ia-secondary-content");return new b.Deferred().resolve(b("<div>").append(b("<div>").addClass("acs-side-bar-flyout-wiki-wrapper").append(e.clone()).append(d.clone()).append(g.clone()).append(f.clone())).html())},pageTreeCollapsedContent:function(){var d=b(".page-tree-flyout-content");if(d.length==0){return c().pipe(function(e){var f=b("<div>").addClass("acs-side-bar-flyout-wiki-wrapper").append(Confluence.Templates.Sidebar.Pages.renderPageContextualNav({pageContextualNav:e,hasCreatePermission:b(".acs-nav").data("has-create-permission")}));b("body").append(b("<div>").addClass("page-tree-flyout-content hidden").append(f.clone()));return f})}else{return new b.Deferred().resolve(d.html())}}};function c(){return b.ajax({url:a+"/rest/ia/1.0/space/childPagesContextualNav",data:{pageId:AJS.Meta.get("page-id")}})}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-links.js' */
AJS.$(function(){Confluence.Sidebar.Configure={mode:false};var b=AJS.$,m=AJS.Meta.get("context-path"),k=AJS.Meta.get("space-key"),i=b(".acs-side-bar"),q=i.find(".ia-secondary-container"),u=i.find(".project-shortcut-dialog-trigger"),c,o,j,l,g=b(".acs-nav");b.ajaxSetup({cache:false});b("body").on("click","#acs-configure-link, a.configure-sidebar",function(v){v.preventDefault();t()});function t(){AJS.trigger("sidebar-before-enter-configure-mode");l=g.data("nav-type");Confluence.Sidebar.Configure.mode=true;j=b(".acs-nav-sections .acs-nav-item.current-item").data("collector-key");c=Confluence.Sidebar.throbberDiv();c.height(b(".acs-nav-sections").height());b(".acs-nav-sections").replaceWith(c);q.hide();o=b(Confluence.Templates.Sidebar.configure({pageTree:l==="page-tree",quickLinksState:g.data("quick-links-state")})).hide();c.after(o);d(false);h();f();r();var w={};var v=function(){c.replaceWith(o);o.show()};b("#acs-nav-list-main").one(AJS.RestfulTable.Events.INITIALIZED,function(){w.main=true;w.quick&&v()});b("#acs-nav-list-quick").one(AJS.RestfulTable.Events.INITIALIZED,function(){w.quick=true;w.main&&v()});b(".acs-nav-type").change(function(x){s("nav-type",b(this).val(),function(y){q.data("tree-type",y);g.data("nav-type",y)})});b(".acs-done-link").click(function(x){x.preventDefault();b(".acs-done-link").attr("aria-disabled",true).prop("disabled",true);n()});b(".quick-links-header a").click(function(y){y.preventDefault();var x=g.data("quick-links-state")=="hide"?"show":"hide";s("quick-links-state",x,a)});AJS.$(".acs-side-bar-space-info").on("click.configurelogo",p);AJS.trigger("sidebar.enter-configure-mode")}function p(x){var w=AJS.$(".acs-side-bar-space-info > .flyout-handle");w.addClass("loading").spin();var v=WRM.require("wr!com.atlassian.confluence.plugins.confluence-space-ia:avatar-picker",function(){AJS.trigger("deferred.spaceia.open.configure.space")});v.always(function(){w.removeClass("loading").spinStop()});x.preventDefault()}function s(v,w,x){b.ajax({url:m+"/rest/ia/1.0/space/option",type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:k,option:v,value:w}),success:function(y){x(w)}})}function n(){if(l!==g.data("nav-type")){location.reload();return}c=Confluence.Sidebar.throbberDiv();c.height(o.height());o.replaceWith(c);d(true);e();q.show().css("display","");var v=function(){var x=b(Confluence.Templates.Sidebar.renderLinks({mainLinks:w.main,quickLinks:w.quick.reverse(),advancedLinks:w.advanced,hasConfigurePermission:true,collectorToHighlight:j,quickLinksState:g.data("quick-links-state")}));c.replaceWith(x);Confluence.Sidebar.Configure.mode=false;AJS.trigger("sidebar.exit-configure-mode")};var w={};b.get(m+"/rest/ia/1.0/link/main",{spaceKey:k,includeHidden:false}).done(function(x){w.main=x;w.quick&&w.advanced&&v()});b.get(m+"/rest/ia/1.0/link/quick",{spaceKey:k}).done(function(x){w.quick=x;w.main&&w.advanced&&v()});b.get(m+"/rest/ia/1.0/link/advanced",{spaceKey:k}).done(function(x){w.advanced=x;w.main&&w.quick&&v()});Confluence.Sidebar.Configure.Logo&&Confluence.Sidebar.Configure.Logo.unbind()}function h(){WRM.require("wr!com.atlassian.confluence.plugins.confluence-space-ia:link-dialog",function(){var v=new b.Deferred();b(".acs-add-link").click(function(w){v.done(function(){w.preventDefault();if(g.data("quick-links-state")!=="hide"){Confluence.Sidebar.LinkAdapter.hijackLinkBrowser();Confluence.Editor.LinkBrowser.open();b("#recentlyviewed-panel-id").click()}})}).addClass("acs-add-link-ready");if(AJS.Meta.get("space-key")){AJS.Confluence.EditorLoader.load(function(){v.resolve()},function(){AJS.log("Attempted to load editor for space ia side bar. Loading the editor failed.");v.reject()})}else{v.resolve()}})}function f(){var v=b("#acs-nav-list-quick");var x=b(".acs-nav-sections .tip").hide();var w=function(){if(Confluence.Sidebar.Configure.QuickLinks.isEmpty()){v.hide();x.show()}else{x.hide();v.show()}};AJS.bindEvt(AJS.RestfulTable.Events.INITIALIZED,w);AJS.bindEvt(AJS.RestfulTable.Events.ROW_ADDED,w);AJS.bindEvt(AJS.RestfulTable.Events.ROW_REMOVED,w)}function r(){Confluence.Sidebar.Configure.MainLinks=new AJS.Confluence.ConfigurableNav({$el:b("#acs-nav-list-main"),resources:{all:m+"/rest/ia/1.0/link/main?spaceKey="+k+"&includeHidden=true",self:m+"/rest/ia/1.0/link"}});Confluence.Sidebar.Configure.QuickLinks=new AJS.Confluence.ConfigurableNav({$el:b("#acs-nav-list-quick"),resources:{all:m+"/rest/ia/1.0/link/quick?spaceKey="+k,self:m+"/rest/ia/1.0/link"},reverseOrder:true})}function e(){Confluence.Sidebar.Configure.MainLinks.remove();Confluence.Sidebar.Configure.MainLinks.unbind();Confluence.Sidebar.Configure.QuickLinks.remove();Confluence.Sidebar.Configure.QuickLinks.unbind();b(AJS).unbind(AJS.RestfulTable.Events.INITIALIZED);b(AJS).unbind(AJS.RestfulTable.Events.ROW_ADDED);b(AJS).unbind(AJS.RestfulTable.Events.ROW_REMOVED)}function d(v){u.length&&u.toggleClass("project-shortcut-dialog-trigger",v)}function a(v){g.data("quick-links-state",v);if(v==="hide"){b(".acs-nav-list-quick-section").addClass("hidden-section")}else{b(".acs-nav-list-quick-section").removeClass("hidden-section")}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-space-tools.js' */
AJS.toInit(function(f){var a=[];var d=[];var e;var h;var b;var g=f.browser.msie&&parseInt(f.browser.version,10)<=8;f("#space-tools-web-items div").each(function(){a.push({label:f(this).data("label"),href:f(this).data("href")})});f("#space-tools-menu-additional-items div").each(function(){d.push({className:f(this).data("class"),label:f(this).data("label"),href:f(this).data("href")})});h={hideDelay:null,width:170,displayShadow:false,calculatePositions:function(i,j){var k=j.target.offset();return{popupCss:{top:k.top-i.height(),left:k.left},arrowCss:{display:"none"}}},hideCallback:function(){AJS.trigger("sidebar.enable-all-tooltips")}};e=AJS.InlineDialog(f("#space-tools-menu-trigger"),"space-tools",function(j,i,k){j.html(Confluence.Templates.Sidebar.spaceToolsMenu({spaceToolLinks:a,spaceLinks:d}));f(i).one("click",function(l){if(f("#inline-dialog-space-tools").is(":visible")){setTimeout(function(){e.hide()},0)}});AJS.trigger("sidebar.disable-tooltip",i);AJS.trigger("sidebar.spacetools-loaded");k();return false},h);e.addClass("aui-dropdown2 aui-style-default");AJS.bind("sidebar.hide-overlays",e.hide);b=f(".expand-collapse-trigger");b.click(function(i){i.preventDefault();Confluence.Sidebar.toggle()});b.attr("data-tooltip",f(".ia-fixed-sidebar").hasClass("collapsed")?Confluence.Sidebar.expandTooltip:Confluence.Sidebar.collapseTooltip);AJS.bind("sidebar.collapsed",function(){b.attr("data-tooltip",Confluence.Sidebar.expandTooltip);c()});AJS.bind("sidebar.expanded",function(){b.attr("data-tooltip",Confluence.Sidebar.collapseTooltip);c()});c();function c(){if(g){f("#space-tools-menu-trigger").toggleClass("force-redraw")}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-flyouts.js' */
(function(d){var b,c,a;Confluence.Sidebar.createFlyouts=function(h){b=g(d(".collapsed .quick-links-section"),Confluence.Sidebar.Pages.quickLinksContent,"sidebar-quick-links-flyout",{flyout:"quick-links"});var i=h.find(".ia-secondary-container");if(i.length&&i.attr("data-tree-type")=="pages"){c=g(d(".collapsed .ia-secondary-header-title.wiki"),Confluence.Sidebar.Pages.childPageCollapsedContent,"sidebar-children-flyout",{flyout:"children"})}if(i.length&&i.attr("data-tree-type")=="page-tree"){a=g(d(".collapsed .ia-secondary-header-title.page-tree"),Confluence.Sidebar.Pages.pageTreeCollapsedContent,"sidebar-page-tree-flyout",{flyout:"pagetree"})}};function g(h,k,j,m){var l=function(o,n,p){d(o).addClass("acs-side-bar-flyout ia-scrollable-section");d(o).empty().append(Confluence.Sidebar.throbberDiv());k().done(function(q){d(o).html(q)});AJS.trigger("sidebar.flyout-triggered",m);p();d(n).one("click",function(q){if(d("#inline-dialog-"+j).is(":visible")){setTimeout(function(){i.hide()},0)}});AJS.trigger("sidebar.disable-tooltip",n)};var i=AJS.InlineDialog(h,j,l,{getArrowPath:e,calculatePositions:f,useLiveEvents:true,hideDelay:null,hideCallback:function(){AJS.trigger("sidebar.enable-all-tooltips")}});AJS.bind("sidebar.hide-overlays",i.hide);return i}function f(i,l,q,h){var r=l.target.offset();var p=l.target.width();var m=l.target.height();var o={top:r.top+m/2-15,left:r.left+p+5,right:"auto"};var j=d(window);var n=20;o.maxHeight=j.height()+j.scrollTop()-o.top-n;if(d.browser.msie&&parseInt(d.browser.version,10)<=8){o.maxHeight-=40}var k={top:9,left:-7};return{displayAbove:false,popupCss:o,arrowCss:k}}function e(){return"M8,16 L0,8,8,0"}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/external/jquery.mousewheel.min.js' */
/*! Copyright (c) 2011 Brandon Aaron (http://brandonaaron.net)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Thanks to: http://adomas.org/javascript-mouse-wheel/ for some pointers.
 * Thanks to: Mathias Bank(http://www.mathias-bank.de) for a scope bug fix.
 * Thanks to: Seamus Leahy for adding deltaX and deltaY
 *
 * Version: 3.0.6
 * 
 * Requires: 1.2.2+
 */
(function(a){function d(b){var c=b||window.event,d=[].slice.call(arguments,1),e=0,f=!0,g=0,h=0;return b=a.event.fix(c),b.type="mousewheel",c.wheelDelta&&(e=c.wheelDelta/120),c.detail&&(e=-c.detail/3),h=e,c.axis!==undefined&&c.axis===c.HORIZONTAL_AXIS&&(h=0,g=-1*e),c.wheelDeltaY!==undefined&&(h=c.wheelDeltaY/120),c.wheelDeltaX!==undefined&&(g=-1*c.wheelDeltaX/120),d.unshift(b,e,g,h),(a.event.dispatch||a.event.handle).apply(this,d)}var b=["DOMMouseScroll","mousewheel"];if(a.event.fixHooks)for(var c=b.length;c;)a.event.fixHooks[b[--c]]=a.event.mouseHooks;a.event.special.mousewheel={setup:function(){if(this.addEventListener)for(var a=b.length;a;)this.addEventListener(b[--a],d,!1);else this.onmousewheel=d},teardown:function(){if(this.removeEventListener)for(var a=b.length;a;)this.removeEventListener(b[--a],d,!1);else this.onmousewheel=null}},a.fn.extend({mousewheel:function(a){return a?this.bind("mousewheel",a):this.trigger("mousewheel")},unmousewheel:function(a){return this.unbind("mousewheel",a)}})})(jQuery);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-logo.js' */
AJS.toInit(function(f){Confluence.Sidebar.Configure.Logo={};var b=f(".acs-side-bar-space-info div.name a");var h;var a;var e=function(i){f(".space-logo .avatar-img").attr("src",AJS.Meta.get("context-path")+i)};var d=function(i){b.attr("title",i).text(i)};var g=function(j,i){if(!h){h=new j({onCrop:function(l,k){f.ajax({type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:AJS.Meta.get("space-key"),spaceName:k,logoDataURI:l}),url:AJS.Meta.get("context-path")+"/rest/ia/1.0/space/setLogo",success:function(m){e(m.logoDownloadPath);d(m.name);h.hide()},error:function(m){h.setMessage("An error occurred while updating space details");h._removeSaveImageLoadingIcon()}})}});i.onDomReady()}h.show(f(".acs-side-bar-space-info div.name a").text());return false};var c=function(){var i=function(m,l,n){f(m).addClass("acs-side-bar-flyout");f(m).empty();m.html(AJS.template.load("logo-config-content"));m.unbind("mouseover mouseout");AJS.trigger("sidebar.disable-tooltip",l);n()};if(!a){a=AJS.InlineDialog(f(".acs-side-bar-space-info"),"space-logo-config",i,{getArrowPath:j,calculatePositions:k,useLiveEvents:true,hideCallback:function(){AJS.trigger("sidebar.enable-all-tooltips")},hideDelay:null,noBind:true,width:635})}function k(m,o,s,l){var t=o.target.offset();var r=o.target.width();var p=o.target.height();var q={top:t.top+p/2-15,left:t.left+r+5,right:"auto"};var n={top:9,left:-7};return{displayAbove:false,popupCss:q,arrowCss:n}}function j(){return"M8,16 L0,8,8,0"}a.show()};AJS.bind("sidebar-before-enter-configure-mode",function(){AJS.bind("deferred.spaceia.open.configure.space",function(i){if(AJS.Meta.get("space-key")=="~"+AJS.Meta.get("remote-user")){c()}else{require(["confluence-space-ia/avatar-picker/avatar-picker-dialog","confluence-space-ia/avatar-picker/fd-slider"],g)}i.preventDefault();return false})});Confluence.Sidebar.Configure.Logo.unbind=function(){f("#inline-dialog-space-logo-config .cancel").click();f(".acs-side-bar-space-info").off("click.configurelogo");AJS.unbind("deferred.spaceia.open.configure.space")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'soy/sidebar-relevant.soy' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-heuristics.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-parser.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-structure.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-tracker.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/page-mode-view.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/keyboard-mode-view.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/controller.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.macros.core:flash-autosize', location = 'javascript/flash-autosize.js' */
AJS.toInit(function(d){function e(f,a){var b;20<=a?AJS.log("unable to auto size flash - took too long to load"):(b=d([]),f.each(function(){var c=d(this),a;if(this.GetVariable){if(!c.attr("height"))if(a=this.GetVariable("height"))c.height(a);else{b=b.add(c);return}c.attr("width")||((a=this.GetVariable("width"))?c.width(a):b=b.add(c))}}),b.length&&setTimeout(function(){e(b,a+1)},100))}e(d('embed[type="application/x-shockwave-flash"]'),0);d(window).bind("render-content-loaded",function(f,a){e(d('embed[type="application/x-shockwave-flash"]',
a),0)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:view-comment', location = '/includes/js/comments.js' */
AJS.toInit(function(a){var e=Confluence.storageManager("comments"),f=function(){return confirm("Are you sure you want to delete the comment?")?(this.href+="&confirm=yes",!0):!1};Confluence.Comments={bindRemoveConfirmation:function(b){a("#comment-"+b+" .comment-action-remove a").click(f)}};if(a("#comments-section").length){AJS.isIE6&&(a(".logo.anonymous").each(function(){var b=document.createElement("div");b.className="replacement";AJS.applyPngFilter(b,this.src);a(this).replaceWith(b)}),a(".comment-actions .comment-permalink a").each(function(){a(this).addClass("filtered");
var b=a(this).css("background-image").replace(/^url\(\"?|\"?\)$/g,""),c=b.replace("light","dark");AJS.applyPngFilter(this,b);this.style.cursor="pointer";this.style.background="none";a(this).hover(function(){AJS.applyPngFilter(this,c)},function(){AJS.applyPngFilter(this,b)})}));a("#comments-section .comment:odd").addClass("odd");a(".comment-action-remove a").click(f);var d=a("#addcomment.comment-text"),c=a("#comments-text-editor textarea");c.focus(function(){d.addClass("active")}).blur(function(){a.trim(c.val()).length||
d.removeClass("active")}).bind("reset.default-text",function(){d.removeClass("active")});a("form[name='textcommentform']").submit(function(){var b=c.val();if(!a.trim(b)){alert("Comment text is empty. Cannot create empty comments.");return false}return true});a("#add-comment-rte").click(function(){c.hasClass("placeholded")||e.setItem("text-comment",a.trim(c.val()))});a("#addcomment #rte").length&&AJS.bind("init.rte",function(a,c){var d=e.getItem("text-comment");if(d){c.editor.setContent(d);e.setItem("text-comment","")}})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:shared-templates', location = '/includes/soy/user.soy' */
// This file was automatically generated from user.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.User == 'undefined') { Confluence.Templates.User = {}; }


Confluence.Templates.User.userLinkUrl = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append(soy.$$escapeHtml("/wiki"), '/display/~', soy.$$escapeUri(opt_data.username));
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.User.logo = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.profilePictureInfo['default'] && opt_data.username == opt_data.currentUsername) {
    output.append('<a ', (opt_data.canView) ? ' ' + ((! opt_data.disableUserHover) ? 'class="userLogoLink"' : '') + ' data-username="' + soy.$$escapeHtml(opt_data.username) + '"' : '', ' href="', soy.$$escapeHtml("/wiki"), '/users/profile/editmyprofilepicture.action" title="', soy.$$escapeHtml("Add a picture of yourself"), '"><img class="userLogo logo defaultLogo" src="', soy.$$escapeHtml("/wiki/s/en_GB/5785/ede5f0c65682583b938793f0499809b6742a2089.17/_"), '/images/icons/profilepics/add_profile_pic.png" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml("Add a picture of yourself"), '"></a>');
  } else {
    if (opt_data.profilePictureInfo.anonymous) {
      output.append('<img class="userLogo logo anonymous" src="', soy.$$escapeHtml("/wiki/s/en_GB/5785/ede5f0c65682583b938793f0499809b6742a2089.17/_"), '/images/icons/profilepics/anonymous.png" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml("Anonymous"), '" title="', soy.$$escapeHtml("Anonymous"), '">');
    } else if (opt_data.canView) {
      output.append('<a ', (! opt_data.disableUserHover) ? 'class="userLogoLink"' : '', ' data-username="', soy.$$escapeHtml(opt_data.username), '" href="');
      Confluence.Templates.User.userLinkUrl(opt_data, output);
      output.append('"><img class="userLogo logo" src="', soy.$$escapeHtml("/wiki"), soy.$$escapeHtml(opt_data.profilePictureInfo.downloadPath), '" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml(opt_data.username), '" title="', soy.$$escapeHtml(opt_data.username), '"></a>');
    } else {
      output.append('<img class="userLogo logo anonymous" src="', soy.$$escapeHtml("/wiki/s/en_GB/5785/ede5f0c65682583b938793f0499809b6742a2089.17/_"), '/images/icons/profilepics/anonymous.png" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml(opt_data.username), '" title="', soy.$$escapeHtml(opt_data.username), '">');
    }
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.User.usernameLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.username && opt_data.username != '') {
    output.append('<a href="');
    Confluence.Templates.User.userLinkUrl(opt_data, output);
    output.append('"', (opt_data.canView) ? 'class="url fn confluence-userlink" data-username="' + soy.$$escapeHtml(opt_data.username) + '"' : 'class="url fn"', '>', (opt_data.fullName && opt_data.fullName != '') ? soy.$$escapeHtml(opt_data.fullName) : soy.$$escapeHtml(opt_data.username), '</a>');
  } else {
    output.append(soy.$$escapeHtml("Anonymous"));
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.User.fullNameOrAnonymous = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.user && opt_data.user.fullName) ? soy.$$escapeHtml(opt_data.user.fullName) : soy.$$escapeHtml("Anonymous"));
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.User.usernameOrAnonymous = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.user && opt_data.user.name) ? soy.$$escapeHtml(opt_data.user.name) : soy.$$escapeHtml("Anonymous"));
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:shared-templates', location = '/includes/soy/icons.soy' */
// This file was automatically generated from icons.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Icons == 'undefined') { Confluence.Templates.Icons = {}; }


Confluence.Templates.Icons.contentIcon = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.content.type == 'trackback') ? '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="icon icon-trackback" title="' + soy.$$escapeHtml("Track back") + '">' + soy.$$escapeHtml("Track back") + ':</a>' : '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="icon ' + soy.$$escapeHtml(opt_data.iconCss) + '" title="' + soy.$$escapeHtml(opt_data.iconTitle) + '">' + soy.$$escapeHtml(opt_data.iconTitle) + '</a>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Icons.contentIconFont = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.content.type == 'trackback') ? '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="icon icon-trackback" title="' + soy.$$escapeHtml("Track back") + '">' + soy.$$escapeHtml("Track back") + ':</a>' : '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" title="' + soy.$$escapeHtml(opt_data.iconTitle) + '"><span class="icon ' + soy.$$escapeHtml(opt_data.iconCss) + '">' + soy.$$escapeHtml(opt_data.iconTitle) + '</span></a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-page', location = 'soy/comments.soy' */
// This file was automatically generated from comments.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Comments == 'undefined') { Confluence.Templates.Comments = {}; }


Confluence.Templates.Comments.displayReplyEditorLoadingContainer = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ol class="comment-threads"><li class="comment-thread">');
  Confluence.Templates.Comments.displayCommentEditorCommon({comment: {'ownerId': opt_data.contentId, 'parentId': opt_data.parentCommentId}, commenter: opt_data.commenter, state: 'loading', mode: 'reply'}, output);
  output.append('</li></ol>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.displayTopLevelCommentEditorPlaceholder = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  Confluence.Templates.Comments.displayCommentEditorCommon({comment: {'ownerId': opt_data.contentId}, commenter: opt_data.commenter, state: 'placeholder', mode: 'add'}, output);
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.displayEditEditorContainer = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  Confluence.Templates.Comments.displayCommentEditorCommon({comment: {'ownerId': opt_data.contentId, 'id': opt_data.commentId}, commenter: opt_data.commenter, state: 'placeholder', mode: 'edit'}, output);
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.editorLoadErrorMessage = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p>', soy.$$escapeHtml(opt_data.message), '</p><p><a href="', soy.$$escapeHtml(opt_data.fallbackUrl), '">', soy.$$escapeHtml("Try again"), '</a></p>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.displayCommentEditorCommon = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="quick-comment-container comment ', soy.$$escapeHtml(opt_data.mode), '">');
  Confluence.Templates.Comments.userLogo({userInfo: opt_data.commenter}, output);
  output.append('<div class="quick-comment-body"><div class="quick-comment-loading-container" style="display:', (opt_data.state == 'loading') ? 'block' : 'none', ';"></div><div id="editor-messages"></div><div id="all-messages"></div><form style="display:', (opt_data.state == 'loading') ? 'none' : 'block', ';" class="quick-comment-form aui" method="post" ');
  switch (opt_data.mode) {
    case 'add':
      output.append('name="inlinecommentform" action="', soy.$$escapeHtml("/wiki"), '/pages/doaddcomment.action?pageId=', soy.$$escapeHtml(opt_data.comment.ownerId), '"');
      break;
    case 'edit':
      output.append('name="editcommentform" action="', soy.$$escapeHtml("/wiki"), '/pages/doeditcomment.action?pageId=', soy.$$escapeHtml(opt_data.comment.ownerId), '&commentId=', soy.$$escapeHtml(opt_data.comment.id), '"');
      break;
    case 'reply':
      output.append('name="threadedcommentform"  action="', soy.$$escapeHtml("/wiki"), '/pages/doaddcomment.action?pageId=', soy.$$escapeHtml(opt_data.comment.ownerId), '&parentId=', soy.$$escapeHtml(opt_data.comment.parentId), '"');
      break;
  }
  output.append(' >', (opt_data.mode == 'add') ? '<div title="' + soy.$$escapeHtml("Add a Comment") + '" class="quick-comment-prompt"><span>' + soy.$$escapeHtml("Write a comment\u2026") + '</span></div>' : '', '</form></div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.userLogo = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p class="comment-user-logo">');
  if (opt_data.userInfo.userName == null) {
    output.append('<img class="userLogo logo anonymous" src="', soy.$$escapeHtml("/wiki/s/en_GB/5785/ede5f0c65682583b938793f0499809b6742a2089.17/_"), '/images/icons/profilepics/anonymous.png" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml("Anonymous"), '" title="', soy.$$escapeHtml("Anonymous"), '">');
  } else if (opt_data.userInfo.profilePicture.isDefault) {
    output.append('<a class="userLogoLink" data-username="', soy.$$escapeHtml(opt_data.userInfo.userName), '" href="', soy.$$escapeHtml("/wiki"), '/users/profile/editmyprofilepicture.action" title="', soy.$$escapeHtml("Add a picture of yourself"), '"><img class="userLogo logo defaultLogo" src="', soy.$$escapeHtml("/wiki/s/en_GB/5785/ede5f0c65682583b938793f0499809b6742a2089.17/_"), '/images/icons/profilepics/add_profile_pic.png" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml("Add a picture of yourself"), '"></a>');
  } else {
    output.append('<a class="userLogoLink" data-username="', soy.$$escapeHtml(opt_data.userInfo.userName), '" href="');
    Confluence.Templates.User.userLinkUrl({username: opt_data.userInfo.userName}, output);
    output.append('"><img class="userLogo logo" src="', soy.$$escapeHtml(opt_data.userInfo.profilePicture.path), '" alt="', soy.$$escapeHtml("User icon"), ': ', soy.$$escapeHtml(opt_data.userInfo.userName), '" title="', soy.$$escapeHtml(opt_data.userInfo.userName), '"></a>');
  }
  output.append('</p>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.displayComment = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.comment.parentId == 0 && opt_data.firstReply) {
    output.append('<div id="comments-section" class="pageSection group"><div class="section-header"><h2 id="comments-section-title" class="section-title">', soy.$$escapeHtml("1 Comment"), '</h2>');
    Confluence.Templates.Comments.commentThread({comment: opt_data.comment, commenter: opt_data.commenter, highlight: opt_data.highlight, topLevel: true}, output);
    output.append('</div></div>');
  } else if (opt_data.firstReply) {
    Confluence.Templates.Comments.commentThread({comment: opt_data.comment, commenter: opt_data.commenter, highlight: opt_data.highlight, topLevel: false}, output);
  } else {
    Confluence.Templates.Comments.commentThreadItem({comment: opt_data.comment, commenter: opt_data.commenter, highlight: true}, output);
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.commentThread = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ol class="comment-threads', (opt_data.topLevel) ? ' top-level" id="page-comments' : '', '">');
  Confluence.Templates.Comments.commentThreadItem(opt_data, output);
  output.append('</ol>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.commentThreadItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li id="comment-thread-', soy.$$escapeHtml(opt_data.comment.id), '" class="comment-thread">');
  Confluence.Templates.Comments.commentView(opt_data, output);
  output.append('</li>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.commentView = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="comment', (opt_data.highlight == true) ? ' focused' : '', '" id="comment-', soy.$$escapeHtml(opt_data.comment.id), '">');
  Confluence.Templates.Comments.userLogo({userInfo: opt_data.commenter}, output);
  output.append('<div class="comment-header"><h4 class="author">', (opt_data.commenter.userName == null) ? soy.$$escapeHtml("Anonymous") : '<a href="' + soy.$$escapeHtml("/wiki") + '/display/~' + soy.$$escapeUri(opt_data.commenter.userName) + '" class="url fn confluence-userlink" data-username="' + soy.$$escapeHtml(opt_data.commenter.userName) + '">' + soy.$$escapeHtml(opt_data.commenter.displayName) + '</a>', '</h4></div><div class="comment-body"><div class="comment-content wiki-content">', opt_data.comment.html, '</div><div class="comment-actions">');
  Confluence.Templates.Comments.displayCommentActions({section: 'secondary', actions: opt_data.comment.secondaryActions, commentId: opt_data.comment.id}, output);
  Confluence.Templates.Comments.displayCommentActions({section: 'primary', actions: opt_data.comment.primaryActions, commentId: opt_data.comment.id}, output);
  output.append('</div></div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Comments.displayCommentActions = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ul class="comment-actions-', soy.$$escapeHtml(opt_data.section), '">');
  if (opt_data.actions != null) {
    var itemList211 = opt_data.actions;
    var itemListLen211 = itemList211.length;
    for (var itemIndex211 = 0; itemIndex211 < itemListLen211; itemIndex211++) {
      var itemData211 = itemList211[itemIndex211];
      output.append('<li ', (itemData211.style != null) ? ' class="' + soy.$$escapeHtml(itemData211.style) + '"' : '', '><a ', (itemData211.tooltip != null) ? ' title="' + soy.$$escapeHtml(itemData211.tooltip) + '"' : '', ' href="', soy.$$escapeHtml(itemData211.url), '" ', (itemData211.id) ? ' id="' + soy.$$escapeHtml(itemData211.id) + '-' + soy.$$escapeHtml(opt_data.commentId) + '"' : '', '><span>', soy.$$escapeHtml(itemData211.label), '</span></a></li>\n');
    }
  }
  output.append('</ul>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-page', location = 'jscripts/comment-display-manager.js' */
Confluence.CommentDisplayManager=function(f){return{_updateCommentSectionTitle:function(){var a=f("#comments-section-title");if(0!=a.length){var b=this.commentCount();1==b?a.text("1 Comment"):a.text(AJS.format("{0} Comments",b))}},addComment:function(a,b,d,e){a={comment:b,commenter:a,highlight:d,context:{contextPath:AJS.Meta.get("context-path"),staticResourceUrlPrefix:AJS.Meta.get("static-resource-url-prefix")}};if(this.hasComments()){if(0==b.parentId)a.firstReply=
!1,d=AJS.$("#comments-section .comment-threads.top-level");else{var d=AJS.$("#comment-thread-"+b.parentId),c=d.children(".commentThreads");c.length?(a.firstReply=!1,d=c):a.firstReply=!0}e||this.clearFocus();e=f(Confluence.Templates.Comments.displayComment(a));e.addClass("fadeInComment");d.append(e);this._updateCommentSectionTitle()}else a.firstReply=!0,e=Confluence.Templates.Comments.displayComment(a),AJS.$("#comments-section").prepend(e);Confluence.Comments.bindRemoveConfirmation(b.id);b=this.getCommentNode(b.id);
b.scrollToElement();return b},addOrUpdateComment:function(a,b,d,e){var c=this.getCommentNode(b.id);return c?(c.find(".comment-content").html(b.html),e||this.clearFocus(),d&&c.addClass("focused"),c.addClass("fadeInComment"),c.scrollToElement(),c):this.addComment.apply(this,arguments)},isVisible:function(){return!f("#page-comments").hasClass("hidden")},hasComments:function(){return 0<this.commentCount()},commentCount:function(){return AJS.$("#comments-section .comment").not(".quick-comment-container").length},
clearFocus:function(){f(".comment").removeClass("focused")},getCommentNode:function(a){a=f("#comment-"+a);return a.length?a:null},getParentId:function(a){a=getCommentNode(a);return null!=a&&(a=a.closest("div.comment"),a.length)?(a=a.attr("id"),a=/\d+/.exec(a),parseInt(a)):0}}}(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-page', location = 'jscripts/scroll-util.js' */
AJS.$(function(e){e.fn.extend({scrollToElement:function(){this.scrollWindowToElement()||this.scrollOverflowContainerToElement();return this},scrollWindowToElement:function(){function b(){return"pageYOffset"in window?window.pageYOffset:document.documentElement.scrollTop}var a=b(),c;if("number"==typeof window.innerWidth)c=window.innerHeight;else if(document.documentElement&&document.documentElement.clientWidth)c=document.documentElement.clientHeight;else return this[0].scrollIntoView(!1),!0;var d=this.offset().top,
f=this.height();return d+f+40>a+c?(this[0].scrollIntoView(!1),window.scrollBy(0,40),a!=b()):!0},scrollOverflowContainerToElement:function(){var b=null;this.parents().each(function(){var a=AJS.$(this).css("overflow");if("auto"==a||"scroll"==a)return b=AJS.$(this),!1});if(!b)return!1;var a=b.height(),c=this.offset().top,d=this.height(),a=a-(c+d+40);0>a&&(b[0].scrollTop-=a);return!0}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:old-quick-reload', location = 'old/templates/quick-reload.soy' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:old-quick-reload', location = 'old/js/quick-reload-comments.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:old-quick-reload', location = 'js/quick-reload-page.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:old-quick-reload', location = 'old/js/quick-reload-alert.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:old-quick-reload', location = 'js/quick-reload-timer.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:old-quick-reload', location = 'old/js/quick-reload.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'templates/quick-reload.soy' */
// This file was automatically generated from quick-reload.soy.
// Please don't edit this file by hand.

if (typeof QuickReload == 'undefined') { var QuickReload = {}; }
if (typeof QuickReload.Templates == 'undefined') { QuickReload.Templates = {}; }


QuickReload.Templates.notice = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="qr-notice qr-aui-message aui-message aui-message-hint"></div>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.noticeItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="qr-notice-item"><div class="qr-notice-content"><p><span class="qr-notice-text"></span></p>');
  aui.buttons.button({text: opt_data.show, type: 'link', extraClasses: 'qr-notice-show'}, output);
  output.append('<a href="#" class="qr-notice-ignore">');
  aui.icons.icon({useIconFont: true, size: 'small', icon: 'close-dialog'}, output);
  output.append('</a></div></div>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.inlineCommentNoticeItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="qr-notice-item qr-notice-inline-comment-item"><strong class="qr-inline-comment-title">', soy.$$escapeHtml("New inline comment"), '</strong><a href="#" class="qr-notice-inline-comment-ignore">');
  aui.icons.icon({useIconFont: true, size: 'small', icon: 'close-dialog'}, output);
  output.append('</a>');
  QuickReload.Templates.inlineCommentNoticeHeader(opt_data, output);
  output.append('<div class="qr-notice-inline-comment-content qr-notice-edit-message"><span class="qr-notice-inline-commentter">');
  QuickReload.Templates.noticeInlineComment(opt_data, output);
  output.append('</span>');
  aui.buttons.button({text: (opt_data.reloadRequired) ? soy.$$escapeHtml("Reload page") : soy.$$escapeHtml("Show"), type: 'link', extraClasses: 'qr-notice-inline-show', extraAttributes: 'reload-required=' + opt_data.reloadRequired}, output);
  output.append('</div></div>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.commentNoticeItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="qr-notice-item qr-notice-page-', soy.$$escapeHtml(opt_data.type), '-item"><strong class="page-comment-message">', soy.$$escapeHtml(opt_data.message), '</strong><a href="#" class="qr-notice-ignore">');
  aui.icons.icon({useIconFont: true, size: 'small', icon: 'close-dialog'}, output);
  output.append('</a><div class="qr-notice-authors">');
  QuickReload.Templates.noticeHeader(opt_data, output);
  output.append('</div><div class="qr-notice-page-comment-content qr-notice-edit-message"><span class="qr-notice-page-comment-author"></span>');
  aui.buttons.button({text: (opt_data.type == 'page') ? soy.$$escapeHtml("Reload page") : soy.$$escapeHtml("Show"), type: 'link', extraClasses: 'qr-notice-show'}, output);
  output.append('</div></div>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.inlineCommentNoticeHeader = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="qr-notice-author">');
  aui.avatar.avatar({size: 'small', avatarImageUrl: opt_data.authorAvatarUrl, extraClasses: 'qr-author-avatar'}, output);
  output.append('<span class="inline-comment-content">', soy.$$escapeHtml(opt_data.noticeText), '<span></div>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.noticeHeader = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="qr-notice-author">');
  var commentUserList81 = opt_data.commentUsers;
  var commentUserListLen81 = commentUserList81.length;
  for (var commentUserIndex81 = 0; commentUserIndex81 < commentUserListLen81; commentUserIndex81++) {
    var commentUserData81 = commentUserList81[commentUserIndex81];
    output.append('<span>');
    if (opt_data.type == 'comments') {
      aui.avatar.avatar({size: 'small', avatarImageUrl: commentUserData81.commenter.profilePicture.path, title: commentUserData81.commenter.displayName != '' ? commentUserData81.commenter.displayName : "Anonymous", extraClasses: 'qr-author-avatar'}, output);
    } else {
      aui.avatar.avatar({size: 'small', avatarImageUrl: commentUserData81.profilePicture.path, title: commentUserData81.displayName != '' ? commentUserData81.displayName : "Anonymous", extraClasses: 'qr-author-avatar'}, output);
    }
    output.append('</span>');
  }
  output.append('<span class="qr-notice-page-comment-text">', soy.$$escapeHtml(opt_data.noticeText), '</span></div>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.noticePageEdit = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span classs="page-edit-content">', soy.$$escapeHtml("by"), '  </span><span class="editor">');
  Confluence.Templates.User.usernameLink({canView: false, username: opt_data.commenter.userName, fullName: opt_data.commenter.displayName != '' ? opt_data.commenter.displayName : "Anonymous"}, output);
  output.append('</span> <span class="page-edit-content-by"></span>');
  return opt_sb ? '' : output.toString();
};


QuickReload.Templates.noticeInlineComment = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span classs="page-edit-content">', soy.$$escapeHtml("by"), '  </span><span class="editor">');
  Confluence.Templates.User.usernameLink({canView: false, username: opt_data.authorUserName, fullName: opt_data.authorDisplayName != '' ? opt_data.authorDisplayName : "Anonymous"}, output);
  output.append('</span> <span class="page-edit-content-by"></span>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'js/quick-reload-comments.js' */
Confluence.QuickReload=Confluence.QuickReload||{};
AJS.toInit(function(a){function f(a){return a.comment.id}var d=Confluence.CommentDisplayManager;Confluence.QuickReload.Comments=function(){var c=[];return{property:"comments",singleText:function(){return "New comment"},manyText:function(a){return AJS.format("{0} New comments",a.length)},showText:function(a){return 1<a.length?"Show all":"Show"},ignoreOnce:function(a){c.push(a)},filterNewResults:function(d,
b){if(0===b.length)return b;var g=a.map(d,f);return a(b).filter(function(b,d){if(d.comment.isInlineComment)return!1;var e=f(d);if(0<=a.inArray(e,g))return!1;e=a.inArray(e,c);return 0<=e?(c.splice(e,1),!1):!0}).splice(0)},update:function(c){d.clearFocus();a.map(c,function(b){var c=b.comment;if(!c.isInlineComment){var h=null!=d.getCommentNode(f(b)),b=d.addOrUpdateComment(b.commenter,c,!0,!0);Confluence.Likes&&!h&&(Confluence.Likes.appendAction(a(b)),Confluence.Likes.updateComment(a(b),{}))}})}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'js/quick-reload-inline-comments.js' */
Confluence.QuickReload=Confluence.QuickReload||{};AJS.toInit(function(c){Confluence.QuickReload.InlineComments=function(){return{property:"comments",singleText:function(b){return b&&b.comment&&c("<div>").html(b.comment.html).text()},filterNewResults:function(b,a){return 0===a.length?a:c(a).filter(function(b,a){return!a.comment.isInlineComment||a.commenter.userName===AJS.Meta.get("remote-user")?!1:!0}).splice(0)}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'js/quick-reload-page.js' */
Confluence.QuickReload=Confluence.QuickReload||{};AJS.toInit(function(){Confluence.QuickReload.Page=function(){return{property:"page",singleText:function(){return "New page edits"},manyText:function(){return "New page edits"},showText:function(){},filterNewResults:function(b,a){return a},update:function(){window.location.reload()}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'js/quick-reload-alert.js' */
Confluence.QuickReload=Confluence.QuickReload||{};
AJS.toInit(function(d){var g=QuickReload.Templates;Confluence.QuickReload.Notice=function(){var h=0,m=0,k=d("<div>").addClass("qr-notice-container").appendTo("body"),c,i=0;return{removeAllNotices:function(){0<k.length&&k.empty()},addPageNotice:function(a,b,n,j,o,p){c=k.find(".qr-notice:first");if(0===c.length||0===h)c=d(g.notice()),c.appendTo(k);var f=[],l=[],m="qr-notice-page-"+b+"-item",e=c.find("."+m),q=a.slice(0);"comments"===b?d.each(q,function(a,b){_.contains(l,b.commenter.userName)?f=_.filter(f,
function(a){return a.commenter.userName!==b.commenter.userName}):l.push(b.commenter.userName);f.unshift(b)}):d.each(q,function(a,b){_.contains(l,b.editor.userName)?f=_.filter(f,function(a){return a.userName!==b.editor.userName}):l.push(b.editor.userName);f.unshift(b.editor)});i=c.find(".qr-notice-item:first").width();var a=f.length,r="";if(0===e.length){h++;e.addClass(m);"comments"===b?(8<a?e=d(g.commentNoticeItem({commentUsers:f.slice(0,8),noticeText:"",message:n,type:b})).appendTo(c):(1==a&&(r=
d("<div>").html(q.pop().comment.html).text()),e=d(g.commentNoticeItem({commentUsers:f,noticeText:this._trimToLengthContentDoubleQuote(r,30),message:n,type:b})).appendTo(c)),d(g.noticePageEdit({commenter:f[0].commenter})).appendTo(e.find(".qr-notice-page-comment-author"))):(e=d(g.commentNoticeItem({commentUsers:f,noticeText:"",message:n,type:b})).appendTo(c),e.height(74),d(g.noticePageEdit({commenter:f[0]})).appendTo(e.find(".qr-notice-page-comment-author")));0<i&&e.width(i);var t=this,b=function(a){h--;
if(h===0)t._hideNotice(c,function(){c.remove();c=void 0;i=0});else{h===1&&d(".qr-notice-shadow").remove();e.remove()}p();a.preventDefault()};2==a?e.find(".page-edit-content-by").text("and 1 other"):2<a&&e.find(".page-edit-content-by").text(AJS.format("and {0} others",a-1));e.find(".qr-notice-show").text(j);e.find(".qr-notice-ignore").click(b);e.find(".qr-notice-show").click(b).click(o)}else e.find(".qr-notice-page-comment-author").empty(),e.find(".qr-notice-author").remove(),
"comments"===b?(d(g.noticePageEdit({commenter:f[0].commenter})).appendTo(e.find(".qr-notice-page-comment-author")),1==a?(r=d("<div>").html(q.pop().comment.html).text(),d(g.noticeHeader({commentUsers:f,type:b,noticeText:this._trimToLengthContentDoubleQuote(r,30)})).appendTo(e.find(".qr-notice-authors"))):8<a?d(g.noticeHeader({commentUsers:f.slice(0,8),type:b,noticeText:""})).appendTo(e.find(".qr-notice-authors")):d(g.noticeHeader({commentUsers:f,type:b,noticeText:""})).appendTo(e.find(".qr-notice-authors")),
e.find(".qr-notice-show").text(j)):(d(g.noticePageEdit({commenter:f[0]})).appendTo(e.find(".qr-notice-page-comment-author")),1==a?d(g.noticeHeader({commentUsers:f,type:b,noticeText:""})).appendTo(e.find(".qr-notice-authors")):8<a?d(g.noticeHeader({commentUsers:f.slice(0,8),type:b,noticeText:""})).appendTo(e.find(".qr-notice-authors")):d(g.noticeHeader({commentUsers:f,type:b,noticeText:""})).appendTo(e.find(".qr-notice-authors"))),2==a?e.find(".page-edit-content-by").text("and 1 other"):
2<a&&e.find(".page-edit-content-by").text(AJS.format("and {0} others",a-1));k.find(".qr-notice-item").css("z-index","");e.css("z-index",1E4);e.find(".page-comment-message").text(n);this._animatePageNotice()},updateInlineCommentNotice:function(a,b,c,d,g,h){var f=this._getInlineCommentNotice(a);return f&&0<f.length&&(d=(f="true"===f.find(".qr-notice-show").attr("reload-required"))?d:g,this._removeInlineCommentNotice(a))?(this._addInlineCommentItem(a,b,f,c,d,h),this._renderInlineCommentCount(),
!0):!1},addInlineCommentNotice:function(a,b,i,j,o,p){0===m&&(!c||0===c.length)?(this._getNextNoticeTop(),c=d(g.notice()),c.appendTo(k)):c=d(".qr-notice:first");this._addInlineCommentItem(a,b,i,j,o,p);m++;h++;this._renderInlineCommentCount();this._animateInlineCommentNotice()},scroll:function(a){var b=d("body").hasClass("theme-documentation"),c=d("#header").offset().top+d("#header").height(),j=0,g=0;b?g=c:(j=d("#main-header").offset().top+20,b=k.offset().top,a<=j?g=j-a:a>j&&0<b?g=0:b<j&&(g=j));this._setNoticeContainerTop(g)},
_setNoticeContainerTop:function(a){k.css("top",a+"px")},_getInlineCommentNotice:function(a){if(c)return c.find("#"+a)},_removeInlineCommentNotice:function(a){return c&&(a=c.find("#"+a),0!==a.length)?(a.remove(),!0):!1},_animatePageNotice:function(){if(!c)return!1;c.appendTo(k);var a=c.find(".qr-notice-ignore");c.mouseenter(function(){a.css("opacity",".3")}).mouseleave(function(){a.css("opacity","0")});a.mouseenter(function(){a.css("opacity","1")}).mouseleave(function(){a.css("opacity",".3")});var b=
this;1===h&&!c.hasClass("qr-aui-message-collapsed")&&c.animate({display:"block",opacity:"show",top:20},500).queue(function(){setTimeout(function(){if(0<h)var a=setInterval(function(){if(!b._isAnimatingNotices()){clearInterval(a);var c=d(".qr-notice,.qr-notice-shadow");c.addClass("qr-aui-message-collapsed");c.children().animate({width:"+=35"},500);i+=35}},500)},5E3);d(this).dequeue()});if(1<h&&0===k.find(".qr-notice-shadow").length)var g=setInterval(function(){b._isAnimatingNotices()||(clearInterval(g),
b._addCommentNoticeShadow(c))},500)},_trimToLength:function(a,b){return jQuery.trim(a.length)>b?jQuery.trim(a).substring(0,b).split(" ").slice(0,-1).join(" ")+"...":a},_trimToLengthContentDoubleQuote:function(a,b){return 0==jQuery.trim(a.length)?a:jQuery.trim(a.length)>b?'"'+jQuery.trim(a).substring(0,b).split(" ").slice(0,-1).join(" ")+'..."':'"'+a+'"'},_addInlineCommentItem:function(a,b,n,j,o,p){var f=this._trimToLength(j.displayName,25),l=d(g.inlineCommentNoticeItem({authorDisplayName:f,authorUserName:j.userName,
authorAvatarUrl:j.profilePicture.path,noticeText:this._trimToLengthContentDoubleQuote(b,30),reloadRequired:n}));l.attr("id",a);l.appendTo(c);0===i&&(i=c.find(".qr-notice-item:first").width());35===i&&(i=303===c.find(".qr-notice-item:first").width()?c.find(".qr-notice-item:first").width():i+c.find(".qr-notice-item:first").width());l.width(i);k.find(".qr-notice-item").css("z-index","");l.css("z-index",1E4);var s=this,a=function(a){m--;h--;0===h?s._hideNotice(c,function(){c.remove();c=void 0;i=0}):(1===
h&&d(".qr-notice-shadow").remove(),l.remove());p();a.preventDefault()},e=l.find(".qr-notice-inline-comment-ignore");e.click(a);c.mouseenter(function(){e.css("opacity",".3")}).mouseleave(function(){e.css("opacity","0")});e.mouseenter(function(){e.css("opacity","1")}).mouseleave(function(){e.css("opacity",".3")});l.find(".qr-notice-inline-show").click(a).click(o)},_getNextNoticeTop:function(){var a=d(".qr-notice:last"),b=20;0<a.length&&(b=a.position().top+a.height()+20);return b},_hideNotice:function(a,
b){a.animate({opacity:"hide",right:0},500,b)},_animateInlineCommentNotice:function(){if(!c)return!1;var a=this;1===h&&!c.hasClass("qr-aui-message-collapsed")&&c.animate({display:"block",opacity:"show",top:20},500).queue(function(){setTimeout(function(){if(0<h)var b=setInterval(function(){if(!a._isAnimatingNotices()){clearInterval(b);var c=d(".qr-notice,.qr-notice-shadow");c.addClass("qr-aui-message-collapsed");c.children().animate({width:"+=35"},500);i+=35}},500)},5E3);d(this).dequeue()});if(1<h&&
0===k.find(".qr-notice-shadow").length)var b=setInterval(function(){a._isAnimatingNotices()||(clearInterval(b),a._addCommentNoticeShadow(c))},500)},_renderInlineCommentCount:function(){1<m?c.find(".qr-inline-comment-title").text("New inline comments"):c.find(".qr-inline-comment-title").text("New inline comment")},_addCommentNoticeShadow:function(a){var b=a.clone().removeClass("qr-notice").removeAttr("height").addClass("qr-notice-shadow").empty();
d("<div>").addClass("qr-notice-inline-comment-item").css("bottom","0px").css("right","0px").width(a.find(".qr-notice-item:first").width()).appendTo(b);b.css("top",a.position().top+30+"px").width(a.width()-20).css("opacity",".6").css("right","30px");b.insertAfter(a)},_isAnimatingNotices:function(){var a=d(".qr-notice");return a.find(".qr-notice-page-page-item").is(":animated")||a.find(".qr-notice-page-comments-item").is(":animated")||a.find(".qr-notice-inline-comment-item").is(":animated")}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'js/quick-reload-timer.js' */
Confluence.QuickReload=Confluence.QuickReload||{};
AJS.toInit(function(a){Confluence.QuickReload.SmartTimer=function(f,i){function g(){c&&clearTimeout(c);var a=setTimeout,d=e.min,b;b=(document.hidden?j:1)*Math.ceil(((new Date).getTime()-h)/e.inactivity);b=Math.max(Math.min(e.max/e.min,b),1);b=isNaN(b)?1:b;c=a(function(){f();g()},d*b)}var e=a.extend({min:3E4,max:36E5,inactivity:12E4},i),j=3,h=(new Date).getTime(),c=null,d=function(){if(c){var a=(new Date).getTime()-h>e.inactivity;h=(new Date).getTime();a&&(f(),g())}};document.addEventListener("visibilitychange",
function(){document.hidden||d()},!1);a(window).focus(d);a("body").click(d);a(window).scroll(d);return{start:function(){f();g()},stop:function(){clearTimeout(c);c=null}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload', location = 'js/quick-reload.js' */
Confluence.QuickReload=Confluence.QuickReload||{};
AJS.toInit(function(b){function m(f){g-=f;0===g&&(b("body").hasClass("theme-documentation")?b("#splitter-content").unbind("scroll",n):b(window).unbind("scroll",j))}function q(){b("body").hasClass("theme-documentation")?b("#splitter-content").unbind("scroll",n).scroll(n):b(window).unbind("scroll",j).scroll(j)}var u={404:"not found - the plugin has been probably been removed or disabled from Confluence",500:"generic server error",503:"service unavailable",504:"gateway timeout"};if(!AJS.DarkFeatures.isEnabled("quickreload.disabled")&&
Confluence.CommentDisplayManager){var r=AJS.Meta.get("page-id");if(void 0!=r){var v=document.title,s=new Confluence.QuickReload.Comments,d=new Confluence.QuickReload.InlineComments,c=new Confluence.QuickReload.Page,w=[s,c],i=new Confluence.QuickReload.Notice;b("#editPageLink").click(function(){i.removeAllNotices()});var t=b("meta[name='confluence-request-time']").attr("content")||(new Date).getTime(),g=0,o=function(){document.title=(0<g?"("+g+") ":"")+v};Confluence.QuickReload.update=function(){b("body").hasClass("contenteditor")?
Confluence.QuickReload.disable():b.ajax({type:"GET",url:Confluence.getContextPath()+"/rest/quickreload/latest/"+r+"?since="+encodeURIComponent(t),dataType:"json"}).done(function(f,h,c){if(204!==c.status){var k=!1;t=f.time;b.map(w,function(a){var b=f[a.property];a.results=a.results||[];if(b){var e=a.results.concat(a.filterNewResults(a.results,b)),b=e.length-a.results.length,d=0<b;a.results=e;if(d){q();var c=!1,h=function(){m(a.results.length);c||o()},e=function(){a.update(a.results);a.results=[];h();
Confluence.CommentDisplayManager._updateCommentSectionTitle()};if(AJS.DarkFeatures.isEnabled("confluence.quick-reload-automated"))return c=!0,e();i.addPageNotice(a.results,a.property,1===a.results.length?a.singleText(a.results[0],function(a){return a.displayName}):a.manyText(a.results),a.showText(a.results),e,h)}k|=d;g+=b}});k&&j();d.inlineCommentResults=d.inlineCommentResults||[];h=d.filterNewResults(d.inlineCommentResults,f[d.property]);g+=h.length;d.inlineCommentResults=d.inlineCommentResults.concat(h);
var c=0<h.length,l=function(){m(1);o()};c&&(q(),j(),b.each(h,function(a,f){var e,c=f.comment;e=0===c.parentId?c.id:c.parentId;var h=function(){AJS.trigger("qr:show-new-thread",e)},g=function(){var a=AJS.Meta.Links.canonical(),b=-1===a.indexOf("?")?"?":"&";window.location=a+b+"focusedCommentId="+e+"#comment-"+e};i.updateInlineCommentNotice(e,d.singleText(f),f.commenter,g,h,l)?m(1):0===f.comment.parentId?(c=new b.Deferred,c.fail(function(a){i.addInlineCommentNotice(e,d.singleText(a),!0,a.commenter,
g,l)}),c.done(function(a){i.addInlineCommentNotice(e,d.singleText(a),!1,a.commenter,h,l)}),AJS.trigger("qr:add-new-highlight",[f,c])):i.addInlineCommentNotice(e,d.singleText(f),!1,f.commenter,h,l)}));(k=k||c)&&o()}}).fail(function(b){b=b||{};if(b=u[b.status])Confluence.QuickReload.disable(),AJS.log('Quick comment reload plugin has been disabled in this page due to a server error: "'+b+'". Please refresh the page to get it back.')})};c={};AJS.DarkFeatures.isEnabled("confluence.quick-reload-automated")&&
(c.min=5E3);var p=new Confluence.QuickReload.SmartTimer(Confluence.QuickReload.update,c);Confluence.QuickReload.disable=function(){i.removeAllNotices();p.stop()};Confluence.QuickReload.enable=function(){p.start()};p.start();AJS.bind("page.commentAddedOrUpdated",function(b,c){s.ignoreOnce(c.commentId)});var j=function(){i.scroll(b(window).scrollTop())},n=function(){i.scroll(b("#splitter-content").scrollTop())}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:internal-aui-browser', location = 'js/aui/internal/browser.js' */
(function(A){AJS._internal=AJS._internal||{};AJS._internal.browser=A(AJS.$)})(function(B){var A={};var C=null;A.supportsCalc=function(){if(C===null){var D=B('<div style="height: 10px; height: -webkit-calc(20px + 0); height: calc(20px);"></div>');C=(20===D.appendTo(document.documentElement).height());D.remove()}return C};A.supportsRequestAnimationFrame=function(){return !!window.requestAnimationFrame};return A});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:dialog2', location = 'js/dialog2.js' */
(function(A){AJS.dialog2=A(AJS.$,AJS.layer,AJS._internal.widget)})(function(D,G,C){var F={"aui-focus":"false","aui-blanketed":"true"};function B(H){D.each(F,function(I,J){var K="data-"+I;if(!H[0].hasAttribute(K)){H.attr(K,J)}})}function A(H){if(H){this.$el=D(H)}else{this.$el=D(aui.dialog.dialog2({}))}B(this.$el)}A.prototype.on=function(I,H){G(this.$el).on(I,H);return this};A.prototype.off=function(I,H){G(this.$el).off(I,H);return this};A.prototype.show=function(){G(this.$el).show();return this};A.prototype.hide=function(){G(this.$el).hide();return this};A.prototype.remove=function(){G(this.$el).remove();return this};A.prototype.isVisible=function(){return G(this.$el).isVisible()};var E=C("dialog2",A);E.on=function(H,I){G.on(H,".aui-dialog2",I);return this};E.off=function(H,I){G.off(H,".aui-dialog2",I);return this};D(document).on("click",".aui-dialog2-header-close",function(H){H.preventDefault();E(D(this).closest(".aui-dialog2")).hide()});E.on("show",function(K,J){var I=[".aui-dialog2-content",".aui-dialog2-footer",".aui-dialog2-header"];var H;I.some(function(L){H=J.find(L+" :aui-tabbable");return H.length});H&&H.first().focus()});E.on("hide",function(J,I){var H=G(I);if(I.data("aui-remove-on-hide")){H.remove()}});return E});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:dialog2', location = 'soy/dialog2.soy' */
// This file was automatically generated from dialog2.soy.
// Please don't edit this file by hand.

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.dialog == 'undefined') { aui.dialog = {}; }


aui.dialog.dialog2 = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var param12 = new soy.StringBuilder();
  aui.dialog.dialog2Content({id: null, titleText: opt_data.titleText, titleContent: opt_data.titleContent, headerActionContent: opt_data.headerActionContent, headerSecondaryContent: opt_data.headerSecondaryContent, modal: opt_data.modal, content: opt_data.content, footerHintText: opt_data.footerHintText, footerHintContent: opt_data.footerHintContent, footerActionContent: opt_data.footerActionContent}, param12);
  aui.dialog.dialog2Chrome({id: opt_data.id, titleId: opt_data.id ? opt_data.id + '-dialog-title' : null, modal: opt_data.modal, tagName: opt_data.tagName, removeOnHide: opt_data.removeOnHide, visible: opt_data.visible, size: opt_data.size, extraClasses: opt_data.extraClasses, extraAttributes: opt_data.extraAttributes, content: param12.toString()}, output);
  return opt_sb ? '' : output.toString();
};


aui.dialog.dialog2Chrome = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<', soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'section'), (opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '', (opt_data.titleId) ? ' aria-labelledby="' + soy.$$escapeHtml(opt_data.titleId) + '"' : '', ' role="dialog" class=" aui-layer aui-dialog2 aui-dialog2-', soy.$$escapeHtml(opt_data.size ? opt_data.size : 'medium'));
  aui.renderExtraClasses(opt_data, output);
  output.append('"', (opt_data.modal) ? 'data-aui-modal="true"' : '', (opt_data.removeOnHide) ? 'data-aui-remove-on-hide="true"' : '', (opt_data.visible != true) ? 'aria-hidden="true"' : '');
  aui.renderExtraAttributes(opt_data, output);
  output.append('>', (opt_data.content) ? opt_data.content : '', '</', soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'section'), '>');
  return opt_sb ? '' : output.toString();
};


aui.dialog.dialog2Content = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  aui.dialog.dialog2Header({titleId: opt_data.id ? opt_data.id + '-dialog-title' : null, titleText: opt_data.titleText, titleContent: opt_data.titleContent, actionContent: opt_data.headerActionContent, secondaryContent: opt_data.headerSecondaryContent, modal: opt_data.modal}, output);
  aui.dialog.dialog2Panel(opt_data, output);
  aui.dialog.dialog2Footer({hintText: opt_data.footerHintText, hintContent: opt_data.footerHintContent, actionContent: opt_data.footerActionContent}, output);
  return opt_sb ? '' : output.toString();
};


aui.dialog.dialog2Header = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<header', (opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '', ' class="aui-dialog2-header');
  aui.renderExtraClasses(opt_data, output);
  output.append('"');
  aui.renderExtraAttributes(opt_data, output);
  output.append('><h2 ', (opt_data.titleId) ? ' id="' + soy.$$escapeHtml(opt_data.titleId) + '"' : '', ' class="aui-dialog2-header-main">', (opt_data.titleText) ? soy.$$escapeHtml(opt_data.titleText) : '', (opt_data.titleContent) ? opt_data.titleContent : '', '</h2>', (opt_data.actionContent) ? '<div class="aui-dialog2-header-actions">' + opt_data.actionContent + '</div>' : '', (opt_data.secondaryContent) ? '<div class="aui-dialog2-header-secondary">' + opt_data.secondaryContent + '</div>' : '', (opt_data.modal != true) ? '<a class="aui-dialog2-header-close"><span class="aui-icon aui-icon-small aui-iconfont-close-dialog">' + soy.$$escapeHtml("Close") + '</span></a>' : '', '</header>');
  return opt_sb ? '' : output.toString();
};


aui.dialog.dialog2Footer = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<footer', (opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '', ' class="aui-dialog2-footer');
  aui.renderExtraClasses(opt_data, output);
  output.append('"');
  aui.renderExtraAttributes(opt_data, output);
  output.append('>', (opt_data.actionContent) ? '<div class="aui-dialog2-footer-actions">' + opt_data.actionContent + '</div>' : '', (opt_data.hintText || opt_data.hintContent) ? '<div class="aui-dialog2-footer-hint">' + ((opt_data.hintText) ? soy.$$escapeHtml(opt_data.hintText) : '') + ((opt_data.hintContent) ? opt_data.hintContent : '') + '</div>' : '', '</footer>');
  return opt_sb ? '' : output.toString();
};


aui.dialog.dialog2Panel = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div', (opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '', ' class="aui-dialog2-content');
  aui.renderExtraClasses(opt_data, output);
  output.append('"');
  aui.renderExtraAttributes(opt_data, output);
  output.append('>', (opt_data.content) ? opt_data.content : '', '</div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-alignment', location = 'js/aui/internal/alignment.js' */
(function(A){AJS.Alignment=A(window.Tether);if(typeof window.define==="function"){define("aui/internal/alignment",["aui/internal/tether"],function(){return AJS.Alignment})}})(function(E){var C="data-aui-alignment";var J="data-aui-alignment-static";var H="aui-alignment";var A="aui-alignment-side-";var K="aui-alignment-snap-";var D="right middle";var I={"top left":{el:"bottom left",target:"top left"},"top center":{el:"bottom center",target:"top center"},"top right":{el:"bottom right",target:"top right"},"right top":{el:"top left",target:"top right"},"right middle":{el:"middle left",target:"middle right"},"right bottom":{el:"bottom left",target:"bottom right"},"bottom left":{el:"top left",target:"bottom left"},"bottom center":{el:"top center",target:"bottom center"},"bottom right":{el:"top right",target:"bottom right"},"left top":{el:"top right",target:"top left"},"left middle":{el:"middle right",target:"middle left"},"left bottom":{el:"bottom right",target:"bottom left"}};function G(Q,P,M){var N=A+P;var O=K+M;Q.className+=" "+N+" "+O}function B(M){var N=(M.getAttribute(C)||D).split(" ");return{side:N[0],snap:N[1]}}function F(N,M){return I[N+" "+M]||I[D]}function L(O,P){var R=B(O);var Q=F(R.side,R.snap);var N=O.hasAttribute(J);var M=new E({enabled:false,element:O,target:P,attachment:Q.el,targetAttachment:Q.target,classPrefix:H,constraints:[{to:"window",attachment:N===true?"none":"together"}]});G(O,R.side,R.snap);this._auiTether=M}L.prototype={destroy:function(){this._auiTether.destroy();return this},disable:function(){this._auiTether.disable();return this},enable:function(){this._auiTether.enable();return this}};return L});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-trigger', location = '/js/aui/trigger.js' */
(function(A){define("aui/trigger",[],function(){return A(AJS.$,window.skate)})})(function(D,B){function C(E){return document.getElementById(E.getAttribute("aria-controls"))}function A(F,G){if(F.isEnabled()){var E=C(F);if(E&&E.message){E.message(G)}}}B("data-aui-trigger",{type:B.types.ATTR,insert:function(E){D(E).on({click:function(F){A(E,F);F.preventDefault()},"mouseenter mouseleave focus blur":function(F){A(E,F)}})},prototype:{disable:function(){this.setAttribute("aria-disabled","true")},enable:function(){this.setAttribute("aria-disabled","false")},isEnabled:function(){return this.getAttribute("aria-disabled")!=="true"}}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-trigger', location = '/soy/trigger.soy' */
// This file was automatically generated from trigger.soy.
// Please don't edit this file by hand.

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.trigger == 'undefined') { aui.trigger = {}; }


aui.trigger.trigger = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<', soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'a'), (opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '', ' class="');
  aui.renderExtraClasses(opt_data, output);
  output.append('" aria-owns="', soy.$$escapeHtml(opt_data.menu.id), '" aria-controls="', soy.$$escapeHtml(opt_data.menu.id), '" aria-haspopup="true"', (opt_data.title) ? ' title="' + soy.$$escapeHtml(opt_data.title) + '"' : '', (opt_data.container) ? ' data-container="' + soy.$$escapeHtml(opt_data.container) + '"' : '', ((! opt_data.tagName || opt_data.tagName == 'a') && (! opt_data.extraAttributes || Object.prototype.toString.call(opt_data.extraAttributes) === '[object Object]' && ! opt_data.extraAttributes.href && ! opt_data.extraAttributes.tabindex)) ? ' tabindex="0"' : '', ' data-aui-trigger');
  aui.renderExtraAttributes(opt_data, output);
  output.append('>', (opt_data.content) ? opt_data.content : '', (opt_data.text) ? soy.$$escapeHtml(opt_data.text) : '', (! (opt_data.showIcon == false)) ? '<span class="icon ' + soy.$$escapeHtml(opt_data.iconClasses ? opt_data.iconClasses : 'aui-icon-dropdown') + '">' + ((opt_data.iconText) ? soy.$$escapeHtml(opt_data.iconText) : '') + '</span>' : '', '</', soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'a'), '>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-inline-dialog2', location = '/js/aui/inline-dialog2.js' */
(function(A){define("aui/inline-dialog2",["./internal/alignment","./trigger"],function(B){return A(B,AJS.layer,window.skate)})})(function(J,C,E){var I=1000;function K(M){return document.querySelector('[aria-controls="'+M.id+'"]')}function F(N,O){var M=K(N);if(M){O(M)}}function G(M,O){var N=M.getAttribute("data-aui-responds-to")==="hover";if(N){O(M)}}function L(N,M){if(!N._auiAlignment){N._auiAlignment=new J(N,M)}}function B(N,M){L(N,M);N._auiAlignment.enable()}function A(N,M){L(N,M);N._auiAlignment.disable()}E("aui-inline-dialog2",{type:E.types.TAG,ready:function(M){F(M,function(N){N.setAttribute("aria-expanded",M.isVisible());N.setAttribute("aria-haspopup","true")});G(M,function(){M.mouseInside=false;M.addEventListener("mouseenter",function(){M.mouseInside=true;M.message({type:"mouseenter"})});M.addEventListener("mouseleave",function(){M.mouseInside=false;M.message({type:"mouseleave"})})})},remove:function(M){if(M._auiAlignment){M._auiAlignment.destroy()}},prototype:{remove:function(){C(this).remove()},show:function(){var M=this;C(this).show();F(this,function(N){B(M,N);N.setAttribute("aria-expanded","true")});return this},hide:function(){var M=this;C(this).hide();F(this,function(N){A(M,N);N.setAttribute("aria-expanded","false")});return this},isVisible:function(){return C(this).isVisible()},message:function(M){D(this,M);return this}}});function D(O,Q){var N={toggle:["click"],hover:["mouseenter","mouseleave","focus","blur"]};var M=O.getAttribute("data-aui-responds-to");var P=N[M];if(P&&P.indexOf(Q.type)>-1){H[Q.type](O,Q)}}var H={click:function(M){if(M.isVisible()){if(!C(M).isPersistent()){M.hide()}}else{M.show()}},mouseenter:function(M){if(!M.isVisible()){M.show()}if(M._clearMouseleaveTimeout){M._clearMouseleaveTimeout()}},mouseleave:function(M){if(C(M).isPersistent()||!M.isVisible()){return }if(M._clearMouseleaveTimeout){M._clearMouseleaveTimeout()}var N=setTimeout(function(){if(!M.mouseInside){M.hide()}},I);M._clearMouseleaveTimeout=function(){clearTimeout(N);M._clearMouseleaveTimeout=null}},focus:function(M){if(!M.isVisible()){M.show()}},blur:function(M){if(!C(M).isPersistent()&&M.isVisible()){M.hide()}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-inline-dialog2', location = 'soy/inline-dialog2.soy' */
// This file was automatically generated from inline-dialog2.soy.
// Please don't edit this file by hand.

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.inlineDialog2 == 'undefined') { aui.inlineDialog2 = {}; }


aui.inlineDialog2.inlineDialog2 = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<aui-inline-dialog2 ', (opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '', '  class="aui-layer aui-inline-dialog');
  aui.renderExtraClasses(opt_data, output);
  output.append('" data-aui-alignment="', soy.$$escapeHtml(opt_data.alignment ? opt_data.alignment : ''), '" data-aui-responds-to="', soy.$$escapeHtml(opt_data.respondsTo ? opt_data.respondsTo : ''), '" aria-hidden="true"');
  aui.renderExtraAttributes(opt_data, output);
  output.append('>');
  aui.inlineDialog2.inlineDialog2Content(opt_data, output);
  output.append('</aui-inline-dialog2>');
  return opt_sb ? '' : output.toString();
};


aui.inlineDialog2.inlineDialog2Content = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="aui-inline-dialog-contents">', (opt_data.content) ? opt_data.content : '', '</div>');
  return opt_sb ? '' : output.toString();
};


aui.inlineDialog2.trigger = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  aui.trigger.trigger(soy.$$augmentData(opt_data, {showIcon: opt_data.showIcon ? opt_data.showIcon : false}), output);
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:jsUri', location = '/includes/js/jsUri.js' */
(function(){function g(a){a=decodeURIComponent(a);return a=a.replace("+"," ")}function h(a){var c,b,f,e,d=[];if("undefined"===typeof a||null===a||""===a)return d;0===a.indexOf("?")&&(a=a.substring(1));c=a.toString().split(/[&;]/);for(a=0;a<c.length;a++)b=c[a],f=b.split("="),e=f[0],b=-1===b.indexOf("=")?null:null===f[1]?"":f[1],d.push([e,b]);return d}function d(a){var c=/^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/.exec(a||
""),b={};"source protocol authority userInfo user password host port relative path directory file query anchor".split(" ").forEach(function(a,e){b[a]=c[e]||""});this.uriParts=b;this.queryPairs=h(this.uriParts.query);this.hasAuthorityPrefixUserPref=null}Array.prototype.forEach||(Array.prototype.forEach=function(a,c){for(var b=0,f=this.length;b<f;++b)a.call(c||this,this[b],b,this)});"protocol userInfo host port path anchor".split(" ").forEach(function(a){d.prototype[a]=function(c){typeof c!=="undefined"&&
(this.uriParts[a]=c);return this.uriParts[a]}});d.prototype.hasAuthorityPrefix=function(a){if(typeof a!=="undefined")this.hasAuthorityPrefixUserPref=a;return this.hasAuthorityPrefixUserPref===null?this.uriParts.source.indexOf("//")!==-1:this.hasAuthorityPrefixUserPref};d.prototype.query=function(a){var c="",b;if(typeof a!=="undefined")this.queryPairs=h(a);for(a=0;a<this.queryPairs.length;a++){b=this.queryPairs[a];c.length>0&&(c=c+"&");c=b[1]===null?c+b[0]:c+b.join("=")}return c.length>0?"?"+c:c};
d.prototype.getQueryParamValue=function(a){var c,b;for(b=0;b<this.queryPairs.length;b++){c=this.queryPairs[b];if(g(a)===g(c[0]))return c[1]}};d.prototype.getQueryParamValues=function(a){var c=[],b,f;for(b=0;b<this.queryPairs.length;b++){f=this.queryPairs[b];g(a)===g(f[0])&&c.push(f[1])}return c};d.prototype.deleteQueryParam=function(a,c){var b=[],f,e,d,h;for(f=0;f<this.queryPairs.length;f++){e=this.queryPairs[f];d=g(e[0])===g(a);h=g(e[1])===g(c);(arguments.length===1&&!d||arguments.length===2&&!d&&
!h)&&b.push(e)}this.queryPairs=b;return this};d.prototype.addQueryParam=function(a,c,b){if(arguments.length===3&&b!==-1){b=Math.min(b,this.queryPairs.length);this.queryPairs.splice(b,0,[a,c])}else arguments.length>0&&this.queryPairs.push([a,c]);return this};d.prototype.replaceQueryParam=function(a,c,b){var d=-1,e,h;if(arguments.length===3){for(e=0;e<this.queryPairs.length;e++){h=this.queryPairs[e];if(g(h[0])===g(a)&&decodeURIComponent(h[1])===g(b)){d=e;break}}this.deleteQueryParam(a,b).addQueryParam(a,
c,d)}else{for(e=0;e<this.queryPairs.length;e++){h=this.queryPairs[e];if(g(h[0])===g(a)){d=e;break}}this.deleteQueryParam(a);this.addQueryParam(a,c,d)}return this};"protocol hasAuthorityPrefix userInfo host port path query anchor".split(" ").forEach(function(a){var c="set"+a.charAt(0).toUpperCase()+a.slice(1);d.prototype[c]=function(b){this[a](b);return this}});d.prototype.scheme=function(){var a="";if(this.protocol()){a=a+this.protocol();this.protocol().indexOf(":")!==this.protocol().length-1&&(a=
a+":");a=a+"//"}else this.hasAuthorityPrefix()&&this.host()&&(a=a+"//");return a};d.prototype.origin=function(){var a=this.scheme();if(this.userInfo()&&this.host()){a=a+this.userInfo();this.userInfo().indexOf("@")!==this.userInfo().length-1&&(a=a+"@")}if(this.host()){a=a+this.host();this.port()&&(a=a+(":"+this.port()))}return a};d.prototype.toString=function(){var a=this.origin();if(this.path())a=a+this.path();else if(this.host()&&(this.query().toString()||this.anchor()))a=a+"/";if(this.query().toString()){this.query().toString().indexOf("?")!==
0&&(a=a+"?");a=a+this.query().toString()}if(this.anchor()){this.anchor().indexOf("#")!==0&&(a=a+"#");a=a+this.anchor()}return a};d.prototype.clone=function(){return new d(this.toString())};define("confluence/jsUri",function(){return d})})(this);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-jquery', location = '/js/confluence/preview-support.js' */
define("cp/confluence/preview-support",["ajs"],function(a){var d=function(){var e=b.SELECTOR_STRINGS.IMAGE+", "+b.SELECTOR_STRINGS.LINK_IMAGE+", "+b.SELECTOR_STRINGS.EXTERNAL_IMAGE;if(b.isPDFSupported()){e+=", "+b.SELECTOR_STRINGS.PDF+", "+b.SELECTOR_STRINGS.LINK_PDF}return e};var c=function(){return b.SELECTOR_STRINGS.IMAGE+", "+b.SELECTOR_STRINGS.EXTERNAL_IMAGE+", "+b.SELECTOR_STRINGS.FILE+", "+b.SELECTOR_STRINGS.LINK_FILE};var b={SELECTOR_STRINGS:{IMAGE:"img.confluence-embedded-image[data-linked-resource-id]",EXTERNAL_IMAGE:"img.confluence-embedded-image.confluence-external-resource",PDF:"a.confluence-embedded-file[data-nice-type='PDF Document']",LINK_IMAGE:"a[data-linked-resource-type='attachment'][data-nice-type='Image']",LINK_PDF:"a[data-linked-resource-type='attachment'][data-nice-type='PDF Document']",FILE:"a.confluence-embedded-file",LINK_FILE:"a[data-linked-resource-type='attachment']",FILE_OVERLAY:"span.confluence-embedded-file-wrapper .overlay"},VIEW_MODE:{FULL:"full",COMMENT:"comment",SIMPLE:"simple"},isPDFSupported:function(){return a.DarkFeatures.isEnabled("pdf-preview")},getFileSelectorString:function(){if(a.DarkFeatures.isEnabled("previews.trigger-all-file-types")){return c()}else{return d()}}};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-jquery', location = '/js/confluence/preview.js' */
define("cp/confluence/preview",["underscore","jquery","cp/confluence/preview-support","ajs","confluence/jsUri"],function(k,e,f,i,b){var j,l;e(document).ready(g);function g(){var o=e(f.getFileSelectorString());o.off("click.fb");e(document.body).off("click.filePreviews");e(document.body).on("click.filePreviews",f.getFileSelectorString(),n);e(document.body).on("click.filePreviews",f.SELECTOR_STRINGS.FILE_OVERLAY,h);e(window).on("popstate",function(){if(!l&&i.DarkFeatures.isEnabled("previews.sharing.pushstate")){a()}});a()}function n(o){if(!o.altKey&&!o.ctrlKey&&!o.metaKey&&!e(this).parent().closest("a, #draft-changes-dialog, #cp-annotations").length){o.preventDefault();m(this)}}function h(p){p.preventDefault();var o=e(p.target);var q=o.closest("span.confluence-embedded-file-wrapper");m(q.find(f.SELECTOR_STRINGS.IMAGE+","+f.SELECTOR_STRINGS.FILE),{autoShowAnnotationPanel:o.closest(".comment-count-overlay").length>0})}function m(p,o){if(!l){l=WRM.require(["wr!com.atlassian.confluence.plugins.confluence-previews:confluence-previews-resources","wrc!file-viewer"],function(){j=require("cp/confluence/file-preview-loader");d(p,o)})}else{l.done(k.partial(d,p,o))}return l}var d=function(q,p){p=p||{};var o=e("#content");var r=e(q).closest(".comment,.cq-content,.ic-content");if(!p.viewMode){if(!(o.hasClass("page")||o.hasClass("blogpost"))){p.viewMode=f.VIEW_MODE.SIMPLE}else{if(r.length){p.viewMode=f.VIEW_MODE.COMMENT}}}if(p.viewMode===f.VIEW_MODE.COMMENT){j.showPreviewerForComment(q,r,p);i.trigger("analyticsEvent",{name:"confluence-spaces.previews.opened",data:{source:"comments"}})}else{if(p.viewMode===f.VIEW_MODE.SIMPLE){j.showPreviewerForSingleFile(q,p);i.trigger("analyticsEvent",{name:"confluence-spaces.previews.opened",data:{source:p&&p.source}})}else{p.viewMode=f.VIEW_MODE.FULL;j.showPreviewer(q,p);i.trigger("analyticsEvent",{name:"confluence-spaces.previews.opened",data:{source:"main"}})}}};function a(){if(c()){var q=new b(window.location.href);var p=window.history.pushState&&i.DarkFeatures.isEnabled("previews.sharing.pushstate");if(q.getQueryParamValue("preview")&&!p){var r="#!/preview"+q.getQueryParamValue("preview");var o=decodeURIComponent(q.deleteQueryParam("preview").setAnchor(r).toString());if(window.history.replaceState){window.history.replaceState({},"",o)}else{window.location=o}}else{if(q.anchor().indexOf("!/preview")===0&&p){var o;if(q.getQueryParamValue("preview")){o=q.setAnchor("")}else{o=q.addQueryParam("preview",q.anchor().substr("!/preview".length,q.anchor().length)).setAnchor("")}window.history.replaceState({},"",o)}}m()}}function c(){var o=new b(window.location.href);return i.DarkFeatures.isEnabled("previews.sharing")&&(o.getQueryParamValue("preview")||(o.anchor()&&o.anchor().indexOf("!/preview")===0))}return{loadConfluencePreviews:m}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-jquery', location = '/js/confluence/jquery-previewer.js' */
require(["cp/confluence/preview","jquery"],function(b,a){a.fn.previewer=function(c){if(!a(this).length){return this}var d=a.extend({},c);return this.each(function(){var f=a(this);var e=f.closest("li");var g=d.src||f.attr("data-image-src")||f.attr("src");if(g){f.click(function(j){var i={src:g,type:d.type,thumbnail:g,title:d.title||e.attr("data-file-name")||g,rank:0,id:e.attr("data-attachment-id"),ownerId:e.attr("data-owner-id")};var h=b.loadConfluencePreviews([i],{source:d.from||"custom",viewMode:d.viewMode||"simple"});d.zindex&&h.done(function(){a("#cp-container").css({"z-index":d.zindex})})})}})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.issue-status-plugin:issue-status-resources', location = 'templates/status.soy' */
// This file was automatically generated from status.soy.
// Please don't edit this file by hand.

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Template == 'undefined') { JIRA.Template = {}; }
if (typeof JIRA.Template.Util == 'undefined') { JIRA.Template.Util = {}; }
if (typeof JIRA.Template.Util.Issue == 'undefined') { JIRA.Template.Util.Issue = {}; }
if (typeof JIRA.Template.Util.Issue.Status == 'undefined') { JIRA.Template.Util.Issue.Status = {}; }


JIRA.Template.Util.Issue.Status.issueStatusResolver = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (! opt_data.issueStatus) {
    output.append('<span class="aui-icon aui-icon-small aui-iconfont-help jira-issue-status-render-error" title="', soy.$$escapeHtml("No issue status information was provided"), '"></span>');
  } else if (opt_data.issueStatus.statusCategory) {
    JIRA.Template.Util.Issue.Status.issueStatus(opt_data, output);
  } else {
    JIRA.Template.Util.Issue.Status.iconStatus({name: opt_data.issueStatus.name, iconUrl: opt_data.issueStatus.iconUrl, description: opt_data.issueStatus.description, isCompact: opt_data.isCompact}, output);
  }
  return opt_sb ? '' : output.toString();
};


JIRA.Template.Util.Issue.Status.iconStatus = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<img src="', soy.$$escapeHtml(opt_data.iconUrl), '" width="16" height="16" alt="', soy.$$escapeHtml(opt_data.name), '" title="', soy.$$escapeHtml(opt_data.name), (opt_data.description) ? ' - ' + soy.$$escapeHtml(opt_data.description) : '', '" class="jira-issue-status-icon">', (! opt_data.isCompact) ? ' ' + soy.$$escapeHtml(opt_data.name) : '');
  return opt_sb ? '' : output.toString();
};


JIRA.Template.Util.Issue.Status.issueStatus = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  JIRA.Template.Util.Issue.Status.statusLozenge({name: opt_data.issueStatus.name, categoryKey: opt_data.issueStatus.statusCategory.key, colorName: opt_data.issueStatus.statusCategory.colorName, description: opt_data.issueStatus.description, isSubtle: opt_data.isSubtle, isCompact: opt_data.isCompact, maxWidth: opt_data.maxWidth}, output);
  return opt_sb ? '' : output.toString();
};


JIRA.Template.Util.Issue.Status.statusLozenge = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var maxWidth__soy46 = opt_data.maxWidth ? opt_data.maxWidth : 'medium';
  var tooltipContent__soy47 = new soy.StringBuilder('<span class="jira-issue-status-tooltip-title">', soy.$$escapeHtml(opt_data.name), '</span>', (opt_data.description) ? '<br><span class="jira-issue-status-tooltip-desc">' + soy.$$escapeHtml(opt_data.description) + '</span>' : '');
  tooltipContent__soy47 = tooltipContent__soy47.toString();
  output.append('<span class=" jira-issue-status-lozenge aui-lozenge ');
  JIRA.Template.Util.Issue.Status.statusLozengeClasses(opt_data, output);
  output.append((opt_data.isSubtle && ! opt_data.isCompact) ? ' aui-lozenge-subtle' : '', (opt_data.isCompact) ? ' jira-issue-status-lozenge-compact' : '', ' jira-issue-status-lozenge-max-width-', soy.$$escapeHtml(maxWidth__soy46), '" data-tooltip="', soy.$$escapeHtml(tooltipContent__soy47), '">', soy.$$escapeHtml(opt_data.name), '</span>');
  return opt_sb ? '' : output.toString();
};


JIRA.Template.Util.Issue.Status.statusLozengeClasses = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('jira-issue-status-lozenge-', soy.$$escapeHtml(opt_data.colorName ? opt_data.colorName : 'medium-gray'), ' ', (opt_data.categoryKey) ? 'jira-issue-status-lozenge-' + soy.$$escapeHtml(opt_data.categoryKey) : '');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.issue-status-plugin:issue-status-resources', location = '/js/issue-status-plugin.js' */
AJS.$(function(){if(AJS.$.fn.tooltip){AJS.$(".jira-issue-status-lozenge[data-tooltip]").tooltip({aria:true,gravity:AJS.$.fn.tipsy.autoWE,delayIn:100,html:true,live:true,title:"data-tooltip",className:"jira-issue-status-tooltip"})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-jira-metadata:confluence-jira-metadata-resources', location = 'soy/jira-metadata.soy' */
// This file was automatically generated from jira-metadata.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Metadata == 'undefined') { Confluence.Templates.Metadata = {}; }
if (typeof Confluence.Templates.Metadata.JIRA == 'undefined') { Confluence.Templates.Metadata.JIRA = {}; }


Confluence.Templates.Metadata.JIRA.metadata = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="jira-metadata-dialog" class="rendered-content"><h2 class="title">', soy.$$escapeHtml("JIRA links"), '</h2><div class="items-section">');
  var groupList6 = opt_data.groups;
  var groupListLen6 = groupList6.length;
  for (var groupIndex6 = 0; groupIndex6 < groupListLen6; groupIndex6++) {
    var groupData6 = groupList6[groupIndex6];
    if (groupData6.items.length) {
      switch (groupData6.type) {
        case 'ISSUES':
          Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Issues", type: groupData6.type, links: groupData6.links}, output);
          break;
        case 'SPRINTS':
          Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Sprints", type: groupData6.type, links: groupData6.links}, output);
          break;
        case 'VERSIONS':
          Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Versions", type: groupData6.type, links: groupData6.links}, output);
          break;
        case 'EPICS':
          Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Epics", type: groupData6.type, links: groupData6.links}, output);
          break;
      }
    }
  }
  output.append('</div>');
  Confluence.Templates.Metadata.JIRA.renderAuthPrompts({appLinks: opt_data.unauthorisedAppLinks}, output);
  Confluence.Templates.Metadata.JIRA.renderJiraErrors(opt_data, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.featureDiscovery = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="jira-metadata-feature-discovery"><h2>', soy.$$escapeHtml("View related JIRA items here"), '</h2><p>', soy.$$escapeHtml("Now you can see which epics, sprints, versions and issues relate to this page."), '</p><div class="aui-toolbar2" role="toolbar"><div class="aui-toolbar2-inner">');
  aui.buttons.button({text: "Show me", extraClasses: 'showme'}, output);
  aui.buttons.button({text: "Don\x27t show again", type: 'link', extraClasses: 'close'}, output);
  output.append('</div></div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.nometadata = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="jira-metadata-dialog" class="rendered-content">');
  aui.message.warning({content: '<p>' + soy.$$escapeHtml("JIRA links cannot be displayed. Either you do not have correct JIRA permissions or the links have been removed.") + '</p>'}, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.renderAuthPrompts = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.appLinks.length) {
    var param66 = new soy.StringBuilder();
    if (opt_data.appLinks.length == 1) {
      var appLink__soy69 = opt_data.appLinks[0];
      param66.append('<p>', AJS.format("{0}Login \x26amp; Approve{1} to retrieve data from {2}",'<a class="jira-metadata-auth-link" href="#" data-href="' + appLink__soy69.authorisationUrl + '">','</a>',appLink__soy69.htmlSafeName), '</p>');
    } else {
      param66.append('<p>', soy.$$escapeHtml("Authenticate to retrieve data from the following instances:"), '</p>');
      var appLinkList78 = opt_data.appLinks;
      var appLinkListLen78 = appLinkList78.length;
      for (var appLinkIndex78 = 0; appLinkIndex78 < appLinkListLen78; appLinkIndex78++) {
        var appLinkData78 = appLinkList78[appLinkIndex78];
        param66.append('<div><a class="jira-metadata-auth-link" href="#" data-href="', soy.$$escapeHtml(appLinkData78.authorisationUrl), '">', soy.$$escapeHtml(appLinkData78.name), '</a></div>');
      }
    }
    aui.message.hint({content: param66.toString()}, output);
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.renderGroup = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="jira-metadata-section ', soy.$$escapeHtml(opt_data.type), '-section"><div class="section-label"><span class="icon"></span><span>', soy.$$escapeHtml(opt_data.headingText), '</span></div><ul class="jira-metadata-list jira-', soy.$$escapeHtml(opt_data.type), '-list">');
  var itemList94 = opt_data.items;
  var itemListLen94 = itemList94.length;
  for (var itemIndex94 = 0; itemIndex94 < itemListLen94; itemIndex94++) {
    var itemData94 = itemList94[itemIndex94];
    output.append('<li class="jira-metadata-item"><span class="item-label"><a href="', soy.$$escapeHtml("/wiki"), '/plugins/servlet/jira-metadata/redirect?u=', soy.$$escapeUri(itemData94.url), '&t=', soy.$$escapeHtml(opt_data.type), '" title="', soy.$$escapeHtml(itemData94.name), '">', soy.$$escapeHtml(itemData94.name), '</a>');
    if (itemData94.status) {
      output.append('&nbsp;');
      if (itemData94.status.statusCategory) {
        JIRA.Template.Util.Issue.Status.issueStatusResolver({issueStatus: itemData94.status, isSubtle: true}, output);
      } else {
        output.append('<span class="item-status">(', soy.$$escapeHtml(itemData94.status.name), ')</span>');
      }
    }
    output.append('</span>', (itemData94.description != '') ? '<span class="item-subtext">' + soy.$$escapeHtml(itemData94.description) + '</span>' : '', '</li>');
  }
  output.append('</ul><ul class="jira-metadata-list ', soy.$$escapeHtml(opt_data.type), '-more-link">');
  var linkList130 = opt_data.links;
  var linkListLen130 = linkList130.length;
  for (var linkIndex130 = 0; linkIndex130 < linkListLen130; linkIndex130++) {
    var linkData130 = linkList130[linkIndex130];
    output.append('<li class="jira-metadata-item"><a href="', soy.$$escapeHtml("/wiki"), '/plugins/servlet/jira-metadata/redirect?u=', soy.$$escapeUri(linkData130.url), '&t=', soy.$$escapeHtml(opt_data.type), '&more">', soy.$$escapeHtml(AJS.format("View {0} more in {1}",linkData130.numItems,linkData130.appName)), '</a></li>');
  }
  output.append('</ul></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.loadingMetadata = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="jira-metadata-dialog"><h2 class="title">', soy.$$escapeHtml("JIRA links"), '</h2><div class="spinner-container"><div class="spinner"></div></div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.renderJiraErrors = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.errors.length == 1) {
    var error__soy150 = opt_data.errors[0];
    aui.message.warning({content: '<p>' + soy.$$escapeHtml("Unable to retrieve JIRA metadata.") + ' ' + soy.$$escapeHtml(error__soy150.errorMessage) + '</p>'}, output);
  } else if (opt_data.errors.length > 1) {
    var param159 = new soy.StringBuilder('<p>', soy.$$escapeHtml("Unable to retrieve JIRA metadata. The following errors occurred:"), '</p><ul>');
    var errorList163 = opt_data.errors;
    var errorListLen163 = errorList163.length;
    for (var errorIndex163 = 0; errorIndex163 < errorListLen163; errorIndex163++) {
      var errorData163 = errorList163[errorIndex163];
      param159.append('<li>', soy.$$escapeHtml(errorData163.errorMessage), '</li>');
    }
    param159.append('</ul>');
    aui.message.warning({content: param159.toString()}, output);
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Metadata.JIRA.unknownError = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="jira-metadata-dialog" class="rendered-content">');
  aui.message.warning({content: '<p>' + soy.$$escapeHtml("Unable to retrieve JIRA metadata. Could not connect to Confluence") + '</p>'}, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-jira-metadata:confluence-jira-metadata-resources', location = '/js/jira-metadata.js' */
AJS.toInit(function(h){var i="com.atlassian.confluence.plugins.confluence-jira-metadata";var s=false;var o;var l;var q="jira-metadata-dialog";var g=h("#content-metadata-jira");var t;var e="jira-metadata-discovery";var r=AJS.Meta.get("jira-metadata-count");var k="linked-issues-dropdown";if(r>0){p(r,AJS.Meta.get("jira-metadata-count-incomplete"))}else{if(r==-1){h.ajax({url:AJS.contextPath()+"/rest/jira-metadata/1.0/metadata/aggregate?pageId="+AJS.Meta.get("page-id"),type:"GET",dataType:"json",contentType:"application/json",cache:false,success:function(u){if(u.count>0){p(u.count,u.incomplete)}}})}}function p(v,u){f(v,u);g.removeClass("hidden");if(b()){o=AJS.InlineDialog(g,q,function(x,w,y){AJS.trigger("analytics",{name:"confluence.jira.metadata.expanded"});if(!l||!s){l=x;y();a(x)}else{y()}return false},{hideDelay:null});g.click(function(){if(h("#"+q).is(":visible")){o.hide()}})}if(g&&j()){m();g.one("click",function(){Confluence.FeatureDiscovery.forPlugin(i).markDiscovered(k)})}}function f(v,u){if(!u){h("#content-metadata-jira > span").text(v==1?"1 JIRA link":AJS.format("{0} JIRA links",v))}}function b(){return !g.attr("href")}function m(){t=AJS.InlineDialog(g,e,function(v,u,w){v.html(Confluence.Templates.Metadata.JIRA.featureDiscovery());v.find(".showme").on("click",function(){Confluence.FeatureDiscovery.forPlugin(i).markDiscovered(k);t.hide();o.show()});v.find(".close").on("click",function(){Confluence.FeatureDiscovery.forPlugin(i).markDiscovered(k);t.hide()});w()},{noBind:true,closeOthers:false,hideDelay:null});t.show();Confluence.FeatureDiscovery.forPlugin(i).addDiscoveryView(k)}function j(){return !AJS.Meta.get("blueprint-index-popup-key")&&Confluence.FeatureDiscovery.forPlugin(i).shouldShow(k)}function a(){d();l.html(Confluence.Templates.Metadata.JIRA.loadingMetadata());l.find(".spinner").spin("medium");h.ajax({url:AJS.contextPath()+"/rest/jira-metadata/1.0/metadata?pageId="+AJS.Meta.get("page-id"),type:"GET",dataType:"json",contentType:"application/json",error:function(u){c();l.html(Confluence.Templates.Metadata.JIRA.unknownError())},success:function(v){c();s=true;f(v.count,false);var w;if(v.count===0&&!(v.unauthorisedAppLinks&&v.unauthorisedAppLinks.length>0)&&v.errors.length==0){AJS.trigger("analytics",{name:"confluence.jira.metadata.error.no-metadata"});w=Confluence.Templates.Metadata.JIRA.nometadata()}else{w=Confluence.Templates.Metadata.JIRA.metadata(v)}var x=l.height();l.html(w);var u=l.height();l.find("#"+q+" > *").not("h2").css("opacity",0).animate({opacity:1},350,"easeInOutQuad");l.css({overflow:"hidden",height:x+"px"}).animate({height:u+"px"},350,"easeInOutQuad",function(){l.css({overflow:"",height:""})});n()},complete:function(){h("#"+q+" .icon-close").click(function(u){u.stopPropagation();h(this).closest(".closable").remove()})}})}function n(){h(".jira-metadata-auth-link").click(function(u){u.preventDefault();AppLinks.authenticateRemoteCredentials(h(this).data("href"),a,function(){})})}function d(){if(l&&l.height()>0){l.css("height",l.height())}}function c(){l&&l.css("height","")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:blueprint-first-time-tooltip-resources', location = 'com/atlassian/confluence/plugins/createcontent/js/first-time-tooptip.js' */
AJS.bind("sidebar.finished-loading",function(){var a=AJS.Meta.get("blueprint-index-popup-key");AJS.debug("Index key for "+a);if(a){Confluence.Blueprint.showIndexPagePopup(a)}});Confluence.Blueprint.showIndexPagePopup=function(b){var d=function(i){return function(l,j,k){l.html(Confluence.Templates.Blueprints.sidebarIndexPagePopup({indexPageTitle:i.toLowerCase()}));k()}};var a=AJS.$(AJS.$("li.blueprint."+b)[0]);var h=a.text();var g=AJS.$(".icon",a);var f="blueprintIndexSidebarPopup";var c=AJS.InlineDialog(g.is(":visible")?g:AJS.$(".acs-nav-sections .quick-links-section"),f,d(h),{addActiveClass:false,hideDelay:null,noBind:true});AJS.$(document).bind("showLayer",function(i){var j=f+".inline-dialog-check";AJS.$("body").unbind("click."+j)});c.show();var e=function(i){AJS.$(document).on("click","#dismiss-index-popup",function(){i.hide();return false})}(c);AJS.bind("quickedit.success",function(){c.hide()})};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:create-from-template-resources', location = 'com/atlassian/confluence/plugins/createcontent/js/create-from-template-macro.js' */
AJS.toInit(function(b){var a=b(".create-from-template-button");a.each(function(){var d=b(this);if(d.attr("aria-disabled")=="true"){var c={live:true,gravity:"n",title:"data-tooltip",delayIn:250,delayOut:0};d.tooltip(c)}else{d.click(function(){d.addClass("launching-dialog");Confluence.Blueprint.Dialog.launch(d.data());return false})}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:create-from-template-resources', location = 'com/atlassian/confluence/plugins/createcontent/soy/create-from-template-macro.soy' */
// This file was automatically generated from create-from-template-macro.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Blueprints == 'undefined') { Confluence.Templates.Blueprints = {}; }
if (typeof Confluence.Templates.Blueprints.CreateFromTemplate == 'undefined') { Confluence.Templates.Blueprints.CreateFromTemplate = {}; }


Confluence.Templates.Blueprints.CreateFromTemplate.macroTemplate = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a class=\'aui-button create-from-template-button\'', (! opt_data.hasCreatePermission) ? 'aria-disabled=\'true\' data-tooltip="' + soy.$$escapeHtml("Sorry, you don\x27t have permission to create content. Contact your space administrator to request access.") + '"' : '', 'data-space-key=\'', soy.$$escapeHtml(opt_data.spaceKey), '\' href=\'', soy.$$escapeHtml(opt_data.createContentUrl), '\'', (opt_data.title) ? 'data-title=\'' + soy.$$escapeHtml(opt_data.title) + '\'' : '', (opt_data.templateId) ? 'data-template-id=\'' + soy.$$escapeHtml(opt_data.templateId) + '\'' : '', (opt_data.contentBlueprintId) ? 'data-content-blueprint-id=\'' + soy.$$escapeHtml(opt_data.contentBlueprintId) + '\'' : '', '>', soy.$$escapeHtml(opt_data.buttonLabel), '</a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/like.js' */
define("confluence/ic/model/like",["backbone"],function(b){var a=b.Model.extend({initialize:function(c,d){if(!c){throw new Error("Attributes is required")}if(!c.username){throw new Error("username is a required attribute")}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/likes.js' */
define("confluence/ic/model/likes",["ajs","underscore","backbone","confluence/ic/model/like","confluence/ic/likes/likes-manager"],function(b,d,f,c,a){var e=f.Collection.extend({model:c,url:function(){return b.contextPath()+"/rest/likes/1.0/content/"+this.contentId+"/likes"},initialize:function(h,g){d.bindAll(this,"_handleSaveSuccess","_handleDestroySuccess");g=g||{};if(g.contentId===undefined){throw new Error("content ID is required.")}this.contentId=g.contentId;if(a.getLikes(g.contentId)){this.reset(a.getLikes(g.contentId))}this.listenTo(f,"ic:likes-received",this.updateLikes);this.bind("add",function(i){i.save(null,{success:this._handleSaveSuccess,error:this._handleError})});this.bind("remove",function(i){i.id="";i.destroy({success:this._handleDestroySuccess,error:this._handleError})});this.currentUserName=b.Meta.get("remote-user")},updateLikes:function(){this.reset(a.getLikes(this.contentId))},addUser:function(g){return this.add({username:g})},removeUser:function(g){return this.remove(this.getUserByName(g))},isLikedByUser:function(g){return !!this.getUserByName(g)},getUserByName:function(g){return this.findWhere({username:g})},toggleLike:function(){if(this.isLikedByUser(this.currentUserName)){this.removeUser(this.currentUserName)}else{this.addUser(this.currentUserName)}},_handleSaveSuccess:function(g){a.add(this.contentId,this.currentUserName)},_handleDestroySuccess:function(g){a.remove(this.contentId,this.currentUserName)},_handleError:function(g){f.trigger("ic:error","Likes cannot be updated.")}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/comment.js' */
define("confluence/ic/model/comment",["jquery","underscore","backbone","ajs","confluence/ic/util/utils","confluence/ic/model/reply-collection"],function(d,b,g,a,c,f){var e=g.Model.extend({defaults:{authorDisplayName:c.getAuthorDisplayName(),authorUserName:a.Meta.get("remote-user"),authorAvatarUrl:a.contextPath()+a.Meta.get("current-user-avatar-url"),body:"",originalSelection:"",containerId:a.Meta.get("latest-page-id"),parentCommentId:"0",lastFetchTime:d("meta[name=confluence-request-time]").attr("content"),hasDeletePermission:true,hasEditPermission:true,hasResolvePermission:true,resolveProperties:{resolved:false,resolvedTime:0},serializedHighlights:"",deleted:false},urlRoot:a.contextPath()+"/rest/inlinecomments/1.0/comments",initialize:function(h){h=h||{};this._setHighlights(h.markerRef);var i=this;this.replies=new f();this.replies.url=function(){return i.url()+"/replies"};if(c.getDarkFeatures().DANGLING_COMMENT&&a.Meta.get("page-id")===a.Meta.get("latest-page-id")){if(this.isDangling()&&!this.isResolved()){this.resolve(true,{wait:true,dangling:true,success:b.bind(function(){g.trigger("ic:open:dangled",this)},this),error:b.bind(function(){g.trigger("ic:resolve:dangled:failed",this)},this)})}}},validate:function(){if(!this.get("body")){return true}},resolve:function(h,i){i=i||{};this.save({},b.extend(i,{url:this.urlRoot+"/"+this.get("id")+"/resolve/"+h+"/dangling/"+(i.dangling===true)}))},isResolved:function(){return this.get("resolveProperties").resolved},isDangling:function(){return this.highlight===undefined},isDeleted:function(){return this.get("deleted")},_setHighlights:function(i){var h;if(i!==undefined){h=d("#content .wiki-content:first").find('.inline-comment-marker[data-ref="'+i+'"]')}else{h=d(".ic-current-selection")}if(h.length!==0){this.highlights=h;this.highlight=h.first()}else{this.highlights=undefined;this.highlight=undefined}},destroy:function(i){i=i?b.clone(i):{};var h=this;var k=i.success;var j=function(n,m){var l=m.error;m.error=function(o){if(l){l(n,o,m)}n.trigger("error",n,o,m)}};i.success=function(l){if(k){k(h,l,i)}};j(this,i);return this.sync("delete",this,i)}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/comment-collection.js' */
define("confluence/ic/model/comment-collection",["jquery","backbone","ajs","underscore","confluence/ic/model/comment"],function(d,f,a,b,e){var c=f.Collection.extend({model:e,initialize:function(){this.listenTo(this,"sort",this._removeCachedMarkers)},url:function(){var h=a.contextPath();var g=a.Meta.get("page-id");return h+"/rest/inlinecomments/1.0/comments?containerId="+g},getResolvedCount:function(){return this.getResolvedComments().length},getUnresolveCount:function(){return this.reject(function(g){return g.isResolved()===true&&g.isDeleted()===false}).length},getResolvedComments:function(){return this.filter(function(g){return g.isResolved()===true&&g.isDeleted()===false})},getResolvedCommentsDesc:function(){return b.sortBy(this.getResolvedComments(),function(g){return 0-g.get("resolveProperties").resolvedTime})},getNextCommentOnPage:function(){return this._getCommentAtRelativeOffset(1)},getPrevCommentOnPage:function(){return this._getCommentAtRelativeOffset(-1)},_getCommentAtRelativeOffset:function(j){var k=this.getCommentsOnPage();var g=this.findWhere({active:true});if(g===undefined||k.length<=1){return null}var i=b.pluck(k,"id");var h=b.indexOf(i,g.get("id"));return k[(h+j+k.length)%k.length]},getCommentsOnPage:function(){return this.filter(function(g){return((g.isResolved()===false)&&!g.isDangling()&&(g.isDeleted()===false))||g.get("active")===true})},getCommentsOnPageCount:function(){return this.getCommentsOnPage().length},getActiveIndexWithinPageComments:function(){var h=b.pluck(this.getCommentsOnPage(),"id");var g=this.findWhere({active:true});if(g===undefined){return null}var i=g.get("id");return b.indexOf(h,i)},comparator:function(h,g){if(this.markers===undefined){this.markers=d("#content .wiki-content:first").find(".inline-comment-marker")}if(h.highlight===undefined){return 1}if(g.highlight===undefined){return -1}return this.markers.index(h.highlight)-this.markers.index(g.highlight)},_removeCachedMarkers:function(){this.markers=undefined}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/reply.js' */
define("confluence/ic/model/reply",["jquery","backbone","ajs","confluence/ic/util/utils",],function(d,e,b,c){var a=e.Model.extend({defaults:{authorDisplayName:c.getAuthorDisplayName(),authorUserName:b.Meta.get("remote-user"),authorAvatarUrl:b.contextPath()+b.Meta.get("current-user-avatar-url"),body:"",commentId:"0",hasDeletePermission:true,hasEditPermission:!!b.Meta.get("remote-user")},urlRoot:function(){return b.contextPath()+"/rest/inlinecomments/1.0/comments/"+this.get("commentId")+"/replies"},sync:function(h,g,f){f=f||{};if(h==="create"){f.url=this.urlRoot()+"?containerId="+b.Meta.get("latest-page-id")}return e.sync.call(this,h,g,f)},validate:function(){if(!this.get("body")){return true}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/reply-collection.js' */
define("confluence/ic/model/reply-collection",["backbone","confluence/ic/model/reply"],function(c,a){var b=c.Collection.extend({model:a});return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:highlight-view', location = 'view/highlight-text/highlight-text.js' */
define("confluence/ic/view/highlight-text",["backbone","ajs","confluence/ic/util/text-highlighter","confluence/ic/util/utils"],function(e,b,c,d){var a=e.View.extend({el:"#content .wiki-content:first",events:{"click .inline-comment-marker.valid":"commentClick"},initialize:function(){if(this.collection){this.listenTo(this.collection,"sync remove change:deleted",this.render);this.listenTo(this.collection,"change:active",this.setActive)}this.listenTo(e,"ic:view ic:overlap ic:sidebar-hidden",this.clearSelection);this.listenTo(e,"ic:persist",this.persistComment);this.listenTo(e,"ic:delete",this.render);b.bind("qr:add-new-highlight",this._addQuickReloadMarker)},render:function(){this.inlineLinks=[];this.$(".inline-comment-marker").removeClass("valid");this.collection.each(function(f){if(!f.isResolved()&&!f.get("deleted")&&f.highlights){f.highlights.addClass("valid");this._pushToInlineLinks(f.highlights)}},this);this._setupLinkDialog()},_pushToInlineLinks:function(g){var f=this;g.each(function(){var h=d.getInlineLinks(this);h.each(function(){if($(this).attr("href")){f.inlineLinks.push($(this))}})})},_setupLinkDialog:function(){var f={width:200,onHover:true,noBind:true,calculatePositions:this._calculatePositions,hideDelay:1000};$(this.inlineLinks).each(function(){var g=this;b.InlineDialog(g,"inline-comment-link",function(i,h,j){i.addClass("inline-comment-link");i.html(Confluence.Templates.IC.highlightTextLink({link:g.attr("href")}));j();return false},f)})},_calculatePositions:function(f,g,h){return{displayAbove:true,popupCss:{top:g.target.offset().top-f.height()-10,left:h.x-(f.width()/2)},arrowCss:{top:f.height(),left:f.width()/2-4}}},setActive:function(g){this.$(".inline-comment-marker").removeClass("active");var f=this.$('.inline-comment-marker[data-ref="'+g.get("markerRef")+'"]');if(g.get("active")&&f.length){f.addClass("active")}},commentClick:function(f){f.preventDefault();var g=this.$(f.currentTarget);if(!g.hasClass("active")){this.displayComment(g)}else{e.trigger("ic:hide-sidebar",f,true)}},displayComment:function(i,h){var g=i.data("ref");var f=this.collection.findWhere({markerRef:g});e.trigger("ic:view",f,h)},clearSelection:function(){(new c()).removeHighlight()},persistComment:function(f){this.$(".ic-current-selection").removeClass("ic-current-selection").addClass("inline-comment-marker").attr("data-ref",f.get("markerRef"));this.collection.add(f)},_addQuickReloadMarker:function(j,h,f){var k=h.comment;var g=this.$('.inline-comment-marker[data-ref="'+k.dataRef+'"]');if(g.length){f.resolve(h);return}var i=(new c()).deserializeHighlights(k.serializedHighlights,k.dataRef);if(i){f.resolve(h)}else{f.reject(h)}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:highlight-view', location = 'view/highlight-text/highlight-text.soy' */
// This file was automatically generated from highlight-text.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.highlightTextLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  aui.icons.icon({useIconFont: true, size: 'small', icon: 'link'}, output);
  output.append('<a href=\'', soy.$$escapeHtml(opt_data.link), '\'>', soy.$$escapeHtml(opt_data.link), '</a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:confirm-dialog-view', location = 'view/confirm-dialog/confirm-dialog.soy' */
// This file was automatically generated from confirm-dialog.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.confirmDialog = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<strong class="ic-confirm-label">', soy.$$escapeHtml(opt_data.label), '</strong><div class="ic-confirm-message">', soy.$$escapeHtml(opt_data.message), '</div><div class="ic-confirm-buttons">');
  aui.buttons.button({text: "Delete", tagName: 'button', extraClasses: ['ic-action-delete-confirm', 'aui-button-compact']}, output);
  aui.buttons.button({text: "Cancel", tagName: 'button', type: 'link', extraClasses: ['ic-action-cancel-confirm', 'aui-button-compact']}, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:confirm-dialog-view', location = 'view/confirm-dialog/confirm-dialog.js' */
define("confluence/ic/view/confirm-dialog",["backbone","underscore","jquery"],function(d,b,c){var a=d.View.extend({tagName:"div",className:"ic-confirm-container",initialize:function(e){this.$menuEl=e.$menuEl;this.$bodyEl=e.$bodyEl;this.$menuEl.addClass("ic-action-menu-active");this.render();b.bindAll(this,"clickOutside");this.$bodyEl.on("click",this.clickOutside)},events:{"click .ic-action-cancel-confirm":"cancel","click .ic-action-delete-confirm":"confirm"},template:Confluence.Templates.IC.confirmDialog,render:function(){this.$el.html(this.template(this.model.toJSON()));return this},clickOutside:function(f){if(c.contains(this.el,f.target)||this.el===f.target){return}this.cancel()},cancel:function(){this.destroy()},confirm:function(){this.trigger("ic:confirm");this.destroy()},destroy:function(){this.$bodyEl.off("click",this.clickOutside);this.$menuEl.removeClass("ic-action-menu-active");this.remove()}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:common-resource', location = 'common/common.soy' */
// This file was automatically generated from common.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.authorAvatar = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.authorUserName == '') {
    aui.avatar.avatar({size: opt_data.size, avatarImageUrl: opt_data.authorAvatarUrl, extraClasses: 'ic-author-avatar'}, output);
  } else {
    output.append('<a data-username="', soy.$$escapeHtml(opt_data.authorUserName), '" href="', soy.$$escapeHtml("/wiki"), '/display/~', soy.$$escapeHtml(opt_data.authorUserName), '" title="" data-user-hover-bound="true">');
    aui.avatar.avatar({size: opt_data.size, avatarImageUrl: opt_data.authorAvatarUrl, extraClasses: 'ic-author-avatar'}, output);
    output.append('</a>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.sidebarHeading = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-sidebar-heading"><div id="ic-nav-container">');
  if (opt_data.createComment == true) {
    Confluence.Templates.IC.navigation({disabled: true, showIndex: false}, output);
  }
  output.append('</div><div class="ic-right-toolbar">');
  if (opt_data.showMenu) {
    Confluence.Templates.IC.commentMenu(opt_data, output);
  }
  aui.buttons.button({type: 'text', extraClasses: 'aui-button-text ic-action-hide', iconType: 'aui', iconClass: 'aui-icon-small aui-iconfont-close-dialog', text: '', extraAttributes: {'title': "Close sidebar (])"}}, output);
  output.append('</div></div><div class="ic-error"></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.commentHeader = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-author">');
  Confluence.Templates.IC.authorAvatar({authorUserName: opt_data.authorUserName, authorAvatarUrl: opt_data.authorAvatarUrl, size: 'small'}, output);
  Confluence.Templates.User.usernameLink({canView: opt_data.authorUserName != '', username: opt_data.authorUserName, fullName: opt_data.authorDisplayName}, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.timeLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a class="ic-date-link" title="', soy.$$escapeHtml(opt_data.time), '" href="', soy.$$escapeHtml("/wiki" + opt_data.commentUrl), '"><span>', soy.$$escapeHtml(opt_data.time), '</span></a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:library', location = 'lib/jquery.textHighlighter.js' */
(function(f,e,b,g){var a={ELEMENT_NODE:1,TEXT_NODE:3};var d={name:"textHighlighter"};function c(i,h){this.context=i;this.$context=f(i);this.options=f.extend({},f[d.name].defaults,h);this.init()}c.prototype={init:function(){this.$context.addClass(this.options.contextClass);this.bindEvents()},destroy:function(){this.unbindEvents();this.$context.removeClass(this.options.contextClass);this.$context.removeData(d.name)},bindEvents:function(){},unbindEvents:function(){},highlightHandler:function(i){var h=i.data.self;h.doHighlight()},doHighlight:function(k){var i=k||this.getCurrentRange();if(!i||i.collapsed){return}var j=i.toString();var l="";if(this.options.onBeforeHighlight(i)==true){var m=f.textHighlighter.createWrapper(this.options);var h=this.highlightRange(i,m);l=this.normalizeHighlights(h);this.options.onAfterHighlight(l,j)}this.removeAllRanges();return l},getCurrentRange:function(){var i=this.getCurrentSelection();var h;if(i.rangeCount>0){h=i.getRangeAt(0)}return h},removeAllRanges:function(){var h=this.getCurrentSelection();h.removeAllRanges()},getCurrentSelection:function(){var i=this.getCurrentWindow();var h;if(i.getSelection){h=i.getSelection()}else{if(f("iframe").length){f("iframe",top.document).each(function(){if(this.contentWindow===i){h=rangy.getIframeSelection(this);return false}})}else{h=rangy.getSelection()}}return h},getCurrentWindow:function(){var h=this.getCurrentDocument();if(h.defaultView){return h.defaultView}else{return h.parentWindow}},getCurrentDocument:function(){return this.context.ownerDocument?this.context.ownerDocument:this.context},highlightRange:function(o,q){if(o.collapsed){return}var s=["SCRIPT","STYLE","SELECT","BUTTON","OBJECT","APPLET"];var l=o.startContainer;var t=o.endContainer;var n=o.commonAncestorContainer;var r=true;if(o.endOffset==0){while(!t.previousSibling&&t.parentNode!=n){t=t.parentNode}t=t.previousSibling}else{if(t.nodeType==a.TEXT_NODE){if(o.endOffset<t.nodeValue.length){t.splitText(o.endOffset)}}else{if(o.endOffset>0){t=t.childNodes.item(o.endOffset-1)}}}if(l.nodeType==a.TEXT_NODE){if(o.startOffset==l.nodeValue.length){r=false}else{if(o.startOffset>0){l=l.splitText(o.startOffset);if(t==l.previousSibling){t=l}}}}else{if(o.startOffset<l.childNodes.length){l=l.childNodes.item(o.startOffset)}else{l=l.nextSibling}}var m=false;var k=l;var p=[];do{if(r&&k.nodeType==a.TEXT_NODE){if(/\S/.test(k.nodeValue)){var i=q.clone(true).get(0);var h=k.parentNode;if(f.contains(this.context,h)||h===this.context){var j=f(k).wrap(i).parent().get(0);p.push(j)}}r=false}if(k==t&&(!t.hasChildNodes()||!r)){m=true}if(f.inArray(k.tagName,s)!=-1){r=false}if(r&&k.hasChildNodes()){k=k.firstChild}else{if(k.nextSibling!=null){k=k.nextSibling;r=true}else{k=k.parentNode;r=false}}}while(!m);return p},normalizeHighlights:function(i){this.flattenNestedHighlights(i);this.mergeSiblingHighlights(i);var h=f.map(i,function(j){if(typeof j.parentElement!="undefined"){return j.parentElement!=null?j:null}else{return j.parentNode!=null?j:null}});return h},flattenNestedHighlights:function(i){var h=this;f.each(i,function(k){var o=f(this);var l=o.parent();var n=l.prev();var m=l.next();if(h.isHighlight(l)){if(l.css("background-color")!=o.css("background-color")){if(h.isHighlight(n)&&!o.get(0).previousSibling&&n.css("background-color")!=l.css("background-color")&&n.css("background-color")==o.css("background-color")){o.insertAfter(n)}if(h.isHighlight(m)&&!o.get(0).nextSibling&&m.css("background-color")!=l.css("background-color")&&m.css("background-color")==o.css("background-color")){o.insertBefore(m)}if(l.is(":empty")){l.remove()}}else{var j=b.createTextNode(l.text());l.empty();l.append(j);f(i[k]).remove()}}})},mergeSiblingHighlights:function(i){var h=this;function j(l,k){return k&&k.nodeType==a.ELEMENT_NODE&&f(l).css("background-color")==f(k).css("background-color")&&f(k).hasClass(h.options.highlightedClass)?true:false}f.each(i,function(){var k=this;var n=k.previousSibling;var m=k.nextSibling;if(j(k,n)){var l=f(n).text()+f(k).text();f(k).text(l);f(n).remove()}if(j(k,m)){var l=f(k).text()+f(m).text();f(k).text(l);f(m).remove()}})},setColor:function(h){this.options.color=h},getColor:function(){return this.options.color},removeHighlights:function(j){var h=(j!==g?j:this.context);var l=function(n){return f(n).contents().unwrap().get(0)};var k=function(p){var o=p.previousSibling;var n=p.nextSibling;if(o&&o.nodeType==a.TEXT_NODE){p.nodeValue=o.nodeValue+p.nodeValue;o.parentNode.removeChild(o)}if(n&&n.nodeType==a.TEXT_NODE){p.nodeValue=p.nodeValue+n.nodeValue;n.parentNode.removeChild(n)}};var i=this;var m=this.getAllHighlights(h,true);m.each(function(){if(i.options.onRemoveHighlight(this)==true){var n=l(this)}})},getAllHighlights:function(i,j){var h="."+this.options.highlightedClass;var k=f(i).find(h);if(j==true&&f(i).hasClass(this.options.highlightedClass)){k=k.add(i)}return k},isHighlight:function(h){return h.hasClass(this.options.highlightedClass)},serializeHighlights:function(l){var k=l||this.getAllHighlights(this.context);var i=this.context;var m=[];var h=this;var j=function(o,q){var p=[];do{var n=f.inArray(o,o.parentNode.childNodes);p.unshift(n);o=o.parentNode}while(o!==q);return p};k.each(function(p,o){var r=0;var q=o.firstChild.length;var n=j(o,i);var s=f(o).clone().empty().get(0).outerHTML;if(o.previousSibling&&o.previousSibling.nodeType===a.TEXT_NODE){r=o.previousSibling.length}m.push([f(o).text(),n.join(":"),r,q])});return JSON.stringify(m)},deserializeHighlights:function(i,o){try{var n=JSON.parse(i)}catch(m){throw"Can't parse serialized highlights: "+m}var l=[];var h=this;var j=function(w){var v=w[0];var y=w[1].split(":");var z=w[2];var t=w[3];var u=y.pop();var x=null;var r=h.context;while((x=y.shift())!==g){r=r.childNodes[x]}if(r.childNodes[u-1]&&r.childNodes[u-1].nodeType===a.TEXT_NODE){u-=1}var s=r.childNodes[u];var p=s.splitText(z);p.splitText(t);if(p.nextSibling&&p.nextSibling.nodeValue==""){p.parentNode.removeChild(p.nextSibling)}if(p.previousSibling&&p.previousSibling.nodeValue==""){p.parentNode.removeChild(p.previousSibling)}if(v!==p.nodeValue){throw"Different text"}var q=f(p).wrap(o).parent().get(0);l.push(q)};var k=true;f.each(n,function(q,p){try{j(p)}catch(r){console&&console.warn&&console.warn("Can't deserialize "+q+"-th descriptor. Cause: "+r);k=false;return true}});return k&&l}};f.fn.getHighlighter=function(){return this.data(d.name)};f.fn[d.name]=function(h){return this.each(function(){if(!f.data(this,d.name)){f.data(this,d.name,new c(this,h))}})};f.textHighlighter={createWrapper:function(h){return f("<span></span>").css("backgroundColor",h.color).addClass(h.highlightedClass)},defaults:{color:"#ffff7b",highlightedClass:"highlighted",contextClass:"highlighter-context",onRemoveHighlight:function(){return true},onBeforeHighlight:function(){return true},onAfterHighlight:function(){}}}})(jQuery,window,document);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:library', location = 'lib/WeakMap.js' */
if(typeof WeakMap==="undefined"){(function(){var b=Object.defineProperty;var a=Date.now()%1000000000;var c=function(){this.name="__st"+(Math.random()*1000000000>>>0)+(a+++"__")};c.prototype={set:function(d,f){var e=d[this.name];if(e&&e[0]===d){e[1]=f}else{b(d,this.name,{value:[d,f],writable:true})}},get:function(d){var e;return(e=d[this.name])&&e[0]===d?e[1]:undefined},"delete":function(e){var f=e[this.name];if(!f){return false}var d=f[0]===e;f[0]=f[1]=undefined;return d},has:function(d){var e=d[this.name];if(!e){return false}return e[0]===d}};window.WeakMap=c})()};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:library', location = 'lib/MutationObserver.js' */
(function(r){var w=new WeakMap();var t=window.msSetImmediate;if(!t){var j=[];var o=String(Math.random());window.addEventListener("message",function(z){if(z.data===o){var y=j;j=[];y.forEach(function(A){A()})}});t=function(y){j.push(y);window.postMessage(o,"*")}}var g=false;var i=[];function d(y){i.push(y);if(!g){g=true;t(k)}}function x(y){return window.ShadowDOMPolyfill&&window.ShadowDOMPolyfill.wrapIfNeeded(y)||y}function k(){g=false;var z=i;i=[];z.sort(function(B,A){return B.uid_-A.uid_});var y=false;z.forEach(function(B){var A=B.takeRecords();q(B);if(A.length){B.callback_(A,B);y=true}});if(y){k()}}function q(y){y.nodes_.forEach(function(z){var A=w.get(z);if(!A){return}A.forEach(function(B){if(B.observer===y){B.removeTransientObservers()}})})}function f(E,F){for(var C=E;C;C=C.parentNode){var D=w.get(C);if(D){for(var B=0;B<D.length;B++){var A=D[B];var z=A.options;if(C!==E&&!z.subtree){continue}var y=F(z);if(y){A.enqueue(y)}}}}}var s=0;function n(y){this.callback_=y;this.nodes_=[];this.records_=[];this.uid_=++s}n.prototype={observe:function(C,z){C=x(C);if(!z.childList&&!z.attributes&&!z.characterData||z.attributeOldValue&&!z.attributes||z.attributeFilter&&z.attributeFilter.length&&!z.attributes||z.characterDataOldValue&&!z.characterData){throw new SyntaxError()}var B=w.get(C);if(!B){w.set(C,B=[])}var y;for(var A=0;A<B.length;A++){if(B[A].observer===this){y=B[A];y.removeListeners();y.options=z;break}}if(!y){y=new u(this,C,z);B.push(y);this.nodes_.push(C)}y.addListeners()},disconnect:function(){this.nodes_.forEach(function(A){var B=w.get(A);for(var z=0;z<B.length;z++){var y=B[z];if(y.observer===this){y.removeListeners();B.splice(z,1);break}}},this);this.records_=[]},takeRecords:function(){var y=this.records_;this.records_=[];return y}};function h(y,z){this.type=y;this.target=z;this.addedNodes=[];this.removedNodes=[];this.previousSibling=null;this.nextSibling=null;this.attributeName=null;this.attributeNamespace=null;this.oldValue=null}function p(z){var y=new h(z.type,z.target);y.addedNodes=z.addedNodes.slice();y.removedNodes=z.removedNodes.slice();y.previousSibling=z.previousSibling;y.nextSibling=z.nextSibling;y.attributeName=z.attributeName;y.attributeNamespace=z.attributeNamespace;y.oldValue=z.oldValue;return y}var c,e;function a(y,z){return c=new h(y,z)}function b(y){if(e){return e}e=p(c);e.oldValue=y;return e}function m(){c=e=undefined}function v(y){return y===e||y===c}function l(z,y){if(z===y){return z}if(e&&v(z)){return e}return null}function u(y,A,z){this.observer=y;this.target=A;this.options=z;this.transientObservedNodes=[]}u.prototype={enqueue:function(y){var z=this.observer.records_;var A=z.length;if(z.length>0){var B=z[A-1];var C=l(B,y);if(C){z[A-1]=C;return}}else{d(this.observer)}z[A]=y},addListeners:function(){this.addListeners_(this.target)},addListeners_:function(z){var y=this.options;if(y.attributes){z.addEventListener("DOMAttrModified",this,true)}if(y.characterData){z.addEventListener("DOMCharacterDataModified",this,true)}if(y.childList){z.addEventListener("DOMNodeInserted",this,true)}if(y.childList||y.subtree){z.addEventListener("DOMNodeRemoved",this,true)}},removeListeners:function(){this.removeListeners_(this.target)},removeListeners_:function(z){var y=this.options;if(y.attributes){z.removeEventListener("DOMAttrModified",this,true)}if(y.characterData){z.removeEventListener("DOMCharacterDataModified",this,true)}if(y.childList){z.removeEventListener("DOMNodeInserted",this,true)}if(y.childList||y.subtree){z.removeEventListener("DOMNodeRemoved",this,true)}},addTransientObserver:function(y){if(y===this.target){return}this.addListeners_(y);this.transientObservedNodes.push(y);var z=w.get(y);if(!z){w.set(y,z=[])}z.push(this)},removeTransientObservers:function(){var y=this.transientObservedNodes;this.transientObservedNodes=[];y.forEach(function(A){this.removeListeners_(A);var B=w.get(A);for(var z=0;z<B.length;z++){if(B[z]===this){B.splice(z,1);break}}},this)},handleEvent:function(G){G.stopImmediatePropagation();switch(G.type){case"DOMAttrModified":var A=G.attrName;var B=G.relatedNode.namespaceURI;var H=G.target;var E=new a("attributes",H);E.attributeName=A;E.attributeNamespace=B;var z=G.attrChange===MutationEvent.ADDITION?null:G.prevValue;f(H,function(J){if(!J.attributes){return}if(J.attributeFilter&&J.attributeFilter.length&&J.attributeFilter.indexOf(A)===-1&&J.attributeFilter.indexOf(B)===-1){return}if(J.attributeOldValue){return b(z)}return E});break;case"DOMCharacterDataModified":var H=G.target;var E=a("characterData",H);var z=G.prevValue;f(H,function(J){if(!J.characterData){return}if(J.characterDataOldValue){return b(z)}return E});break;case"DOMNodeRemoved":this.addTransientObserver(G.target);case"DOMNodeInserted":var H=G.relatedNode;var I=G.target;var F,C;if(G.type==="DOMNodeInserted"){F=[I];C=[]}else{F=[];C=[I]}var y=I.previousSibling;var D=I.nextSibling;var E=a("childList",H);E.addedNodes=F;E.removedNodes=C;E.previousSibling=y;E.nextSibling=D;f(H,function(J){if(!J.childList){return}return E})}m()}};r.JsMutationObserver=n;if(!r.MutationObserver){r.MutationObserver=n}})(this);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:util-resource', location = 'util/utils.js' */
define("confluence/ic/util/utils",["jquery","underscore","ajs","backbone","exports"],function(r,K,p,s,A){var i={INLINE_COMMENTS:p.DarkFeatures.isEnabled("confluence-inline-comments"),RESOLVED_INLINE_COMMENTS:p.DarkFeatures.isEnabled("confluence-inline-comments-resolved"),RICH_TEXT_EDITOR:p.DarkFeatures.isEnabled("confluence-inline-comments-rich-editor"),DANGLING_COMMENT:p.DarkFeatures.isEnabled("confluence-inline-comments-dangling-comment")},o=["dateautocomplete","confluencemacrobrowser","propertypanel","jiraconnector","dfe"],j=["autoresize","confluenceleavecomment"];var a,x,m;function H(){return K.clone(i)}function G(){return K.clone(o)}function g(){return K.clone(j)}function d(N,M){var P;if(!N||!M){return}var L=r(N.containingElement);if(!L.is(".inline-comment-marker.valid")){L=r("<div/>").append(N.html).find(".inline-comment-marker.valid")}if(L.length>0){var O=L.first().data("ref");P=M.findWhere({markerRef:O});return P}}function f(L){return p.contextPath()+"/pages/viewpage.action?pageId="+p.Meta.get("latest-page-id")+"&focusedCommentId="+L+"#comment-"+L}function n(R,Q,L){var O=Q.match(/(focusedCommentId|replyToComment)=(\d+)/);if(O==null){return}var N=O[1]==="replyToComment";var P=parseInt(O[2],10);var M=R.findWhere({id:P});if(M!=null){k(R,M,L,N)}else{r.ajax({url:p.contextPath()+"/rest/inlinecomments/1.0/comments/replies/"+P+"/commentId"}).done(function(S){M=R.findWhere({id:S});k(R,M,L,N)})}}function k(O,N,L,M){if(N!=null){if(N.isResolved()){new L({collection:O,focusCommentId:N.get("id")}).render()}else{if(!N.isDangling()){s.trigger("ic:view",N,"permalink",{isReplyComment:M})}}}}function D(){if(p.Meta.get("current-user-avatar-url")){return p.contextPath()+p.Meta.get("current-user-avatar-url")}return p.Meta.get("static-resource-url-prefix")+"/images/icons/profilepics/anonymous.png"}function I(){return p.Meta.get("user-display-name")||p.Meta.get("current-user-fullname")}function b(N){if(typeof N.selectionStart==="number"){var L=N.value.length;N.selectionStart=L;N.selectionEnd=L}else{if(typeof N.createTextRange!=null){N.focus();var M=N.createTextRange();M.collapse(false);M.select()}}}function E(L){b(L);window.setTimeout(function(){b(L)},1)}function z(P,O){var N="webkitAnimationEnd oanimationend msAnimationEnd animationend";var M=P.$wikiContent;var L=r.Deferred();if(O){var Q=r(".inline-comment-marker.active");M.addClass("ic-fade-in-animation");M.one(N,function(){r(this).removeClass("ic-fade-in-animation")});P.$el.addClass("ic-slide-in");P.$el.one(N,function(){r(this).removeClass("ic-slide-in");Q.addClass("ic-highlight-pulse");Q.one(N,function(){Q.removeClass("ic-highlight-pulse")})});L.resolve()}else{M.bind(N,function(R){if(R.originalEvent.animationName=="ic-fade-out-animation"){P.$wikiContent.removeClass("ic-fade-out-animation");P.$wikiContent.css("opacity","0.5")}else{if(R.originalEvent.animationName=="ic-fade-in-animation"){P.$wikiContent.css("opacity","1");P.$wikiContent.removeClass("ic-fade-in-animation");P.$wikiContent.unbind(N)}}});M.addClass("ic-fade-out-animation");P.$el.addClass("ic-slide-out");P.$el.one(N,function(){P.$el.removeClass("ic-slide-out");P._emptySidebar();t().css("padding-right","0");M.addClass("ic-fade-in-animation");M.css("position","static");L.resolve()})}return L.promise()}function h(L){var M=r(L).closest("a");if(!M.length){M=r(L).find("a")}return M}function v(L){L.each(function(){var M=h(this);M.length&&M.off("mousemove")})}function J(){return document.body.style.animation!==undefined||document.body.style.webkitAnimation!==undefined}function c(M){var L=M.parents(".expand-content.expand-hidden");L.each(function(N){r(this).siblings(".expand-control").click()})}function q(M){var L=p.Rte&&p.Rte.getEditor();if(M===true){if(F()&&L&&L.isDirty()){return confirm("Your comment will be lost.")}}else{if(L&&L.isDirty()){return confirm("Your comment will be lost.")}}return true}function F(){return !!r(".ic-sidebar #wysiwygTextarea_ifr").length}function B(){return p.Meta.get("use-keyboard-shortcuts")&&Confluence.KeyboardShortcuts&&Confluence.KeyboardShortcuts.enabled}function l(L){L.$("button.ic-action-hide").tooltip({gravity:"se"});L.$("#ic-nav-next").tooltip({gravity:"s"});L.$("#ic-nav-previous").tooltip({gravity:"s"})}function w(P){if(C()){P.css("padding-bottom","20px");return}var N=P.height();var O=P.offset().top;var M=O+N;var Q=this.getPageContainer().offset().top;var L=M-Q;this.getPageContainer().css({"min-height":L+"px"})}function u(P){P=P.closest(".ic-display-comment-view");var O=this;var M=r(".confluence-embedded-image, .confluence-embedded-file img",P);var N=M.length;var L=0;if(N>0){M.off("load").one("load",function(){if(++L===N){O.recalculateContentHeight(P)}}).each(function(){if(this.complete){r(this).load()}})}}function C(){if(m===undefined){m=!!y().length}return m}function t(){if(a===undefined){a=r("#content")}return a}function y(){if(x===undefined){x=r("#splitter-content")}return x}function e(L,M){if(M&&!M.is(":visible")){return}if(L){if(this.isDocTheme()){this.getSplitterContent().scrollTop(M.offset().top-L)}else{window.scrollTo(0,M.offset().top-L)}}}A.overlappedSelection=d;A.focusedCommentUrl=f;A.showFocusedComment=n;A.getAuthorAvatarUrl=D;A.moveCaretToEnd=E;A.animateSidebar=z;A.getDarkFeatures=H;A.getInlineLinks=h;A.removeInlineLinksDialog=v;A.isAnimationSupported=J;A.showHighlightContent=c;A.getUnsupportedRtePlugins=G;A.getSupportedRtePlugins=g;A.confirmProcess=q;A.getAuthorDisplayName=I;A.isKeyboardShortcutsEnable=B;A.addSidebarHeadingTooltip=l;A.hasEditorInSidebar=F;A.recalculateContentHeight=w;A.resizeContentAfterLoadingImages=u;A.isDocTheme=C;A.getPageContainer=t;A.getSplitterContent=y;A.scrollToCommentAfterToggleSideBar=e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:util-resource', location = 'util/text-highlighter.js' */
define("confluence/ic/util/text-highlighter",["jquery"],function(c){var a="ic-current-selection";function b(){c.textHighlighter.createWrapper=function(d){return c("<span></span>").addClass(d.highlightedClass)};this.$el=c("#content .wiki-content").first();if(this.$el.length>0){this.$el.textHighlighter({highlightedClass:a})}}b.prototype.highlight=function(e){if(this.$el.length===0){return}var d=c(this.$el.getHighlighter().doHighlight(e));return this.$el.getHighlighter().serializeHighlights(d)};b.prototype.removeHighlight=function(){if(this.$el.length===0){return}this.$el.getHighlighter().removeHighlights();return this};b.prototype.deserializeHighlights=function(d,e){if(this.$el.length===0){return}var f='<span class="inline-comment-marker" data-ref="'+e+'"></span>';return this.$el.getHighlighter().deserializeHighlights(d,f)};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.editor:editor-core-resources', location = 'loader/profiles.js' */
AJS.Confluence=AJS.Confluence||{};AJS.Confluence.Editor=AJS.Confluence.Editor||{};
AJS.Confluence.Editor._Profiles=function(){return{createProfileForCommentEditor:function(){return{plugins:"searchreplace confluenceimagedialog autocompletemacro confluencemacrobrowser confluenceleavecomment confluencewatch autoresize".split(" ")}},createProfileForPageEditor:function(a){var b="searchreplace confluencedrafts confluenceimagedialog autocompletemacro confluencemacrobrowser flextofullsize referrer".split(" ");AJS.Meta.getBoolean("shared-drafts")&&b.push("unpublishedchanges");a&&a.versionComment&&
b.push("confluenceversioncomment");a&&a.notifyWatchers&&b.push("confluencenotifywatchers");return{plugins:b}},createProfileForTemplateEditor:function(){return{plugins:"searchreplace confluenceimagedialog autocompletemacro confluencemacrobrowser confluenceleavetemplate flextofullsize confluencetemplateeditor".split(" ")}}}}();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/quick-edit.js' */
(function(b){function k(){var a=new b.Deferred;AJS.Confluence.EditorLoader.load(function(){setTimeout(function(){a.resolve()},0)},function(){a.reject()});return a}var l=AJS.DarkFeatures.isEnabled("editor.quicker.quick.comment.disable"),i={enableShortcut:function(){b("#editPageLink").addClass("full-load")},disableShortcut:function(){b("#editPageLink").removeClass("full-load")}},d=[];AJS.Confluence.QuickEdit={loadingContentTimeout:4E3,register:function(a){d.push(a)},disableHandlers:function(){b.each(d,
function(a,b){return b.disable()})},enableHandlers:function(){b.each(d,function(a,b){return b.enable()})},SaveBarBinder:{bind:function(a,b){a&&(Confluence.Editor.removeAllSaveHandlers(),Confluence.Editor.addSaveHandler(a));b&&(Confluence.Editor.removeAllCancelHandlers(),Confluence.Editor.addCancelHandler(b))}},activateEditor:function(a){function f(){var f,g=new b.Deferred;if(AJS.Rte&&AJS.Rte.getEditor())return AJS.debug("there is already an editor open"),g.reject("there is already an editor open");
if(!a.$container||!a.$form)return AJS.logError("activateEditor could not be initialsed: bad arguments",a),g.reject("bad parameters");f=AJS.Confluence.BlockAndBuffer.block(b(document));a.preActivate&&a.preActivate();i.disableShortcut();var e=a.timeoutResources||AJS.Confluence.EditorLoader.loadingTimeout,d=AJS.Confluence.QuickEdit.loadingContentTimeout,h=AJS.Confluence.QuickEdit.Util.timeoutDeferred;b.when(h(k(),e),h(a.fetchContent||b.when(),d)).done(function(e,d){var c={$container:a.$container,content:d,
$form:a.$form,replayBufferedKeys:f};a.preInitialise&&a.preInitialise(c);b(".quick-comment-prompt",c.$container).hide();b(".quick-comment-body",c.$container).addClass("comment-body");var j=AJS.Confluence.EditorLoader.getPreloadContainer();if(c.content&&c.content.title){var i=c.content.title;j.find("#content-title").val(i)}c.$form.append(j.children());j.show();b("#editor-precursor").hide();b("#rte-savebar").find(".toolbar-split-left").hide();var h=function(){c.editor=AJS.Rte.getEditor();l&&(AJS.Confluence.QuickEdit.disableHandlers(),
AJS.Confluence.QuickEdit.QuickComment.TopLevel.bindCommentAreaFallbackHandler());c.$container.find(".quick-comment-loading-container").hide();c.$form.show();c.$form.addClass("fadeIn");var d=c.editor,f=c.content?c.content.editorContent:"",e=c.replayBufferedKeys;f&&(d.setContent(f),d.startContent=d.getContent({format:"raw",no_events:1}),d.undoManager.clear());e();d.undoManager.add();AJS.trigger("quickedit.success");AJS.trigger("quickedit.visible");AJS.trigger("add-bindings.keyboardshortcuts");AJS.trigger("active.dynamic.rte");
b("div.aui-message.closeable").each(function(){var a=b(this),c;if(!a.find(".icon-close").length){c=b('<span class="aui-icon icon-close" role="button" tabindex="0"></span>').click(function(){a.closeMessage()}).keypress(function(b){if(b.which===AJS.keyCode.ENTER||b.which===AJS.keyCode.SPACE){a.closeMessage();b.preventDefault()}});a.append(c)}});a.postInitialise&&a.postInitialise(c);AJS.Confluence.QuickEdit.SaveBarBinder.bind(a.saveHandler,a.cancelHandler);AJS.trigger("rte-quick-edit-ready");AJS.unbind("rte-ready",
h);g.resolve()};AJS.bind("rte-ready",h);AJS.bind("rte-destroyed",a.postDeactivate||function(){});AJS.Rte.BootstrapManager.initialise({plugins:a.plugins,toolbar:a.toolbar,excludePlugins:a.excludePlugins,isQuickEdit:!0})}).fail(function(b){g.reject(b);AJS.logError("Error loading page quick edit. Falling back to normal edit URL...");AJS.trigger("analytics",{name:"rte.quick-edit.activate-editor.failed"});a.fallbackUrl&&(AJS.log("This parameter is deprecated. To be removed in the next major version (5.8 or 6.0). Please use the promise returned to bind custom action if the editor fails to load instead."),
window.location=a.fallbackUrl)});return g.promise()}if(a.closeAnyExistingEditor&&AJS.Rte&&AJS.Rte.getEditor()){var e=new b.Deferred;this.deactivateEditor().done(function(){f().done(function(){e.resolve()}).fail(function(a){e.reject(a)})}).fail(function(){AJS.debug("Could not deactivate current editor.");e.reject("Could not deactivate current editor.")});return e}return f()},deactivateEditor:function(){tinymce.execCommand("mceRemoveControl",!0,"wysiwygTextarea");Confluence.Editor.UI.toggleSavebarBusy(!1);
var a=AJS.Confluence.EditorLoader.getPreloadContainer().empty();b(".editor-container").remove();b("#editor-precursor").remove();b("#anonymous-warning").remove();b(".quick-comment-prompt").show();b(".bottom-comment-panels").show();b("#editor-notification-container").empty();b(".action-reply-comment").removeAttr("reply-disabled");i.enableShortcut();return AJS.Confluence.EditorLoader.getEditorPreloadMarkup().done(function(b){a.append(b);a.hide();(new AJS.Confluence.QuickEditCaptchaManager(a)).refreshCaptcha();
AJS.trigger("rte-destroyed");AJS.unbind("rte-destroyed")})}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/util.js' */
(function(){AJS.Confluence.QuickEdit.Util={generateUUID:function(){var a=function(){return Math.floor(65536*(1+Math.random())).toString(16).substring(1)};return a()+a()+"-"+a()+"-"+a()+"-"+a()+"-"+a()+a()+a()},getBaseUrl:function(){var a=window.location.protocol.replace(/:$/,"")+"://"+window.location.host+"/"+window.location.pathname.replace(/^\//,""),b=window.location.search.replace(/^\?/,""),b=b.replace(/\&?focusedCommentId=\d+/,""),b=b.replace(/^\&/,"");return{url:a,search:b,addQueryParam:function(a,
b){this.search=this.search?this.search+"&"+a+"="+b:a+"="+b},toString:function(){return this.url+"?"+this.search}}},timeoutDeferred:function(a,b){setTimeout(function(){"pending"===a.state()&&a.reject("timeout")},b);return a}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/captcha-manager.js' */
(function(d){AJS.Confluence.QuickEditCaptchaManager=function(e){function a(a){return d(e||"body").find(a)}return{refreshCaptcha:function(){var b=a("img.captcha-image");if(0<b.length){var c=Math.random();b.attr("src",AJS.contextPath()+"/jcaptcha?id="+c);a('input[name="captchaId"]').val(c);a('input[name="captchaResponse"]').val("")}},getCaptchaData:function(){return{id:a('input[name="captchaId"]').val(),response:a('input[name="captchaResponse"]').val()}}}}})($);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/handlers/shortcut.js' */
(function(){var c=!1;AJS.bind("initialize.keyboardshortcuts add-bindings.keyboardshortcuts",function(){c=!0});AJS.bind("remove-bindings.keyboardshortcuts",function(){c=!1});AJS.Confluence.QuickEdit=AJS.Confluence.QuickEdit||{};AJS.Confluence.QuickEdit.KeyboardShortcuts={createShortcut:function(e,f){function a(){b=b||AJS.whenIType(e).moveToAndClick(f)}function d(){b&&b.unbind();b=null}var b;return{bind:function(){c&&a();AJS.bind("initialize.keyboardshortcuts",a);AJS.bind("add-bindings.keyboardshortcuts",
a);AJS.bind("remove-bindings.keyboardshortcuts",d)},unbind:function(){d();AJS.unbind("initialize.keyboardshortcuts",a);AJS.unbind("add-bindings.keyboardshortcuts",a);AJS.unbind("remove-bindings.keyboardshortcuts",d)}}}}})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/handlers/page.js' */
(function(b){function g(a){AJS.Confluence.QuickEdit.QuickEditPage.disable();AJS.populateParameters();var c=a.$form,e="page"===AJS.Data.get("content-type")?"doeditpage":"doeditblogpost",e=Confluence.getContextPath()+"/pages/"+e+".action?pageId="+Confluence.getContentId();b(".ia-splitter-left").remove();try{b("#main").unwrap()}catch(d){}b("#rte").removeClass("editor-default").addClass("editor-fullheight");a.$container.children().remove();b(".editor-container").children().eq(0).unwrap();c.attr({"class":"editor aui",
action:e,name:"editpageform",id:"editpageform",style:""});a.$container.append(c);a.$container.removeClass("view").addClass("edit");b("body").addClass("contenteditor edit")}function h(a){b("#editor-precursor").show();b("#rte-savebar").find(".toolbar-split-left").show();if(window.history.pushState){var c=b("#editPageLink").attr("href");c!=window.location.pathname+window.location.search&&(history.pushState({quickEdit:!0},"",c),AJS.trigger("rte-quick-edit-push-state",c))}else window.location.hash="editor",
AJS.trigger("rte-quick-edit-push-hash");c=a.content;if(c.permissions)for(var d in c.permissions)b("#"+d).attr("value",c.permissions[d]);b("#originalVersion").val(a.content.pageVersion);a=a.content.atlToken;AJS.Meta.set("atl-token",a);b('input[name="atl_token"]').val(a);AJS.trigger("analyticsEvent",{name:"quick-edit-success"});b("#navigation").remove()}function i(){var a=new b.Deferred,c=b.ajax({url:Confluence.getContextPath()+"/rest/tinymce/1/content/"+Confluence.getContentId()+".json",cache:!1});
c.success(function(b){a.resolve(b)});c.error(function(){a.reject("error fetching content")});return a}var f,d={editShortcut:AJS.Confluence.QuickEdit.KeyboardShortcuts.createShortcut("e","#editPageLink"),activateEventHandler:function(a){if(!a.metaKey&&!a.shiftKey&&!a.ctrlKey&&!a.altKey&&!(2==a.which||3==a.which))a.preventDefault(),f&&"pending"===f.state()?AJS.debug("Editor is being activated. Ignoring handler..."):(f=d.activateEditor(),a=b("#editPageLink"),a.find(".aui-icon").css("visibility","hidden"),
a.parent().spin({left:"10px"}))},enable:function(){if(b("body").is(".theme-default")){var a=b("#editPageLink");a.bind("click",d.activateEventHandler);a.removeClass("full-load");d.editShortcut.bind();AJS.debug("QuickPageEdit enabled")}else AJS.debug("QuickPageEdit not enabled")},activateEditor:function(){var a=b("#content").find(".quick-comment-form");return AJS.Confluence.QuickEdit.activateEditor({fetchContent:i(),$container:b("#content"),$form:a.length?a:b('<form method="post"></form>'),preInitialise:g,
postInitialise:h,saveHandler:function(){1<Confluence.Editor.getNumConcurrentEditors()&&AJS.Confluence.Analytics.publish("rte.notification.concurrent-editing.save",{numEditors:Confluence.Editor.getNumConcurrentEditors(),pageId:AJS.params.pageId,draftType:AJS.params.draftType})},cancelHandler:function(){1<Confluence.Editor.getNumConcurrentEditors()&&AJS.Confluence.Analytics.publish("rte.notification.concurrent-editing.cancel",{numEditors:Confluence.Editor.getNumConcurrentEditors(),pageId:AJS.params.pageId,
draftType:AJS.params.draftType})},plugins:AJS.Confluence.Editor._Profiles.createProfileForPageEditor({versionComment:!0,notifyWatchers:!0}).plugins}).fail(function(){window.location=b("#editPageLink").attr("href")})},disable:function(){AJS.debug("QuickPageEdit disabled.");d.editShortcut.unbind();b("#editPageLink").unbind("click",d.activateEventHandler)}};AJS.Confluence.QuickEdit.QuickEditPage={disable:d.disable};b.browser.msie&&9>+b.browser.version||AJS.Confluence.QuickEdit.register(d)})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/init.js' */
(function(a){var b=function(){AJS.DarkFeatures.isEnabled("shipit25.quick.edit.defer")?AJS.debug("QuickComment: editor preload is disabled"):a(window).load(function(){AJS.debug("QuickComment: instigated background loading of the comment editor.");AJS.Confluence.EditorLoader.load()});AJS.Confluence.QuickEdit.enableHandlers();AJS.trigger("rte-quick-edit-enable-handlers")};AJS.DarkFeatures.isEnabled("disable-quick-edit")?AJS.log("disable-quick-edit is turned on; run AJS.Confluence.EditorLoader.load() manually."):
AJS.toInit(b)})($);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment.js' */
(function(c){function i(a,b){var d=a.match(RegExp("[?&]"+b+"=(\\d+)"));return d&&1<d.length?parseInt(d[1]):0}c(function(){AJS.AppLinksInitialisationBinder=function(a){AJS.bind("init.rte",a)}});AJS.Confluence.QuickEdit.QuickComment={preInitialise:function(){AJS.Confluence.QuickEdit.QuickEditPage.disable();AJS.Meta.set("content-type","comment");AJS.Meta.set("draft-type","");AJS.params.contentType="comment";AJS.params.draftType="";AJS.Meta.set("use-inline-tasks","false");c("#editor-precursor").children().eq(0).hide();
c("#pagelayout-menu").parent().hide();c("#page-layout-2-group").hide();c("#rte-button-tasklist").remove();c("#rte-insert-tasklist").parent().remove()},postInitialise:function(a){c("head").append(AJS.Meta.get("editor.loader.comment.resources"));AJS.Rte.editorFocus(a.editor)},delegatingSaveCommentHandler:function(a){return a.asyncRenderSafe?AJS.Confluence.QuickEdit.QuickComment.ajaxSaveCommentHandler(a):AJS.Confluence.QuickEdit.QuickComment.reloadPageSaveCommentHandler(a)},reloadPageSaveCommentHandler:function(a){var b=
AJS.Confluence.QuickEdit.Util.getBaseUrl();b.addQueryParam("focusedCommentId",a.id);b.addQueryParam("refresh",+new Date);window.location.href=b.toString()+"#comment-"+a.id},ajaxSaveCommentHandler:function(a){var b={isDefault:!0,path:AJS.Meta.get("static-resource-url-prefix")+"/images/icons/profilepics/default.png"};"/images/icons/profilepics/default.png"!==AJS.Meta.get("current-user-avatar-url")&&(b={isDefault:!1,path:AJS.contextPath()+AJS.Meta.get("current-user-avatar-url")});var d=AJS.Meta.get("remote-user"),
c={userName:""==d?null:d,displayName:AJS.Meta.get("current-user-fullname"),profilePicture:b};AJS.Confluence.QuickEdit.QuickComment.cancelComment().done(function(){Confluence.CommentDisplayManager.addOrUpdateComment(c,a,!0,!1);AJS.trigger("page.commentAddedOrUpdated",{commentId:a.id})})},cancelHandler:function(){if(Confluence.Editor.UI.isFormEnabled()&&(Confluence.Editor.hasContentChanged()&&!Confluence.Editor.isEmpty())&&!confirm("Your comment will be lost."))return!1;AJS.Rte.Content.editorResetContentChanged();
AJS.Confluence.QuickEdit.deactivateEditor()},createCommenterParam:function(a,b,c){return{userName:b||AJS.Meta.get("remote-user")||null,displayName:c||AJS.Meta.get("user-display-name"),profilePicture:{isDefault:a.hasClass("defaultLogo"),path:a.attr("src")}}},createSaveHandler:function(a,b){var d=Confluence.QuickEdit.Util.generateUUID();return function(g){g.preventDefault();if(AJS.Rte.Content.isEmpty())AJS.Confluence.EditorNotification.clear(),AJS.Confluence.EditorNotification.notify("warning","Comment text is empty. Cannot create empty comments.",
8);else if(Confluence.Editor.UI.toggleSavebarBusy(!0)){var e=g=0,f=AJS.Confluence.EditorLoader.getEditorForm();f.is("form")&&(e=f.attr("action"),g=i(e,"parentId"),e=i(e,"commentId"));var h=new AJS.Confluence.QuickEditCaptchaManager(f),f=function(a){b(a);h.refreshCaptcha()},j=c("#watchPage").is(":checked");0<e?Confluence.Editor.CommentManager.updateComment(Confluence.getContentId(),e,AJS.Rte.Content.getHtml(),j,h.getCaptchaData(),a,f):Confluence.Editor.CommentManager.saveComment(Confluence.getContentId(),
g,AJS.Rte.Content.getHtml(),j,d,h.getCaptchaData(),a,f)}else AJS.log("QuickComment: subsequent save operation attempted but ignored.")}},saveCommentErrorHandler:function(a){Confluence.Editor.UI.toggleSavebarBusy(!1);var b;b=a&&-1!=a.search(/captcha/i)?"The typed word did not match the text in the picture.":"Failed to save the comment. Please try again later.";AJS.logError("Error saving comment",a);AJS.Confluence.EditorNotification.clear();AJS.Confluence.EditorNotification.notify("error",b,30)},cancelComment:function(){AJS.Rte.Content.editorResetContentChanged();
return AJS.Confluence.QuickEdit.deactivateEditor()},proceedWithActivation:function(){var a=new c.Deferred,b=AJS.Rte&&AJS.Rte.getEditor();if(b)if(b.isDirty()&&!Confluence.Editor.isEmpty())if(confirm("Your comment will be lost."))a=AJS.Confluence.QuickEdit.QuickComment.cancelComment();else return a.reject();else a=AJS.Confluence.QuickEdit.QuickComment.cancelComment();else a.resolve();return a}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment/top-level.js' */
(function(a){function d(a){AJS.Confluence.QuickEdit.QuickComment.preInitialise(a)}function e(b){a("#rte-savebar").scrollWindowToElement();AJS.Confluence.QuickEdit.QuickComment.postInitialise(b)}function f(){AJS.Confluence.EditorLoader.resourcesLoaded()||(AJS.trigger("analytics",{name:"rte.quick-edit.top-comment.spinner"}),a(".quick-comment-prompt").hide(),a(".quick-comment-loading-container").fadeIn().spin("medium"))}function g(b){b.preventDefault();window.location=a("#add-comment-rte").attr("href")}
var c={commentShortcut:AJS.Confluence.QuickEdit.KeyboardShortcuts.createShortcut("m",".quick-comment-prompt"),activateEventHandler:function(b){b.preventDefault();AJS.Confluence.QuickEdit.QuickComment.proceedWithActivation().done(function(){var b=AJS.Confluence.QuickEdit.QuickComment.createSaveHandler(AJS.Confluence.QuickEdit.QuickComment.delegatingSaveCommentHandler,AJS.Confluence.QuickEdit.QuickComment.saveCommentErrorHandler);return AJS.Confluence.QuickEdit.activateEditor({preActivate:f,$container:a("form[name=inlinecommentform]").closest(".quick-comment-container"),
$form:a("form[name=inlinecommentform]"),preInitialise:d,saveHandler:b,cancelHandler:AJS.Confluence.QuickEdit.QuickComment.cancelHandler,postInitialise:e,plugins:AJS.Confluence.Editor._Profiles.createProfileForCommentEditor().plugins}).fail(function(){window.location=a("#add-comment-rte").attr("href")})})},enable:function(){a("#comments-section").delegate(".quick-comment-prompt","click",c.activateEventHandler);a("#add-comment-rte").removeClass("full-load");this.commentShortcut.bind()},disable:function(){a("#comments-section").undelegate(".quick-comment-prompt",
"click");this.commentShortcut.unbind()}};AJS.Confluence.QuickEdit.QuickComment.TopLevel={bindCommentAreaFallbackHandler:function(){a("#comments-section").delegate(".quick-comment-prompt","click",g)},cancelComment:function(){AJS.log("'AJS.Confluence.QuickEdit.QuickComment.TopLevel.cancelComment' is deprecated in 5.7, consider using 'AJS.Confluence.QuickEdit.QuickComment.cancelComment' instead.");return AJS.Confluence.QuickEdit.QuickComment.cancelComment()}};AJS.Confluence.QuickEdit.register(c)})($);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment/reply.js' */
(function(a){function g(a){AJS.Confluence.QuickEdit.QuickComment.preInitialise(a);a.$container.scrollWindowToElement()}function h(a){AJS.Confluence.QuickEdit.QuickComment.postInitialise(a)}function f(a){var d=a.attr("id").match(/comment-(\d+)/),e=0;d?e=parseInt(d[1]):(AJS.trigger("analytics",{name:"rte.quick-edit.get-reply-parent.failed"}),AJS.logError("replyHandler: activateEventHandler - could not extract a parent comment Id from the comment id "+a.attr("id")));return e}function i(){a(".comment.reply").closest(".comment-threads").remove()}
var c={activateEventHandler:function(c){c.preventDefault();c.stopPropagation();var d=this;if(a(d).attr("reply-disabled"))return!1;AJS.Confluence.QuickEdit.QuickComment.proceedWithActivation().done(function(){var e=a(d).closest("div.comment");a(".quick-comment-form").removeClass("quick-comment-form");var b=a(".quick-comment-container img.userLogo"),b=AJS.Confluence.QuickEdit.QuickComment.createCommenterParam(b),b={contentId:Confluence.getContentId(),parentCommentId:f(e),commenter:b,context:{contextPath:AJS.Meta.get("context-path"),
staticResourceUrlPrefix:AJS.Meta.get("static-resource-url-prefix")}},b=a(Confluence.Templates.Comments.displayReplyEditorLoadingContainer(b)),c=a(".quick-comment-loading-container",b);c.hide();e.after(b);AJS.Confluence.EditorLoader.resourcesLoaded()?AJS.trigger("analytics",{name:"rte.quick-edit.reply-comment.no-spinner"}):(AJS.trigger("analytics",{name:"rte.quick-edit.reply-comment.spinner"}),e.after(b),c.fadeIn(),c.spin("medium"),c[0].scrollIntoView());b=a(d).closest(".comment-thread").find(".quick-comment-container");
AJS.Meta.set("form-name",a("form",b).attr("name"));AJS.Confluence.QuickEdit.activateEditor({$container:b,$form:b.find(".quick-comment-form"),preInitialise:g,postInitialise:h,saveHandler:AJS.Confluence.QuickEdit.QuickComment.createSaveHandler(AJS.Confluence.QuickEdit.QuickComment.delegatingSaveCommentHandler,AJS.Confluence.QuickEdit.QuickComment.saveCommentErrorHandler),cancelHandler:AJS.Confluence.QuickEdit.QuickComment.cancelHandler,plugins:AJS.Confluence.Editor._Profiles.createProfileForCommentEditor().plugins,
postDeactivate:i}).fail(function(){window.location=a("#reply-comment-"+f(e)).attr("href")});a(d).attr("reply-disabled",!0)})},enable:function(){a("#comments-section").delegate(".action-reply-comment","click",c.activateEventHandler)},disable:function(){a("#comments-section").undelegate(".action-reply-comment","click")}};AJS.Confluence.QuickEdit.QuickComment.Reply={cancelComment:function(){AJS.log("'AJS.Confluence.QuickEdit.QuickComment.Reply.cancelComment' is deprecated in 5.7, consider using 'AJS.Confluence.QuickEdit.QuickComment.cancelComment' instead.");
return AJS.Confluence.QuickEdit.QuickComment.cancelComment()}};AJS.Confluence.QuickEdit.register(c)})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment/edit.js' */
(function(c){function h(a){AJS.Confluence.QuickEdit.QuickComment.preInitialise(a);a.$container.scrollWindowToElement()}function i(a){AJS.Confluence.QuickEdit.QuickComment.postInitialise(a)}function f(a){return(a=a.attr("id").match(/comment-(\d+)/))?parseInt(a[1]):0}function j(a){var d=new c.Deferred;c.ajax({url:Confluence.getContextPath()+"/rest/api/content/"+a+"?expand=body.editor",cache:!1}).done(function(a){!a||!a.body||!a.body.editor?d.reject("invalid response from loading comment rest endpoint"):
d.resolve({editorContent:a.body.editor.value})}).fail(function(){d.reject("error fetching content")});return d}function k(){var a=c(".comment.edit");a.prev(".comment").show();a.remove()}var l=AJS.DarkFeatures.isEnabled("editor.quicker.quick.comment.edit.disable"),g={activateEventHandler:function(a){var d=this;a.preventDefault();a.stopPropagation();AJS.Confluence.QuickEdit.QuickComment.proceedWithActivation().done(function(){var a=c(d).closest("div.comment");c(".quick-comment-form").removeClass("quick-comment-form");
var b;b=a.find(".author .confluence-userlink");var e=a.find(".comment-user-logo img.userLogo");b=AJS.Confluence.QuickEdit.QuickComment.createCommenterParam(e,b.attr("data-username"),b.text());b={contentId:Confluence.getContentId(),commentId:f(a),commenter:b,context:{contextPath:AJS.Meta.get("context-path"),staticResourceUrlPrefix:AJS.Meta.get("static-resource-url-prefix")},mode:"edit"};b=c(Confluence.Templates.Comments.displayEditEditorContainer(b));e=c(".quick-comment-loading-container",b);a.hide();
a.after(b);e.fadeIn().spin("medium");e[0].scrollIntoView();b=a.next(".quick-comment-container");AJS.Meta.set("form-name",c("form",b).attr("name"));AJS.Confluence.QuickEdit.activateEditor({$container:b,$form:b.find(".quick-comment-form"),fetchContent:j(f(a)),preInitialise:h,postInitialise:i,saveHandler:AJS.Confluence.QuickEdit.QuickComment.createSaveHandler(AJS.Confluence.QuickEdit.QuickComment.delegatingSaveCommentHandler,AJS.Confluence.QuickEdit.QuickComment.saveCommentErrorHandler),cancelHandler:AJS.Confluence.QuickEdit.QuickComment.cancelHandler,
plugins:AJS.Confluence.Editor._Profiles.createProfileForCommentEditor().plugins,postDeactivate:k}).fail(function(){window.location=c("#edit-comment-"+f(a)).attr("href")})})},enable:function(){c("#comments-section").delegate(".comment-action-edit","click",g.activateEventHandler)},disable:function(){c("#comments-section").undelegate(".comment-action-edit","click")}};AJS.Confluence.QuickEdit.QuickComment.Edit={cancelComment:function(){AJS.log("'AJS.Confluence.QuickEdit.QuickComment.Edit.cancelComment' is deprecated in 5.7, consider using 'AJS.Confluence.QuickEdit.QuickComment.cancelComment' instead.");
return AJS.Confluence.QuickEdit.QuickComment.cancelComment()}};l||AJS.Confluence.QuickEdit.register(g)})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/editor-comment-manager.js' */
AJS.bind("init.rte",function(){var k=AJS.$,j=function(a,d,e,h,b,f,g){a={type:"POST",url:a,contentType:"application/x-www-form-urlencoded; charset=UTF-8",data:{html:d,watch:e,uuid:h},dataType:"json",cache:!1,headers:{"X-Atlassian-Token":"nocheck"},success:function(a){f(a)},error:function(a,c,b){c=c+": "+b;a.responseText&&(c=c+" - "+a.responseText);g(c)},timeout:12E4};b&&b.id&&(a.headers["X-Atlassian-Captcha-Id"]=b.id,a.headers["X-Atlassian-Captcha-Response"]=b.response);k.ajax(a)};Confluence.Editor.CommentManager=
{addComment:function(a,d,e,h,b,f,g,i,c){Confluence.Editor.CommentManager.saveComment(a,d,e,function(a){Confluence.CommentDisplayManager.addComment(g,a,f);i(a)},c)},saveComment:function(a,d,e,h,b,f,g,i){var c=null,c=d?Confluence.getContextPath()+"/rest/tinymce/1/content/"+a+"/comments/"+d+"/comment?actions=true":Confluence.getContextPath()+"/rest/tinymce/1/content/"+a+"/comment?actions=true";j(c,e,h,b,f,g,i)},updateComment:function(a,d,e,h,b,f,g){a=Confluence.getContextPath()+"/rest/tinymce/1/content/"+
a+"/comments/"+d+"?actions=true";j(a,e,h,null,b,f,g)}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:editor', location = 'editor/editor.js' */
define("confluence/ic/editor/editor",["jquery","ajs","confluence/ic/util/utils","exports"],function(e,h,f,c){function b(){if(!h.Confluence.EditorLoader.resourcesLoaded()){this.$form.find(".loading-container").spin("small")}}function i(){h.Meta.set("content-type","comment");h.Meta.set("use-inline-tasks","false");h.Meta.set("min-editor-height",80)}function k(l){l.$form.find(".loading-container").hide();l.$form.find("#rte-button-publish").text("Save").removeAttr("title");l.$form.find("#toolbar-hints-draft-status").hide();if(this.hideCancelButton){l.$form.find("#rte-button-cancel").hide()}var m=tinymce.DOM;m.setStyle(m.get(l.editor.id+"_ifr"),"height","80px");h.Confluence.QuickEdit.QuickEditPage.disable()}function j(l){return h.Confluence.QuickEdit.activateEditor({preActivate:b,preInitialise:i,postInitialise:e.proxy(k,l),toolbar:false,$container:l.container,$form:l.form,saveHandler:l.saveHandler,cancelHandler:l.cancelHandler,fetchContent:l.fetchContent(),closeAnyExistingEditor:true,postDeactivate:l.postDeactivate,plugins:f.getSupportedRtePlugins(),excludePlugins:f.getUnsupportedRtePlugins()})}function d(){if(h.Rte&&h.Rte.getEditor()){return h.Confluence.QuickEdit.deactivateEditor()}else{return e.Deferred().resolve()}}function a(){return h.Rte.Content.getHtml()}function g(l){if(l){e(".ic-sidebar #rte-spinner").spin()}else{e(".ic-sidebar #rte-spinner").spinStop()}e("#rte-button-publish").prop("disabled",l)}c.init=j;c.remove=d;c.getContent=a;c.setEditorBusy=g});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:create-comment-view', location = 'view/create-comment/create-comment.soy' */
// This file was automatically generated from create-comment.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.createComment = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-comment-container">');
  if (opt_data.type == 'topLevel') {
    Confluence.Templates.IC.sidebarHeading({showMenu: false, createComment: true, darkFeatures: opt_data.darkFeatures}, output);
  }
  Confluence.Templates.IC.commentForm(opt_data, output);
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.commentForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-container ic-create-comment">');
  Confluence.Templates.IC.commentHeader(opt_data, output);
  output.append('<div class="ic-body"><form class="aui">');
  if (! opt_data.darkFeatures.RICH_TEXT_EDITOR) {
    var placeholder__soy27 = new soy.StringBuilder((opt_data.type == 'reply') ? soy.$$escapeHtml("Reply") : soy.$$escapeHtml("write a comment\u2026"));
    placeholder__soy27 = placeholder__soy27.toString();
    output.append('<textarea class="textarea ic-textarea" name="body" placeholder="', soy.$$escapeHtml(placeholder__soy27), '">', soy.$$escapeHtml(opt_data.text), '</textarea><div class="ic-actions"><ul><li>');
    aui.buttons.button({tagName: 'button', text: "Save", type: 'link', extraClasses: 'ic-action-save', isDisabled: true}, output);
    output.append('</li>');
    if (opt_data.type != 'topLevel') {
      output.append('<li>');
      aui.buttons.button({text: "Cancel", type: 'link', extraClasses: 'ic-action-discard'}, output);
      output.append('</li>');
    }
    output.append('</ul></div>');
  } else {
    output.append('<div class="loading-container" />');
  }
  output.append('</form></div></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:create-comment-view', location = 'view/create-comment/create-comment.js' */
define("confluence/ic/view/create-comment",["underscore","jquery","backbone","ajs","confluence/ic/model/comment","confluence/ic/model/reply","confluence/ic/util/utils","confluence/ic/editor/editor"],function(h,c,g,f,b,a,e,d){var i=g.View.extend({tagName:"div",className:"ic-create-comment-view",events:{"click .ic-action-save":"saveComment","click .ic-action-discard":"discardComment","keyup .ic-textarea":"onInput","focus .ic-textarea":"onFocus"},template:Confluence.Templates.IC.createComment,initialize:function(j){this.selection=j.selection;this.type=j.type;this.onFinished=j.onFinished||function(){};this.commentText=j.commentText||"";this.stopFocus=j.stopFocus;this.serializedHighlights=j.serializedHighlights;if(j.type==="edit"||j.type==="reply"){this.template=Confluence.Templates.IC.commentForm;g.trigger("ic:discard-edit");this.listenTo(g,"ic:discard-edit",this.discardComment)}},render:function(){var k=this._getAuthorObject();var j={type:this.type,text:this.commentText,showMenu:false};var l=h.extend({},k,j,{darkFeatures:e.getDarkFeatures()});this.$el.html(this.template(l));if(e.getDarkFeatures().RICH_TEXT_EDITOR){this.renderEditor()}else{if(!this.stopFocus){setTimeout(h.bind(this.focusEditor,this),1)}}e.addSidebarHeadingTooltip(this);return this},onInput:function(k){var j=this.$(k.target).val().trim()!=="";this._saveDisable(!j)},onFocus:function(){if(this.type==="edit"){var j=this.$(".textarea");e.moveCaretToEnd(j[0]);this._saveDisable(j.text()==="")}},saveComment:function(j){j.preventDefault();g.trigger("ic:clearError");if(!this._isValid()){return}this._disableForm();if(this.type==="reply"){this._addReply()}else{if(this.type==="edit"){this._saveEdit()}else{this._addComment()}}},_getAuthorObject:function(){var j;var k;var l;if(this.type==="edit"){j=this.model.get("authorUserName");k=this.model.get("authorAvatarUrl");l=this.model.get("authorDisplayName")}else{j=f.Meta.get("remote-user");k=e.getAuthorAvatarUrl();l=e.getAuthorDisplayName()}return{authorUserName:j,authorAvatarUrl:k,authorDisplayName:l}},_saveEdit:function(){var k=this._getContent();var j={wait:true,success:h.bind(this._onSaveSuccess,this),error:h.bind(this._showEditError,this)};this.model.save({body:k},j)},_showEditError:function(k,j){var l;if(j.status===401){l="You don\'t have permission to edit this comment."}else{l="We can\'t save your edit. The comment might have been deleted."}this._triggerError(l);this._disableForm(false)},_triggerError:function(k,j){g.trigger("ic:error",k,j);this._disableForm(false)},_addReply:function(){var j=new a({body:this._getContent(),commentId:this.model.get("id"),hasDeletePermission:!!f.Meta.get("remote-user")||this.model.get("hasDeletePermission")});j.save(null,{success:h.bind(this._onSaveSuccess,this),error:h.bind(this._triggerError,this,"Could not save the reply")})},_addComment:function(){var k=new b({originalSelection:this.selection.text&&c.trim(this.selection.text.replace(/\n/g,"")),body:this._getContent(),matchIndex:this.selection.searchText.index,numMatches:this.selection.searchText.numMatches,serializedHighlights:this.serializedHighlights});var j={callback:this.bindPageReloadLink};k.save(null,{success:h.bind(this._onSaveSuccess,this),error:h.bind(function(m,l){if(l.status===409){this._triggerError(f.format("Page content is out of date, please {0}refresh{1} and try again.",'<a href="#" class="ic-reload-page">',"</a>"),j)}else{if(l.status===412){f.trigger("analytics",{name:"confluence.comment.inline.cannot.create"});this._triggerError("We can\'t add your inline comment; the section you highlighted may contain a macro or user mention. Try highlighting plain text.")}else{this._triggerError("Could not save the comment")}}},this)})},_isValid:function(){if(!c.trim(this._getContent()).length){g.trigger("ic:error","You cannot save an empty comment.");return false}return true},_onSaveSuccess:function(j){switch(this.type){case"topLevel":j.set("hasDeletePermission",true);g.trigger("ic:persist",j);g.trigger("ic:view",j,undefined,{ignoreConfirmDialog:true});break;case"reply":this.model.replies.push(j);g.trigger("ic:reply:persist",j);this.onFinished();break;case"edit":g.trigger("ic:edit");this.onFinished();break}},_disableForm:function(j){if(j===undefined){j=true}this._saveDisable(j);if(!e.getDarkFeatures().RICH_TEXT_EDITOR){this.$(".ic-action-discard,.ic-textarea").prop("disabled",j).attr("aria-disabled",j)}},_saveDisable:function(j){if(e.getDarkFeatures().RICH_TEXT_EDITOR){d.setEditorBusy(j);c("#rte-button-cancel")[0].disabled=j}else{this.$(".ic-action-save").prop("disabled",j).attr("aria-disabled",j)}},renderEditor:function(){var k=this.$(".ic-body");var j=this.commentText;return d.init({container:k,form:k.find("form.aui"),saveHandler:h.bind(this.saveComment,this),cancelHandler:h.bind(this.discardComment,this),fetchContent:function(){var l=new c.Deferred();l.resolve({editorContent:j});return l},postDeactivate:h.bind(function(){g.trigger("ic:clearError");this.onFinished()},this),hideCancelButton:this.type==="topLevel"}).done(h.bind(this.renderEditorCompleted,this)).fail(h.bind(this.renderEditorFail,this))},renderEditorCompleted:function(){g.trigger("ic:clearError");if(this.type==="topLevel"){this.$("#rte-button-cancel").hide()}},renderEditorFail:function(){var j={closeable:true,callback:this.bindPageReloadLink};switch(this.type){case"topLevel":this.$(".loading-container").hide();this.$(".ic-create-comment").hide();j.closeable=false;break;case"edit":case"reply":this.onFinished();break}g.trigger("ic:error",f.format("The editor didn\'\'t load properly. Please {0}reload the page{1} to try again.",'<a href="#" class="ic-reload-page">',"</a>"),j);g.trigger("ic:editor:load:fail")},bindPageReloadLink:function(){c(".ic-error").off("click",".ic-reload-page").on("click",".ic-reload-page",function(){window.location.reload();return false})},discardComment:function(j){j&&j.preventDefault();g.trigger("ic:clearError");this.onFinished()},_getContent:function(){if(e.getDarkFeatures().RICH_TEXT_EDITOR){return d.getContent()}else{return this.$("textarea").val()}},focusEditor:function(){if(e.getDarkFeatures().RICH_TEXT_EDITOR){f.Rte.getEditor()&&f.Rte.getEditor().focus()}else{this.$(".ic-textarea:visible").focus()}},destroy:function(){if(e.getDarkFeatures().RICH_TEXT_EDITOR){d.remove()}this.remove()}});return i});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:display-reply-view', location = 'view/display-reply/display-reply.soy' */
// This file was automatically generated from display-reply.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.renderReply = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  Confluence.Templates.IC.commentHeader(opt_data, output);
  output.append('<div class="ic-body wiki-content"><div class="ic-content ic-reply-content">', opt_data.body, '</div></div>');
  if (opt_data.darkFeatures.INLINE_COMMENTS && ! opt_data.resolved) {
    Confluence.Templates.IC.renderReplyActions(opt_data, output);
  } else {
    output.append('<div>');
    Confluence.Templates.IC.timeLink({time: opt_data.lastModificationDate, commentUrl: opt_data.commentDateUrl}, output);
    output.append('</div>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.renderReplyActions = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-actions"><ul>');
  if (opt_data.hasDeletePermission) {
    output.append('<li>');
    aui.buttons.button({text: "Delete", type: 'link', extraClasses: 'ic-action-delete-reply'}, output);
    output.append('</li>');
  }
  if (opt_data.hasEditPermission) {
    output.append('<li>');
    aui.buttons.button({text: "Edit", type: 'link', extraClasses: 'ic-action-edit-reply'}, output);
    output.append('</li>');
  }
  output.append('<li class="ic-action-like-reply"></li><li class="ic-date">');
  Confluence.Templates.IC.timeLink({time: opt_data.lastModificationDate, commentUrl: opt_data.commentDateUrl}, output);
  output.append('</li></ul></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.showmoreReply = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="ic-showmore-container"><div class="ic-decor-line"/><div class="ic-decor-line"/><div class="ic-collapse-decor-center"><span>', soy.$$escapeHtml(AJS.format("{0} more replies",opt_data.totalReplies)), '</span></div></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:display-reply-view', location = 'view/display-reply/display-reply.js' */
define("confluence/ic/view/display-reply",["jquery","ajs","underscore","backbone","confluence/ic/util/utils","confluence/ic/view/create-comment","confluence/ic/view/likes"],function(g,b,c,h,f,a,e){var d=h.View.extend({tagName:"div",className:"ic-display-reply",template:Confluence.Templates.IC.renderReply,events:{"click .ic-action-edit-reply":"editReply","click .ic-action-delete-reply":"confirmDelete"},initialize:function(){c.bindAll(this,"onEditCallback");this.$el.attr("data-comment-id",this.model.get("id"))},render:function(){var j=c.extend(this.model.toJSON(),{resolved:this.options.resolved,darkFeatures:f.getDarkFeatures()});var i=this.template(j);this.$el.html(i);if(this.likesView){this.likesView.remove()}this.likesView=new e({contentId:this.model.id}).render();if(this.likesView.$el.is(":empty")){this.$(".ic-action-like-reply").remove()}else{this.$(".ic-action-like-reply").html(this.likesView.el)}return this},editReply:function(i){if(f.confirmProcess()){this.editView=new a({model:this.model,type:"edit",selection:{},onFinished:this.onEditCallback,commentText:this.model.get("body")});this.$el.html(this.editView.$el);this.editView.render()}else{i&&i.currentTarget.blur()}},onEditCallback:function(){this.editView&&this.editView.destroy();this.editView=null;this.render()},deleteFail:function(k,i,j){if(i.status===401){h.trigger("ic:error","You don\'t have permission to delete this comment.")}else{h.trigger("ic:error","Could not complete your request.")}},confirmDelete:function(j){var i=window.confirm("Are you sure you want to delete this reply?");if(i===true){this.deleteReply(j)}},deleteReply:function(i){g(i.target).attr("aria-disabled",true).prop("disabled",true);this.model.destroy({wait:true,error:this.deleteFail,success:function(){h.trigger("ic:reply:delete")}})},destroy:function(){this.likesView.remove();this.editView&&this.editView.destroy();this.remove()}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:reply-list-view', location = 'view/reply-list/reply-list.js' */
define("confluence/ic/view/reply-list",["jquery","ajs","underscore","backbone","confluence/ic/view/display-reply","confluence/ic/util/utils"],function(f,a,b,g,c,e){var d=g.View.extend({tagName:"div",className:"ic-replies",events:{"click #ic-showmore-container":"forceShowAllReplies"},initialize:function(h){if(!h.commentModel){throw new Error("Inline Comment Model should be passed as a parameter when init ReplyListView","ReplyListView")}this.replyViews=[];this.collection=h.commentModel.replies;this.source=h.source;this.listenTo(this.collection,"add remove",this.render);if(this.collection.isFetched!==true){this.listenToOnce(this.collection,"sync",this.fetchComplete);this.collection.fetch({reset:true})}this.expandReplies=false;this.COMMENT_NUMBER_TO_COLLAPSE=4},fetchComplete:function(){this.collection.isFetched=true;this.render();e.resizeContentAfterLoadingImages(this.$el)},render:function(h){if(this.collection.isFetched!==true){return this}if(h&&this.collection.last()===h){this.appendReply(h);return}this.cleanUpReplyViews();this.$el.empty();if(this.collection.length>this.COMMENT_NUMBER_TO_COLLAPSE&&this.expandReplies===false&&this.source!=="permalink"&&this.options.commentModel&&!this.options.commentModel.isResolved()){this.renderCollapsibleReplies()}else{this.renderFullReplies()}this.trigger("ic:reply-rendered",this.options.commentModel);this._hightlightReply();return this},renderFullReplies:function(){this.collection.each(function(h){this.appendReply(h)},this)},forceShowAllReplies:function(){this.expandReplies=true;this.render()},renderCollapsibleReplies:function(){this.renderExpendButton();var h=this.collection.last();this.appendReply(h)},appendReply:function(i){var h=this.createReplyView(i);this.replyViews.push(h);this.$el.append(h.render().el)},renderExpendButton:function(){this.$el.append(Confluence.Templates.IC.showmoreReply({totalReplies:this.collection.length-1}))},createReplyView:function(h){return new c({model:h,resolved:this.options.commentModel.isResolved()})},_hightlightReply:function(){if(this.source!=="permalink"){return}var j=window.location.search;var i=j.match(/(focusedCommentId|replyToComment)=(\d+)/);if(i==null){return}var h=parseInt(i[2],10);if(h&&h!==0){this.$("[data-comment-id="+h+"]").addClass("ic-comment-reply-highlight")}},cleanUpReplyViews:function(){var h;for(h=0;h<this.replyViews.length;h++){this.replyViews[h].destroy();this.replyViews[h]=null}this.replyViews=[]},destroy:function(){this.cleanUpReplyViews();this.remove()}});return d});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:navigation-view', location = 'view/navigation/navigation.soy' */
// This file was automatically generated from navigation.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.navigation = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  aui.buttons.button({type: 'text', id: 'ic-nav-next', extraClasses: 'aui-button-text', iconType: 'aui', iconClass: 'aui-icon-small aui-iconfont-arrow-down', text: '', isDisabled: opt_data.disabled, extraAttributes: {'tabIndex': opt_data.disabled ? '' : 0, 'title': "Next comment (N)"}}, output);
  aui.buttons.button({type: 'text', id: 'ic-nav-previous', extraClasses: 'aui-button-text', iconType: 'aui', iconClass: 'aui-icon-small aui-iconfont-arrow-up', text: '', isDisabled: opt_data.disabled, extraAttributes: {'tabIndex': opt_data.disabled ? '' : 0, 'title': "Previous comment (P)"}}, output);
  output.append((opt_data.showIndex) ? '<span class="ic-nav-x-out-of-y">' + soy.$$escapeHtml(AJS.format("{0} of {1}",opt_data.index,opt_data.size)) + '</span>' : '');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:navigation-view', location = 'view/navigation/navigation.js' */
define("confluence/ic/view/navigation",["backbone"],function(b){var a=b.View.extend({tagName:"div",events:{"click #ic-nav-previous":"showPrevious","click #ic-nav-next":"showNext"},template:Confluence.Templates.IC.navigation,initialize:function(){this.collection=this.model.collection;this.listenTo(this.collection,"change:resolveProperties",this.onResolveToggle);this.disabled=this.collection.getCommentsOnPageCount()<=1;this.listenTo(b,"ic:show-previous",this.showPrevious);this.listenTo(b,"ic:show-next",this.showNext)},render:function(){this.$el.html(this.template({disabled:this.disabled,showIndex:!(this.model.isResolved()||this.model.get("deleted")),index:this.collection.getActiveIndexWithinPageComments()+1,size:this.collection.getCommentsOnPageCount()}));return this},onResolveToggle:function(){this.disabled=this.collection.getCommentsOnPageCount()<=1;this.render()},showPrevious:function(){if(this.disabled){return}var c=this.collection.getPrevCommentOnPage();if(c!=null){b.trigger("ic:view",c,"nav")}},showNext:function(){if(this.disabled){return}var c=this.collection.getNextCommentOnPage();if(c!=null){b.trigger("ic:view",c,"nav")}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:likes-view', location = 'view/likes/likes.soy' */
// This file was automatically generated from likes.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.likes = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.showLikeButton) {
    aui.buttons.button({text: (opt_data.isLikedByUser) ? soy.$$escapeHtml("Unlike") : soy.$$escapeHtml("Like"), type: 'link', extraClasses: 'ic-like-button'}, output);
  }
  output.append((opt_data.likesCount > 0) ? '<span class="ic-like-summary"><span class="ic-small-like-icon"></span><a class="ic-likes-count" data-content-id="' + soy.$$escapeHtml(opt_data.contentId) + '"><span class="ic-like-summary">' + soy.$$escapeHtml(opt_data.likesCount) + '</span></a></span>' : '');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:likes-view', location = 'view/likes/likes.js' */
define("confluence/ic/view/likes",["backbone","ajs","confluence/ic/model/likes","confluence/ic/likes/likes-manager"],function(e,b,d,a){var c=e.View.extend({className:"ic-likes",events:{"click .ic-like-button":"toggleLike","click .ic-likes-count":function(f){Confluence.Likes.showLikeUsers&&Confluence.Likes.showLikeUsers.apply(f.currentTarget,[f])}},initialize:function(f){this.collection=new d(null,{contentId:f.contentId});this.listenTo(this.collection,"add remove reset",this.render);this.currentUserName=b.Meta.get("remote-user")||"";if(f.showLikeButton===undefined){this.showLikeButton=true}else{this.showLikeButton=f.showLikeButton}},render:function(){this.$el.empty();if(a.isLikable()){var h=this.currentUserName==="";var g=this.collection.length;var i=this.collection.isLikedByUser(this.currentUserName);var f=Confluence.Templates.IC.likes({showLikeButton:this.showLikeButton&&!h,isLikedByUser:i,likesCount:g,contentId:this.collection.contentId});this.$el.html(f)}return this},toggleLike:function(){this.collection.toggleLike()}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:likes-view', location = 'view/likes/likes-manager.js' */
define("confluence/ic/likes/likes-manager",["underscore"],function(b){var a={init:function(c){this.likesCache=b.clone(c)||{}},getLikes:function(d){if(this.likesCache&&this.likesCache[d]){var c=b.map(this.likesCache[d].likes,function(e){return{username:e.user.name}});return c}return null},add:function(d,c){if(!this.likesCache[d]){this.likesCache[d]={likes:[]}}this.likesCache[d].likes.push({user:{name:c}})},remove:function(e,d){if(this.likesCache[e]&&this.likesCache[e].likes){var c=b.reject(this.likesCache[e].likes,function(f){return f.user.name===d});this.likesCache[e].likes=c}},isLikable:function(){return this.likesCache!==undefined}};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:display-comment-view', location = 'view/display-comment/display-comment.soy' */
// This file was automatically generated from display-comment.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.displayComment = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-comment-container">');
  Confluence.Templates.IC.sidebarHeading({authorUserName: opt_data.authorUserName, hasDeletePermission: opt_data.hasDeletePermission, hasResolvePermission: opt_data.hasResolvePermission, hasEditPermission: opt_data.hasEditPermission, hasReplyPermission: opt_data.hasReplyPermission, showMenu: opt_data.showMenu && ! opt_data.resolveProperties.resolved, darkFeatures: opt_data.darkFeatures}, output);
  if (opt_data.resolveProperties.resolved) {
    Confluence.Templates.IC.resolvedMask(null, output);
  } else {
    Confluence.Templates.IC.comment(opt_data, output);
  }
  output.append('</div>');
  if (! opt_data.resolveProperties.resolved) {
    output.append('<div class="ic-list"></div><div class="ic-reply-container">');
    if (opt_data.darkFeatures.INLINE_COMMENTS && opt_data.hasReplyPermission) {
      output.append('<div class="ic-reply-placeholder">');
      Confluence.Templates.IC.commentHeader({authorUserName: opt_data.currentAuthorUserName, authorAvatarUrl: opt_data.currentAuthorAvatarUrl, authorDisplayName: opt_data.currentAuthorDisplayName}, output);
      output.append('<div class="ic-body"><form class="aui"><textarea class="textarea ic-textarea" name="body" placeholder="', soy.$$escapeHtml("Reply"), '"></textarea></form></div></div>');
    }
    output.append('</div>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.deleteComment = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-comment-container ic-deleted">');
  Confluence.Templates.IC.sidebarHeading({createComment: false, showMenu: false}, output);
  output.append('<div class="ic-delete-comment-view"><h2><span class="aui-icon ic-delete-image line">::before</span>', soy.$$escapeHtml("Deleted"), '</h2></div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.comment = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div data-comment-id="', soy.$$escapeHtml(opt_data.id), '" class="ic-container ic-display-comment">');
  Confluence.Templates.IC.commentHeader(opt_data, output);
  output.append('<div class="ic-body wiki-content"><div class="ic-content">', (opt_data.resolveProperties.resolved) ? '<blockquote><span class="ic-resolved-marker">' + soy.$$escapeHtml(opt_data.originalSelection) + '</span></blockquote>' : '', opt_data.body, '</div></div>');
  if (opt_data.resolveProperties.resolved) {
    Confluence.Templates.IC.renderResolvedActions(opt_data, output);
  } else {
    Confluence.Templates.IC.renderActions(opt_data, output);
  }
  output.append('</div>', (! opt_data.resolveProperties.resolved && opt_data.resolveProperties.resolvedTime > 0 && opt_data.resolveProperties.resolvedUser) ? '<div class="ic-unresolved-message">' + soy.$$escapeHtml(AJS.format("Reopened by {0} {1}",opt_data.resolveProperties.resolvedUser,opt_data.resolveProperties.resolvedFriendlyDate)) + '</div>' : '');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.commentMenu = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.darkFeatures.INLINE_COMMENTS && (opt_data.hasDeletePermission || opt_data.hasReplyPermission || opt_data.hasResolvePermission && opt_data.darkFeatures.RESOLVED_INLINE_COMMENTS)) {
    aui.buttons.button({type: 'subtle', extraClasses: 'aui-button-compact aui-dropdown2-trigger-arrowless aui-style-default ic-action-menu', iconType: 'aui', iconClass: 'aui-icon-small aui-iconfont-more', text: '', dropdown2Target: 'ic-menu-items', extraAttributes: {'title': "Previous comment (P)"}}, output);
    aui.dropdown2.contents({id: 'ic-menu-items', extraClasses: 'aui-style-default', content: '<ul class="aui-list-truncate">' + ((opt_data.hasResolvePermission && opt_data.darkFeatures.RESOLVED_INLINE_COMMENTS) ? '<li class="ic-action-resolve"><a href="#">' + soy.$$escapeHtml("Resolve") + '</a></li>' : '') + ((opt_data.hasReplyPermission) ? '<li class="ic-action-reply"><a href="#">' + soy.$$escapeHtml("Reply") + '</a></li>' : '') + ((opt_data.hasEditPermission) ? '<li class="ic-action-edit"><a href="#">' + soy.$$escapeHtml("Edit") + '</a></li>' : '') + ((opt_data.hasDeletePermission) ? '<li class="ic-action-delete"><a href="#">' + soy.$$escapeHtml("Delete") + '</a></li>' : '') + '</ul>'}, output);
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.renderResolvedActions = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.darkFeatures.INLINE_COMMENTS) {
    output.append('<div class="ic-actions"><ul class="aui-list-truncate">');
    if (opt_data.hasResolvePermission && ! opt_data.isDangling) {
      output.append('<li>');
      aui.buttons.button({text: "Reopen", type: 'link', extraClasses: 'ic-action-unresolve'}, output);
      output.append('</li>');
    }
    output.append('<li class="hidden">');
    aui.buttons.button({type: 'link', extraClasses: 'ic-action-show-reply'}, output);
    output.append('</li>', (opt_data.hasReply) ? '' : '');
    if (opt_data.resolveProperties.resolvedTime > 0) {
      output.append('<li class="ic-resolved-message">');
      aui.icons.icon({useIconFont: true, size: 'small', icon: 'success'}, output);
      output.append('  <span>');
      Confluence.Templates.IC.timeLink({time: (opt_data.isDangling && opt_data.resolveProperties.resolvedByDangling) ? AJS.format("Resolved because the text was deleted by {0} {1}",opt_data.resolveProperties.resolvedUser,opt_data.resolveProperties.resolvedFriendlyDate) : AJS.format("Resolved by {0} {1}",opt_data.resolveProperties.resolvedUser,opt_data.resolveProperties.resolvedFriendlyDate), commentUrl: opt_data.commentDateUrl}, output);
      output.append('</span></li>');
    }
    output.append('</ul></div>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.renderActions = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.darkFeatures.INLINE_COMMENTS) {
    output.append('<div class="ic-actions"><ul class="aui-list-truncate">');
    if (opt_data.hasResolvePermission && opt_data.darkFeatures.RESOLVED_INLINE_COMMENTS) {
      output.append('<li>');
      aui.buttons.button({text: "Resolve", type: 'link', extraClasses: 'ic-action-resolve'}, output);
      output.append('</li>');
    }
    output.append('<li class="ic-action-like"></li><li class="ic-date">');
    Confluence.Templates.IC.timeLink({time: opt_data.lastModificationDate, commentUrl: opt_data.commentDateUrl}, output);
    output.append('</li></ul></div>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.resolvedMask = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="ic-resolved-mask"><div class="ic-resolved-mask-content"><h2 class="ic-resolved-icon">');
  aui.icons.icon({useIconFont: true, size: 'large', icon: 'success', extraClasses: 'line'}, output);
  output.append(soy.$$escapeHtml("Resolved"), '</h2></div><div class="resolved-message-container"><div class="resolved-message-sideline"><p>', soy.$$escapeHtml("This comment isn\x27t gone forever! You can see resolved comments at any time."), '</p>');
  aui.buttons.button({text: "Show me", type: 'link', id: 'show-resolved-comments'}, output);
  output.append('</div></div></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:display-comment-view', location = 'view/display-comment/display-comment.js' */
define("confluence/ic/view/display-comment",["jquery","ajs","underscore","backbone","confluence/ic/util/utils","confluence/ic/view/create-comment","confluence/ic/view/confirm-dialog","confluence/ic/view/reply-list","confluence/ic/view/resolved-dialog-discovery","confluence/ic/view/navigation","confluence/ic/view/likes"],function(d,g,j,i,e,l,k,h,c,b,a){var f=i.View.extend({tagName:"div",className:"ic-display-comment-view",template:Confluence.Templates.IC.displayComment,events:{"click .ic-action-reply":"replyComment","click .ic-action-resolve":"resolveComment","click .ic-action-edit":"editComment","click #show-resolved-comments":"showResolvedDialogDiscovery","click .ic-reply-placeholder .textarea":"replyComment","focus .ic-reply-container .textarea":"onReplyPlaceholderFocus"},initialize:function(m){j.bindAll(this,"confirm","destroy","deleteFail","replyComment","resolveComment","editComment","renderCommentOnly");this.model.set("active",true);this.listenTo(this.model,"change:resolveProperties",this.render);d("body").on("click",".ic-action-delete a",this.confirm);d("body").on("click",".ic-action-reply a",this.replyComment);d("body").on("click",".ic-action-resolve a",this.resolveComment);d("body").on("click",".ic-action-edit a",this.editComment);this.replyListView=new h({commentModel:this.model,source:m.source})},render:function(){this.$el.html(this.template(j.extend(this.model.toJSON(),{showMenu:true,currentAuthorUserName:g.Meta.get("remote-user"),currentAuthorAvatarUrl:e.getAuthorAvatarUrl(),currentAuthorDisplayName:e.getAuthorDisplayName(),darkFeatures:e.getDarkFeatures()})));if(this.model.isResolved()){this.$(".ic-comment-container").addClass("ic-resolved")}else{this.$(".ic-list").append(this.replyListView.render().el)}this._renderNavigation();this._renderLikes();e.addSidebarHeadingTooltip(this);return this},_renderNavigation:function(){if(this.navigationView){this.navigationView.remove()}this.navigationView=new b({model:this.model});this.navigationView.render();this.$("#ic-nav-container").html(this.navigationView.el)},_renderLikes:function(){if(this.likesView){this.likesView.remove()}this.likesView=new a({contentId:this.model.id}).render();this.$(".ic-action-like").html(this.likesView.el)},editComment:function(m){m.preventDefault();if(this.editView){this.editView.focusEditor()}else{if(e.confirmProcess()){this.editView=new l({model:this.model,type:"edit",selection:{},onFinished:this.renderCommentOnly,commentText:this.model.get("body")});this.$(".ic-display-comment").html(this.editView.$el);this.editView.render()}}},renderCommentOnly:function(){this.editView&&this.editView.destroy();this.editView=null;var m=j.extend(this.model.toJSON(),{darkFeatures:e.getDarkFeatures()});this.$(".ic-display-comment").html(d(Confluence.Templates.IC.comment(m)).children());this._renderLikes()},replyComment:function(m){m&&m.preventDefault();if(this.createReplyView){this.createReplyView.focusEditor()}else{if(e.confirmProcess()){this.createReplyView=new l({model:this.model,type:"reply",onFinished:j.bind(function(){this.createReplyView&&this.createReplyView.destroy();this.createReplyView=null},this)});this.$(".ic-reply-container").prepend(this.createReplyView.$el);this.createReplyView.render()}else{m&&m.currentTarget.blur()}}},confirm:function(n){n.preventDefault();if(this.model.replies.length>0){i.trigger("ic:error","You can\'t delete inline comment threads with replies.");return false}var m=new k({model:new i.Model({label:"Delete",message:"Are you sure you want to delete the comment?"}),$menuEl:d(".ic-action-menu"),$bodyEl:d("body")});this.$(".ic-sidebar-heading").append(m.$el);this.listenTo(m,"ic:confirm",this.deleteComment)},deleteComment:function(){var m=j.bind(function(){this.$el.html(Confluence.Templates.IC.deleteComment());this.model.set("deleted",true);this._renderNavigation();e.removeInlineLinksDialog(this.model.highlights);e.addSidebarHeadingTooltip(this);i.trigger("ic:delete")},this);this.model.destroy({wait:true,success:m,error:this.deleteFail})},deleteFail:function(o,m,n){if(m.status===401){i.trigger("ic:error","You don\'t have permission to delete this comment.")}else{if(m.status===409){i.trigger("ic:error",m.responseText)}else{i.trigger("ic:error","Could not complete your request.")}}},destroy:function(m){d("body").off("click",".ic-action-delete a",this.confirm);d("body").off("click",".ic-action-reply a",this.replyComment);d("body").off("click",".ic-action-resolve a",this.resolveComment);d("body").off("click",".ic-action-edit a",this.editComment);this.createReplyView&&this.createReplyView.destroy();this.editView&&this.editView.destroy();this.replyListView.destroy();this.navigationView&&this.navigationView.remove();this.likesView&&this.likesView.remove();m!==true&&this.remove()},resolveComment:function(m){m&&m.preventDefault();if(e.confirmProcess(true)){this.model.resolve(true,{wait:true,success:j.bind(this.onResolveComplete,this),error:this.onResolveFail})}},onResolveComplete:function(){this.createReplyView&&this.createReplyView.destroy();this.createReplyView=null;i.trigger("ic:resolved");e.removeInlineLinksDialog(this.model.highlights)},onResolveFail:function(n,m){if(m.status===401){i.trigger("ic:error","You don\'t have permission to resolve this comment.")}else{i.trigger("ic:error","Could not complete your request.")}},showResolvedDialogDiscovery:function(){(new c()).show();i.trigger("ic:resolved:show:recovery")},onReplyPlaceholderFocus:function(n){if(e.getDarkFeatures().RICH_TEXT_EDITOR){var m=(navigator.userAgent.indexOf("Safari")!==-1&&navigator.userAgent.indexOf("Chrome")==-1);m&&n.currentTarget.blur()}}});return f});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:sidebar-view', location = 'view/sidebar/sidebar.js' */
define("confluence/ic/view/sidebar",["underscore","backbone","jquery","confluence/ic/view/display-comment","confluence/ic/view/create-comment","confluence/ic/util/utils","ajs"],function(d,h,f,c,a,e,b){var g=h.View.extend({tagName:"div",className:"ic-sidebar",events:{"click button.ic-action-hide":function(i){this.hide(i,true);h.trigger("ic:sidebar:close")}},initialize:function(i){var j=this;this.listenTo(h,"ic:view ic:overlap",this.displayComment);this.listenTo(h,"ic:create",this.displayCreateComment);this.listenTo(h,"ic:error",this.displayError);this.listenTo(h,"ic:hide-sidebar",this.hide);this.listenTo(h,"ic:clearError",this.clearError);if(e.getDarkFeatures().RICH_TEXT_EDITOR){b.bind("rte-quick-edit-ready",function(){var l=j.$el.find("#wysiwygTextarea_ifr");if(l.length!==0){var m=new MutationObserver(function(){l.resize()});m.observe(l[0],{attributes:true,attributeFilter:["style"]});if(!b.Rte.getEditor().getContent()){j._scrollToEditorView(l)}}else{var k=j.$el.is(":visible");if(!k){e.getPageContainer().css("padding-right","0");j.$wikiContent.css("position","static");e.getPageContainer().css({"min-height":0})}}})}else{b.bind("init.rte",d.bind(this.hideInEditMode,this))}this.defaultNavOffset=130;this.defaultPermalinkedCommentOffset=100;this.$wikiContent=i.$wikiContent||f("#content .wiki-content").first();this.sidebarObserver=new MutationObserver(d.bind(this.setSidebarYPos,this));this.sidebarObserver.observe(this.el,{childList:true,subtree:true});f(window).resize(d.debounce(d.bind(this.setSidebarYPos,this),100));b.bind("sidebar.expanded sidebar.collapsed",d.debounce(d.bind(this.setSidebarYPos,this),50))},displayComment:function(m,l,i){var k=function(){if(m.highlight.is(":hidden")){e.showHighlightContent(m.highlight);if(m.highlight.is(":hidden")){return}}this.distanceToTop=this.previousHighlightOffset||this.defaultNavOffset;this._emptySidebar(true);this.commentView=new c({model:m,source:l});this.show(true);this.previousHighlightOffset=m.highlight.position().top;var n=this.commentView.render().$el;n.css("visibility","hidden");if(l==="nav"){this._scrollToComment(m)}else{if(l==="permalink"){this._scrollToPermalinkedComment(m,this.defaultPermalinkedCommentOffset,i)}else{if(l==="quickreload"){this._scrollToQuickReloadComment(m)}}}this.$el.html(n);Confluence.Binder&&Confluence.Binder.userHover()};var j=(i===undefined)||(i.ignoreConfirmDialog===false);if(j){if(e.confirmProcess(true)){k.call(this)}}else{k.call(this)}},_scrollToQuickReloadComment:function(k){var j=f(".qr-feedback:first");var i=this.defaultPermalinkedCommentOffset;if(j.length>0){i=j.height()+67}this._scrollToPermalinkedComment(k,i)},_scrollToEditorView:function(j){var k=e.isDocTheme()?e.getSplitterContent():f("body, html");var l=this.$(".ic-display-comment-view").position().top;var i=j.closest(".ic-create-comment-view").position().top+l;if(k.height()<i||k.scrollTop()>i){k.animate({scrollTop:i},100)}},_scrollToPermalinkedComment:function(m,j,l){var k;if(e.isDocTheme()){var i=40;k=m.highlight.offset().top+e.getSplitterContent().scrollTop()-i;e.getSplitterContent().animate({scrollTop:k-j},100).promise().done(d.bind(this._scrollToPermalinkedCommentCompleted,this,l))}else{k=m.highlight.offset().top;f("html, body").animate({scrollTop:k-j},100).promise().done(d.bind(this._scrollToPermalinkedCommentCompleted,this,l))}},_scrollToPermalinkedCommentCompleted:function(i){if(i&&i.isReplyComment){this.commentView.replyComment()}},_scrollToComment:function(j){var i=j.highlight.position().top;if(e.isDocTheme()){e.getSplitterContent().animate({scrollTop:e.getSplitterContent().scrollTop()+i-this.distanceToTop},100)}else{f("html, body").animate({scrollTop:window.pageYOffset+i-this.distanceToTop},100)}},displayCreateComment:function(i,j,k){this._emptySidebar(true);this.createCommentView=new a({collection:i,selection:j,type:"topLevel",isFocus:true,onFinished:d.bind(function(){if(!this.createCommentView.keepSidebar){if(this.isShowing){this.hide()}}},this),serializedHighlights:k});this.show();this.createCommentView.$el.css("visibility","hidden");this.$el.html(this.createCommentView.$el);this.createCommentView.render()},displayError:function(j,i){i=d.extend({closeable:true},i);this.clearError();b.messages.warning(".ic-error",{body:j,closeable:i.closeable});i.callback&&i.callback()},clearError:function(){f(".ic-error").empty()},show:function(i){if(this.isShowing){return}this._toggleSidebar(i);this.isShowing=true},hideInEditMode:function(i){if(b.Meta.get("content-type")!=="comment"){this.sidebarObserver.disconnect();this.hide(i)}},hide:function(j,i){j&&j.preventDefault();if(e.confirmProcess(true)){if(!this.isShowing){return}e.getPageContainer().css({"min-height":"initial"});this._toggleSidebar(i);h.trigger("ic:sidebar-hidden");this.isShowing=false}},_toggleSidebar:function(i){var m=this;var n=f(".inline-comment-marker.active:first, .ic-current-selection:first");var l;var k=(e.isDocTheme()?e.getSplitterContent().scrollTop():window.pageYOffset);if(n.length>0){l=n.offset().top-k}var j=f.Deferred();var o=j.promise();if(this.isShowing){if(i&&e.isAnimationSupported()){o=e.animateSidebar(this,false)}else{e.getPageContainer().css("padding-right","0");this.$wikiContent.css("position","static");this._emptySidebar();j.resolve()}}else{e.getPageContainer().css("padding-right","280px");if(i&&e.isAnimationSupported()){o=e.animateSidebar(this,true)}else{j.resolve()}this.$wikiContent.css("position","relative")}o.done(function(){e.scrollToCommentAfterToggleSideBar(l,n)})},_emptySidebar:function(i){if(this.commentView){this.commentView.model.unset&&this.commentView.model.unset("active");this.commentView.destroy();this.commentView=null}if(this.createCommentView){this.createCommentView.keepSidebar=i;this.createCommentView.destroy();this.createCommentView=null}},setSidebarYPos:function(){if(!this.isShowing){return}var i=this.$el.offset().top;var l,j;if(this.commentView!=null){l=this.commentView.$el;j=this.commentView.model.highlight}else{if(this.createCommentView!=null){l=this.createCommentView.$el;j=f(".ic-current-selection")}else{return}}if(!j){return}var k=this.$(".ic-sidebar-heading").height();l.css({visibility:"visible",position:"absolute",top:(j.offset().top-i-k)+"px"});e.recalculateContentHeight(l)}});return g});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:resolved-comment-view', location = 'view/resolved-comment/resolved-comment-list.soy' */
// This file was automatically generated from resolved-comment-list.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.IC == 'undefined') { Confluence.Templates.IC = {}; }


Confluence.Templates.IC.resolvedCommentDialog = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var param8 = new soy.StringBuilder();
  aui.buttons.button({id: 'resolved-dialog-close-button', text: "Close", type: 'link'}, param8);
  aui.dialog.dialog2({id: 'ic-resolved-comment-dialog', removeOnHide: true, extraClasses: 'ic-resolved-comment-dialog-content', modal: true, titleText: "Resolved comments", footerActionContent: param8.toString(), content: '<!-- Placeholder for error message --><div id="ic-resolved-comment-dialog-error" />'}, output);
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.IC.resolvedDiscovery = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p>', soy.$$escapeHtml("Got more to say? You can reopen resolved comments to continue the discussion."), '</p>');
  aui.buttons.button({id: 'ic-resolved-discovery-dismiss', text: "OK, got it", type: 'link'}, output);
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:resolved-comment-view', location = 'view/resolved-comment/resolved-comment.js' */
define("confluence/ic/view/resolved-comment-item",["jquery","underscore","ajs","backbone","confluence/ic/util/utils","confluence/ic/view/reply-list","confluence/ic/view/likes"],function(g,b,a,h,f,e,d){var c=h.View.extend({tagName:"div",className:"ic-display-comment-view",template:Confluence.Templates.IC.comment,events:{"click .ic-action-unresolve":"unresolveComment","click .ic-action-show-reply":"showReply"},initialize:function(){b.bindAll(this,"onUnresolveComplete","destroy");this.replyListView=new e({commentModel:this.model});this.listenTo(this.replyListView,"ic:reply-rendered",function(){this.renderNumberOfReplies()})},render:function(){var i=this.template(b.extend(this.model.toJSON(),{showMenu:false,isDangling:this.model.isDangling(),darkFeatures:f.getDarkFeatures(),hasReply:this.model.replies.length>0}));this.$el.html(i);if(this.likesView){this.likesView.remove()}this.likesView=new d({contentId:this.model.id,showLikeButton:false}).render();this.$(".ic-action-like").html(this.likesView.el);this.$el.append(this.replyListView.$el.hide());this.replyListView.render();return this},unresolveComment:function(){h.trigger("ic:resolvedClearError");this.model.resolve(false,{wait:true,success:this.onUnresolveComplete,error:this.onUnresolveFail})},onUnresolveComplete:function(){h.trigger("ic:unresolved");this.$el.slideUp(this.destroy)},onUnresolveFail:function(j,i){if(i.status===401){h.trigger("ic:resolvedError","You don\'t have permission to resolve this comment.")}else{h.trigger("ic:resolvedError","Could not complete your request.")}},showReply:function(){this.$(".ic-action-show-reply").parent().remove();this.$(".ic-replies").slideDown()},renderNumberOfReplies:function(){var k=this.model.replies.length;var j=this.$(".ic-action-show-reply");if(k>0){var i;if(k===1){i=a.format("{0} reply",1)}else{i=a.format("{0} replies",k)}j.text(i);j.parent().removeClass("hidden")}else{j.parent().remove()}},destroy:function(){this.replyListView.destroy();this.remove()}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:resolved-comment-view', location = 'view/resolved-comment/resolved-comment-list.js' */
define("confluence/ic/view/resolved-comment-list",["jquery","underscore","backbone","ajs","confluence/ic/view/resolved-comment-item"],function(e,c,f,b,d){var a=f.View.extend({events:{"click #resolved-dialog-close-button":"destroy"},template:Confluence.Templates.IC.resolvedCommentDialog,initialize:function(){c.bindAll(this,"render","destroy","_onKeyDown");this._resolvedCommentViews=[];this.listenTo(this.collection,"change:resolveProperties",this.onResolvedChanged);this.listenTo(f,"ic:resolvedError",this.displayError);this.listenTo(f,"ic:resolvedClearError",this.clearErrors);var g=e(this.template());this.setElement(g);this.dialog=b.dialog2(this.$el);e(document).bind("keydown",this._onKeyDown);b.trigger("remove-bindings.keyboardshortcuts")},render:function(){var g=e("<div>");var h=this.collection.getResolvedCount();if(h!==0){c.each(this.collection.getResolvedCommentsDesc(),function(j){var i=new d({model:j});this._resolvedCommentViews.push(i);g.append(i.render().$el)},this)}else{this.displayNoCommentMessage()}this.$(".aui-dialog2-content").append(g);this.dialog.show();if(this.options.focusCommentId){this.scrollToComment(this.options.focusCommentId)}f.trigger("ic:resolved:view",h);return this},onResolvedChanged:function(){if(this.collection.getResolvedCount()===0){this.displayNoCommentMessage()}},displayNoCommentMessage:function(){b.messages.generic(this.$(".aui-dialog2-content"),{body:"There are no resolved comments on this page.",closeable:false})},displayError:function(g){this.clearErrors();b.messages.warning(this.$("#ic-resolved-comment-dialog-error"),{body:g})},clearErrors:function(){this.$("#ic-resolved-comment-dialog-error").empty()},scrollToComment:function(h){var i=this.$(b.format("[data-comment-id={0}]",h));if(i.length){i.addClass("focused");return this.$(".aui-dialog2-content").animate({scrollTop:i.parent().position().top},100)}var g=new e.Deferred();return g.reject()},_onKeyDown:function(g){if(this.$el&&this.$el.is(":visible")&&g.keyCode===b.keyCode.ESCAPE){this.destroy()}},destroy:function(){b.trigger("add-bindings.keyboardshortcuts");e(document).unbind("keydown",this._onKeyDown);this.dialog.hide();this.dialog.remove();c.each(this._resolvedCommentViews,function(g){g.destroy()});this._resolvedCommentViews=null;this.remove()}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:resolved-comment-view', location = 'view/resolved-comment/resolved-dialog-discovery.js' */
define("confluence/ic/view/resolved-dialog-discovery",["jquery","underscore","backbone","ajs"],function(d,c,e,b){var a=e.View.extend({DIALOG_BACKGROUND_COLOR:"#ffffff",DIALOG_BORDER_COLOR:"#f79232",initialize:function(){c.bindAll(this,"getDiscoveryDialogContent","destroy","onEndScroll")},template:Confluence.Templates.IC.resolvedDiscovery,show:function(){d.when(this.scrollTop()).done(this.onEndScroll)},onEndScroll:function(){this.showToolsMenu();this._discoveryDialog=this.createDiscoveryDialog();this._discoveryDialog.show()},showToolsMenu:function(){var f=d("#action-menu");f.on("aui-dropdown2-hide",this.destroy);d("#action-menu-link").trigger("aui-button-invoke");f.find("a.active").removeClass("active");f.find("#view-resolved-comments").addClass("active").focus()},createDiscoveryDialog:function(){var h={gravity:"w",hideCallback:this.destroy,width:280,noBind:true};if(b.version<"5.5"){var g=this;h=c.extend(h,{getArrowPath:function(){return"M0,0L8,8L0,16"},getArrowAttributes:function(){return{fill:g.DIALOG_BACKGROUND_COLOR,stroke:g.DIALOG_BORDER_COLOR,"stroke-width":"2"}},calculatePositions:this.calculatePositions,persistent:true})}var f=b.InlineDialog(d("#view-resolved-comments"),"ic-resolved-dialog-discovery",this.getDiscoveryDialogContent,h);f.on("click focusin mousedown",function(i){i.stopPropagation()});return f},getDiscoveryDialogContent:function(g,f,j){var h=this.template();g.html(h);var i=this;g.find("#ic-resolved-discovery-dismiss").on("click",function(){e.trigger("ic:resolved:dismiss:recovery");i._discoveryDialog.hide()});j();return false},calculatePositions:function(f,j){var i=this.width;var g=16;var k=16;var n=j.target.offset();var l=j.target.height();var m={top:n.top+l/2-15,left:n.left-i-(2*g)-k,right:"auto"};var h={top:9,right:-16};return{displayAbove:false,popupCss:m,arrowCss:h}},scrollTop:function(){var f=d("#splitter-content");var h=!!f.length;var i=(h)?f:d("html, body");var g=(i.scrollTop()===0)?1:300;return i.animate({scrollTop:0},g)},destroy:function(){var f=d("#action-menu");f.off("aui-dropdown2-hide");if(f.is(":visible")){d("#action-menu-link").trigger("aui-button-invoke")}this._discoveryDialog.remove();this.remove()}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:app', location = 'analytics/ic-analytics.js' */
define("confluence/ic/analytics",["ajs","underscore","backbone"],function(b,c,d){var a={};c.extend(a,d.Events);a.start=function(){if(this.running===true){return}this.running=true;this.send=function(e,f){b.trigger("analytics",{name:e,data:f})};this.listenTo(d,"ic:highlight-panel-click",function(){this.send("confluence.highlight.actions.comment.inline")});this.listenTo(d,"ic:view",function(f,e){this.send("confluence.comment.inline.view");if(e==="nav"){this.send("confluence.comment.inline.view.nav")}if(e==="permalink"){this.send("confluence.comment.inline.view.permalink")}});this.listenTo(d,"ic:overlap",function(){this.send("confluence.comment.inline.overlap")});this.listenTo(d,"ic:edit",function(){this.send("confluence.comment.inline.edit")});this.listenTo(d,"ic:persist",function(){this.send("confluence.comment.inline.create")});this.listenTo(d,"ic:sidebar:close",function(){this.send("confluence.comment.inline.sidebar.close")});this.listenTo(d,"ic:reply:persist",function(){this.send("confluence.comment.inline.reply")});this.listenTo(d,"ic:delete ic:reply:delete",function(){this.send("confluence.comment.inline.delete")});this.listenTo(d,"ic:resolved",function(){this.send("confluence.comment.inline.resolved")});this.listenTo(d,"ic:unresolved",function(){this.send("confluence.comment.inline.unresolved")});this.listenTo(d,"ic:resolved:view",function(f){var e={total:f};this.send("confluence.comment.inline.resolved.view",e)});this.listenTo(d,"ic:resolved:dismiss:recovery",function(){this.send("confluence.comment.inline.resolved.dismiss")});this.listenTo(d,"ic:resolved:show:recovery",function(){this.send("confluence.comment.inline.resolved.discovery")});this.listenTo(d,"ic:open:dangled",function(f){var e={commentId:f.get("id"),pageId:b.Meta.get("page-id")};this.send("confluence.comment.inline.open.dangled",e)});this.listenTo(d,"ic:editor:load:fail",function(){var e={pageId:b.Meta.get("page-id")};this.send("confluence.comment.inline.editor.load.fail",e)});this.listenTo(d,"ic:resolve:dangled:failed",function(f){var e={commentId:f.get("id"),pageId:b.Meta.get("page-id")};this.send("confluence.comment.inline.resolved.dangled.failed",e)})};a.stop=function(){this.running=false;this.stopListening()};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:app', location = '/app/app.js' */
define("confluence/ic/app/app",["jquery","backbone","ajs","confluence/ic/model/comment","confluence/ic/model/comment-collection","confluence/ic/view/highlight-text","confluence/ic/view/sidebar","confluence/ic/view/resolved-comment-list","confluence/ic/util/text-highlighter","confluence/ic/util/utils","confluence/ic/analytics","confluence/ic/likes/likes-manager","exports"],function(f,m,k,b,c,a,i,d,h,g,l,j,e){function n(){l.start();var q=new i({$wikiContent:f("#content .wiki-content").first()});g.getPageContainer().append(q.$el);var p=new c();new a({collection:p});f("body").on("click","#view-resolved-comments",function(u){u.preventDefault();new d({collection:p}).render()});var t=f("#view-resolved-comments>span");var s=function(){t.text("Resolved comments"+k.format(" ({0})",p.getResolvedCount()))};p.fetch({cache:false});p.once("sync",function(u){var v=window.location.search;g.showFocusedComment(u,v,d);s()});p.on("change:resolveProperties",function(){s()});var o=function(w,v){var x=p.get(v);var u=false;if(x===undefined){x=new b({id:v});u=true}x.fetch({success:function(y){y._setHighlights(y.get("markerRef"));if(u){p.add(y)}else{x.replies.isFetched=false}m.trigger("ic:view",x,"quickreload")}})};k.bind("qr:show-new-thread",o);if(Confluence&&Confluence.Likes&&Confluence.Likes.getLikesCache){Confluence.Likes.getLikesCache().done(function(u){j.init(u);m.trigger("ic:likes-received")})}if(!g.getDarkFeatures().INLINE_COMMENTS){return}var r="com.atlassian.confluence.plugins.confluence-inline-comments:create-inline-comment";if(Confluence&&Confluence.HighlightAction){Confluence.HighlightAction.registerButtonHandler(r,{onClick:function(w){if(g.confirmProcess()){m.trigger("ic:highlight-panel-click");f(".inline-comment-marker").removeClass("active");var u=g.overlappedSelection(w,p);if(u){var v=f('.inline-comment-marker[data-ref="'+u.get("markerRef")+'"]');Confluence.HighlightAction.clearTextSelection();u.highlight=v;m.trigger("ic:overlap",u)}else{var x=(new h()).removeHighlight().highlight(w.range);m.trigger("ic:create",p,w,x)}}},shouldDisplay:Confluence.HighlightAction.WORKING_AREA.MAINCONTENT_ONLY})}}e.init=n});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:bootstrap', location = '/app/bootstrap.js' */
require(["jquery","ajs","confluence/ic/app/app"],function(c,a,b){if(a.Meta.get("page-id")&&(a.Meta.get("page-id")===a.Meta.get("latest-page-id"))){c(b.init)}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-content-report-plugin:resources', location = 'com/atlassian/confluence/plugins/content_report/js/tablesorter-date-parser.js' */
(function(A){A(function(){A.tablesorter.addParser({id:"dateAttributeParser",is:function(B,D,C){return A(C).is(".content-report-table-macro .modified")
},format:function(B,D,C,E){return A(C).attr("data-sortable-date")
},type:"numeric"})
})
})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-content-report-plugin:resources', location = 'com/atlassian/confluence/plugins/content_report/soy/content-report-table.soy' */
// This file was automatically generated from content-report-table.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Plugins == 'undefined') { Confluence.Templates.Plugins = {}; }
if (typeof Confluence.Templates.Plugins.ContentReport == 'undefined') { Confluence.Templates.Plugins.ContentReport = {}; }


Confluence.Templates.Plugins.ContentReport.contentReportTable = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var hasSocialColumn__soy3 = opt_data.showCommentsCount || opt_data.showLikesCount;
  if (opt_data.results.length == 0 && opt_data.blueprintKey) {
    output.append('<div class="blueprint-blank-experience ', soy.$$escapeHtml(opt_data.blueprintKey), '"><div class="content"><h2>', soy.$$escapeHtml(opt_data.blankTitle), '</h2><p>', soy.$$escapeHtml(opt_data.blankDescription), '</p></div>', (opt_data.createButtonLabel) ? '<p><button class="create-from-template-button aui-button aui-button-primary" data-space-key="' + soy.$$escapeHtml(opt_data.dataSpaceKey) + '" data-content-blueprint-id="' + soy.$$escapeHtml(opt_data.contentBlueprintId) + '" href="' + soy.$$escapeHtml(opt_data.createContentUrl) + '" >' + soy.$$escapeHtml(opt_data.createButtonLabel) + '</button></p>' : '', '</div>');
  } else {
    output.append('<table class="aui content-report-table-macro', (hasSocialColumn__soy3) ? ' with-extra-columns' : '', '"', (opt_data.analyticsKey) ? ' data-analytics-key="' + soy.$$escapeHtml(opt_data.analyticsKey) + '"' : '', '><thead><tr><th>', soy.$$escapeHtml("Title"), '</th><th>', soy.$$escapeHtml("Creator"), '</th><th>', soy.$$escapeHtml("Modified"), '</th></tr></thead><tbody>');
    var resultList43 = opt_data.results;
    var resultListLen43 = resultList43.length;
    if (resultListLen43 > 0) {
      for (var resultIndex43 = 0; resultIndex43 < resultListLen43; resultIndex43++) {
        var resultData43 = resultList43[resultIndex43];
        output.append('<tr><td class="title"><a href="', soy.$$escapeHtml(resultData43.urlPath), '">', soy.$$escapeHtml(resultData43.title), '</a></td><td class="creator">');
        Confluence.Templates.User.usernameLink({canView: opt_data.canViewProfiles, username: resultData43.creatorName, fullName: resultData43.creatorFullName, contextPath: opt_data.contextPath}, output);
        output.append('</td><td class="modified" data-sortable-date="', soy.$$escapeHtml(resultData43.sortableDate), '">', soy.$$escapeHtml(resultData43.friendlyModificationDate), '</td>', (hasSocialColumn__soy3) ? '<td class="social">' + ((opt_data.showCommentsCount && resultData43.commentCount != 0) ? '<span class="icon icon-comment"></span> <span class="count">' + soy.$$escapeHtml(resultData43.commentCount) + '</span>' : '') + ((opt_data.showLikesCount && resultData43.likeCount != 0) ? '<span class="icon icon-like"></span> <span class="count">' + soy.$$escapeHtml(resultData43.likeCount) + '</span>' : '') + '</td>' : '', '</tr>');
      }
    } else {
      output.append('<tr><td colspan="3">', soy.$$escapeHtml("No content found."), '</td></tr>');
    }
    output.append('</tbody></table>', (opt_data.searchMoreResultsLinkUrl) ? '<div class="more-results"><a href="' + soy.$$escapeHtml("/wiki") + soy.$$escapeHtml(opt_data.searchMoreResultsLinkUrl) + '">' + soy.$$escapeHtml("Find more results") + '</a></div>' : '');
  }
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-content-report-plugin:resources', location = 'com/atlassian/confluence/plugins/content_report/js/content-report-analytics.js' */
AJS.$(function(A){A(".content-report-table-macro").on("click",".title a",function(D){var B=A(D.delegateTarget).data("analytics-key");
if(B){var C="content-report-table-macro.content-click."+B;
AJS.trigger("analytics",{name:C})
}})
});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-page-banner:page-banner-common-resources', location = 'js/page-banner.js' */
AJS.toInit(function(e){d();AJS.bind("system-content-metadata.toggled-restrictions",function(g,h){AJS.setVisible("#content-metadata-page-restrictions",h.hasRestrictions);d()});AJS.bind("breadcrumbs.expanded",f);e("#page-metadata-banner").css("visibility","visible");b();e("#content-metadata-page-restrictions").click(function(g){g.preventDefault();AJS.trigger("system-content-metadata.open-restrictions-dialog")});function d(){if(e("#system-content-items").children(":not(.hidden)").length==0){e("#system-content-items").addClass("hidden")}else{e("#system-content-items").removeClass("hidden")}}function f(){e("#page-metadata-banner").hide()}function b(){var g=e("#system-content-items a:not(.tipsy-disabled), .page-metadata-item a:not(.tipsy-disabled), .page-metadata-modification-info a.last-modified:not(tipsy-disabled)");a(g);g.click(function(h){c(e(h.target).closest("a"))});e(window).on("click scroll resize",c)}function a(g){e(g).tooltip({live:true,gravity:e("#com-atlassian-confluence").hasClass("theme-documentation view-blog-post")?"nw":"n",title:"title",delayIn:500})}function c(g){e(".tipsy").remove();if(g){var h=e(g).data("tipsy");if(h){h.hoverState="out"}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-page-banner:page-banner-common-resources', location = 'js/page-banner-analytics.js' */
AJS.toInit(function(c){function b(){if(!AJS.Confluence.Analytics||!AJS.Confluence.Analytics.setAnalyticsSource){AJS.log("WARNING: Could not initialise analytics for the page banner: AJS.Confluence.Analytics.setAnalyticsSource is not defined.");return}var e=AJS.Confluence.Analytics.setAnalyticsSource;var f=c("#breadcrumbs > li");e(f.filter(":not(#ellipsis)").find("a"),"breadcrumbs");e(f.filter(".hidden-crumb").find("a"),"breadcrumbs-expanded");e(f.filter(":last").find("a"),"breadcrumbs-parent");var d=c("#com-atlassian-confluence").hasClass("theme-documentation")?"breadcrumbs-homepage":"breadcrumbs-collector";e(f.filter(".first").find("a"),d)}function a(e,d,g){var f=null;e.mouseover(function(){f=setTimeout(g,d)});e.mouseout(function(){clearTimeout(f)})}AJS.bind("breadcrumbs.expanded",function(){AJS.trigger("analyticsEvent",{name:"breadcrumbs-expanded"})});b()});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-page-banner:soy-resources', location = 'soy/page-banner.soy' */
// This file was automatically generated from page-banner.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.PageBanner == 'undefined') { Confluence.Templates.PageBanner = {}; }


Confluence.Templates.PageBanner.banner = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="page-metadata-banner"><ul class="banner">');
  Confluence.Templates.PageBanner.renderSystemContentItems(opt_data, output);
  var itemList6 = opt_data.pageBannerItems;
  var itemListLen6 = itemList6.length;
  for (var itemIndex6 = 0; itemIndex6 < itemListLen6; itemIndex6++) {
    var itemData6 = itemList6[itemIndex6];
    Confluence.Templates.PageBanner.renderPageBannerItem(itemData6, output);
  }
  output.append('</ul></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.PageBanner.renderSystemContentItems = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li id="system-content-items" class="noprint">');
  var itemList12 = opt_data.systemContentItems;
  var itemListLen12 = itemList12.length;
  for (var itemIndex12 = 0; itemIndex12 < itemListLen12; itemIndex12++) {
    var itemData12 = itemList12[itemIndex12];
    Confluence.Templates.PageBanner.itemAnchor(soy.$$augmentData(itemData12, {isSystemContentItem: true}), output);
  }
  output.append('</li>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.PageBanner.renderPageBannerItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li class="page-metadata-item noprint ', (opt_data.isAuiButton) ? 'has-button' : '', '" ', (opt_data.linkId) ? ' id="' + soy.$$escapeHtml(opt_data.linkId) + '-wrapper"' : '', '>');
  Confluence.Templates.PageBanner.itemAnchor(opt_data, output);
  output.append('</li>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.PageBanner.itemAnchor = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="', soy.$$escapeHtml(opt_data.href), '" title="', soy.$$escapeHtml(opt_data.tooltip), '" ', (opt_data.linkId) ? 'id="' + soy.$$escapeHtml(opt_data.linkId) + '"' : '', ' ', (opt_data.styleClasses) ? 'class="' + soy.$$escapeHtml(opt_data.styleClasses) + '"' : '', '>');
  Confluence.Templates.PageBanner.itemIcon(opt_data, output);
  output.append((! opt_data.isSystemContentItem) ? '<span>' + soy.$$escapeHtml(opt_data.label) + '</span>' : '', '</a>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.PageBanner.itemIcon = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.icon) ? '<img class="page-banner-item-icon" src="' + soy.$$escapeHtml(opt_data.icon.url) + '" style="height: ' + soy.$$escapeHtml(opt_data.icon.height) + 'px; width: ' + soy.$$escapeHtml(opt_data.icon.width) + 'px;"/>' : '');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'js/inline-tasks.js' */
(function(f){function e(m){var h,n;if(m.offsetX===undefined){var l=0,k=0,j=m.target,i;do{if(j.scrollTop!=0||j.scrollLeft!=0){i=j}l+=j.offsetLeft;k+=j.offsetTop;j=j.offsetParent}while(j&&j!=j.offsetParent);h=m.pageX+(i?i.scrollLeft:0)-l;n=m.pageY+(i?i.scrollTop:0)-k}else{h=m.offsetX;n=m.offsetY}return h>=3&&h<=14&&n>=3&&n<=14}function d(h){return h.currentTarget===h.target}function c(i){var h="page";if(i.closest("table.tasks-report").length){h="report"}else{if(i.closest("#task-container").length){h="mytasks"}else{if(i.closest("ul.inline-task-list").length){h="task"}}}return h}function g(k,i){var h=k.attr("data-inline-task-id");var j=k.find(i).first();if(j.closest("li").attr("data-inline-task-id")===h){return j}else{return f()}}var a=false;f(window).bind("beforeunload",function(){a=true});var b=[];f(document).delegate("ul.inline-task-list > li[data-inline-task-id]",{click:function(m){if(d(m)&&e(m)){var k=f(m.target).toggleClass("checked"),h=k.hasClass("checked")?"CHECKED":"UNCHECKED",j=k.data("inline-task-id"),n=k.closest("ul").attr("data-inline-tasks-content-id")||AJS.params.pageId,i=AJS.contextPath()+"/rest/inlinetasks/1/task/"+n+"/"+j+"/";k.prop("disabled",true);var l=k.closest("tr");l.attr("aria-disabled",true);b.push(j);AJS.trigger("inline-tasks.status-update.start",{status:h,taskId:j,taskListQueue:b});f.ajax({type:"POST",url:i,data:{status:h,trigger:"VIEW_PAGE",atl_token:AJS.Meta.get("atl-token")},dataType:"text",timeout:30000,error:function(p,r,o){if(a||r==="timeout"){return}AJS.logError("Inline Task #"+j+" was not persisted to "+h+" because of "+o+" (status: "+r+")");k.toggleClass("checked");var q;if(p.status===403){q=new Confluence.InlineTasks.Notice({textMessage:"Oops! You can\'t update this task because you are not allowed to edit the page it appears on.",className:"forbidden-notice"})}else{q=new Confluence.InlineTasks.Notice()}q.show()},success:function(){var o={dueDate:g(k,"time").attr("datetime"),completionDate:moment().format("YYYY-MM-DD"),mode:"view",assigneeUsername:g(k,".user-mention").attr("data-username"),context:c(k)};if(h==="CHECKED"){AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.completed",data:o})}}}).always(function(){k.prop("disabled",false);var o=k.closest("tr");o.attr("aria-disabled",false);b.splice(AJS.indexOf(b,j),1);AJS.trigger("inline-tasks.status-update.complete",{status:h,taskId:j,taskListQueue:b})})}},mousemove:function(h){if(d(h)){if(e(h)){f(h.target).addClass("hover")}else{f(h.target).removeClass("hover")}}},mouseout:function(h){if(d(h)){f(h.target).removeClass("hover")}},mousedown:function(h){if(d(h)&&e(h)){f(h.target).addClass("task-active")}},mouseup:function(h){if(d(h)&&e(h)){f(h.target).removeClass("task-active")}}});f("ul.inline-task-list li:not(.checked) time.date-upcoming").tooltip({title:function(){return "This task is due in less than a week"},live:true});f("ul.inline-task-list li:not(.checked) time.date-past").tooltip({title:function(){return "This task is overdue"},live:true});f("span.emptycompletedate").tooltip({title:function(){return "A completion date wasn\'t recorded for this task"},live:true});f(document).on("click","time",function(){var i=f(this);var h={date:i.attr("datetime"),mode:"view",context:c(i)};AJS.trigger("analyticsEvent",{name:"confluence-spaces.date.clicked",data:h})})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'js/inline-tasks-alert.js' */
Confluence.InlineTasks=Confluence.InlineTasks||{};(function(b){var a=function(c){this.settings=b.extend({},a.DEFAULTS,c);this.template=Confluence.InlineTasks.Templates;b("#inline-tasks-notice").remove();var d=b(this.template.notice(this.settings));d.hide().appendTo("body");d.find(".notice-close").click(function(){d.hide()});this.$notice=d};a.DEFAULTS={textMessage:"Oops! Your task change couldn\'t be saved. \u003cbr/\u003eThere could be a few reasons for this.",className:"general-notice"};a.prototype.show=function(){this.$notice.show();return this};a.prototype.hide=function(){this.$notice.hide();return this};Confluence.InlineTasks.Notice=a}(AJS.$));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'templates/inline-tasks.soy' */
// This file was automatically generated from inline-tasks.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.InlineTasks == 'undefined') { Confluence.InlineTasks = {}; }
if (typeof Confluence.InlineTasks.Templates == 'undefined') { Confluence.InlineTasks.Templates = {}; }


Confluence.InlineTasks.Templates.notice = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="aui-message error', (opt_data.className) ? ' ' + soy.$$escapeHtml(opt_data.className) : '', '" id="inline-tasks-notice">', opt_data.textMessage, '&nbsp;&nbsp;<a href="#" class="notice-close">', soy.$$escapeHtml("Dismiss"), '</a></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'js/inline-tasks-focus.js' */
AJS.$(document).ready(function(f){var d="focusedTaskId";var a=require("confluence/jsUri");var c=new a(window.location.href);var g=c.getQueryParamValue(d);if(g){var b=$("li[data-inline-task-id="+g+"]");if(b.length){b.addClass("focused");window.scrollTo(b.offset().left,(b.offset().top-($(window).height()/2)))}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:sortable-table-server-side', location = 'js/jquery.tablesorter.serveronly.js' */
(function(a){a.extend({tablesorterServerOnly:new function(){this.defaults={classNameDisableSorting:"aui-table-column-unsortable",classNameHeaderDesc:"tablesorter-headerDesc",classNameHeaderAsc:"tablesorter-headerAsc",reverseSort:false,sortColumn:"",onInit:function(){},onSort:function(){},events:{clickHeader:"click.sortServerOnly",refreshHeader:"refreshHeader.sortServerOnly",simulateClickHeader:"simulateClickHeader.sortServerOnly"}};var b=this;var d={updateCurrentHeaderSort:function(e,f){d.resetHeadersSort(e,f);f.$headers.each(function(){var h=a(this),g=h.attr("data-column-name");var i=f.reverseSort;if(g===f.sortColumn){i?h.addClass(f.classNameHeaderDesc):h.addClass(f.classNameHeaderAsc)}})},resetHeadersSort:function(e,f){f.$headers.removeClass(f.classNameHeaderDesc).removeClass(f.classNameHeaderAsc)},prepareHTMLHeader:function(e,f){f.$headers.not("."+f.classNameDisableSorting).attr("unselectable","on").bind("selectstart",false).addClass("tablesorter-header").wrapInner("<span class='aui-table-header-content'/>")},bindEvents:function(f,g){var e=a(f);e.on(g.events.refreshHeader,function(){d.updateCurrentHeaderSort(f,g)});e.on(g.events.simulateClickHeader,function(i,j,h){g.reverseSort=h;g.sortColumn=j})}};var c=function(f,g){var e=a(f);g.$table=e;g.$headers=e.find("thead th");g.$tbodies=e.find("tbody");d.prepareHTMLHeader(f,g);d.updateCurrentHeaderSort(f,g);if(typeof g.onInit==="function"){g.onInit.apply(f,[g])}g.$headers.on(g.events.clickHeader,function(){var h=a(this);if(h.hasClass(g.classNameDisableSorting)){return false}var i=h.attr("data-column-name");if(i===g.sortColumn){g.reverseSort=!g.reverseSort}else{g.reverseSort=false}g.sortColumn=i;if(typeof g.onSort==="function"){g.onSort.apply(f,[g])}return false});d.bindEvents(f,g)};b.construct=function(e){return this.each(function(){var f=this,g=a.extend(true,{},a.tablesorterServerOnly.defaults,e);if(this.config&&f.hasInitialized&&a.tablesorter){a.tablesorter.destroy(f,false,function(){c(f,g)})}else{c(f,g)}})}}()});a.fn.extend({tablesorterServerOnly:a.tablesorterServerOnly.construct})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:sortable-table-server-side', location = 'js/tasks-table-sortable.js' */
(function(a){var b=function(d){this.ajaxUrl=d.ajaxUrl;this.restUrlPagination=d.restUrlPagination;this.$wrapper=d.$wrapper;this.table=d.table;this.$table=a(this.table);this.analyticEventKey=d.analyticEventKey;this.sortColumnDefault=d.sortColumnDefault||"duedate";this.sortReverseSortDefault=d.sortReverseSortDefault||false;this.reportParametersDefault=d.reportParametersDefault;this.pageIndex=d.pageIndex||0;this.pageSize=d.pageSize||10;this.pageTotal=d.pageTotal||0;this.pageLimit=d.pageLimit||7;this.adaptive=d.adaptive;this.columns=d.columns;this.templates=d.templates;this.onRenderEmptyTable=d.onRenderEmptyTable;this.onBusySorting=d.onBusySorting};b.getColumnNameFromSortBy=function(e){var d={"due date":"duedate","page title":"location",assignee:"assignee"};return d[e]?d[e]:"duedate"};b.getSortByFromColumnName=function(d){var e={duedate:"due date",location:"page title"};return e[d]?e[d]:d};b.prototype.updateOptions=function(d){a.extend(this,d);this.$table=a(this.table)};b.prototype.getCurrentPageIndex=function(){var e=this.$wrapper.find(".macro-auto-pagination").last();var d=parseInt(e.attr("data-initial-page-index"),10);return isNaN(d)?0:d};b.prototype.renderPagination=function(e,g){var d=this;if(!e){e=d.$table}if(!g){g=d.reportParametersDefault}this.$wrapper.find(".macro-auto-pagination").remove();if(!(d.pageTotal>1)){return}c.UI.Components.Pagination.build({scope:e,pageSize:d.pageSize,totalPages:d.pageTotal,pageLimit:d.pageLimit,path:d.restUrlPagination,adaptive:d.adaptive,currentPage:d.pageIndex,data:{reportParameters:JSON.stringify(g)},success:function f(h,j){var k={task:h,columns:d.columns};var i=d.templates.tasksReportLine(k);j.append(i)}})};b.prototype.toggleBusyState=function(d){this.$wrapper.attr("data-loading",d);if(d){this.$wrapper.find(".task-blanket").show()}else{this.$wrapper.find(".task-blanket").hide()}if(typeof this.onBusySorting==="function"){this.onBusySorting.apply(this,[d])}};b.prototype.renderTable=function(e){var d=this;var f=_.map(e,function(g){return d.templates.tasksReportLine({task:g,columns:d.columns})}).join("");d.$table.find("tbody").html(f)};b.prototype._triggerAnalyticsSorting=function(){var d=this.analyticEventKey;var e={column:this.sortColumn,direction:this.reverseSort?"desc":"asc"};AJS.trigger("analyticsEvent",{name:d,data:e})};b.prototype._buildAjaxData=function(e){var d={url:this.ajaxUrl,cache:false,dataType:"json",data:{pageIndex:this.pageIndex,pageSize:this.pageSize,reportParameters:JSON.stringify(e)}};return d};b.prototype.init=function(){var d=this;d.sortColumn=d.sortColumnDefault;d.reverseSort=d.sortReverseSortDefault;this.$table.tablesorterServerOnly({sortColumn:d.sortColumn,reverseSort:d.reverseSort,onInit:function(){var e=a(this);e.addClass("aui-table-sortable")},onSort:function(i){var h=this,f=a(h);d.pageIndex=d.getCurrentPageIndex();d.sortColumn=i.sortColumn;d.reverseSort=i.reverseSort;d.toggleBusyState(true);var g=a.extend({},d.reportParametersDefault,{sortColumn:b.getSortByFromColumnName(d.sortColumn),reverseSort:d.reverseSort});var e=d._buildAjaxData(g);a.ajax(e).done(function(j){d.pageIndex=d.getCurrentPageIndex();d.pageTotal=j.totalPages;if(d.pageIndex===0&&d.pageTotal===0){if(typeof d.onRenderEmptyTable==="function"){d.$wrapper.find(".macro-auto-pagination").remove();f.remove();d.onRenderEmptyTable.apply(d)}return}d.renderTable(j.detailLines);d.renderPagination(null,g);f.trigger("refreshHeader.sortServerOnly");d._triggerAnalyticsSorting()}).fail(function(){var j=new c.InlineTasks.Notice({textMessage:"We can\'t sort your tasks right now. Refresh the page to try again.",className:"forbidden-notice"});j.show()}).always(function(){d.toggleBusyState(false)})}})};var c=window.Confluence||{};c.InlineTasks=c.InlineTasks||{};c.InlineTasks.TasksTableSortable=b})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:common', location = '/js/namespace.js' */
window.Confluence||(window.Confluence={});window.Confluence.UI||(window.Confluence.UI={});window.Confluence.UI.Components||(window.Confluence.UI.Components={});window.Confluence.UI.Components.SpacePicker||(window.Confluence.UI.Components.SpacePicker={});window.Confluence.UI.Components.LabelPicker||(window.Confluence.UI.Components.LabelPicker={});window.Confluence.UI.Components.Pagination||(window.Confluence.UI.Components.Pagination={});window.Confluence.UI.Components.SpacePagePicker||(window.Confluence.UI.Components.SpacePagePicker={});window.Confluence.UI.Components.PagePicker||(window.Confluence.UI.Components.PagePicker={});window.Confluence.UI.Components.CQL||(window.Confluence.UI.Components.CQL={});window.Confluence.UI.Components.CQL.Ajax||(window.Confluence.UI.Components.CQL.Ajax={});window.Confluence.UI.Components.CQL.Field||(window.Confluence.UI.Components.CQL.Field={});window.Confluence.UI.Components.CQL.Field.Model||(window.Confluence.UI.Components.CQL.Field.Model={});window.Confluence.UI.Components.CQL.FilterField||(window.Confluence.UI.Components.CQL.FilterField={});window.Confluence.UI.Components.CQL.FilterSelect||(window.Confluence.UI.Components.CQL.FilterSelect={});window.Confluence.UI.Components.CQL.ContentTypePicker||(window.Confluence.UI.Components.CQL.ContentTypePicker={});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:pagination', location = '/js/pagination.js' */
(function(e,c){var d=function(j,k,i){var h=j.find("a").attr("aria-disabled",i);if(i){h.attr("disabled","disabled")}else{h.removeAttr("disabled");var g=e(".aui-nav-selected",j).data("index")+1;j.find(".aui-nav-next > a").attr("aria-disabled",g==k);j.find(".aui-nav-previous > a").attr("aria-disabled",g==1)}};var b={scope:null,success:null,data:null,path:"",url:"#",pageLimit:7,currentPage:0,adaptive:false,totalPages:0,pageSize:0};var f=function(i,j,k){var g=Math.floor(k/2);var h=j-1;if(!k||j<=k||i-g<0){return 0}if(i+g>h){return j-k}return i-g};var a=function(l){var k=l.totalPages,j=l.currentPage,m=l.pageLimit,h=l.adaptive,g;if(m){if(h){k=j+m}g=m}else{g=k}var i=f(j,k,m);return Confluence.UI.Components.Pagination.Templates.paginationFooter({currentPage:j||0,startPage:i,itemsToRender:g,totalPages:k,pageSize:l.pageSize,url:l.url||"#"})};c.build=function(j){var h=_.extend({},b,j);if(typeof h.success!=="function"){h.success=function(){}}var k=a(h);h.scope.after(k);var i=h.scope.next();var g=i.data("initial-page-index");i.on("click","a",function(p){var o=e(this),r=o.parents("ol").prev(),n=r.is("table")?r:r.find("table");var l=n.data("pageIndex")||g,q=o.parent("li");if(q.hasClass("aui-nav-selected")||q.find("> a[aria-disabled=true]").length){return}if(q.hasClass("aui-nav-next")){l++}else{if(q.hasClass("aui-nav-previous")){l--}else{l=q.data("index")}}d(i,h.totalPages,true);var m=e.extend({},{pageSize:h.pageSize,pageIndex:l},h.data);e.getJSON(Confluence.getContextPath()+h.path,m).done(function(t){l=t.currentPage;var s=n.find("tbody");s.find("tr").remove();n.data("pageIndex",l);_.each(t.detailLines,function(v){h.success(v,s)});AJS.trigger("ui.components.pagination.updated",[t,h]);var u=e.extend({},h,{totalPages:t.totalPages,adaptive:t.adaptive,currentPage:l});i.html(a(u));d(i,u.totalPages,false)}).fail(function(){d(i,h.totalPages,false)});p.preventDefault()})}})(AJS.$,window.Confluence.UI.Components.Pagination);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:pagination', location = '/soy/pagination.soy' */
// This file was automatically generated from pagination.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.UI == 'undefined') { Confluence.UI = {}; }
if (typeof Confluence.UI.Components == 'undefined') { Confluence.UI.Components = {}; }
if (typeof Confluence.UI.Components.Pagination == 'undefined') { Confluence.UI.Components.Pagination = {}; }
if (typeof Confluence.UI.Components.Pagination.Templates == 'undefined') { Confluence.UI.Components.Pagination.Templates = {}; }


Confluence.UI.Components.Pagination.Templates.paginationFooter = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ol class="aui-nav aui-nav-pagination macro-auto-pagination" data-page-size="', soy.$$escapeHtml(opt_data.pageSize), '" data-initial-page-index="', soy.$$escapeHtml(opt_data.currentPage), '"><li class="aui-nav-previous"><a ', (opt_data.currentPage == 0) ? 'aria-disabled="true"' : 'href="#"', '>', soy.$$escapeHtml("Prev"), '</a></li>');
  var startIdx__soy16 = opt_data.startPage + 1;
  var currentIdx__soy17 = opt_data.currentPage + 1;
  var endIdx__soy18 = startIdx__soy16 + opt_data.itemsToRender;
  var totalRange__soy19 = opt_data.totalPages + 1;
  var indexInit20 = startIdx__soy16;
  var indexLimit20 = endIdx__soy18 < totalRange__soy19 ? endIdx__soy18 : totalRange__soy19;
  for (var index20 = indexInit20; index20 < indexLimit20; index20++) {
    output.append((index20 == currentIdx__soy17) ? '<li class="aui-nav-selected" data-index="' + soy.$$escapeHtml(index20 - 1) + '">' + soy.$$escapeHtml(index20) + '</li>' : '<li data-index="' + soy.$$escapeHtml(index20 - 1) + '"><a href="#">' + soy.$$escapeHtml(index20) + '</a></li>');
  }
  output.append('<li class="aui-nav-next"><a ', (currentIdx__soy17 == opt_data.totalPages) ? 'aria-disabled="true"' : 'href="' + soy.$$escapeHtml(opt_data.url) + '"', '>', soy.$$escapeHtml("Next"), '</a></li></ol>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:blank-placeholder-box', location = 'soy/blank-placeholder-box.soy' */
// This file was automatically generated from blank-placeholder-box.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.UI == 'undefined') { Confluence.UI = {}; }
if (typeof Confluence.UI.Components == 'undefined') { Confluence.UI.Components = {}; }
if (typeof Confluence.UI.Components.BlankPlaceholderBox == 'undefined') { Confluence.UI.Components.BlankPlaceholderBox = {}; }
if (typeof Confluence.UI.Components.BlankPlaceholderBox.Templates == 'undefined') { Confluence.UI.Components.BlankPlaceholderBox.Templates = {}; }


Confluence.UI.Components.BlankPlaceholderBox.Templates.blankBox = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="blank-placeholder-box ', (opt_data.customClass) ? soy.$$escapeHtml(opt_data.customClass) : '', '"><div class="content"><h2>', soy.$$escapeHtml(opt_data.blankTitle), '</h2><p>', soy.$$escapeHtml(opt_data.blankDescription), '</p></div>', (opt_data.customHtml) ? opt_data.customHtml : '', '</div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-experimental-table-sortable', location = 'js-vendor/jquery/jquery.tablesorter.js' */
/*
 * TableSorter 2.10.8 - Client-side table sorting with ease!
 * @requires jQuery v1.2.6+
 *
 * Copyright (c) 2007 Christian Bach
 * Examples and docs at: http://tablesorter.com
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * @type jQuery
 * @name tablesorter
 * @cat Plugins/Tablesorter
 * @author Christian Bach/christian.bach@polyester.se
 * @contributor Rob Garrison/https://github.com/Mottie/tablesorter
 */
!(function(B){B.extend({tablesorter:new function(){var C=this;C.version="2.10.8";C.parsers=[];C.widgets=[];C.defaults={theme:"default",widthFixed:false,showProcessing:false,headerTemplate:"{content}",onRenderTemplate:null,onRenderHeader:null,cancelSelection:true,dateFormat:"mmddyyyy",sortMultiSortKey:"shiftKey",sortResetKey:"ctrlKey",usNumberFormat:true,delayInit:false,serverSideSorting:false,headers:{},ignoreCase:true,sortForce:null,sortList:[],sortAppend:null,sortInitialOrder:"asc",sortLocaleCompare:false,sortReset:false,sortRestart:false,emptyTo:"bottom",stringTo:"max",textExtraction:"simple",textSorter:null,widgets:[],widgetOptions:{zebra:["even","odd"]},initWidgets:true,initialized:null,tableClass:"tablesorter",cssAsc:"tablesorter-headerAsc",cssChildRow:"tablesorter-childRow",cssDesc:"tablesorter-headerDesc",cssHeader:"tablesorter-header",cssHeaderRow:"tablesorter-headerRow",cssIcon:"tablesorter-icon",cssInfoBlock:"tablesorter-infoOnly",cssProcessing:"tablesorter-processing",selectorHeaders:"> thead th, > thead td",selectorSort:"th, td",selectorRemove:".remove-me",debug:false,headerList:[],empties:{},strings:{},parsers:[]};function O(Y){if(typeof console!=="undefined"&&typeof console.log!=="undefined"){console.log(Y)}else{alert(Y)}}function I(Y,Z){O(Y+" ("+(new Date().getTime()-Z.getTime())+"ms)")}C.log=O;C.benchmark=I;function F(b,a,Y){if(!a){return""}var e=b.config,Z=e.textExtraction,d="";if(Z==="simple"){if(e.supportsTextContent){d=a.textContent}else{d=B(a).text()}}else{if(typeof Z==="function"){d=Z(a,b,Y)}else{if(typeof Z==="object"&&Z.hasOwnProperty(Y)){d=Z[Y](a,b,Y)}else{d=e.supportsTextContent?a.textContent:B(a).text()}}}return B.trim(d)}function J(e,g,c,b){var d,Z=C.parsers.length,Y=false,a="",f=true;while(a===""&&f){c++;if(g[c]){Y=g[c].cells[b];a=F(e,Y,b);if(e.config.debug){O("Checking if value was empty on row "+c+", column: "+b+': "'+a+'"')}}else{f=false}}while(--Z>=0){d=C.parsers[Z];if(d&&d.id!=="text"&&d.is&&d.is(a,e,Y)){return d}}return C.getParserById("text")}function K(k){var j=k.config,d=j.$tbodies=j.$table.children("tbody:not(."+j.cssInfoBlock+")"),m,g,b,e,f,Y,a,Z="";if(d.length===0){return j.debug?O("*Empty table!* Not building a parser cache"):""}m=d[0].rows;if(m[0]){g=[];b=m[0].cells.length;for(e=0;e<b;e++){f=j.$headers.filter(":not([colspan])");f=f.add(j.$headers.filter('[colspan="1"]')).filter('[data-column="'+e+'"]:last');Y=j.headers[e];a=C.getParserById(C.getData(f,Y,"sorter"));j.empties[e]=C.getData(f,Y,"empty")||j.emptyTo||(j.emptyToBottom?"bottom":"top");j.strings[e]=C.getData(f,Y,"string")||j.stringTo||"max";if(!a){a=J(k,m,-1,e)}if(j.debug){Z+="column:"+e+"; parser:"+a.id+"; string:"+j.strings[e]+"; empty: "+j.empties[e]+"\n"}g.push(a)}}if(j.debug){O(Z)}j.parsers=g}function X(q){var l=q.tBodies,d=q.config,n,Y,o=d.parsers,r,p,f,e,a,g,h,m,Z=[];d.cache={};if(!o){return d.debug?O("*Empty table!* Not building a cache"):""}if(d.debug){m=new Date()}if(d.showProcessing){C.isProcessing(q,true)}for(a=0;a<l.length;a++){d.cache[a]={row:[],normalized:[]};if(!B(l[a]).hasClass(d.cssInfoBlock)){n=(l[a]&&l[a].rows.length)||0;Y=(l[a].rows[0]&&l[a].rows[0].cells.length)||0;for(f=0;f<n;++f){g=B(l[a].rows[f]);h=[];if(g.hasClass(d.cssChildRow)){d.cache[a].row[d.cache[a].row.length-1]=d.cache[a].row[d.cache[a].row.length-1].add(g);continue}d.cache[a].row.push(g);for(e=0;e<Y;++e){r=F(q,g[0].cells[e],e);p=o[e].format(r,q,g[0].cells[e],e);h.push(p);if((o[e].type||"").toLowerCase()==="numeric"){Z[e]=Math.max(Math.abs(p)||0,Z[e]||0)}}h.push(d.cache[a].normalized.length);d.cache[a].normalized.push(h)}d.cache[a].colMax=Z}}if(d.showProcessing){C.isProcessing(q)}if(d.debug){I("Building cache for "+n+" rows",m)}}function V(u,s){var v=u.config,w=u.tBodies,d=[],g=v.cache,f,h,a,e,x,Z,t,q,p,o,Y,m;if(!g[0]){return }if(v.debug){m=new Date()}for(p=0;p<w.length;p++){x=B(w[p]);if(x.length&&!x.hasClass(v.cssInfoBlock)){Z=C.processTbody(u,x,true);f=g[p].row;h=g[p].normalized;a=h.length;e=a?(h[0].length-1):0;for(t=0;t<a;t++){Y=h[t][e];d.push(f[Y]);if(!v.appender||!v.removeRows){o=f[Y].length;for(q=0;q<o;q++){Z.append(f[Y][q])}}}C.processTbody(u,Z,false)}}if(v.appender){v.appender(u,d)}if(v.debug){I("Rebuilt table",m)}if(!s){C.applyWidget(u)}B(u).trigger("sortEnd",u)}function Q(u){var r=[],a={},q=0,h=B(u).find("thead:eq(0), tfoot").children("tr"),f,e,d,b,o,s,p,Y,n,g,m,Z;for(f=0;f<h.length;f++){s=h[f].cells;for(e=0;e<s.length;e++){o=s[e];p=o.parentNode.rowIndex;Y=p+"-"+o.cellIndex;n=o.rowSpan||1;g=o.colSpan||1;if(typeof (r[p])==="undefined"){r[p]=[]}for(d=0;d<r[p].length+1;d++){if(typeof (r[p][d])==="undefined"){m=d;break}}a[Y]=m;q=Math.max(m,q);B(o).attr({"data-column":m});for(d=p;d<p+n;d++){if(typeof (r[d])==="undefined"){r[d]=[]}Z=r[d];for(b=m;b<m+g;b++){Z[b]="x"}}}}u.config.columns=q;return a}function H(Y){return(/^d/i.test(Y)||Y===1)}function S(j){var a=Q(j),Y,b,e,d,k,g,Z,f=j.config;f.headerList=[];f.headerContent=[];if(f.debug){Z=new Date()}d=f.cssIcon?'<i class="'+f.cssIcon+'"></i>':"";f.$headers=B(j).find(f.selectorHeaders).each(function(c){b=B(this);Y=f.headers[c];f.headerContent[c]=this.innerHTML;k=f.headerTemplate.replace(/\{content\}/g,this.innerHTML).replace(/\{icon\}/g,d);if(f.onRenderTemplate){e=f.onRenderTemplate.apply(b,[c,k]);if(e&&typeof e==="string"){k=e}}this.innerHTML='<div class="tablesorter-header-inner">'+k+"</div>";if(f.onRenderHeader){f.onRenderHeader.apply(b,[c])}this.column=a[this.parentNode.rowIndex+"-"+this.cellIndex];this.order=H(C.getData(b,Y,"sortInitialOrder")||f.sortInitialOrder)?[1,0,2]:[0,1,2];this.count=-1;this.lockedOrder=false;g=C.getData(b,Y,"lockedOrder")||false;if(typeof g!=="undefined"&&g!==false){this.order=this.lockedOrder=H(g)?[1,1,1]:[0,0,0]}b.addClass(f.cssHeader);f.headerList[c]=this;b.parent().addClass(f.cssHeaderRow);b.attr("tabindex",0)});L(j);if(f.debug){I("Built headers:",Z);O(f.$headers)}}function P(Z,Y,b){var a=Z.config;a.$table.find(a.selectorRemove).remove();K(Z);X(Z);W(a.$table,Y,b)}function L(Z){var Y,a=Z.config;a.$headers.each(function(b,c){Y=C.getData(c,a.headers[b],"sorter")==="false";c.sortDisabled=Y;B(c)[Y?"addClass":"removeClass"]("sorter-false")})}function D(k){var e,b,Z,Y,h=k.config,g=h.sortList,d=[h.cssAsc,h.cssDesc],a=B(k).find("tfoot tr").children().removeClass(d.join(" "));h.$headers.removeClass(d.join(" "));Y=g.length;for(b=0;b<Y;b++){if(g[b][1]!==2){e=h.$headers.not(".sorter-false").filter('[data-column="'+g[b][0]+'"]'+(Y===1?":last":""));if(e.length){for(Z=0;Z<e.length;Z++){if(!e[Z].sortDisabled){e.eq(Z).addClass(d[g[b][1]]);if(a.length){a.filter('[data-column="'+g[b][0]+'"]').eq(Z).addClass(d[g[b][1]])}}}}}}}function N(a){if(a.config.widthFixed&&B(a).find("colgroup").length===0){var Y=B("<colgroup>"),Z=B(a).width();B(a.tBodies[0]).find("tr:first").children("td").each(function(){Y.append(B("<col>").css("width",parseInt((B(this).width()/Z)*1000,10)/10+"%"))});B(a).prepend(Y)}}function T(b,d){var a,Z,e,f=b.config,Y=d||f.sortList;f.sortList=[];B.each(Y,function(g,c){a=[parseInt(c[0],10),parseInt(c[1],10)];e=f.headerList[a[0]];if(e){f.sortList.push(a);Z=B.inArray(a[1],e.order);e.count=Z>=0?Z:a[1]%(f.sortReset?3:2)}})}function M(Z,Y){return(Z&&Z[Y])?Z[Y].type||"":""}function U(n,m,f){var l,d,b,Y,p,h=n.config,Z=!f[h.sortMultiSortKey],g=B(n);g.trigger("sortStart",n);m.count=f[h.sortResetKey]?2:(m.count+1)%(h.sortReset?3:2);if(h.sortRestart){d=m;h.$headers.each(function(){if(this!==d&&(Z||!B(this).is("."+h.cssDesc+",."+h.cssAsc))){this.count=-1}})}d=m.column;if(Z){h.sortList=[];if(h.sortForce!==null){l=h.sortForce;for(b=0;b<l.length;b++){if(l[b][0]!==d){h.sortList.push(l[b])}}}Y=m.order[m.count];if(Y<2){h.sortList.push([d,Y]);if(m.colSpan>1){for(b=1;b<m.colSpan;b++){h.sortList.push([d+b,Y])}}}}else{if(h.sortAppend&&h.sortList.length>1){if(C.isValueInArray(h.sortAppend[0][0],h.sortList)){h.sortList.pop()}}if(C.isValueInArray(d,h.sortList)){for(b=0;b<h.sortList.length;b++){p=h.sortList[b];Y=h.headerList[p[0]];if(p[0]===d){p[1]=Y.order[Y.count];if(p[1]===2){h.sortList.splice(b,1);Y.count=-1}}}}else{Y=m.order[m.count];if(Y<2){h.sortList.push([d,Y]);if(m.colSpan>1){for(b=1;b<m.colSpan;b++){h.sortList.push([d+b,Y])}}}}}if(h.sortAppend!==null){l=h.sortAppend;for(b=0;b<l.length;b++){if(l[b][0]!==d){h.sortList.push(l[b])}}}g.trigger("sortBegin",n);setTimeout(function(){D(n);R(n);V(n)},1)}function R(p){var d=0,h=p.config,j=h.sortList,e=j.length,a=p.tBodies.length,r,n,g,o,f,Y,Z,q,b,m;if(h.serverSideSorting||!h.cache[0]){return }if(h.debug){r=new Date()}for(g=0;g<a;g++){f=h.cache[g].colMax;Y=h.cache[g].normalized;Z=Y.length;m=(Y&&Y[0])?Y[0].length-1:0;Y.sort(function(i,c){for(n=0;n<e;n++){o=j[n][0];b=j[n][1];q=/n/i.test(M(h.parsers,o))?"Numeric":"Text";q+=b===0?"":"Desc";if(/Numeric/.test(q)&&h.strings[o]){if(typeof (h.string[h.strings[o]])==="boolean"){d=(b===0?1:-1)*(h.string[h.strings[o]]?-1:1)}else{d=(h.strings[o])?h.string[h.strings[o]]||0:0}}var k=B.tablesorter["sort"+q](p,i[o],c[o],o,f[o],d);if(k){return k}}return i[m]-c[m]})}if(h.debug){I("Sorting on "+j.toString()+" and dir "+b+" time",r)}}function G(Y,Z){Y.trigger("updateComplete");if(typeof Z==="function"){Z(Y[0])}}function W(Z,Y,a){if(Y!==false&&!Z[0].isProcessing){Z.trigger("sorton",[Z[0].config.sortList,function(){G(Z,a)}])}else{G(Z,a)}}function E(Z){var d=Z.config,a=d.$table,Y,b;d.$headers.find(d.selectorSort).add(d.$headers.filter(d.selectorSort)).unbind("mousedown.tablesorter mouseup.tablesorter sort.tablesorter keypress.tablesorter").bind("mousedown.tablesorter mouseup.tablesorter sort.tablesorter keypress.tablesorter",function(g,h){if(((g.which||g.button)!==1&&!/sort|keypress/.test(g.type))||(g.type==="keypress"&&g.which!==13)){return false}if(g.type==="mouseup"&&h!==true&&(new Date().getTime()-b>250)){return false}if(g.type==="mousedown"){b=new Date().getTime();return g.target.tagName==="INPUT"?"":!d.cancelSelection}if(d.delayInit&&!d.cache){X(Z)}var f=/TH|TD/.test(this.tagName)?B(this):B(this).parents("th, td").filter(":first"),c=f[0];if(!c.sortDisabled){U(Z,c,g)}});if(d.cancelSelection){d.$headers.attr("unselectable","on").bind("selectstart",false).css({"user-select":"none",MozUserSelect:"none"})}a.unbind("sortReset update updateRows updateCell updateAll addRows sorton appendCache applyWidgetId applyWidgets refreshWidgets destroy mouseup mouseleave ".split(" ").join(".tablesorter ")).bind("sortReset.tablesorter",function(c){c.stopPropagation();d.sortList=[];D(Z);R(Z);V(Z)}).bind("updateAll.tablesorter",function(f,c,g){f.stopPropagation();C.refreshWidgets(Z,true,true);C.restoreHeaders(Z);S(Z);E(Z);P(Z,c,g)}).bind("update.tablesorter updateRows.tablesorter",function(f,c,g){f.stopPropagation();L(Z);P(Z,c,g)}).bind("updateCell.tablesorter",function(h,k,i,m){h.stopPropagation();a.find(d.selectorRemove).remove();var f,o,j,c=a.find("tbody"),n=c.index(B(k).parents("tbody").filter(":first")),g=B(k).parents("tr").filter(":first");k=B(k)[0];if(c.length&&n>=0){o=c.eq(n).find("tr").index(g);j=k.cellIndex;f=d.cache[n].normalized[o].length-1;d.cache[n].row[Z.config.cache[n].normalized[o][f]]=g;d.cache[n].normalized[o][j]=d.parsers[j].format(F(Z,k,j),Z,k,j);W(a,i,m)}}).bind("addRows.tablesorter",function(g,j,h,k){g.stopPropagation();var f,o=j.filter("tr").length,m=[],c=j[0].cells.length,n=a.find("tbody").index(j.parents("tbody").filter(":first"));if(!d.parsers){K(Z)}for(f=0;f<o;f++){for(Y=0;Y<c;Y++){m[Y]=d.parsers[Y].format(F(Z,j[f].cells[Y],Y),Z,j[f].cells[Y],Y)}m.push(d.cache[n].row.length);d.cache[n].row.push([j[f]]);d.cache[n].normalized.push(m);m=[]}W(a,h,k)}).bind("sorton.tablesorter",function(f,c,h,g){f.stopPropagation();a.trigger("sortStart",this);T(Z,c);D(Z);a.trigger("sortBegin",this);R(Z);V(Z,g);if(typeof h==="function"){h(Z)}}).bind("appendCache.tablesorter",function(c,g,f){c.stopPropagation();V(Z,f);if(typeof g==="function"){g(Z)}}).bind("applyWidgetId.tablesorter",function(c,f){c.stopPropagation();C.getWidgetById(f).format(Z,d,d.widgetOptions)}).bind("applyWidgets.tablesorter",function(c,f){c.stopPropagation();C.applyWidget(Z,f)}).bind("refreshWidgets.tablesorter",function(g,f,c){g.stopPropagation();C.refreshWidgets(Z,f,c)}).bind("destroy.tablesorter",function(g,h,f){g.stopPropagation();C.destroy(Z,h,f)})}C.construct=function(Y){return this.each(function(){if(!this.tHead||this.tBodies.length===0||this.hasInitialized===true){return(this.config&&this.config.debug)?O("stopping initialization! No thead, tbody or tablesorter has already been initialized"):""}var d=B(this),b=this,e,a="",Z=B.metadata;b.hasInitialized=false;b.isProcessing=true;b.config={};e=B.extend(true,b.config,C.defaults,Y);B.data(b,"tablesorter",e);if(e.debug){B.data(b,"startoveralltimer",new Date())}e.supportsTextContent=B("<span>x</span>")[0].textContent==="x";e.supportsDataObject=parseFloat(B.fn.jquery)>=1.4;e.string={max:1,min:-1,"max+":1,"max-":-1,zero:0,none:0,"null":0,top:true,bottom:false};if(!/tablesorter\-/.test(d.attr("class"))){a=(e.theme!==""?" tablesorter-"+e.theme:"")}e.$table=d.addClass(e.tableClass+a);e.$tbodies=d.children("tbody:not(."+e.cssInfoBlock+")");S(b);N(b);K(b);if(!e.delayInit){X(b)}E(b);if(e.supportsDataObject&&typeof d.data().sortlist!=="undefined"){e.sortList=d.data().sortlist}else{if(Z&&(d.metadata()&&d.metadata().sortlist)){e.sortList=d.metadata().sortlist}}C.applyWidget(b,true);if(e.sortList.length>0){d.trigger("sorton",[e.sortList,{},!e.initWidgets])}else{if(e.initWidgets){C.applyWidget(b)}}if(e.showProcessing){d.unbind("sortBegin.tablesorter sortEnd.tablesorter").bind("sortBegin.tablesorter sortEnd.tablesorter",function(c){C.isProcessing(b,c.type==="sortBegin")})}b.hasInitialized=true;b.isProcessing=false;if(e.debug){C.benchmark("Overall initialization time",B.data(b,"startoveralltimer"))}d.trigger("tablesorter-initialized",b);if(typeof e.initialized==="function"){e.initialized(b)}})};C.isProcessing=function(b,Z,a){b=B(b);var d=b[0].config,Y=a||b.find("."+d.cssHeader);if(Z){if(d.sortList.length>0){Y=Y.filter(function(){return this.sortDisabled?false:C.isValueInArray(parseFloat(B(this).attr("data-column")),d.sortList)})}Y.addClass(d.cssProcessing)}else{Y.removeClass(d.cssProcessing)}};C.processTbody=function(a,Y,Z){var b;if(Z){a.isProcessing=true;Y.before('<span class="tablesorter-savemyplace"/>');b=(B.fn.detach)?Y.detach():Y.remove();return b}b=B(a).find("span.tablesorter-savemyplace");Y.insertAfter(b);b.remove();a.isProcessing=false};C.clearTableBody=function(Y){B(Y)[0].config.$tbodies.empty()};C.restoreHeaders=function(Y){var Z=Y.config;Z.$table.find(Z.selectorHeaders).each(function(a){if(B(this).find(".tablesorter-header-inner").length){B(this).html(Z.headerContent[a])}})};C.destroy=function(d,Z,g){d=B(d)[0];if(!d.hasInitialized){return }C.refreshWidgets(d,true,true);var f=B(d),e=d.config,Y=f.find("thead:first"),a=Y.find("tr."+e.cssHeaderRow).removeClass(e.cssHeaderRow),b=f.find("tfoot:first > tr").children("th, td");Y.find("tr").not(a).remove();f.removeData("tablesorter").unbind("sortReset update updateAll updateRows updateCell addRows sorton appendCache applyWidgetId applyWidgets refreshWidgets destroy mouseup mouseleave keypress sortBegin sortEnd ".split(" ").join(".tablesorter "));e.$headers.add(b).removeClass(e.cssHeader+" "+e.cssAsc+" "+e.cssDesc).removeAttr("data-column");a.find(e.selectorSort).unbind("mousedown.tablesorter mouseup.tablesorter keypress.tablesorter");C.restoreHeaders(d);if(Z!==false){f.removeClass(e.tableClass+" tablesorter-"+e.theme)}d.hasInitialized=false;if(typeof g==="function"){g(d)}};C.regex=[/(^([+\-]?(?:0|[1-9]\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?)?$|^0x[0-9a-f]+$|\d+)/gi,/(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[\/\-]\d{1,4}[\/\-]\d{1,4}|^\w+, \w+ \d+, \d{4})/,/^0x[0-9a-f]+$/i];C.sortText=function(s,m,l,d){if(m===l){return 0}var k=s.config,j=k.string[(k.empties[d]||k.emptyTo)],Y=C.regex,p,f,h,q,Z,o,g,n;if(m===""&&j!==0){return typeof j==="boolean"?(j?-1:1):-j||-1}if(l===""&&j!==0){return typeof j==="boolean"?(j?1:-1):j||1}if(typeof k.textSorter==="function"){return k.textSorter(m,l,s,d)}p=m.replace(Y[0],"\\0$1\\0").replace(/\\0$/,"").replace(/^\\0/,"").split("\\0");h=l.replace(Y[0],"\\0$1\\0").replace(/\\0$/,"").replace(/^\\0/,"").split("\\0");f=parseInt(m.match(Y[2]),16)||(p.length!==1&&m.match(Y[1])&&Date.parse(m));q=parseInt(l.match(Y[2]),16)||(f&&l.match(Y[1])&&Date.parse(l))||null;if(q){if(f<q){return -1}if(f>q){return 1}}n=Math.max(p.length,h.length);for(g=0;g<n;g++){Z=isNaN(p[g])?p[g]||0:parseFloat(p[g])||0;o=isNaN(h[g])?h[g]||0:parseFloat(h[g])||0;if(isNaN(Z)!==isNaN(o)){return(isNaN(Z))?1:-1}if(typeof Z!==typeof o){Z+="";o+=""}if(Z<o){return -1}if(Z>o){return 1}}return 0};C.sortTextDesc=function(f,Z,Y,d){if(Z===Y){return 0}var h=f.config,g=h.string[(h.empties[d]||h.emptyTo)];if(Z===""&&g!==0){return typeof g==="boolean"?(g?-1:1):g||1}if(Y===""&&g!==0){return typeof g==="boolean"?(g?1:-1):-g||-1}if(typeof h.textSorter==="function"){return h.textSorter(Y,Z,f,d)}return C.sortText(f,Y,Z)};C.getTextValue=function(Z,e,c){if(e){var b,Y=Z?Z.length:0,f=e+c;for(b=0;b<Y;b++){f+=Z.charCodeAt(b)}return c*f}return 0};C.sortNumeric=function(g,Z,Y,f,j,i){if(Z===Y){return 0}var k=g.config,h=k.string[(k.empties[f]||k.emptyTo)];if(Z===""&&h!==0){return typeof h==="boolean"?(h?-1:1):-h||-1}if(Y===""&&h!==0){return typeof h==="boolean"?(h?1:-1):h||1}if(isNaN(Z)){Z=C.getTextValue(Z,j,i)}if(isNaN(Y)){Y=C.getTextValue(Y,j,i)}return Z-Y};C.sortNumericDesc=function(g,Z,Y,f,j,i){if(Z===Y){return 0}var k=g.config,h=k.string[(k.empties[f]||k.emptyTo)];if(Z===""&&h!==0){return typeof h==="boolean"?(h?-1:1):h||1}if(Y===""&&h!==0){return typeof h==="boolean"?(h?1:-1):-h||-1}if(isNaN(Z)){Z=C.getTextValue(Z,j,i)}if(isNaN(Y)){Y=C.getTextValue(Y,j,i)}return Y-Z};C.characterEquivalents={a:"\u00e1\u00e0\u00e2\u00e3\u00e4\u0105\u00e5",A:"\u00c1\u00c0\u00c2\u00c3\u00c4\u0104\u00c5",c:"\u00e7\u0107\u010d",C:"\u00c7\u0106\u010c",e:"\u00e9\u00e8\u00ea\u00eb\u011b\u0119",E:"\u00c9\u00c8\u00ca\u00cb\u011a\u0118",i:"\u00ed\u00ec\u0130\u00ee\u00ef\u0131",I:"\u00cd\u00cc\u0130\u00ce\u00cf",o:"\u00f3\u00f2\u00f4\u00f5\u00f6",O:"\u00d3\u00d2\u00d4\u00d5\u00d6",ss:"\u00df",SS:"\u1e9e",u:"\u00fa\u00f9\u00fb\u00fc\u016f",U:"\u00da\u00d9\u00db\u00dc\u016e"};C.replaceAccents=function(b){var Z,c="[",Y=C.characterEquivalents;if(!C.characterRegex){C.characterRegexArray={};for(Z in Y){if(typeof Z==="string"){c+=Y[Z];C.characterRegexArray[Z]=new RegExp("["+Y[Z]+"]","g")}}C.characterRegex=new RegExp(c+"]")}if(C.characterRegex.test(b)){for(Z in Y){if(typeof Z==="string"){b=b.replace(C.characterRegexArray[Z],Z)}}}return b};C.isValueInArray=function(b,Z){var c,Y=Z.length;for(c=0;c<Y;c++){if(Z[c][0]===b){return true}}return false};C.addParser=function(c){var b,Z=C.parsers.length,Y=true;for(b=0;b<Z;b++){if(C.parsers[b].id.toLowerCase()===c.id.toLowerCase()){Y=false}}if(Y){C.parsers.push(c)}};C.getParserById=function(Z){var a,Y=C.parsers.length;for(a=0;a<Y;a++){if(C.parsers[a].id.toLowerCase()===(Z.toString()).toLowerCase()){return C.parsers[a]}}return false};C.addWidget=function(Y){C.widgets.push(Y)};C.getWidgetById=function(a){var b,Z,Y=C.widgets.length;for(b=0;b<Y;b++){Z=C.widgets[b];if(Z&&Z.hasOwnProperty("id")&&Z.id.toLowerCase()===a.toLowerCase()){return Z}}};C.applyWidget=function(h,g){h=B(h)[0];var b=h.config,d=b.widgetOptions,e=[],Z,a,f,Y;if(b.debug){Z=new Date()}if(b.widgets.length){b.widgets=B.grep(b.widgets,function(i,c){return B.inArray(i,b.widgets)===c});B.each(b.widgets||[],function(c,j){Y=C.getWidgetById(j);if(Y&&Y.id){if(!Y.priority){Y.priority=10}e[c]=Y}});e.sort(function(i,c){return i.priority<c.priority?-1:i.priority===c.priority?0:1});B.each(e,function(j,c){if(c){if(g){if(c.hasOwnProperty("options")){d=h.config.widgetOptions=B.extend(true,{},c.options,d)}if(c.hasOwnProperty("init")){c.init(h,c,b,d)}}else{if(!g&&c.hasOwnProperty("format")){c.format(h,b,d,false)}}}})}if(b.debug){f=b.widgets.length;I("Completed "+(g===true?"initializing ":"applying ")+f+" widget"+(f!==1?"s":""),Z)}};C.refreshWidgets=function(f,e,Y){f=B(f)[0];var d,g=f.config,b=g.widgets,a=C.widgets,Z=a.length;for(d=0;d<Z;d++){if(a[d]&&a[d].id&&(e||B.inArray(a[d].id,b)<0)){if(g.debug){O("Refeshing widgets: Removing "+a[d].id)}if(a[d].hasOwnProperty("remove")){a[d].remove(f,g,g.widgetOptions)}}}if(Y!==true){C.applyWidget(f,e)}};C.getData=function(d,c,b){var e="",Z=B(d),Y,a;if(!Z.length){return""}Y=B.metadata?Z.metadata():false;a=" "+(Z.attr("class")||"");if(typeof Z.data(b)!=="undefined"||typeof Z.data(b.toLowerCase())!=="undefined"){e+=Z.data(b)||Z.data(b.toLowerCase())}else{if(Y&&typeof Y[b]!=="undefined"){e+=Y[b]}else{if(c&&typeof c[b]!=="undefined"){e+=c[b]}else{if(a!==" "&&a.match(" "+b+"-")){e=a.match(new RegExp("\\s"+b+"-([\\w-]+)"))[1]||""}}}}return B.trim(e)};C.formatFloat=function(a,b){if(typeof a!=="string"||a===""){return a}var Z,Y=b&&b.config?b.config.usNumberFormat!==false:typeof b!=="undefined"?b:true;if(Y){a=a.replace(/,/g,"")}else{a=a.replace(/[\s|\.]/g,"").replace(/,/g,".")}if(/^\s*\([.\d]+\)/.test(a)){a=a.replace(/^\s*\(/,"-").replace(/\)/,"")}Z=parseFloat(a);return isNaN(Z)?B.trim(a):Z};C.isDigit=function(Y){return isNaN(Y)?(/^[\-+(]?\d+[)]?$/).test(Y.toString().replace(/[,.'"\s]/g,"")):true}}()});var A=B.tablesorter;B.fn.extend({tablesorter:A.construct});A.addParser({id:"text",is:function(){return true},format:function(C,D){var E=D.config;if(C){C=B.trim(E.ignoreCase?C.toLocaleLowerCase():C);C=E.sortLocaleCompare?A.replaceAccents(C):C}return C},type:"text"});A.addParser({id:"digit",is:function(C){return A.isDigit(C)},format:function(C,D){var E=A.formatFloat((C||"").replace(/[^\w,. \-()]/g,""),D);return C&&typeof E==="number"?E:C?B.trim(C&&D.config.ignoreCase?C.toLocaleLowerCase():C):C},type:"numeric"});A.addParser({id:"currency",is:function(C){return(/^\(?\d+[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]|[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]\d+\)?$/).test((C||"").replace(/[,. ]/g,""))},format:function(C,D){var E=A.formatFloat((C||"").replace(/[^\w,. \-()]/g,""),D);return C&&typeof E==="number"?E:C?B.trim(C&&D.config.ignoreCase?C.toLocaleLowerCase():C):C},type:"numeric"});A.addParser({id:"ipAddress",is:function(C){return(/^\d{1,3}[\.]\d{1,3}[\.]\d{1,3}[\.]\d{1,3}$/).test(C)},format:function(F,H){var E,D=F?F.split("."):"",G="",C=D.length;for(E=0;E<C;E++){G+=("00"+D[E]).slice(-3)}return F?A.formatFloat(G,H):F},type:"numeric"});A.addParser({id:"url",is:function(C){return(/^(https?|ftp|file):\/\//).test(C)},format:function(C){return C?B.trim(C.replace(/(https?|ftp|file):\/\//,"")):C},type:"text"});A.addParser({id:"isoDate",is:function(C){return(/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/).test(C)},format:function(C,D){return C?A.formatFloat((C!=="")?(new Date(C.replace(/-/g,"/")).getTime()||""):"",D):C},type:"numeric"});A.addParser({id:"percent",is:function(C){return(/(\d\s*?%|%\s*?\d)/).test(C)&&C.length<15},format:function(C,D){return C?A.formatFloat(C.replace(/%/g,""),D):C},type:"numeric"});A.addParser({id:"usLongDate",is:function(C){return(/^[A-Z]{3,10}\.?\s+\d{1,2},?\s+(\d{4})(\s+\d{1,2}:\d{2}(:\d{2})?(\s+[AP]M)?)?$/i).test(C)||(/^\d{1,2}\s+[A-Z]{3,10}\s+\d{4}/i).test(C)},format:function(C,D){return C?A.formatFloat((new Date(C.replace(/(\S)([AP]M)$/i,"$1 $2")).getTime()||""),D):C},type:"numeric"});A.addParser({id:"shortDate",is:function(C){return(/(^\d{1,2}[\/\s]\d{1,2}[\/\s]\d{4})|(^\d{4}[\/\s]\d{1,2}[\/\s]\d{1,2})/).test((C||"").replace(/\s+/g," ").replace(/[\-.,]/g,"/"))},format:function(F,G,C,D){if(F){var I=G.config,E=I.headerList[D],H=E.dateFormat||A.getData(E,I.headers[D],"dateFormat")||I.dateFormat;F=F.replace(/\s+/g," ").replace(/[\-.,]/g,"/");if(H==="mmddyyyy"){F=F.replace(/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,"$3/$1/$2")}else{if(H==="ddmmyyyy"){F=F.replace(/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,"$3/$2/$1")}else{if(H==="yyyymmdd"){F=F.replace(/(\d{4})[\/\s](\d{1,2})[\/\s](\d{1,2})/,"$1/$2/$3")}}}}return F?A.formatFloat((new Date(F).getTime()||""),G):F},type:"numeric"});A.addParser({id:"time",is:function(C){return(/^(([0-2]?\d:[0-5]\d)|([0-1]?\d:[0-5]\d\s?([AP]M)))$/i).test(C)},format:function(C,D){return C?A.formatFloat((new Date("2000/01/01 "+C.replace(/(\S)([AP]M)$/i,"$1 $2")).getTime()||""),D):C},type:"numeric"});A.addParser({id:"metadata",is:function(){return false},format:function(D,E,C){var G=E.config,F=(!G.parserMetadataName)?"sortValue":G.parserMetadataName;return B(C).metadata()[F]},type:"numeric"});A.addWidget({id:"zebra",priority:90,format:function(N,K,M){var D,H,J,O,I,E,G,F,C=new RegExp(K.cssChildRow,"i"),L=K.$tbodies;if(K.debug){E=new Date()}for(G=0;G<L.length;G++){D=L.eq(G);F=D.children("tr").length;if(F>1){O=0;H=D.children("tr:visible");H.each(function(){J=B(this);if(!C.test(this.className)){O++}I=(O%2===0);J.removeClass(M.zebra[I?1:0]).addClass(M.zebra[I?0:1])})}}if(K.debug){A.benchmark("Applying Zebra widget",E)}},remove:function(H,I,F){var E,D,C=I.$tbodies,G=(F.zebra||["even","odd"]).join(" ");for(E=0;E<C.length;E++){D=B.tablesorter.processTbody(H,C.eq(E),true);D.children().removeClass(G);B.tablesorter.processTbody(H,D,false)}}})})(jQuery);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-experimental-table-sortable', location = 'js/aui-experimental-tables-sortable.js' */
(function(){var B={sortMultiSortKey:"",headers:{},debug:false};function A(D){var C=B;D.find("th").each(function(F,G){var E=AJS.$(G);C.headers[F]={};if(E.hasClass("aui-table-column-unsortable")){C.headers[F].sorter=false}else{E.attr("tabindex","0");E.wrapInner("<span class='aui-table-header-content'/>");if(E.hasClass("aui-table-column-issue-key")){C.headers[F].sorter="issue-key"}}});D.tablesorter(C)}AJS.tablessortable={setup:function(){AJS.$.tablesorter.addParser({id:"issue-key",is:function(){return false},format:function(G){var C=G.split("-");var D=C[0];var F=C[1];var I="..........";var H="000000";var E=(D+I).slice(0,I.length);E+=(H+F).slice(-H.length);return E},type:"text"});AJS.$.tablesorter.addParser({id:"textSortAttributeParser",is:function(C,E,D){return D.hasAttribute("data-sort-value")&&(!D.hasAttribute("data-sort-type")||D.getAttribute("data-sort-type")==="text")},format:function(C,E,D,F){return D.getAttribute("data-sort-value")},type:"text"});AJS.$.tablesorter.addParser({id:"numericSortAttributeParser",is:function(C,E,D){return D.getAttribute("data-sort-type")==="numeric"&&D.hasAttribute("data-sort-value")},format:function(C,E,D,F){return D.getAttribute("data-sort-value")},type:"numeric"});AJS.$(".aui-table-sortable").each(function(){A(AJS.$(this))})},setTableSortable:function(C){A(C)}};AJS.$(AJS.tablessortable.setup)})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-report-resources', location = 'templates/tasks-report.soy' */
// This file was automatically generated from tasks-report.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.InlineTasks == 'undefined') { Confluence.InlineTasks = {}; }
if (typeof Confluence.InlineTasks.Report == 'undefined') { Confluence.InlineTasks.Report = {}; }
if (typeof Confluence.InlineTasks.Report.Templates == 'undefined') { Confluence.InlineTasks.Report.Templates = {}; }


Confluence.InlineTasks.Report.Templates.tasksReport = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="table-wrapper" data-loading="false"><div class="task-blanket"></div><input type="hidden" name="reportParameters" value="', soy.$$escapeHtml(opt_data.reportParameters), '" /><table class="aui aui-table-interactive tasks-report" data-sortable="false" data-total-pages="', soy.$$escapeHtml(opt_data.totalPages), '" data-page-size="', soy.$$escapeHtml(opt_data.pageSize), '" data-adaptive="', soy.$$escapeHtml(opt_data.adaptive), '" data-page-limit="', soy.$$escapeHtml(opt_data.pageLimit), '"><thead><tr class="tablesorter-headerRow">');
  var headingList14 = opt_data.headings;
  var headingListLen14 = headingList14.length;
  for (var headingIndex14 = 0; headingIndex14 < headingListLen14; headingIndex14++) {
    var headingData14 = headingList14[headingIndex14];
    output.append('<th class="header-', soy.$$escapeHtml(headingData14), (headingData14 == 'description') ? ' aui-table-column-unsortable' : '', '" data-column-name="', soy.$$escapeHtml(headingData14), '">', soy.$$escapeHtml(opt_data.headingTexts[headingData14]), '</th>');
  }
  output.append('</tr></thead><tbody>');
  if (opt_data.tasks.length) {
    var taskList29 = opt_data.tasks;
    var taskListLen29 = taskList29.length;
    for (var taskIndex29 = 0; taskIndex29 < taskListLen29; taskIndex29++) {
      var taskData29 = taskList29[taskIndex29];
      Confluence.InlineTasks.Report.Templates.tasksReportLine({task: taskData29, columns: opt_data.headings}, output);
    }
  } else {
    output.append('<tr><td colspan="', soy.$$escapeHtml(opt_data.headings.length), '">', soy.$$escapeHtml("Create a task list in a Confluence page to keep track of things you need to do."), '</td></tr>');
  }
  output.append('</tbody></table></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.tasksFeatureDiscoveryNotification = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<h2>', soy.$$escapeHtml("Hey! Did you know..."), '</h2><p>', soy.$$escapeHtml("You can view the tasks you created, or assigned to you, in the tasks tabs of your profile."), '</p>');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.tasksReportLine = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<tr data-task-id="', soy.$$escapeHtml(opt_data.task.taskId), '" aria-disabled="false">');
  var columnList51 = opt_data.columns;
  var columnListLen51 = columnList51.length;
  for (var columnIndex51 = 0; columnIndex51 < columnListLen51; columnIndex51++) {
    var columnData51 = columnList51[columnIndex51];
    if (columnData51 == 'duedate') {
      output.append('<td class=\'tasks-report-date\'>', (opt_data.task.dueDate) ? soy.$$escapeHtml(opt_data.task.dueDate) : '', '</td>');
    } else if (columnData51 == 'description') {
      output.append('<td>', opt_data.task.taskHtml, '</td>');
    } else if (columnData51 == 'assignee') {
      output.append('<td class=\'tasks-report-assignee\'>');
      if (opt_data.task.assigneeUserName) {
        Confluence.Templates.User.usernameLink({username: opt_data.task.assigneeUserName, fullName: opt_data.task.assigneeFullName, canView: false}, output);
      }
      output.append('</td>');
    } else if (columnData51 == 'location') {
      output.append('<td><a class=\'task-location\' href="', soy.$$escapeHtml(opt_data.task.pageUrl), '">', soy.$$escapeHtml(opt_data.task.pageTitle), '</a></td>');
    } else if (columnData51 == 'completedate') {
      output.append('<td class=\'tasks-report-date\'>', (opt_data.task.completeDate) ? soy.$$escapeHtml(opt_data.task.completeDate) : (opt_data.task.taskCompleted) ? '<span class="emptycompletedate">--</span>' : '', '</td>');
    } else if (columnData51 == 'labels') {
      output.append('<td>');
      var labelList89 = opt_data.task.labels;
      var labelListLen89 = labelList89.length;
      for (var labelIndex89 = 0; labelIndex89 < labelListLen89; labelIndex89++) {
        var labelData89 = labelList89[labelIndex89];
        aui.labels.label({text: labelData89}, output);
      }
      output.append('</td>');
    }
  }
  output.append('</tr>');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.taskReportBrowserWarning = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var param97 = new soy.StringBuilder('<p>', soy.$$escapeHtml("Unable to show this task report."), '</p>');
  var messageList101 = opt_data.messages;
  var messageListLen101 = messageList101.length;
  for (var messageIndex101 = 0; messageIndex101 < messageListLen101; messageIndex101++) {
    var messageData101 = messageList101[messageIndex101];
    param97.append('<p>', soy.$$escapeHtml(messageData101), '</p>');
  }
  aui.message.warning({content: param97.toString()}, output);
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.taskReportWarning = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  aui.message.warning({content: '<p>' + soy.$$escapeHtml("Unable to show the task report. Edit this page to resolve the issues.") + '</p>'}, output);
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-report-resources', location = 'js/tasks-report-blank-exp.js' */
(function(b){Confluence.InlineTasks=Confluence.InlineTasks||{};Confluence.InlineTasks.TasksReport=Confluence.InlineTasks.TasksReport||{};var a={"blank.complete.title":"Task report","blank.complete.desc":"Get going, no tasks completed yet.","blank.incomplete.title":"Task report","blank.incomplete.desc":"Looking good, no incomplete tasks."};Confluence.InlineTasks.TasksReport.renderBlankExperiences=function(g,c){if(!c){c="incomplete"}var f=a["blank."+c+".title"],e=a["blank."+c+".desc"];var d=Confluence.UI.Components.BlankPlaceholderBox.Templates.blankBox({blankTitle:f,blankDescription:e,customClass:c+" tasks-report-blank"});g.html(d)}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-report-resources', location = 'js/tasks-report.js' */
AJS.$(function(c){var b="/rest/inlinetasks/1/task-report/",a=Confluence.InlineTasks.Report.Templates,e=Confluence.InlineTasks.TasksTableSortable;var d=c(".tasks-report").parent();_.each(d,function(i){var l=c(i),n=l.find("table.tasks-report"),m=n.data("page-size"),k=n.data("total-pages"),f=n.data("page-limit"),q=n.data("adaptive"),p=l.find("input[name=reportParameters]").val(),g=JSON.parse(p);var o=function(r,s){c(r).attr("aria-disabled",s)};AJS.bind("inline-tasks.status-update.start",function(t,s){if(s.taskListQueue.length>0){var r=c("li[data-inline-task-id="+s.taskId+"]").closest(".tasks-report").siblings(".macro-auto-pagination");o(r,true);r=r.find("li a");r.on("click.taskreport.pagination",function(u){u.preventDefault();u.stopPropagation()})}});AJS.bind("inline-tasks.status-update.complete",function(s,r){if(r.taskListQueue.length===0){o(".macro-auto-pagination",false);c(".macro-auto-pagination li a").off("click.taskreport.pagination")}});var j=n.closest(".table-wrapper");var h=new e({$wrapper:j,table:n[0],sortReverseSortDefault:g.reverseSort,sortColumnDefault:e.getColumnNameFromSortBy(g.sortColumn),reportParametersDefault:g,pageIndex:0,pageSize:m,pageTotal:k,adaptive:q,pageLimit:f,templates:a,columns:g.columns,onRenderEmptyTable:function(){Confluence.InlineTasks.TasksReport.renderBlankExperiences(j,g.status)},analyticEventKey:"confluence-spaces.tasks.report.sorted",restUrlPagination:b,ajaxUrl:Confluence.getContextPath()+b});h.init();if(q||k>1){h.renderPagination()}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-help-tips:common', location = 'js/help-tip.js' */
(function(f){function b(){return false}function d(){return true}var l=0,g=new Date().getTime();var k=AJS.contextPath()+"/rest/helptips/1.0/tips";function h(n){n=""+(n||"");return n.replace(/\./g,"-")}function j(o,n){if(AJS.EventQueue&&n&&n.attributes.id){var q={};var p=h(n.attributes.id);q.name="helptips."+p+"."+o;q.properties={};AJS.EventQueue.push(q)}}function c(){return"c"+g+(l++)}var a={dismissedTipIds:[],loaded:f.Deferred(),url:function(){return k},sync:function(o,n){o||(o="get");n||(n=null);return f.ajax(this.url(),{type:o,context:this,dataType:"json",contentType:"application/json",data:n&&JSON.stringify(n),processData:false}).promise()},fetch:function(){var n=this.sync();n.done(function(o){f.merge(this.dismissedTipIds,o);this.loaded.resolve()});return n.promise()},show:function(n){this.loaded.done(n)},dismiss:function(n){var o=n.attributes.id;if(!o){n._dismissed=true}else{this.dismissedTipIds.push(o);this.sync("post",{id:o})}},undismiss:function(n){var o=n.attributes.id;if(!o){n._dismissed=false}else{this.dismissedTipIds.splice(f.inArray(o,this.dismissedTipIds),1);this.sync("delete",{id:o})}},isDismissed:function(n){var o=n.attributes.id;return(o)?f.inArray(o,this.dismissedTipIds)>=0:n._dismissed}};var e=AJS.HelpTip=function(n){var o;this.attributes=f.extend({},n);this.attributes.id||(this.attributes.id=false);if(this.attributes.body){this.attributes.bodyHtml=this.attributes.body;delete this.attributes.body}this.cid=c();o=this.attributes.anchor;delete this.attributes.anchor;this.view=o?new i(this,o):new m(this);this.view.$el.addClass("aui-help-tip")};AJS.HelpTip.Manager=a;f.extend(e.prototype,{show:function(){var n=this;AJS.HelpTip.Manager.show(function(){if(!n.isDismissed()){if(AJS.Popups&&AJS.Popups.DisplayController){AJS.Popups.DisplayController.request({name:n.id,weight:1000,show:function(){n.view.show()}})}else{n.view.show()}j("shown",n)}})},dismiss:function(){var n=h(arguments[0]||"programmatically");this.view.dismiss();if(!this.isDismissed()){AJS.HelpTip.Manager.dismiss(this);j("dismissed."+n,this)}},isVisible:function(){return this.view.$el.is(":visible")},isDismissed:function(){return AJS.HelpTip.Manager.isDismissed(this)}});var i=function(o,n){this.initialize(o,n)};f.extend(i.prototype,{initialize:function(r,q){var o=this;var s=q.prop("ownerDocument");var p=s!=window.document;if(p){var n=f("iframe").filter(function(){return this.contentDocument==s});n.contents().scroll(function(){var v=f(this).contents().find("body").scrollTop();var w=n.offset().top;var u=o.popup.data("offset-top");var t=o.popup.find(".arrow").height();o.popup.css("top",u-v);o.popup.toggle(v<=u-w-t&&v+n.height()-t+w-o.popup.height()>=u)})}this.model=r;this.beforeHide=b;this.dismissButton=f(AJS.Templates.HelpTip.tipDismiss());this.dismissButton.click(function(t){r.dismiss("close-button");t.preventDefault()});this.popup=AJS.InlineDialog(q,r.cid,function(v,u,t){v.html(AJS.Templates.HelpTip.tipContent(r.attributes));v.find(".helptip-body").after(o.dismissButton);v.unbind("mouseover mouseout");v.find(".helptip-link").click(function(){j("learn-more.clicked",r)});t()},{container:"body",noBind:true,preHideCallback:function(){return o.beforeHide()},calculatePositions:function(t,y,z,x){var w=AJS.InlineDialog.opts.calculatePositions(t,y,z,x);if(p){var v=t.find(".arrow").height();var u=n.contents().find("body").scrollTop();w.popupCss.top=n.offset().top+(q.offset().top-u)+q.height()+v;w.popupCss.left=q.offset().left;n.contents().scroll()}t.data("offset-top",w.popupCss.top);return w}});this.popup.refresh();this._popupHide=this.popup.hide;this.popup.hide=b;this.$el=f(this.popup[0]);AJS.$(document).bind("showLayer",function(v,u,t){if(u==="inlineDialog"&&t.id===r.cid){AJS.InlineDialog.current=null;AJS.$(document.body).unbind("click."+r.cid+".inline-dialog-check");t._validateClickToClose=b;t.hide=b}})},show:function(){var n=this.popup,o=function(p){if(!n.has(p.target).length){n.shadow.remove();n.remove()}};n.show()},dismiss:function(){this.beforeHide=d;this._popupHide()}});var m=function(n){this.initialize(n)};f.extend(m.prototype,{initialize:function(){this.$el=f("<div />")},show:f.noop,dismiss:f.noop});if(AJS.Meta.get("remote-user")){a.fetch()}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-help-tips:common', location = 'templates/help-tip.soy' */
// This file was automatically generated from help-tip.soy.
// Please don't edit this file by hand.

if (typeof AJS == 'undefined') { var AJS = {}; }
if (typeof AJS.Templates == 'undefined') { AJS.Templates = {}; }
if (typeof AJS.Templates.HelpTip == 'undefined') { AJS.Templates.HelpTip = {}; }


AJS.Templates.HelpTip.tipContent = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.title) ? '<h4 class="helptip-title">' + soy.$$escapeHtml(opt_data.title) + '</h4>' : '', '<div class="helptip-body">', opt_data.bodyHtml, '</div>', (opt_data.url) ? '<a class="helptip-link" href="' + soy.$$escapeHtml(opt_data.url) + '" target="_blank">' + soy.$$escapeHtml("Learn more") + '</a>' : '');
  return opt_sb ? '' : output.toString();
};


AJS.Templates.HelpTip.tipDismiss = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<button class="helptip-dismiss aui-button" type="button">', soy.$$escapeHtml("Dismiss"), '</button>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-feature-discovery-resources', location = 'js/tasks-discovery.js' */
(function(b){function a(){if(!!AJS.HelpTip){var c={id:null,body:Confluence.InlineTasks.Report.Templates.tasksFeatureDiscoveryNotification(),anchor:b("#user-menu-link")};var d=new AJS.HelpTip(c);AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.feature.discovery.shown"});d.show()}}b(document).ready(function(){if(b("meta[name=show-task-feature-discovery-flag]").length>0){a()}})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:editor-view-resources', location = 'jscripts/view-content/pushed-navigation-util.js' */
(function(){function b(){return AJS.Rte&&AJS.Rte.getEditor()&&!!$("#editpageform").length}var a=window.location.hash,c=window.location.search;Confluence.Editor.PushedNavUtil={isInEditPage:b,filterPreviewHashChange:function(){var d=b()||window.history.pushState||!(window.location.hash&&0===window.location.hash.indexOf("#!"))&&!(a&&0===a.indexOf("#!"));a=window.location.hash;return d},filterPreviewNavigationEvent:function(){var a=b()||!/[?&]preview=([^&]*)/.test(window.location.search)&&!/[?&]preview=([^&]*)/.test(c);
c=window.location.search;return a}}})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:editor-view-resources', location = 'jscripts/view-content/pushed-navigation.js' */
(function(a,j){function b(){d?c.split("#")[0]!=window.location.href.split("#")[0]&&(a(window).unbind("popstate",g),window.location.reload()):c.split("#")[0]==window.location.href.split("#")[0]&&"editor"!==c.split("#")[1]||window.location.reload()}function e(){c=window.location.href}function h(){var a=Confluence.Editor.Drafts.unloadMessage();a?(Confluence.Editor.Drafts.unBindUnloadMessage(),confirm(a+"\n\n"+"Press OK to continue, or Cancel to stay on the current page.")?(AJS.trigger("analytics",{name:"rte.quick-edit.confirmation.leaving"}),
b()):(AJS.trigger("analytics",{name:"rte.quick-edit.confirmation.staying"}),d?(f=!0,window.history.forward()):window.location.hash="editor",Confluence.Editor.Drafts.bindUnloadMessage())):b()}function k(){Confluence.Editor.PushedNavUtil.isInEditPage()?"#editor"!==window.location.hash&&h():b()}function g(){f?f=!1:Confluence.Editor.PushedNavUtil.isInEditPage()?h():b()}function i(a,b){return function(){j.every(b,function(a){return a()})&&a()}}var d=!!window.history.pushState,f=!1,c=window.location.href,
l=[Confluence.Editor.PushedNavUtil.filterPreviewHashChange],m=[Confluence.Editor.PushedNavUtil.filterPreviewNavigationEvent],n=function(){e();d?(a(window).bind("popstate",i(g,m)),a(window).bind("rte-quick-edit-push-state",e)):(a(window).bind("hashchange",i(k,l)),a(window).bind("rte-quick-edit-push-hash",e))};AJS.toInit(function(){setTimeout(n,0)});AJS.bind("rte-quick-edit-enable-handlers",function(){"#editor"===window.location.hash&&a("#editPageLink").click()})})($,_);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-urlmacro-resources', location = 'com/atlassian/confluence/plugins/sharelinksurlmacro/soy/sharelinks-urlmacro-templates.soy' */
// This file was automatically generated from sharelinks-urlmacro-templates.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.SharelinksUrlMacro == 'undefined') { Confluence.Blueprints.SharelinksUrlMacro = {}; }


Confluence.Blueprints.SharelinksUrlMacro.bookmarkletLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a class="aui-button sharelinks-urlmacro-button" href="');
  Confluence.Blueprints.SharelinksUrlMacro.bookmarkletScript(opt_data, output);
  output.append('"><span>', soy.$$escapeHtml("Share on Confluence"), '</span></a>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.SharelinksUrlMacro.bookmarkletScript = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('javascript:(function(){var screenWidth=screen.width,screenHeight=screen.height,popupWidth=640,popupHeight=580,popupLeft=0,popupTop=0; if(screenWidth>popupWidth){popupLeft=Math.round((screenWidth/2)-(popupWidth/2));}if(screenHeight>popupHeight){popupTop=Math.round((screenHeight/2)-(popupHeight/2));}window.open(\'', opt_data.bookmarkletActionURL, '?bookmarkedURL=\'+encodeURIComponent(window.location.href), \'\',\'left=\'+popupLeft+\',top=\'+popupTop+\',width=\'+popupWidth+\',height=\'+popupHeight+\',personalbar=0,toolbar=0,scrollbars=1,resizable=1\');}());');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-urlmacro-resources', location = 'com/atlassian/confluence/plugins/sharelinksurlmacro/js/sharelinks-urlmacro.js' */
AJS.toInit(function(a){a(".sharelinks-urlmacro-button").click(function(){alert("Drag this link to your toolbar");return false})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-sortable-tables:sortable-table-resources', location = 'js/SortableTables.js' */
(function(e){function f(){var a=AJS.Meta.get("date.format"),b;a&&0!==a.length&&(a=a.toLowerCase()[0],"m"===a?b="mmddyyyy":"d"===a?b="ddmmyyyy":"y"===a&&(b="yyyymmdd"));return b}e(function(){var a;Confluence.SortableTables={init:function(){a=e("table").filter(function(){var b=e(this),a=b.find("td, th"),d=this.rows.length&&e(this.rows[0].cells),c;if("false"===b.attr("data-sortable"))return!1;c=jQuery.Event("makeSortable.SortableTables");b.trigger(c);if(c.isDefaultPrevented()||!d||0===d.length)return!1;
c=0;for(var f=a.length;c<f;c++)if(b=a[c],1!=b.rowSpan||1!=b.colSpan)return!1;return e(this.rows[0]).find("table").length||d.filter("th").length!=d.length||d.hasClass("nohighlight")?!1:this.rows[1]})},enable:function(){a.each(function(){var b=this.removeChild(this.children[0]),a=e(b.children),a=Array.prototype.shift.call(a),d=document.createDocumentFragment(),c=document.createElement("thead");d.appendChild(c);c.appendChild(a);d.appendChild(b);this.appendChild(d)});a.tablesorter({cssHeader:"sortableHeader",
delayInit:!0,textExtraction:function(a){return AJS.trim(e(a).text())},dateFormat:f()})},refresh:function(){this.init();this.enable()}};Confluence.SortableTables.init();setTimeout(Confluence.SortableTables.enable,100)})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-sortable-tables:sortable-table-resources', location = 'js/jquery.tablesorter.js' */
/*!
* TableSorter 2.3.10 - Client-side table sorting with ease!
* Minified using UglifyJS (http://jscompress.com/)
* Copyright (c) 2007 Christian Bach
*/
!function($){$.extend({tablesorter:new function(){function log(a){if(typeof console!=="undefined"&&typeof console.log!=="undefined"){console.log(a)}else{alert(a)}}function benchmark(a,b){log(a+" ("+((new Date).getTime()-b.getTime())+"ms)")}function getElementText(a,b,c){if(!b){return""}var d=a.config,e=d.textExtraction,f="";if(e==="simple"){if(d.supportsTextContent){f=b.textContent}else{if(b.childNodes[0]&&b.childNodes[0].hasChildNodes()){f=b.childNodes[0].innerHTML}else{f=b.innerHTML}}}else{if(typeof e==="function"){f=e(b,a,c)}else if(typeof e==="object"&&e.hasOwnProperty(c)){f=e[c](b,a,c)}else{f=d.supportsTextContent?b.textContent:$(b).text()}}return $.trim(f)}function getParserById(a){var b,c=parsers.length;for(b=0;b<c;b++){if(parsers[b].id.toLowerCase()===a.toString().toLowerCase()){return parsers[b]}}return false}function detectParserForColumn(a,b,c,d){var e,f=parsers.length,g=false,h="",i=true;while(h===""&&i){c++;if(b[c]){g=b[c].cells[d];h=getElementText(a,g,d);if(a.config.debug){log("Checking if value was empty on row "+c+", column: "+d+": "+h)}}else{i=false}}for(e=1;e<f;e++){if(parsers[e].is(h,a,g)){return parsers[e]}}return parsers[0]}function buildParserCache(a,b){var c=a.config,d=$(a.tBodies).filter(":not(."+c.cssInfoBlock+")"),e=$.tablesorter,f,g,h,i,j,k,l,m,n,o="";if(d.length===0){return}f=d[0].rows;if(f[0]){g=[];h=f[0].cells.length;for(i=0;i<h;i++){j=b.filter(':not([colspan])[data-column="'+i+'"]:last,[colspan="1"][data-column="'+i+'"]:last');l=c.headers[i];n=getParserById(e.getData(j,l,"sorter"));c.empties[i]=e.getData(j,l,"empty")||c.emptyTo||(c.emptyToBottom?"bottom":"top");c.strings[i]=e.getData(j,l,"string")||c.stringTo||"max";if(!n){n=detectParserForColumn(a,f,-1,i)}if(c.debug){o+="column:"+i+"; parser:"+n.id+"; string:"+c.strings[i]+"; empty: "+c.empties[i]+"\n"}g.push(n)}}if(c.debug){log(o)}return g}function buildCache(a){var b=a.tBodies,c=a.config,d,e,f=c.parsers,g,h,i,j,k,l,m;c.cache={};if(c.debug){m=new Date}for(j=0;j<b.length;j++){c.cache[j]={row:[],normalized:[]};if(!$(b[j]).hasClass(c.cssInfoBlock)){$(b[j]).addClass("tablesorter-hidden");d=b[j]&&b[j].rows.length||0;e=b[j].rows[0]&&b[j].rows[0].cells.length||0;for(h=0;h<d;++h){k=$(b[j].rows[h]);l=[];if(k.hasClass(c.cssChildRow)){c.cache[j].row[c.cache[j].row.length-1]=c.cache[j].row[c.cache[j].row.length-1].add(k);continue}c.cache[j].row.push(k);for(i=0;i<e;++i){g=getElementText(a,k[0].cells[i],i);l.push(f[i].format(g,a,k[0].cells[i],i))}l.push(c.cache[j].normalized.length);c.cache[j].normalized.push(l)}$(b[j]).removeClass("tablesorter-hidden")}}if(c.debug){benchmark("Building cache for "+d+" rows",m)}}function getWidgetById(a){var b,c,d=widgets.length;for(b=0;b<d;b++){c=widgets[b];if(c&&c.hasOwnProperty("id")&&c.id.toLowerCase()===a.toLowerCase()){return c}}}function applyWidget(a,b){var c=a.config,d=c.widgets,e,f,g,h=d.length;if(c.debug){e=new Date}for(f=0;f<h;f++){g=getWidgetById(d[f]);if(g){if(b===true&&g.hasOwnProperty("init")){g.init(a,widgets,g)}else if(!b&&g.hasOwnProperty("format")){g.format(a)}}}if(c.debug){benchmark("Completed "+(b===true?"initializing":"applying")+" widgets",e)}}function appendToTable(a,b){var c=a.config,d=a.tBodies,e=[],f,g,h,i,j=c.cache,k,l,m,n,o,p,q;if(c.debug){q=new Date}for(n=0;n<d.length;n++){if(!$(d[n]).hasClass(c.cssInfoBlock)){$(d[n]).addClass("tablesorter-hidden");k=document.createDocumentFragment();f=j[n].row;g=j[n].normalized;h=g.length;i=h?g[0].length-1:0;for(l=0;l<h;l++){p=g[l][i];e.push(f[p]);if(!c.appender||!c.removeRows){o=f[p].length;for(m=0;m<o;m++){k.appendChild(f[p][m])}}}a.tBodies[n].appendChild(k);$(d[n]).removeClass("tablesorter-hidden")}}if(c.appender){c.appender(a,e)}if(c.debug){benchmark("Rebuilt table",q)}if(!b){applyWidget(a)}$(a).trigger("sortEnd",a)}function computeThIndexes(a){var b=[],c={},d=$(a).find("thead:eq(0) tr"),e,f,g,h,i,j,k,l,m,n,o,p;for(e=0;e<d.length;e++){j=d[e].cells;for(f=0;f<j.length;f++){i=j[f];k=i.parentNode.rowIndex;l=k+"-"+i.cellIndex;m=i.rowSpan||1;n=i.colSpan||1;if(typeof b[k]==="undefined"){b[k]=[]}for(g=0;g<b[k].length+1;g++){if(typeof b[k][g]==="undefined"){o=g;break}}c[l]=o;$(i).attr({"data-column":o});for(g=k;g<k+m;g++){if(typeof b[g]==="undefined"){b[g]=[]}p=b[g];for(h=o;h<o+n;h++){p[h]="x"}}}}return c}function formatSortingOrder(a){return/^d/i.test(a)||a===1}function buildHeaders(a){var b=computeThIndexes(a),c,d,e,f,g,h,i=a.config,j=$.tablesorter;i.headerList=[];if(i.debug){g=new Date}h=$(a).find(i.selectorHeaders).each(function(a){d=$(this);c=i.headers[a];this.innerHTML='<div class="tablesorter-header-inner">'+this.innerHTML+"</div>";if(i.onRenderHeader){i.onRenderHeader.apply(d,[a])}this.column=b[this.parentNode.rowIndex+"-"+this.cellIndex];this.order=formatSortingOrder(j.getData(d,c,"sortInitialOrder")||i.sortInitialOrder)?[1,0,2]:[0,1,2];this.count=-1;if(j.getData(d,c,"sorter")==="false"){this.sortDisabled=true}this.lockedOrder=false;f=j.getData(d,c,"lockedOrder")||false;if(typeof f!=="undefined"&&f!==false){this.order=this.lockedOrder=formatSortingOrder(f)?[1,1,1]:[0,0,0]}if(!this.sortDisabled){e=d.addClass(i.cssHeader)}i.headerList[a]=this;d.parent().addClass(i.cssHeader)});if(a.config.debug){benchmark("Built headers:",g);log(h)}return h}function isValueInArray(a,b){var c,d=b.length;for(c=0;c<d;c++){if(b[c][0]===a){return true}}return false}function setHeadersCss(a,b,c){var d,e=[],f,g,h,i=[a.config.cssDesc,a.config.cssAsc];b.removeClass(i.join(" ")).each(function(){if(!this.sortDisabled){e[this.column]=$(this)}});h=c.length;for(f=0;f<h;f++){if(c[f][1]===2){continue}if(e[c[f][0]]){e[c[f][0]].addClass(i[c[f][1]])}d=b.filter('[data-column="'+c[f][0]+'"]');if(h>1&&d.length){for(g=0;g<d.length;g++){if(!d[g].sortDisabled){$(d[g]).addClass(i[c[f][1]])}}}}}function fixColumnWidth(a){if(a.config.widthFixed){var b=$("<colgroup>");$("tr:first td",a.tBodies[0]).each(function(){b.append($("<col>").css("width",$(this).width()))});$(a).prepend(b)}}function updateHeaderSortCount(a,b){var c,d,e,f=a.config,g=b.length;for(c=0;c<g;c++){d=b[c];e=f.headerList[d[0]];if(e){e.count=d[1]%(f.sortReset?3:2)}}}function getCachedSortType(a,b){return a&&a[b]?a[b].type||"":""}function multisort(table,sortList){var dynamicExp,col,mx=0,dir=0,tc=table.config,l=sortList.length,bl=table.tBodies.length,sortTime,i,j,k,c,cache,lc,s,e,order,orgOrderCol;if(tc.debug){sortTime=new Date}for(k=0;k<bl;k++){dynamicExp="var sortWrapper = function(a,b) {";cache=tc.cache[k];lc=cache.normalized.length;for(i=0;i<l;i++){c=sortList[i][0];order=sortList[i][1];s=/n/i.test(getCachedSortType(tc.parsers,c))?"Numeric":"Text";s+=order===0?"":"Desc";e="e"+i;if(/Numeric/.test(s)&&tc.strings[c]){for(j=0;j<lc;j++){col=Math.abs(parseFloat(cache.normalized[j][c]));mx=Math.max(mx,isNaN(col)?0:col)}if(typeof tc.string[tc.strings[c]]==="boolean"){dir=(order===0?1:-1)*(tc.string[tc.strings[c]]?-1:1)}else{dir=tc.strings[c]?tc.string[tc.strings[c]]||0:0}}dynamicExp+="var "+e+" = sort"+s+"(table,a["+c+"],b["+c+"],"+c+","+mx+","+dir+"); ";dynamicExp+="if ("+e+") { return "+e+"; } ";dynamicExp+="else { "}orgOrderCol=cache.normalized&&cache.normalized[0]?cache.normalized[0].length-1:0;dynamicExp+="return a["+orgOrderCol+"]-b["+orgOrderCol+"];";for(i=0;i<l;i++){dynamicExp+="}; "}dynamicExp+="return 0; ";dynamicExp+="}; ";eval(dynamicExp);cache.normalized.sort(sortWrapper)}if(tc.debug){benchmark("Sorting on "+sortList.toString()+" and dir "+order+" time",sortTime)}}function sortText(a,b,c,d){if(b===c){return 0}var e=a.config,f=e.string[e.empties[d]||e.emptyTo],g=$.tablesorter.regex,h,i,j,k,l,m,n,o;if(b===""&&f!==0){return typeof f==="boolean"?f?-1:1:-f||-1}if(c===""&&f!==0){return typeof f==="boolean"?f?1:-1:f||1}if(typeof e.textSorter==="function"){return e.textSorter(b,c,a,d)}h=b.replace(g[0],"\0$1\0").replace(/\0$/,"").replace(/^\0/,"").split("\0");j=c.replace(g[0],"\0$1\0").replace(/\0$/,"").replace(/^\0/,"").split("\0");i=parseInt(b.match(g[2]))||h.length!==1&&b.match(g[1])&&Date.parse(b);k=parseInt(c.match(g[2]))||i&&c.match(g[1])&&Date.parse(c)||null;if(k){if(i<k){return-1}if(i>k){return 1}}o=Math.max(h.length,j.length);for(n=0;n<o;n++){l=!(h[n]||"").match(g[3])&&parseFloat(h[n])||h[n]||0;m=!(j[n]||"").match(g[3])&&parseFloat(j[n])||j[n]||0;if(isNaN(l)!==isNaN(m)){return isNaN(l)?1:-1}if(typeof l!==typeof m){l+="";m+=""}if(l<m){return-1}if(l>m){return 1}}return 0}function sortTextDesc(a,b,c,d){if(b===c){return 0}var e=a.config,f=e.string[e.empties[d]||e.emptyTo];if(b===""&&f!==0){return typeof f==="boolean"?f?-1:1:f||1}if(c===""&&f!==0){return typeof f==="boolean"?f?1:-1:-f||-1}if(typeof e.textSorter==="function"){return e.textSorter(c,b,a,d)}return sortText(a,c,b)}function getTextValue(a,b,c){if(b){var d,e=a.length,f=b+c;for(d=0;d<e;d++){f+=a.charCodeAt(d)}return c*f}return 0}function sortNumeric(a,b,c,d,e,f){if(b===c){return 0}var g=a.config,h=g.string[g.empties[d]||g.emptyTo];if(b===""&&h!==0){return typeof h==="boolean"?h?-1:1:-h||-1}if(c===""&&h!==0){return typeof h==="boolean"?h?1:-1:h||1}if(isNaN(b)){b=getTextValue(b,e,f)}if(isNaN(c)){c=getTextValue(c,e,f)}return b-c}function sortNumericDesc(a,b,c,d,e,f){if(b===c){return 0}var g=a.config,h=g.string[g.empties[d]||g.emptyTo];if(b===""&&h!==0){return typeof h==="boolean"?h?-1:1:h||1}if(c===""&&h!==0){return typeof h==="boolean"?h?1:-1:-h||-1}if(isNaN(b)){b=getTextValue(b,e,f)}if(isNaN(c)){c=getTextValue(c,e,f)}return c-b}function checkResort(a,b,c){var d=a[0];if(b!==false){a.trigger("sorton",[d.config.sortList,function(){a.trigger("updateComplete");if(typeof c==="function"){c(d)}}])}else{a.trigger("updateComplete");if(typeof c==="function"){c(d)}}}this.version="2.3.10";var parsers=[],widgets=[];this.defaults={widthFixed:false,cancelSelection:true,dateFormat:"mmddyyyy",sortMultiSortKey:"shiftKey",usNumberFormat:true,delayInit:false,headers:{},ignoreCase:true,sortForce:null,sortList:[],sortAppend:null,sortInitialOrder:"asc",sortLocaleCompare:false,sortReset:false,sortRestart:false,emptyTo:"bottom",stringTo:"max",textExtraction:"simple",textSorter:null,widgets:[],widgetOptions:{zebra:["even","odd"]},initWidgets:true,initialized:null,onRenderHeader:null,tableClass:"tablesorter",cssAsc:"tablesorter-headerSortUp",cssChildRow:"expand-child",cssDesc:"tablesorter-headerSortDown",cssHeader:"tablesorter-header",cssInfoBlock:"tablesorter-infoOnly",selectorHeaders:"> thead th",selectorRemove:"tr.remove-me",debug:false,headerList:[],empties:{},strings:{},parsers:[]};this.benchmark=benchmark;this.hasInitialized=false;this.construct=function(a){return this.each(function(){if(!this.tHead||this.tBodies.length===0){return}var b,c,d,e,f,g,h,i,j,k,l,m=$.metadata;this.config={};e=$.extend(true,this.config,$.tablesorter.defaults,a);if(e.debug){$.data(this,"startoveralltimer",new Date)}d=$(this).addClass(e.tableClass);$.data(this,"tablesorter",e);e.supportsTextContent=$("<span>x</span>")[0].textContent==="x";e.string={max:1,min:-1,"max+":1,"max-":-1,zero:0,none:0,"null":0,top:true,bottom:false};b=buildHeaders(this);e.parsers=buildParserCache(this,b);if(!e.delayInit){buildCache(this)}fixColumnWidth(this);b.bind("mousedown.tablesorter mouseup.tablesorter",function(a,m){if(a.type==="mousedown"){l=(new Date).getTime();return!e.cancelSelection}if(m!==true&&(new Date).getTime()-l>500){return false}if(e.delayInit&&!e.cache){buildCache(d[0])}if(!this.sortDisabled){d.trigger("sortStart",d[0]);c=$(this);h=!a[e.sortMultiSortKey];this.count=(this.count+1)%(e.sortReset?3:2);if(e.sortRestart){f=this;b.each(function(){if(this!==f&&(h||!$(this).is("."+e.cssDesc+",."+e.cssAsc))){this.count=-1}})}f=this.column;if(h){e.sortList=[];if(e.sortForce!==null){i=e.sortForce;for(g=0;g<i.length;g++){if(i[g][0]!==f){e.sortList.push(i[g])}}}k=this.order[this.count];if(k<2){e.sortList.push([f,k]);if(this.colSpan>1){for(g=1;g<this.colSpan;g++){e.sortList.push([f+g,k])}}}}else{if(isValueInArray(f,e.sortList)){for(g=0;g<e.sortList.length;g++){j=e.sortList[g];k=e.headerList[j[0]];if(j[0]===f){j[1]=k.order[k.count];if(j[1]===2){e.sortList.splice(g,1);k.count=-1}}}}else{k=this.order[this.count];if(k<2){e.sortList.push([f,k]);if(this.colSpan>1){for(g=1;g<this.colSpan;g++){e.sortList.push([f+g,k])}}}}}if(e.sortAppend!==null){i=e.sortAppend;for(g=0;g<i.length;g++){if(i[g][0]!==f){e.sortList.push(i[g])}}}d.trigger("sortBegin",d[0]);setHeadersCss(d[0],b,e.sortList);multisort(d[0],e.sortList);appendToTable(d[0]);return false}});if(e.cancelSelection){b.each(function(){this.onselectstart=function(){return false}})}d.bind("update",function(a,c,f){$(e.selectorRemove,this).remove();e.parsers=buildParserCache(this,b);buildCache(this);checkResort(d,c,f)}).bind("updateCell",function(a,b,c,f){var g=this,h=$(this).find("tbody"),i,j,k=h.index($(b).closest("tbody"));i=h.eq(k).find("tr").index($(b).closest("tr"));j=[i,b.cellIndex];g.config.cache[k].normalized[j[0]][j[1]]=e.parsers[j[1]].format(getElementText(g,b,j[1]),g,b,j[1]);checkResort(d,c,f)}).bind("addRows",function(a,b,c,f){var h,i=b.filter("tr").length,j=[],k=b[0].cells.length,l=this,m=$(this).find("tbody").index(b.closest("tbody"));for(h=0;h<i;h++){for(g=0;g<k;g++){j[g]=e.parsers[g].format(getElementText(l,b[h].cells[g],g),l,b[h].cells[g],g)}j.push(e.cache[m].row.length);e.cache[m].row.push([b[h]]);e.cache[m].normalized.push(j);j=[]}checkResort(d,c,f)}).bind("sorton",function(a,c,d,f){$(this).trigger("sortStart",this);var g=e.headerList.length;e.sortList=[];$.each(c,function(a,b){if(b[0]<g){e.sortList.push(c[a])}});updateHeaderSortCount(this,e.sortList);setHeadersCss(this,b,e.sortList);multisort(this,e.sortList);appendToTable(this,f);if(typeof d==="function"){d(this)}}).bind("appendCache",function(a,b){appendToTable(this,b)}).bind("applyWidgetId",function(a,b){getWidgetById(b).format(this)}).bind("applyWidgets",function(a,b){applyWidget(this,b)}).bind("destroy",function(a,b){$.tablesorter.destroy(this,b)});if(d.data()&&typeof d.data().sortlist!=="undefined"){e.sortList=d.data().sortlist}else if(m&&d.metadata()&&d.metadata().sortlist){e.sortList=d.metadata().sortlist}applyWidget(this,true);if(e.sortList.length>0){d.trigger("sorton",[e.sortList,{},!e.initWidgets])}else if(e.initWidgets){applyWidget(this)}this.hasInitialized=true;if(e.debug){$.tablesorter.benchmark("Overall initialization time",$.data(this,"startoveralltimer"))}d.trigger("tablesorter-initialized",this);if(typeof e.initialized==="function"){e.initialized(this)}})};this.destroy=function(a,b){var c=$(a),d=a.config;c.find("thead:first tr:not(."+d.cssHeader+")").remove();c.find("thead:first .tablesorter-resizer").remove();c.unbind("update updateCell addRows sorton appendCache applyWidgetId applyWidgets destroy mouseup mouseleave").find(d.selectorHeaders).unbind("click mousedown mousemove mouseup").removeClass(d.cssHeader+" "+d.cssAsc+" "+d.cssDesc);if(b!==false){c.removeClass(d.tableClass)}};this.addParser=function(a){var b,c=parsers.length,d=true;for(b=0;b<c;b++){if(parsers[b].id.toLowerCase()===a.id.toLowerCase()){d=false}}if(d){parsers.push(a)}};this.addWidget=function(a){widgets.push(a)};this.formatFloat=function(a,b){if(typeof a!=="string"||a===""){return a}if(b.config.usNumberFormat!==false){a=a.replace(/,/g,"")}else{a=a.replace(/[\s|\.]/g,"").replace(/,/g,".")}if(/^\s*\([.\d]+\)/.test(a)){a=a.replace(/^\s*\(/,"-").replace(/\)/,"")}var c=parseFloat(a);return isNaN(c)?$.trim(a):c};this.isDigit=function(a){return/^[\-+(]?\d+[)]?$/.test(a.replace(/[,.'\s]/g,""))};this.regex=[/(^-?[0-9]+(\.?[0-9]*)[df]?e?[0-9]?$|^0x[0-9a-f]+$|[0-9]+)/gi,/(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[\/\-]\d{1,4}[\/\-]\d{1,4}|^\w+, \w+ \d+, \d{4})/,/^0x[0-9a-f]+$/i,/^0/];this.characterEquivalents={a:"?????",A:"?????",c:"?",C:"?",e:"????",E:"????",i:"??I??",I:"??I??",o:"?????",O:"?????",S:"?",u:"????",U:"????"};this.replaceAccents=function(a){var b,c="[",d=this.characterEquivalents;if(!this.characterRegex){this.characterRegexArray={};for(b in d){if(typeof b==="string"){c+=d[b];this.characterRegexArray[b]=new RegExp("["+d[b]+"]","g")}}this.characterRegex=new RegExp(c+"]")}if(this.characterRegex.test(a)){for(b in d){if(typeof b==="string"){a=a.replace(this.characterRegexArray[b],b)}}}return a};this.getData=function(a,b,c){var d="",e=$(a),f,g;if(!e.length){return""}f=$.metadata?e.metadata():false;g=" "+(e.attr("class")||"");if(e.data()&&(typeof e.data(c)!=="undefined"||typeof e.data(c.toLowerCase())!=="undefined")){d+=e.data(c)||e.data(c.toLowerCase())}else if(f&&typeof f[c]!=="undefined"){d+=f[c]}else if(b&&typeof b[c]!=="undefined"){d+=b[c]}else if(g&&g.match(" "+c+"-")){d=g.match(new RegExp(" "+c+"-(\\w+)"))[1]||""}return $.trim(d)};this.clearTableBody=function(a){$(a.tBodies).filter(":not(."+a.config.cssInfoBlock+")").empty()}}})();var ts=$.tablesorter;$.fn.extend({tablesorter:ts.construct});ts.addParser({id:"text",is:function(a,b,c){return true},format:function(a,b,c,d){var e=b.config;a=$.trim(e.ignoreCase?a.toLocaleLowerCase():a);return e.sortLocaleCompare?ts.replaceAccents(a):a},type:"text"});ts.addParser({id:"currency",is:function(a){return/^\(?[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]\d+/.test(a)},format:function(a,b){return ts.formatFloat(a.replace(/[^\w,. \-()]/g,""),b)},type:"numeric"});ts.addParser({id:"ipAddress",is:function(a){return/^\d{2,3}[\.]\d{2,3}[\.]\d{2,3}[\.]\d{2,3}$/.test(a)},format:function(a,b){var c,d,e=a.split("."),f="",g=e.length;for(c=0;c<g;c++){d=e[c];if(d.length===2){f+="0"+d}else{f+=d}}return ts.formatFloat(f,b)},type:"numeric"});ts.addParser({id:"url",is:function(a){return/^(https?|ftp|file):\/\//.test(a)},format:function(a){return $.trim(a.replace(/(https?|ftp|file):\/\//,""))},type:"text"});ts.addParser({id:"isoDate",is:function(a){return/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(a)},format:function(a,b){return ts.formatFloat(a!==""?(new Date(a.replace(/-/g,"/"))).getTime()||"":"",b)},type:"numeric"});ts.addParser({id:"percent",is:function(a){return/\d%\)?$/.test(a)},format:function(a,b){return ts.formatFloat(a.replace(/%/g,""),b)},type:"numeric"});ts.addParser({id:"usLongDate",is:function(a){return a.match(/^[A-Za-z]{3,10}\.? [0-9]{1,2}, ([0-9]{4}|'?[0-9]{2}) (([0-2]?[0-9]:[0-5][0-9])|([0-1]?[0-9]:[0-5][0-9]\s(AM|PM)))$/)},format:function(a,b){return ts.formatFloat((new Date(a)).getTime()||"",b)},type:"numeric"});ts.addParser({id:"shortDate",is:function(a){return/^(\d{2}|\d{4})[\/\-\,\.\s+]\d{2}[\/\-\.\,\s+](\d{2}|\d{4})$/.test(a)},format:function(a,b,c,d){var e=b.config,f=e.headerList[d],g=f.shortDateFormat;if(typeof g==="undefined"){g=f.shortDateFormat=ts.getData(f,e.headers[d],"dateFormat")||e.dateFormat}a=a.replace(/\s+/g," ").replace(/[\-|\.|\,]/g,"/");if(g==="mmddyyyy"){a=a.replace(/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,"$3/$1/$2")}else if(g==="ddmmyyyy"){a=a.replace(/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,"$3/$2/$1")}else if(g==="yyyymmdd"){a=a.replace(/(\d{4})[\/\s](\d{1,2})[\/\s](\d{1,2})/,"$1/$2/$3")}return ts.formatFloat((new Date(a)).getTime()||"",b)},type:"numeric"});ts.addParser({id:"time",is:function(a){return/^(([0-2]?[0-9]:[0-5][0-9])|([0-1]?[0-9]:[0-5][0-9]\s(am|pm)))$/.test(a)},format:function(a,b){return ts.formatFloat((new Date("2000/01/01 "+a)).getTime()||"",b)},type:"numeric"});ts.addParser({id:"digit",is:function(a){return ts.isDigit(a)},format:function(a,b){return ts.formatFloat(a.replace(/[^\w,. \-()]/g,""),b)},type:"numeric"});ts.addParser({id:"metadata",is:function(a){return false},format:function(a,b,c){var d=b.config,e=!d.parserMetadataName?"sortValue":d.parserMetadataName;return $(c).metadata()[e]},type:"numeric"});ts.addWidget({id:"zebra",format:function(a){var b,c,d,e,f,g,h,i,j=a.config,k=new RegExp(j.cssChildRow,"i"),l=$(a).children("tbody:not(."+j.cssInfoBlock+")"),m=["even","odd"];m=j.widgetZebra&&j.hasOwnProperty("css")?j.widgetZebra.css:j.widgetOptions&&j.widgetOptions.hasOwnProperty("zebra")?j.widgetOptions.zebra:m;if(j.debug){g=new Date}for(h=0;h<l.length;h++){b=$(l[h]);i=b.children("tr").length;if(i>1){e=0;c=b.find("tr:visible");b.addClass("tablesorter-hidden");c.each(function(){d=$(this);if(!k.test(this.className)){e++}f=e%2===0;d.removeClass(m[f?1:0]).addClass(m[f?0:1])});b.removeClass("tablesorter-hidden")}}if(j.debug){ts.benchmark("Applying Zebra widget",g)}}})}(jQuery);

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:about', location = '/includes/js/about/about-page.js' */
AJS.toInit(function(a){var c;a("#confluence-about-link").click(function(d){d.preventDefault();a(this).removeClass("interactive");if(null==c){AJS.Meta.get("version-number").match(/^\d+\.\d+/);var d="Atlassian Confluence and Confluence Plugins",e=AJS.Meta.get("context-path")+"/aboutconfluence.action",b=new AJS.ConfluenceDialog({id:"about-confluence-dialog",closeOnOutsideClick:!0});b.addHeader(d);b.addCancel("Close",function(){b.hide()});a.get(e,function(a){b.addPanel("default",
a,"about-page-content")});c=b}c.show()})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:analytics-support', location = '/includes/js/analytics-support/analytics-support.js' */
define("confluence-analytics-support",["jquery"],function(h){function i(a){var c={};if(a=m.exec(a)){for(var b=0;b<k.length;b++)c[k[b]]=a[b];b=c.queryParams;a={};if(b)for(var b=b.split("&"),d=0;d<b.length;d++){var e=b[d].split("=");a[e[0]]||(a[e[0]]=[]);a[e[0]].push(b[d].substring(e[0].length+1))}c.queryParams=a}return c}function l(a){if(h.isEmptyObject(a))return"";var c=!a.urlPath?"":a.urlPath,b;if(h.isEmptyObject(a.queryParams))b="";else{b=a.queryParams;var d="",e;for(e in b)for(var f=0;f<b[e].length;f++)d+=
"&"+e,b[e][f]&&(d+="="+b[e][f]);b="?"+d.substring(1)}return c+b+(!a.anchor?"":"#"+a.anchor)}AJS.Confluence.Analytics=AJS.Confluence.Analytics||{};var m=/([^\?]+)[\?]?([^#]*)[#]?(.*)/,k=["source","urlPath","queryParams","anchor"],j;AJS.Confluence.Analytics.setAnalyticsSource=function(a,c){if("undefined"===typeof j){var b=h._data(window,"events");j=b&&b.analytics&&0<b.analytics.length}j&&a.attr("href",function(a,b){var f=encodeURIComponent(c),g=i(b);h.isEmptyObject(g)||(g.queryParams.src=[f]);return l(g)})};
AJS.Confluence.Analytics.srcRemovedUrl=function(a){a=i(a);delete a.queryParams.src;for(var c=Object.keys(a.queryParams),b=0;b<c.length;b++){var d=c[b],e=d.split(".");3===e.length&&"src"===e[0]&&delete a.queryParams[d]}return l(a)};AJS.Confluence.Analytics.srcParamValues=function(a){return(a=i(a).queryParams)&&a.src?a.src:[]};AJS.Confluence.Analytics.srcAttrParamValues=function(a){for(var a=i(a).queryParams,c={},b=Object.keys(a),d=0;d<b.length;d++){var e=b[d],f=e.split(".");if(3===f.length&&"src"===
f[0]){var g=f[1],f=f[2];c[g]=c[g]||{};c[g][f]=decodeURIComponent(a[e][0])}}return c};AJS.Confluence.Analytics.extractAnalyticsData=function(a){for(var c=[],b=AJS.Confluence.Analytics.srcParamValues(a),a=AJS.Confluence.Analytics.srcAttrParamValues(a),d=0;d<b.length;d++){var e=b[d];c.push({src:e,attr:a[e]||{}})}return c};AJS.Confluence.Analytics.publish=function(a,c){AJS.trigger("analytics",{name:a,data:c||{}})};AJS.toInit(function(){var a=AJS.Confluence.Analytics.extractAnalyticsData(document.URL);
if(0<a.length){for(var c=0;c<a.length;c++){var b=a[c],d=b.attr;d.userKey=AJS.Meta.get("remote-user-key");AJS.Confluence.Analytics.publish("confluence.viewpage.src."+b.src,d)}window.history&&window.history.replaceState&&(a=AJS.Confluence.Analytics.srcRemovedUrl(document.URL),document.URL!==a&&window.history.replaceState(null,"",a))}});return AJS.Confluence.Analytics});require("confluence-analytics-support");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:general-analytics-bindings', location = '/includes/js/analytics-support/analytics-bindings.js' */
require(["jquery","confluence-analytics-support"],function(b,d){b(function(){function a(a,c){b(a).on("click",".view-historical-version-trigger",function(){d.publish("confluence.page.view-historical.from-"+(c||"unknown"))})}function e(a,c){b(a).on("click",".restore-historical-version-trigger",function(){d.publish("confluence.page.restore-historical.from-"+(c||"unknown"))})}a("#page-history-warning","navigation");a("#page-history-container","history");a(".diff-menu","diff");e("#page-history-warning",
"navigation");e("#page-history-container","history")})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-license-banner:confluence-license-banner-resources', location = '/js/confluence-license-banner.js' */
AJS.toInit(function(){var b=WRM.data.claim("com.atlassian.confluence.plugins.confluence-license-banner:confluence-license-banner-resources.license-details");if(!b){AJS.warn("Unable to claim my required data");return}var a={destroyBanner:function(){AJS.$("#license-banner").slideUp(function(){AJS.$("#license-banner").remove()})},remindMeLater:function(){AJS.$.ajax({type:"POST",dataType:"json",url:AJS.contextPath()+"/rest/licensebanner/1.0/reminder/later"});a.destroyBanner()},remindMeNever:function(){AJS.$.ajax({type:"POST",dataType:"json",url:AJS.contextPath()+"/rest/licensebanner/1.0/reminder/never"});a.destroyBanner()},createBanner:function(e){var c;if(e.showLicenseExpiryBanner){c=Confluence.Templates.LicenseBanner.expiryBanner({days:e.daysBeforeLicenseExpiry,mac:e.renewUrl,sales:e.salesEmail})}else{if(e.showMaintenanceExpiryBanner){c=Confluence.Templates.LicenseBanner.maintenanceBanner({days:e.daysBeforeMaintenanceExpiry,mac:e.renewUrl,sales:e.salesEmail})}}if(c){var d=$("body").prepend(c);$("#license-banner-later").click(function(f){f.preventDefault();a.remindMeLater()});$("#license-banner-never").click(function(f){f.preventDefault();a.remindMeNever()});d.find(".icon-close").click(function(f){f.preventDefault();a.remindMeLater()})}}};a.createBanner(b)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-license-banner:confluence-license-banner-resources', location = 'soy/confluence-license-banner.soy' */
// This file was automatically generated from confluence-license-banner.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.LicenseBanner == 'undefined') { Confluence.Templates.LicenseBanner = {}; }


Confluence.Templates.LicenseBanner.expiryBanner = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var renewTag__soy3 = new soy.StringBuilder('<a id="license-banner-my-link" target="_blank" href="', soy.$$escapeHtml(opt_data.mac), '">');
  renewTag__soy3 = renewTag__soy3.toString();
  var end__soy7 = new soy.StringBuilder('</a>');
  end__soy7 = end__soy7.toString();
  var mailTag__soy9 = new soy.StringBuilder('<a id="license-banner-sales-link" href="mailto:', soy.$$escapeHtml(opt_data.sales), '">');
  mailTag__soy9 = mailTag__soy9.toString();
  aui.message.warning({content: '<div id="license-banner-content" data-days="' + soy.$$escapeHtml(opt_data.days) + '" data-subscription="true">' + ((opt_data.days < 0) ? AJS.format("Your license subscription has expired. This instance is now read-only. Please renew {0}online{1} or contact {2}sales{3}.",renewTag__soy3,end__soy7,mailTag__soy9,end__soy7) : (opt_data.days == 0) ? AJS.format("Your license subscription will expire today and Confluence will become read-only. Please renew {0}online{1} or contact {2}sales{3}.",renewTag__soy3,end__soy7,mailTag__soy9,end__soy7) : AJS.format("Your license subscription will expire in {0,choice,1#{0} day|1\x3c{0} days}. Confluence will become read-only after the expiry. Please renew {1}online{2} or contact {3}sales{4}.",opt_data.days,renewTag__soy3,end__soy7,mailTag__soy9,end__soy7)) + '</div>', isCloseable: opt_data.days > 7, id: 'license-banner'}, output);
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.LicenseBanner.maintenanceBanner = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var renewTag__soy32 = new soy.StringBuilder('<a id="license-banner-my-link" target="_blank" href="', soy.$$escapeHtml(opt_data.mac), '">');
  renewTag__soy32 = renewTag__soy32.toString();
  var end__soy36 = new soy.StringBuilder('</a>');
  end__soy36 = end__soy36.toString();
  var later__soy38 = new soy.StringBuilder('<a href="#" id="license-banner-later">');
  later__soy38 = later__soy38.toString();
  var never__soy40 = new soy.StringBuilder('<a href="#" id="license-banner-never">');
  never__soy40 = never__soy40.toString();
  aui.message.warning({content: '<div id="license-banner-content" data-days="' + soy.$$escapeHtml(opt_data.days) + '" data-subscription="false">' + ((opt_data.days < 0) ? AJS.format("You no longer have access Support and Updates. {0}Renew online{1}, {2}remind me later{3} or {4}never remind me again{5}.",renewTag__soy32,end__soy36,later__soy38,end__soy36,never__soy40,end__soy36) : (opt_data.days == 0) ? AJS.format("You will lose access to Support and Updates today. {0}Renew online{1}, {2}remind me later{3} or {4}never remind me again{5}.",renewTag__soy32,end__soy36,later__soy38,end__soy36,never__soy40,end__soy36) : AJS.format("You will lose access to Support and Updates in {0,choice,1#{0} day|1\x3c{0} days}. {1}Renew online{2}, {3}remind me later{4} or {5}never remind me again{6}.",opt_data.days,renewTag__soy32,end__soy36,later__soy38,end__soy36,never__soy40,end__soy36)) + '</div>', id: 'license-banner'}, output);
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-blueprints:confluence-team-space-blueprint-resources', location = 'com/atlassian/confluence/plugins/team/js/confluence-team-space-blueprints.js' */
AJS.bind("blueprint.wizard-register.ready",function(){function a(d,c){c.pageData.ContentPageTitle=c.pageData.name;return Confluence.SpaceBlueprint.CommonWizardBindings.submit(d,c)}function b(d,c){c.soyRenderContext.atlToken=AJS.Meta.get("atl-token");c.soyRenderContext.showSpacePermission=false}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-space-blueprints:team-space-blueprint-item",function(c){c.on("submit.teamSpaceId",a);c.on("pre-render.teamSpaceId",b);c.on("post-render.teamSpaceId",Confluence.SpaceBlueprint.CommonWizardBindings.postRender)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-blueprints:confluence-team-space-blueprint-resources', location = 'com/atlassian/confluence/plugins/team/soy/dialog-page.soy' */
// This file was automatically generated from dialog-page.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.SpaceBlueprints == 'undefined') { Confluence.SpaceBlueprints = {}; }
if (typeof Confluence.SpaceBlueprints.Team == 'undefined') { Confluence.SpaceBlueprints.Team = {}; }


Confluence.SpaceBlueprints.Team.dialogForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="decisions-form" class="common-space-form aui">');
  Confluence.Templates.Blueprints.CreateSpace.createSpaceFormFields({showSpacePermission: false, fieldErrors: opt_data.fieldErrors, name: opt_data.name, spaceKey: opt_data.spaceKey}, output);
  output.append('<fieldset><div class="field-group"><label for="team-members">', soy.$$escapeHtml("Team members"), '</label><input id="team-members" class="text long-field autocomplete-multiuser" type="text" name="members" placeholder="', soy.$$escapeHtml("Add your team members"), '" data-autofill-user="true"/></div><div class="field-group"><label for="team-description">', soy.$$escapeHtml("Description"), '</label><textarea id="team-description" class="textarea long-field" rows="3" type="text" name="description" placeholder="', soy.$$escapeHtml("Let others know what this space is for"), '"></textarea></div></fieldset><input type="hidden" name="atl_token" value="', soy.$$escapeHtml(opt_data.atlToken), '" /></form>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-blueprints:confluence-documentation-space-blueprint-resources', location = 'com/atlassian/confluence/plugins/documentation/js/confluence-documentation-space-blueprint.js' */
AJS.bind("blueprint.wizard-register.ready",function(){function b(d,c){c.pageData.ContentPageTitle=c.pageData.name;return Confluence.SpaceBlueprint.CommonWizardBindings.submit(d,c)}function a(d,c){c.soyRenderContext.atlToken=AJS.Meta.get("atl-token");c.soyRenderContext.showSpacePermission=false}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-space-blueprints:documentation-space-blueprint-item",function(c){c.on("submit.documentationSpaceId",b);c.on("pre-render.documentationSpaceId",a);c.on("post-render.documentationSpaceId",Confluence.SpaceBlueprint.CommonWizardBindings.postRender)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-blueprints:confluence-documentation-space-blueprint-resources', location = 'com/atlassian/confluence/plugins/documentation/soy/dialog-page.soy' */
// This file was automatically generated from dialog-page.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.SpaceBlueprints == 'undefined') { Confluence.SpaceBlueprints = {}; }
if (typeof Confluence.SpaceBlueprints.Documentation == 'undefined') { Confluence.SpaceBlueprints.Documentation = {}; }


Confluence.SpaceBlueprints.Documentation.dialogForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="documentation-space-form" class="common-space-form aui">');
  Confluence.Templates.Blueprints.CreateSpace.createSpaceFormFields({showSpacePermission: false, fieldErrors: opt_data.fieldErrors, name: opt_data.name, key: opt_data.key}, output);
  output.append('<fieldset><div class="field-group"><label for="documentation-description">', soy.$$escapeHtml("Description"), '</label><textarea id="documentation-description" class="textarea long-field" rows="3" type="text" name="spaceDesc" placeholder="', soy.$$escapeHtml("Briefly describe the documentation in this space"), '"></textarea></div></fieldset><input type="hidden" name="noPageTitlePrefix" value="true" /><input type="hidden" name="atl_token" value="', soy.$$escapeHtml(opt_data.atlToken), '" /></form>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-feature-discovery-plugin:confluence-feature-discovery-plugin-resources', location = '/js/confluence-feature-discovery-plugin.js' */
(function(f){Confluence.FeatureDiscovery={};var c,e=false,i=3;var d="com.atlassian.confluence.plugins.confluence-feature-discovery-plugin";var g=d+":confluence-feature-discovery-plugin-resources.test-mode";var a=WRM.data.claim(g);function j(k){if(c===undefined){c=JSON.parse(AJS.Meta.get("discovered-plugin-features")||"{}")}if(k){return c[k]||[]}return c}function b(m,o){var n=j(m);for(var l=0,k=n.length;l<k;l++){if(n[l]==o){return true}}return false}function h(n,p){var l="com.atlassian.webdriver.discovery="+n+":"+p;var k=document.cookie.split(";");for(var m=0;m<k.length;m++){var o=k[m];while(o.charAt(0)==" "){o=o.substring(1)}if(o.indexOf(l)!=-1){return true}}return false}Confluence.FeatureDiscovery.forPlugin=function(m,l){var p=Confluence.storageManager("feature-discovery."+m);l=l||i;function o(r){var q=parseInt(p.getItem(r),10);return isNaN(q)?0:q}function n(r,q){return p.setItem(r,q)}function k(q){return p.removeItem(q)}return{addDiscoveryView:function(q){n(q,o(q)+1)},shouldShow:function(r,q){if(q===true&&a&&!h(m,r)){return false}if(e||b(m,r)){return false}if(o(r)>=l){this.markDiscovered(r);return false}e=true;return true},markDiscovered:function(r,q){if(b(m,r)){return}f.ajax({url:AJS.contextPath()+"/rest/feature-discovery/1.0/discovered/"+m+"/"+r,type:"POST",success:function(){j(m).unshift(r);k(r);AJS.trigger("feature-discovered",{pluginKey:m,featureKey:r});if(q&&f.isFunction(q)){q()}}})},listDiscovered:function(){return j(m).slice(0)}}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.support.stp:stp-license-status-resources', location = 'js/stp-licenseStatus.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.mywork.mywork-confluence-host-plugin:mw-header-anchor', location = 'templates/anchor.soy' */
// This file was automatically generated from anchor.soy.
// Please don't edit this file by hand.

if (typeof MyWork == 'undefined') { var MyWork = {}; }
if (typeof MyWork.Templates == 'undefined') { MyWork.Templates = {}; }
if (typeof MyWork.Templates.Anchor == 'undefined') { MyWork.Templates.Anchor = {}; }


MyWork.Templates.Anchor.tasksFeatureDiscovery = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p>', soy.$$escapeHtml("See the tasks assigned to you, or created by you, in the Tasks tab of your profile."), '</p><ul class="mw-tasks-discovery-controls"><li><a id="mw-tasks-discovery-view" href="', soy.$$escapeHtml(opt_data.tasksUrl), '" class="aui-button aui-style"><p>', soy.$$escapeHtml("View Tasks"), '</p></a></li><li><a id="mw-tasks-discovery-dismiss" href="#">', soy.$$escapeHtml("Dismiss"), '</a></li></ul>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.mywork.mywork-confluence-host-plugin:mw-header-anchor', location = 'js/miniview-anchor.js' */
var MW=MW||{$:AJS.$||Zepto};
MW.MV={};
AJS.toInit(function(){if(AJS.Meta&&!AJS.Meta.get("remote-user")){return 
}MW.MV.AnchorManager=function(){var K=contextPath,H=K+"/plugins/servlet/notifications-miniview",P=[0,"0"],Q={JIRA:"JIRA",CONFLUENCE:"Confluence"},E=/[?&]show-miniview/.test(window.location.search);
function S(U){U=U.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");
var T="[\\?\\#&]"+U+"=([^&#]*)";
var W=new RegExp(T);
var V=W.exec(window.location.search);
if(V!==null){return decodeURIComponent(V[1].replace(/\+/g," "))
}}var O=S("show-miniview");
if(O){H+="#notification/"+O
}function N(){if(typeof (Confluence)!="undefined"){return Q.CONFLUENCE
}else{if(typeof (JIRA)!="undefined"){return Q.JIRA
}}}function R(){var T="badge-i aui-icon aui-icon-small aui-iconfont-workbox-empty";
MW.$("#notifications-anchor").html('<div class="'+T+'"></div><span class="badge-w"><span class="badge"></span></span>')
}function F(V){var U=false,T;
return function(){if(U){return T
}U=true;
T=V.apply(this,arguments);
return T
}
}var M=F(function(){MW.Dialog.getOptions().closeOthers=false;
MW.Dialog.preload=true;
MW.Dialog.show();
MW.Dialog.hide();
MW.Dialog.getOptions().closeOthers=true
});
function J(T,X){var U=MW.$("#notifications-anchor"),V=U.find(".badge");
V.html(X);
var Y=T>0?AJS.format("New Notifications: {0}",T):"Open Notifications",W=U.attr("title")||"";
U.attr("title",Y+W.replace(/.*?\(/," ("));
U.toggleClass("unread",T!==0);
U.toggleClass("read",T===0);
U.find(".aui-icon").toggleClass("aui-iconfont-workbox",T!==0);
U.find(".aui-icon").toggleClass("aui-iconfont-workbox-empty",T===0);
P=[T,X];
if(T>0&&MW.$("#notifications-anchor:visible").length>0&&!E){M()
}}function L(){AJS.log("Creating iframes");
C("notifications",H);
D()
}function D(){MW.$(document).keydown(function(T){if(AJS.InlineDialog.current&&T.which==27&&!MW.$(T.target).is(":input")){AJS.InlineDialog.current.hide()
}})
}function I(){MW.$("#header-menu-bar").find(".ajs-drop-down").each(function(){this.hide()
})
}function C(Y,W){var X;
var V=function(){X=this
};
var T=function(){if(this.preload!==true){var Z=JSON.stringify({markAllRead:true});
MW.$("#"+Y+"-miniview-iframe")[0].contentWindow.postMessage(Z,"*")
}};
if(!window.addEventListener){window.attachEvent("onmessage",U)
}else{window.addEventListener("message",U,false)
}function U(b){function c(d){return d===location.protocol+"//"+location.host
}if("escKey"===b.data){X.hide();
MW.$("#notifications-anchor").focus();
document.activeElement.blur()
}else{if("getParentConfig"===b.data&&c(b.origin)){var a=JSON.stringify({parentConfig:{parentUrl:location.href,preload:MW.Dialog.preload,unread:P[1]}}),Z=MW.$("#"+Y+"-miniview-iframe")[0].contentWindow;
Z.postMessage(a,"*");
if(MW.Dialog.preload){MW.Dialog.preload=false
}else{Z.focus()
}}}}MW.Dialog=AJS.InlineDialog(MW.$("#"+Y+"-anchor"),Y+"-miniview",function(c,a,d){if(MW.$(c).children().length===0){MW.$(c).append(MW.$('<iframe id="'+Y+'-miniview-iframe" src="'+W+'" frameborder="0"></iframe>'))
}else{var b=JSON.stringify({unread:P[1]}),Z=MW.$("#"+Y+"-miniview-iframe")[0].contentWindow;
Z.postMessage(b,"*");
setTimeout(function(){Z.focus()
},100)
}I();
d()
},{width:500,height:520,hideDelay:null,initCallback:V,hideCallback:T,noBind:true});
MW.Tasks=(function(){var c=300;
var b=20;
var d=16;
var j;
var f=AJS.$("#user-menu-link");
var e=AJS.$("#user-menu-link-content");
var a=e.find("#view-mytasks-link");
var g=function(m,k,n){var l=MyWork.Templates.Anchor.tasksFeatureDiscovery({tasksUrl:AJS.contextPath()+"/plugins/inlinetasks/mytasks.action"});
m.html(l);
m.find("#mw-tasks-discovery-dismiss").click(function(){j.hide()
});
n()
};
function Z(){return"M0,0L8,8L0,16"
}function i(m,o,r,n){var p=o.target.offset();
var l=o.target.height();
var k={top:p.top+l/2-15,left:p.left-c-(2*b)-d,right:"auto"};
var q={top:9,right:-15};
return{displayAbove:false,popupCss:k,arrowCss:q}
}var h=function(){MW.Dialog.hide();
var m=function(){return e.is(":visible")
};
if(!m()){f.trigger("aui-button-invoke")
}var k=function(){j.hide()
};
e.one("aui-dropdown2-hide",k);
j=AJS.InlineDialog(a,"my-tasks-discovery",g,{hideCallback:function(){j.unbind("click focusin mousedown",l);
e.unbind("aui-dropdown2-hide",k);
if(m()){f.trigger("aui-button-invoke")
}MW.$("#inline-dialog-my-tasks-discovery").remove()
},getArrowPath:Z,calculatePositions:i,useLiveEvents:true,width:c,noBind:true});
e.find(".user-item.active").removeClass("active");
a.addClass("active");
a.focus();
var l=function(n){n.stopPropagation()
};
j.on("click focusin mousedown",l);
j.show()
};
return{closeAndDiscoverMyTasks:h}
})();
MW.$("#"+Y+"-anchor").click(function(Z){Z.preventDefault();
if(MW.$("#"+Y+"-miniview-iframe").is(":visible")){MW.Dialog.hide()
}else{MW.Dialog.show()
}});
if(E){MW.$("#"+Y+"-anchor").click()
}}function G(){R();
L()
}return{setupAnchors:G,updateNotificationCount:J}
}();
MW.MV.AnchorManager.setupAnchors();
var B=new MW.AnchorUtil(MW.$,contextPath,MW.MV.AnchorManager.updateNotificationCount);
B.setupAnchors();
MW.$("#notifications-anchor").click(function(){MW.MV.AnchorManager.updateNotificationCount(0,"0")
});
var A=function(){if(document.hidden){B.stopRequests(true)
}else{B.startRequests()
}};
document.addEventListener("visibilitychange",A,false);
if(typeof document.hidden==="undefined"){MW.$(window).focus(function(){B.startRequests()
})
}MW.$("body").click(function(){B.startRequests()
})
});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.mywork.mywork-confluence-host-plugin:mw-header-anchor', location = 'js/util/anchor-util.js' */
MW.AnchorUtil=function(D,L,E){var F=30000,J=F,T,Q=L+"/rest/mywork/latest/status/notification/count";
var S=new Date().getTime();
var B=5*60*1000;
var U=1000*60*5;
var H=1.25;
var C=0;
function I(V){return V<=9?V:"9+"
}function R(V){window.clearInterval(T);
T=undefined;
if(V===true){J=F
}}function P(){return(new Date().getTime()-S)<U
}function N(){if(!P()||!T){M()
}S=new Date().getTime()
}function M(){if(T){clearTimeout(T)
}T=setTimeout(function(){G()
},C=O(C))
}function A(X,V){var W=X*1000;
B=V*1000||B;
if(W&&W!=J){J=W;
N()
}}function O(V){return Math.min(P()?J:V*H,B)
}function G(V){MW.$.getJSON(Q+((V)?"?pageid="+V:""),function(X){A(X.timeout,X.maxTimeout);
var W=X.count;
E(W,I(W))
});
M()
}function K(){var V=AJS&&AJS.Meta&&AJS.Meta.get&&(AJS.Meta.get("content-type")==="page"||AJS.Meta.get("content-type")==="blogpost");
if(V){G(AJS.Meta.get("page-id"))
}else{G()
}N()
}return{setupAnchors:K,startRequests:N,stopRequests:R,updateAnchors:G}
};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'templates/recently.soy' */
// This file was automatically generated from recently.soy.
// Please don't edit this file by hand.

if (typeof RY == 'undefined') { var RY = {}; }
if (typeof RY.Templates == 'undefined') { RY.Templates = {}; }


RY.Templates.body = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="recently-viewed" class="aui-group"><div class="aui-item"><div class="top"><div class="filter"><form class="aui"><input class="filter-input text" type="text" placeholder="', soy.$$escapeHtmlAttribute("Filter"), '"></form></div></div><div class="pages"></div><div class="recently-viewed-spinner" id="', soy.$$escapeHtmlAttribute(opt_data.spinnerId), '"></div></div></div>');
  return opt_sb ? '' : output.toString();
};


RY.Templates.pageCollection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="groups"></div><div class="empty"></div>');
  return opt_sb ? '' : output.toString();
};


RY.Templates.pageGroup = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<h3>', soy.$$escapeHtml(opt_data.title), '</h3><ul/>');
  return opt_sb ? '' : output.toString();
};


RY.Templates.pageItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="page-icon"><a href=', soy.$$escapeHtmlAttributeNospace(soy.$$filterNormalizeUri(opt_data.href)), ' class="icon icon-', soy.$$escapeHtmlAttribute(opt_data.type), '"></a></div><div class="page-title"><a class="ellipsis" href=', soy.$$escapeHtmlAttributeNospace(soy.$$filterNormalizeUri(opt_data.href)), '>', soy.$$escapeHtml(opt_data.title), ' - ', soy.$$escapeHtml(opt_data.space), '</a></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/util.js' */
var RY=RY||{};(function(){var b=new Date();var c=new Date(b).getTime();var a=new Date(b.getFullYear(),b.getMonth(),b.getDate()).getTime();var d=new Date(b.getFullYear(),b.getMonth(),b.getDate()-1).getTime();RY.util=RY.Util={analytics:{trackDialogOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-dialog-open"})},trackPageOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-page-open"})}},quote:function(e){return(e).replace(/([.?*+^$[\]\\(){}|-])/g,"\\$1")},diffInDays:function(g,f){var e=1000*60*60*24;return Math.floor((g-f)/e)},daysSince:function(e){if(e>=a){return 0}else{if(e>=d){return 1}else{return RY.util.diffInDays(c,e)}}},wait:function(h,j,f){var i,k,e;var g=function(){k=setTimeout(function(){h.apply(f,e)},j)};return function(){e=arguments;var l=new Date();if(i&&l-i<j){clearTimeout(k)}g();i=l}}}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/page-storage.js' */
var RY=RY||{};RY.RecentPageStorage=function(h){var f="com.atlassian.confluence.plugins.recently.viewed.pages.v1";var d=100;var c={};var b=function(){var i=function(k,l){if(k==="lastSeen"&&_.isString(l)){if(AJS.$.browser.msie){l=l.replace(/\-/g,"/");l=l.replace(/T.*$/,"")}return new Date(l).getTime()}else{return l}};try{c=JSON.parse(h.getItem(f),i)||{}}catch(j){c={}}return c};var g=function(){var i=_.values(c);var k=i.length-d;if(k>0){var j=_.sortBy(i,function(l){return l.lastSeen});_.times(k,function(){var l=j.shift();delete c[l.id]})}};var e=function(){g();try{h.setItem(f,JSON.stringify(c))}catch(i){}};this.addCurrentPage=function(i){if(!(i.id&&i.title)){return}b();a(i);e()};var a=function(i){var j=c[i.id];if(!j){c[i.id]=j={}}j=_.extend(j,i);j.lastSeen=new Date().getTime();j.count=j.count+1||1};this.getPages=function(){return _.values(b())}};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/filter.js' */
var RY=RY||{};RY.FilterView=Backbone.View.extend({className:"filter",events:{"input .filter-input":"onInput","keyup .filter-input":"onInput","keydown .filter-input":"onKeydown"},initialize:function(){_.bindAll(this,"render","onInput","onKeydown","search");this.navigationEvents=this.options.navigationEvents;this.onInput=RY.util.wait(this.onInput,100,this)},render:function(){this.$input=this.$(".filter-input");return this},onInput:function(a){if(a&&_.contains([37,38,39,40],a.which)){return}this.search()},onKeydown:function(a){switch(a.which){case 13:this.navigationEvents.trigger("select");a.preventDefault();a.stopPropagation();break;case 38:this.navigationEvents.trigger("previous");a.preventDefault();break;case 40:this.navigationEvents.trigger("next");a.preventDefault();break}},search:function(){var a=this.$input.val();this.collection.search(a)}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/page-model.js' */
var RY=RY||{};(function(){var a;if(typeof ConfluenceMobile!="undefined"){a=ConfluenceMobile.AppData.get("confluence-context-path")}else{a=AJS.contextPath()}RY.Page=Backbone.Model.extend({href:function(){return a+this.get("url")},daysSinceLastSeen:function(){return RY.util.daysSince(this.get("lastSeen"))}});RY.PageCollection=Backbone.Collection.extend({model:RY.Page,url:a+"/rest/recentlyviewed/1.0/recent",search:function(c){var b;if(this._queryLength(c)===0){b=this.models}else{var d=c.match(/[^\s-]+/g);b=this.filter(function(g){var h=g.get("title");var f=g.get("space");var e=(h+f).toLowerCase();return _.all(d,function(i){return e.indexOf(i.toLowerCase())!==-1})})}this.trigger("filter",b,c);return b},_queryLength:function(b){if(!String.prototype.trim){return AJS.$.trim(b).length}return b.trim().length},comparator:function(b){return -(b.get("lastSeen"))}})})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/page.js' */
var RY=RY||{};RY.PageView=Backbone.View.extend({tagName:"li",className:"ry-page",template:RY.Templates.pageItem,initialize:function(){_.bindAll(this,"hide","show","render")},hide:function(){this.$el.hide().removeClass("shown")},show:function(){this.$el.show().addClass("shown")},render:function(){var a=this.model.toJSON();a.href=this.model.href();this.$el.html(this.template(a));return this}});RY.PageGroupView=Backbone.View.extend({className:"group",template:RY.Templates.pageGroup,initialize:function(){_.bindAll(this,"hide","hideAll","show","showBorder","showPages","add","render");this.title=this.options.title;this.modelViews={}},hide:function(){this.$el.hide()},hideAll:function(){this.$el.removeClass("border").hide();_.invoke(_.values(this.modelViews),"hide")},show:function(){this.$el.show()},showBorder:function(){this.$el.addClass("border")},showPages:function(a){var c=this;var b=false;_.each(a,function(e){var d=c.modelViews[e.cid];if(d){b=true;d.show()}});if(b){this.show()}return b},add:function(b){var a=new RY.PageView({model:b});this.modelViews[b.cid]=a;this.$list.append(a.render().el)},render:function(){this.$el.html(this.template({title:this.title}));this.$list=this.$("ul");return this}});RY.PageNavigator=function(a,e,c){var g=null;function f(){return a.find("li.shown")}function b(i){pageItems=f();var h=pageItems.index(pageItems.filter(".highlight"));if(g){g.removeClass("highlight")}i+=h;if(i<0){i=pageItems.length-1}if(i>=pageItems.length){i=0}g=pageItems.eq(i);g.addClass("highlight")}function d(){if(!g.length){return}var k=e;var l=k.children();var j=k.height();var i=g.outerHeight(true);var h=g.position().top;if(h<0){if(f().index(g)===0){k.scrollTop(0);return}k.scrollTop(g.offset().top-l.offset().top)}else{if(h>j){k.scrollTop(g.offset().top-l.offset().top-j+i)}}}c.on("select",function(){if(g&&g.is(":visible")){RY.util.analytics.trackPageOpen();var h=g.find(".page-title a").attr("href");window.location=h}},this);c.on("previous",function(){b(-1);d()},this);c.on("next",function(){b(1);d()},this)};RY.PageCollectionView=Backbone.View.extend({template:RY.Templates.pageCollection,events:{"click .page-title a":RY.util.analytics.trackPageOpen},initialize:function(){_.bindAll(this,"checkEmpty","filter","_groupForPage","addOne","showEmptyMessage","clearEmptyMessage","addAll","render");this.modelViews={};this.collection.on("reset",this.addAll,this);this.collection.on("add",this.addOne,this);this.collection.on("filter",this.filter,this)},checkEmpty:function(a,e){var f=this.collection.isEmpty();var b=a.length===0;if(f||b){var c;if(f){c="Sorry mate, looks like you haven\'t visited any pages yet."}else{var d=AJS.contextPath()+"/dosearchsite.action?queryString="+encodeURIComponent(e);c="We didn\'t find any matching pages in your history."+" "+AJS.format("\u003ca href=\"{0}\"\u003eClick here\u003c/a\u003e to search for this term instead.",d)}this.showEmptyMessage(c)}else{this.clearEmptyMessage()}},filter:function(b,d){d=d||"";this.checkEmpty(b,d);var a=[this.$today,this.$yesterday,this.$older];_.invoke(a,"hideAll");var c=[];_.each(a,function(f){var e=f.showPages(b);if(e){c.push(f)}});if(c.length>1){c.pop();_.invoke(c,"showBorder")}},_groupForPage:function(a){var b=a.daysSinceLastSeen();if(b===0){return this.$today}else{if(b===1){return this.$yesterday}else{return this.$older}}},addOne:function(a){var b=this._groupForPage(a);b.add(a)},showEmptyMessage:function(a){this.$(".empty").html(AJS.$("<p>").html(a))},clearEmptyMessage:function(){this.$(".empty").html("")},addAll:function(){this.collection.each(this.addOne)},render:function(){this.$el.html(this.template());this.$today=new RY.PageGroupView({title:"Today"});this.$yesterday=new RY.PageGroupView({title:"Yesterday"});this.$older=new RY.PageGroupView({title:"Older"});var a=this.$(".groups");a.append(this.$today.render().el);a.append(this.$yesterday.render().el);a.append(this.$older.render().el);_.invoke([this.$today,this.$yesterday,this.$older],"hideAll");return this}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/quicknav/util.js' */
var RYQ=RYQ||{};(function(){RYQ.util={analytics:{trackQuickNavOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-quicknav-open"})},trackQuickNavPageOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-quicknav-click-page"})},trackQuickNavRecentlyDialogOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-quicknav-click-more-recent"})}}}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/quicknav/quicknav.js' */
var RYQ=RYQ||{};RYQ.QuickNavEntry=Backbone.Model.extend({classNameByType:{blogpost:"content-type-blogpost",page:"content-type-page"},parse:function(a){return{className:this.classNameByType[a.type],name:a.title,href:AJS.contextPath()+a.url,id:a.id,spaceName:a.space,lastSeen:a.lastSeen}}},{escape:function(b){var a=_.map(b,_.clone);_.each(a,function(c){c.name=_.escape(c.name);c.spaceName=_.escape(c.spaceName)});return a}});RYQ.QuickNavEntryCollection=Backbone.Collection.extend({model:RYQ.QuickNavEntry,url:AJS.contextPath()+"/rest/recentlyviewed/1.0/recent?limit=8",search:function(b){var a;if(AJS.$.trim(b).length===0){a=this.models}else{var c=b.match(/[^\s-]+/g);a=this.filter(function(e){var f=e.get("name");var d=f.toLowerCase();return _.all(c,function(g){return d.indexOf(g.toLowerCase())!==-1})})}this.trigger("filter",a);return a},comparator:function(a){return -(a.get("lastSeen"))}});(function(a){RYQ.QuickNav=Backbone.View.extend({initialize:function(){this.moreLink={className:"recently-viewed",href:"#",name:"More recently viewed pages..."};this.$input=a("#quick-search-query");this.makeDropdown();this.addShowHideHandlers();this.getHistory=_.once(this._getHistory);_.bindAll(this,"makeDropdown","addSearchResultBoostingHandler","_getHistory","render","addShowHideHandlers","_getItemsToShow","showQuickResults","onQuickSearch")},makeDropdown:function(){var c=function(d){a("a",d).each(function(){var g=a(this);var e=g.find("span");var f=AJS.dropDown.getAdditionalPropertyValue(e,"spaceName");if(f&&!g.is(".content-type-spacedesc")){g.after(g.clone().attr("class","space-name").html(f));g.parent().addClass("with-space-name")}})};var b=this;this.$dropdown=AJS.inputDrivenDropdown({dropdownPlacement:function(d){b.$input.closest("form").find(".quick-nav-drop-down").append(d)},dropdownPostprocess:function(d){c(d)},ajsDropDownOptions:{className:"recently-viewed-dropdown"}})},addSearchResultBoostingHandler:function(){var b=this;a(window).on("quicksearch.ajax-success",function(g,f){var d=f.url.match("/json/contentnamesearch.action");var c=f.url.match(/rest\/quicknav\/\d\/search/);if(d||c){b.onQuickSearch(g,f)}})},_getHistory:function(){return this.collection.fetch().done(this.addSearchResultBoostingHandler)},render:function(){var b=this.getHistory();b.done(_.bind(function(){if(AJS.dropDown.current==null&&this.collection.length!==0&&this.$input.val().length===0){this.showQuickResults()}},this));var c=this.$input;c.trigger("quick-search-loading-start");b.always(function(){c.trigger("quick-search-loading-stop")})},addShowHideHandlers:function(){var b=this;this.$input.on("focus",function(){b.render()}).on("click",function(c){c.stopPropagation();b.render()}).on("keyup",function(f){var c=f.which===27;var g=f.which===13;var d=a(this).val().length!==0;if(d||c){if(b.$dropdown.dd&&b.$dropdown.dd.$.is(":visible")){b.$dropdown.hide()}}else{if(!g){b.render()}}})},_getItemsToShow:function(){var c=this.collection.toJSON();var b=c.length>0&&c[0].id==AJS.Meta.get("page-id");if(b){c.shift()}return c},showQuickResults:function(){var b=RYQ.QuickNavEntry.escape(this._getItemsToShow());this.$dropdown.show([b,[this.moreLink]],"","");a(".recently-viewed-dropdown").on("click",".recently-viewed",function(c){c.preventDefault();a("#view-user-history-link").click();RYQ.util.analytics.trackQuickNavRecentlyDialogOpen()});a(".recently-viewed-dropdown").on("click",".with-space-name",function(c){RYQ.util.analytics.trackQuickNavPageOpen()});RYQ.util.analytics.trackQuickNavOpen()},onQuickSearch:function(l,f){var o=f.json.query;var c=_.map(this.collection.search(o),function(e){return e.attributes});c=RYQ.QuickNavEntry.escape(c);if(c.length==0){return}var m=f.json.contentNameMatches;var p=-1;for(var g=0;g<m.length;g++){var n=m[g][0].className;if(n=="content-type-blogpost"||n=="content-type-page"){p=g;break}}if(p!=-1){var h=m[p];var b=Math.min(h.length>4?2:6-h.length,c.length);h.unshift.apply(h,_(c).first(b));m[p]=_.uniq(h,function(e){return +e.id});if(h.length>6){var k=6-b;for(var d=k;d>0;d--){h.pop()}}}else{m.unshift(_(c).first(6))}}})}(AJS.$));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:main-resources', location = 'js/main.js' */
var RY=RY||{};AJS.toInit(function(a){a("#view-user-history-link").unbind("click");a("#view-user-history-link").click(function(i){i.preventDefault();var d=new AJS.Dialog({width:600,height:500,id:"recently-viewed-dialog",closeOnOutsideClick:true});var c="recently-viewed-spinner-"+Math.random();var h=a(RY.Templates.body({spinnerId:c}));d.addHeader("Recently viewed pages");d.addPanel("SinglePanel",h);d.addLink("Close",function(e){e.hide()});var f=a("<div>",{"class":"dialog-tip"}).text("Hint: type \"g\" and then \"r\" anywhere to quickly open this menu");d.popup.element.find(".dialog-button-panel").append(f);var j=new RY.PageCollection();var b=new RY.PageCollectionView({collection:j});h.find(".pages").html(b.render().el);var g=Raphael.spinner(c,16,"#707070");j.fetch({success:function(){g();var k=_.extend({},Backbone.Events);var l=new RY.PageNavigator(b.$el,h.parent(),k);var e=new RY.FilterView({collection:j,el:h.find(".filter"),navigationEvents:k}).render();e.search()}});d.gotoPanel(0);d.show();RY.util.analytics.trackDialogOpen()})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:main-resources', location = 'js/quicknav/main.js' */
var RYQ=RYQ||{};AJS.toInit(function(){var b=new RYQ.QuickNavEntryCollection();var a=new RYQ.QuickNav({collection:b})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.aui.staging:content-ready', location = 'js/content-ready.js' */
(function(c){AJS.contentReady||(AJS.contentReady=function(){var a,d;1===arguments.length?a=arguments[0]:2===arguments.length&&(d=arguments[0],a=arguments[1]);c(AJS).on("content.ready",function(c){var e=Array.prototype.slice.call(arguments,1),b=e[0];if(d){b=b.is(d)?b:b.find(d);if(b.length){e[0]=b;a.apply(this,e)}}else a.apply(this,e)})},AJS.triggerContentReady=function(){c(AJS).trigger("content.ready",arguments)},c(function(){var a=[c("body")];AJS.contentReady.onReadyArgs&&(a=a.concat(AJS.contentReady.onReadyArgs));
AJS.triggerContentReady.apply(this,a)}))})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher.soy' */
// This file was automatically generated from appswitcher.soy.
// Please don't edit this file by hand.

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.appswitcher == 'undefined') { navlinks.templates.appswitcher = {}; }


navlinks.templates.appswitcher.linkSection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.list.length > 0) {
    output.append('<div class="aui-nav-heading sidebar-section-header">', soy.$$escapeHtml(opt_data.title), '</div><ul class="aui-nav nav-links">');
    var linkList8 = opt_data.list;
    var linkListLen8 = linkList8.length;
    for (var linkIndex8 = 0; linkIndex8 < linkListLen8; linkIndex8++) {
      var linkData8 = linkList8[linkIndex8];
      navlinks.templates.appswitcher.applicationsItem(linkData8, output);
    }
    output.append('</ul>');
  }
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.applicationsItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li class="nav-link"><a href="', soy.$$escapeHtml(opt_data.link), '" class="interactive', (opt_data.self) ? ' checked' : '', '" title="', soy.$$escapeHtml(opt_data.link), '"><span class="nav-link-label">', soy.$$escapeHtml(opt_data.label), '</span></a></li>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.shortcutsItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li class="nav-link"><a href="', soy.$$escapeHtml(opt_data.link), '" class="interactive', (opt_data.self) ? ' checked' : '', '" title="', soy.$$escapeHtml(opt_data.link), '"><span class="nav-link-label">', soy.$$escapeHtml(opt_data.label), '</span>', (opt_data.showDescription && opt_data.description) ? '<span class="nav-link-description">' + soy.$$escapeHtml(opt_data.description) + '</span>' : '', '</a></li>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.error = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="app-switcher-error">', "Something went wrong, please \x3cspan class\x3d\x22app-switcher-retry\x22\x3etry again\x3c/span\x3e.", '</div>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.sidebarContents = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="aui-page-panel-nav"><nav class="aui-navgroup aui-navgroup-vertical"><div class="app-switcher-section app-switcher-applications"><div class="aui-nav-heading">', soy.$$escapeHtml("Application Links"), '</div><div class="app-switcher-loading">', "Loading\x26hellip;", '</div></div><div class="app-switcher-section app-switcher-shortcuts"><div class="aui-nav-heading">', soy.$$escapeHtml("Shortcuts"), '</div><div class="app-switcher-loading">', "Loading\x26hellip;", '</div></div></nav></div>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.trigger = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="aui-icon aui-icon-small aui-iconfont-appswitcher">', soy.$$escapeHtml("Linked Applications"), '</span>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.projectHeaderSection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="app-switcher-title">');
  aui.avatar.avatar({size: 'large', avatarImageUrl: opt_data.avatarUrl, isProject: true, title: opt_data.name}, output);
  output.append('<div class="sidebar-project-name">', soy.$$escapeHtml(opt_data.name), '</div></div>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.cogDropdown = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var dropdownList__soy74 = new soy.StringBuilder();
  navlinks.templates.appswitcher.dropdownList({list: opt_data.links}, dropdownList__soy74);
  dropdownList__soy74 = dropdownList__soy74.toString();
  aui.dropdown2.dropdown2({menu: {'id': opt_data.id, 'content': dropdownList__soy74, 'extraClasses': 'aui-style-default sidebar-customize-section'}, trigger: {'showIcon': false, 'content': '<span class="aui-icon aui-icon-small aui-iconfont-configure"></span>', 'container': '#app-switcher'}}, output);
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.dropdownList = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ul class="sidebar-admin-links">');
  var linkList82 = opt_data.list;
  var linkListLen82 = linkList82.length;
  for (var linkIndex82 = 0; linkIndex82 < linkListLen82; linkIndex82++) {
    var linkData82 = linkList82[linkIndex82];
    output.append('<li class="nav-link"><a href="', soy.$$escapeHtml(linkData82.href), '" title="', soy.$$escapeHtml(linkData82.title), '"><span class="nav-link-label">', soy.$$escapeHtml(linkData82.label), '</span></a></li>');
  }
  output.append('</ul>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.switcher = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (true) {
    if (AJS.DarkFeatures.isEnabled('rotp.sidebar')) {
      var sidebarContents__soy97 = new soy.StringBuilder();
      navlinks.templates.appswitcher.sidebarContents(null, sidebarContents__soy97);
      sidebarContents__soy97 = sidebarContents__soy97.toString();
      var triggerContent__soy99 = new soy.StringBuilder();
      navlinks.templates.appswitcher.trigger(null, triggerContent__soy99);
      triggerContent__soy99 = triggerContent__soy99.toString();
      navlinks.templates.appswitcher.sidebar({sidebar: {'id': 'app-switcher', 'content': sidebarContents__soy97}, trigger: {'showIcon': false, 'content': triggerContent__soy99}}, output);
      output.append('<script>\n                (function (NL) {\n                    var initialise = function () {\n                        new NL.SideBar({\n                            sidebarContents: \'#app-switcher\'\n                        });\n                    };\n                    if (NL.SideBar) {\n                        initialise();\n                    } else {\n                        NL.onInit = initialise;\n                    }\n                }(window.NL = (window.NL || {})));\n                window.NL.isUserAdmin = ', soy.$$escapeHtml(false), '<\/script>');
    } else {
      navlinks.templates.appswitcher_old.switcher(null, output);
    }
  }
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher.sidebar = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="', soy.$$escapeHtml(opt_data.sidebar.id), '" class="sidebar-trigger app-switcher-trigger" aria-owns="', soy.$$escapeHtml(opt_data.sidebar.id), '" aria-haspopup="true">', opt_data.trigger.content, '</a><div id=', soy.$$escapeHtml(opt_data.sidebar.id), ' class="app-switcher-sidebar aui-style-default sidebar-offscreen">', opt_data.sidebar.content, '</div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher.js' */
(function(c,a){a.SideBar=function(d){var e=this;this.$sidebar=null;d=c.extend({sidebarContents:null},d);this.getLinks=function(){return c.ajax({url:AJS.contextPath()+"/rest/menu/latest/appswitcher",cache:false,dataType:"json"}).done(this.updateAppLinks).fail(this.showAppSwitcherError)};this.populateProjectHeader=function(g,f){e.getSidebar().find(".app-switcher-shortcuts .aui-nav-heading").after(navlinks.templates.appswitcher.projectHeaderSection({avatarUrl:f,name:g}))};this.getProjectData=function(){var f=c(".project-shortcut-dialog-trigger"),g=f.data("key"),h=f.data("entity-type");if(f.size()==0||!g||!h){c(".app-switcher-shortcuts").remove();return}var j,i;i=c.ajax({url:AJS.contextPath()+"/rest/project-shortcuts/1.0/local/"+g,cache:false,data:{entityType:h},dataType:"json"});j=c.ajax({url:AJS.contextPath()+"/rest/project-shortcuts/1.0/remote/"+g,cache:false,data:{entityType:h},dataType:"json"});c.when(i,j).then(function(l,k){e.updateProjectShortcuts(l,k,{key:g,entityType:h,name:f.data("name"),avatarUrl:f.find("img").prop("src")})},e.showProjectShortcutsError)};this.getSidebar=function(){if(!this.$sidebar){this.$sidebar=c(d.sidebarContents)}return this.$sidebar};this.addApplicationsCog=function(){c(".app-switcher-applications .aui-nav-heading").before(navlinks.templates.appswitcher.cogDropdown({id:"sidebar-applications-admin-dropdown",links:[{href:AJS.contextPath()+"/plugins/servlet/customize-application-navigator",label:"Customize navigator",title:"Add new entries, hide existing or restrict who sees what"},{href:AJS.contextPath()+"/plugins/servlet/applinks/listApplicationLinks",label:"Manage application links",title:"Link to more Atlassian applications"}]}))};this.addProjectShortcutsCog=function(f,h){var g=[{href:AJS.contextPath()+"/plugins/servlet/custom-content-links-admin?entityKey="+f,label:"Customize shortcuts",title:""}];if(e.entityMappings[h]){g.push({href:e.generateEntityLinksUrl(f,e.entityMappings[h]),label:"Manage product links",title:""})}e.getSidebar().find(".app-switcher-shortcuts .aui-nav-heading").before(navlinks.templates.appswitcher.cogDropdown({id:"sidebar-project-shortcuts-admin-dropdown",links:g}))};this.updateAppLinks=function(f){c(function(){e.getSidebar().find(".app-switcher-applications").html(navlinks.templates.appswitcher.linkSection({title:"Application Links",list:f}));if(a.isUserAdmin){e.addApplicationsCog()}e.bindAnalyticsHandlers(e.getSidebar(),f)})};this.updateProjectShortcuts=function(i,g,h){var j=i[0].shortcuts,f=g[0].shortcuts;e.getSidebar().find(".app-switcher-shortcuts").html(navlinks.templates.appswitcher.linkSection({title:"Shortcuts",list:j.concat(f)}));if(a.isUserAdmin){e.addProjectShortcutsCog(h.key,h.entityType)}e.populateProjectHeader(h.name,h.avatarUrl);e.bindAnalyticsHandlers(e.getSidebar(),data)};this.entityMappings={"confluence.space":"com.atlassian.applinks.api.application.confluence.ConfluenceSpaceEntityType","jira.project":"com.atlassian.applinks.api.application.jira.JiraProjectEntityType","bamboo.project":"com.atlassian.applinks.api.application.bamboo.BambooProjectEntityType","stash.project":"com.atlassian.applinks.api.application.stash.StashProjectEntityType"};this.generateEntityLinksUrl=function(f,g){if(g===e.entityMappings["confluence.space"]){return AJS.contextPath()+"/spaces/listentitylinks.action?typeId="+g+"&key="+f}else{return AJS.contextPath()+"/plugins/servlet/applinks/listEntityLinks/"+g+"/"+f}};this.showAppSwitcherError=function(){c(function(){var f=e.getSidebar();f.find(".app-switcher-applications .app-switcher-loading").replaceWith(navlinks.templates.appswitcher.error());f.off(".appswitcher").on("click.appswitcher",".app-switcher-retry",c.proxy(e.retryLoading,e))})};this.showProjectShortcutsError=function(){c(function(){var f=e.getSidebar();f.find(".app-switcher-shortcuts .app-switcher-loading").replaceWith(navlinks.templates.appswitcher.error());f.off(".appswitcher").on("click.appswitcher",".app-switcher-retry",c.proxy(e.retryLoading,e))})};this.retryLoading=function(f){this.getSidebar().html(navlinks.templates.appswitcher.sidebarContents());this.getLinks();this.getProjectData();f&&f.stopPropagation()};this.bindAnalyticsHandlers=function(f,g){};this.getLinks();c(this.getProjectData);this.toggleSidebar=function(h){var i=e.getSidebar(),g=c("body"),f=c(window.document);if(!g.hasClass("app-switcher-open")){var k=c("#header");i.css("left",-i.width());i.parent("body").length||i.appendTo("body");b({data:i});i.animate({left:0},300);function j(l){var n=l.target&&c(l.target),m=l.keyCode;if(l.originalEvent===h.originalEvent){return}if(n&&!m&&!(n.closest(i).length||n.closest(k).length)&&h.which==1&&!(l.shiftKey||l.ctrlKey||l.metaKey)){e.toggleSidebar()}else{if(m===27){e.toggleSidebar()}}}f.on("click.appSwitcher",j);f.on("keydown.appSwitcher",j);f.on("scroll.appSwitcher",i,b)}else{f.off(".appSwitcher")}g.toggleClass("app-switcher-open")};c("#header").on("click",".app-switcher-trigger",this.toggleSidebar)};function b(f){var d=c(document).scrollTop(),g=c("#header"),e=(g.height()+g.offset().top)-d;if(e>=0){f.data.css({top:e,position:"fixed"})}else{f.data.css({top:0,left:0,position:"fixed"})}}if(a.onInit){a.onInit()}}(jQuery,window.NL=(window.NL||{})));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher_old.js' */
(function(e,c){c.AppSwitcher=function(f){var g=AJS.contextPath()+"/plugins/servlet/customize-application-navigator";var h=this;this.$dropdown=null;f=e.extend({dropdownContents:null},f);this.getLinks=function(){return e.ajax({url:AJS.contextPath()+"/rest/menu/latest/appswitcher",cache:false,dataType:"json"}).done(this.updateDropdown).fail(this.showError)};this.getDropdown=function(){if(!this.$dropdown){this.$dropdown=e(f.dropdownContents)}return this.$dropdown};this.updateDropdown=function(i){e(function(){h.getDropdown().html(navlinks.templates.appswitcher_old.applications({apps:i,showAdminLink:c.isUserAdmin,adminLink:g}));h.bindAnalyticsHandlers(h.getDropdown(),i);h.processSuggestionApps(i)})};this.bindAnalyticsHandlers=function(i,j){};this.processSuggestionApps=function(i){e.ajax({type:"GET",dataType:"json",contentType:"application/json; charset=UTF-8",url:AJS.contextPath()+"/rest/menu/latest/isAppSuggestionAvailable"}).done(function(j){if(j===true){h.handleSuggestionApps(i)}})};this.handleSuggestionApps=function(k){var l=_.map(k,function(m){return m.applicationType.toLowerCase()});$suggestionApps=e("<div id='app-switcher-suggestion-apps' class='aui-dropdown2-section'/>");$suggestionApps.html(navlinks.templates.appswitcher_old.suggestionApps);var j=$suggestionApps.find(".suggestion-apps");var i=false;_.each(a,function(m){if(!_.contains(l,m.appName)){i=true;j.append(navlinks.templates.appswitcher_old.suggestionApp({appName:m.appName,appDesc:m.appDesc}))}});if(!i){return}e("#app-switcher").append($suggestionApps);e(".app-discovery-suggestion-app").click(function(){AJS.trigger("analytics",{name:"appswitcher.discovery.user.select."+e(this).find("a").attr("id").toLowerCase()});window.open(e(this).find("a").attr("title"),"_blank")});e(".app-discovery-suggestion-app").hover(function(){e(this).find("a").removeClass("active").removeClass("aui-dropdown2-active")});e(".app-discovery-cancel-button").click(function(){AJS.trigger("analytics",{name:"appswitcher.discovery.nothanks.button.click"});d(b,"true");$suggestionApps.remove()})};this.showError=function(){e(function(){h.getDropdown().html(navlinks.templates.appswitcher_old.error()).off(".appswitcher").on("click.appswitcher",".app-switcher-retry",e.proxy(h.retryLoading,h))})};this.retryLoading=function(i){this.getDropdown().html(navlinks.templates.appswitcher_old.loading());this.getLinks();i&&i.stopPropagation()};this.getLinks()};var b="key-no-thanks";var a=[{appName:"jira",appDesc:"Issue & Project Tracking Software"},{appName:"confluence",appDesc:"Collaboration and content sharing"},{appName:"bamboo",appDesc:"Continuous integration"}];var d=function(f,g){e.ajax({url:AJS.contextPath()+"/rest/menu/latest/userdata/",type:"PUT",contentType:"application/json",data:JSON.stringify({key:f,value:g})})};if(c.onInit){c.onInit()}}(jQuery,window.NL=(window.NL||{})));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher_old.soy' */
// This file was automatically generated from appswitcher_old.soy.
// Please don't edit this file by hand.

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.appswitcher_old == 'undefined') { navlinks.templates.appswitcher_old = {}; }


navlinks.templates.appswitcher_old.applications = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  navlinks.templates.appswitcher_old.applicationsSection({list: opt_data.apps, listClass: 'nav-links', showDescription: opt_data.showDescription}, output);
  if (opt_data.custom) {
    navlinks.templates.appswitcher_old.applicationsSection({list: opt_data.custom, showDescription: opt_data.showDescription}, output);
  }
  if (opt_data.showAdminLink) {
    navlinks.templates.appswitcher_old.adminSection(opt_data, output);
  }
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.applicationsSection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.list.length > 0) {
    var param19 = new soy.StringBuilder('<ul', (opt_data.listClass) ? ' class="' + soy.$$escapeHtml(opt_data.listClass) + '"' : '', '>');
    var linkList27 = opt_data.list;
    var linkListLen27 = linkList27.length;
    for (var linkIndex27 = 0; linkIndex27 < linkListLen27; linkIndex27++) {
      var linkData27 = linkList27[linkIndex27];
      navlinks.templates.appswitcher_old.applicationsItem(soy.$$augmentData(linkData27, {showDescription: opt_data.showDescription}), param19);
    }
    param19.append('</ul>');
    aui.dropdown2.section({content: param19.toString()}, output);
  }
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.applicationsItem = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li class="nav-link', (opt_data.self) ? ' nav-link-local' : '', '"><a href="', soy.$$escapeHtml(opt_data.link), '" class="aui-dropdown2-radio interactive', (opt_data.self) ? ' checked' : '', '" title="', soy.$$escapeHtml(opt_data.link), '"><span class="nav-link-label">', soy.$$escapeHtml(opt_data.label), '</span>', (opt_data.showDescription && opt_data.description) ? '<span class="nav-link-description">' + soy.$$escapeHtml(opt_data.description) + '</span>' : '', '</a></li>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.adminSection = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  aui.dropdown2.section({content: '<ul class="nav-links"><li><a class="nav-link-edit-wrapper" href="' + soy.$$escapeHtml(opt_data.adminLink) + '"><span class="nav-link-edit">' + "Configure\x26hellip;" + '</span></a></li></ul>'}, output);
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.error = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="app-switcher-error">', "Something went wrong, please \x3cspan class\x3d\x22app-switcher-retry\x22\x3etry again\x3c/span\x3e.", '</div>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.loading = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="app-switcher-loading">', "Loading\x26hellip;", '</div>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.trigger = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="aui-icon aui-icon-small aui-iconfont-appswitcher">', soy.$$escapeHtml("Linked Applications"), '</span>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.switcher = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (true) {
    var loadingContent__soy81 = new soy.StringBuilder();
    navlinks.templates.appswitcher_old.loading(null, loadingContent__soy81);
    loadingContent__soy81 = loadingContent__soy81.toString();
    var triggerContent__soy83 = new soy.StringBuilder();
    navlinks.templates.appswitcher_old.trigger(null, triggerContent__soy83);
    triggerContent__soy83 = triggerContent__soy83.toString();
    aui.dropdown2.dropdown2({menu: {'id': 'app-switcher', 'content': loadingContent__soy81, 'extraClasses': 'aui-style-default'}, trigger: {'showIcon': false, 'content': triggerContent__soy83, 'extraClasses': 'app-switcher-trigger'}}, output);
    output.append('<script>\n            (function (NL) {\n                var initialise = function () {\n                    // For some milestones of AUI, the atlassian soy namespace was renamed to aui. Handle that here by ensuring that window.atlassian is defined.\n                    window.atlassian = window.atlassian || window.aui;\n                    new NL.AppSwitcher({\n                        dropdownContents: \'#app-switcher\'\n                    });\n                };\n                if (NL.AppSwitcher) {\n                    initialise();\n                } else {\n                    NL.onInit = initialise;\n                }\n            }(window.NL = (window.NL || {})));\n            window.NL.isUserAdmin = ', soy.$$escapeHtml(false), '<\/script>');
  }
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.suggestionApp = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<li class="app-discovery-suggestion-app"><a id="', soy.$$escapeHtml(opt_data.appName), '" href="#" class="app-discovery-link aui-icon-container app-discovery-', soy.$$escapeHtml(opt_data.appName), '-product-icon" title="https://www.atlassian.com/software/', soy.$$escapeHtml(opt_data.appName), '"/><div class="app-discovery-small">', soy.$$escapeHtml(opt_data.appDesc), '</div></li>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.appswitcher_old.suggestionApps = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ul class=\'nav-links suggestion-apps\'><li><span class=\'app-discovery-suggest-title nav-link-label\'><h6>', soy.$$escapeHtml("Try other Atlassian apps"), '</h6></span></li></ul><div class=\'buttons-container app-discovery-suggest-apps-buttons\'><div class=\'buttons\'><button class=\'aui-button aui-button-link app-discovery-cancel-button\' name=\'cancel\' accesskey=\'c\' href=\'#\'>', soy.$$escapeHtml("Don\x27t show this again"), '</button></div></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/inline-dialog.js' */
(function(d){AJS.CustomInlineDialog=AJS.CustomInlineDialog||function(B,n,r,p){p=p||[];if(p.hasOwnProperty("getArrowAttributes")){getArrowAttributesDeprecationLogger()}if(p.hasOwnProperty("getArrowPath")){getArrowPathDeprecationLogger();if(p.hasOwnProperty("gravity")){getArrowPathWithGravityDeprecationLogger()}}if(p.hasOwnProperty("onTop")){onTopDeprecationLogger();if(p.onTop&&p.gravity===undefined){p.gravity="s"}}if(typeof n==="undefined"){n=String(Math.random()).replace(".","");if(d("#inline-dialog-"+n+", #arrow-"+n+", #inline-dialog-shim-"+n).length){throw"GENERATED_IDENTIFIER_NOT_UNIQUE"}}var z=d.extend(false,AJS.CustomInlineDialog.opts,p);if(z.gravity==="w"){z.offsetX=p.offsetX===undefined?10:p.offsetX;z.offsetY=p.offsetY===undefined?0:p.offsetY}var v=function(){return window.Raphael&&p&&(p.getArrowPath||p.getArrowAttributes)};var j;var q;var K;var u=false;var A=false;var I=false;var J;var x;var g=d('<div id="inline-dialog-'+n+'" class="aui-inline-dialog"><div class="aui-inline-dialog-contents contents"></div><div id="arrow-'+n+'" class="aui-inline-dialog-arrow arrow"></div></div>');var m=d("#arrow-"+n,g);var G=g.find(".contents");if(!v()){g.find(".aui-inline-dialog-arrow").addClass("aui-css-arrow")}if(!z.displayShadow){G.addClass("aui-inline-dialog-no-shadow")}if(z.autoWidth){G.addClass("aui-inline-dialog-auto-width")}else{G.css("width",z.width+"px")}G.mouseover(function(O){clearTimeout(q);g.unbind("mouseover")}).mouseout(function(){E()});var D=function(){if(!j){j={popup:g,hide:function(){E(0)},id:n,show:function(){y()},persistent:z.persistent?true:false,reset:function(){function S(U,T){U.css(T.popupCss);if(v()){if(T.gravity==="s"){T.arrowCss.top-=d.browser.msie?10:9}if(!U.arrowCanvas){U.arrowCanvas=Raphael("arrow-"+n,16,16)}var V=z.getArrowPath,W=d.isFunction(V)?V(T):V;U.arrowCanvas.path(W).attr(z.getArrowAttributes())}else{m.removeClass("aui-bottom-arrow aui-left-arrow aui-right-arrow");if(T.gravity==="s"&&!m.hasClass("aui-bottom-arrow")){m.addClass("aui-bottom-arrow")}else{if(T.gravity==="n"){}else{if(T.gravity==="w"){m.addClass("aui-left-arrow")}else{if(T.gravity==="e"){m.addClass("aui-right-arrow")}}}}}m.css(T.arrowCss)}var P=AJS.$(window).height();var Q=Math.round(P*0.75);g.children(".aui-inline-dialog-contents").css("max-height",Q);var O=z.calculatePositions(g,x,J,z);if(O.hasOwnProperty("displayAbove")){displayAboveDeprecationLogger();O.gravity=O.displayAbove?"s":"n"}S(g,O);g.fadeIn(z.fadeTime,function(){});if(d.browser.msie&&~~(d.browser.version)<10){var R=d("#inline-dialog-shim-"+n);if(!R.length){d(g).prepend(d('<iframe class = "inline-dialog-shim" id="inline-dialog-shim-'+n+'" frameBorder="0" src="javascript:false;"></iframe>'))}R.css({width:G.outerWidth(),height:G.outerHeight()})}}}}return j};var y=function(){if(g.is(":visible")){return}K=setTimeout(function(){if(!I||!A){return}z.addActiveClass&&d(B).addClass("active");u=true;if(!z.persistent){H()}AJS.CustomInlineDialog.current=D();d(document).trigger("showLayer",["inlineDialog",D()]);D().reset()},z.showDelay)};var E=function(O){if(typeof O=="undefined"&&z.persistent){return}A=false;if(u&&z.preHideCallback.call(g[0].popup)){O=(O==null)?z.hideDelay:O;clearTimeout(q);clearTimeout(K);if(O!=null){q=setTimeout(function(){l();z.addActiveClass&&d(B).removeClass("active");g.fadeOut(z.fadeTime,function(){z.hideCallback.call(g[0].popup)});if(g.arrowCanvas){g.arrowCanvas.remove();g.arrowCanvas=null}u=false;A=false;d(document).trigger("hideLayer",["inlineDialog",D()]);AJS.CustomInlineDialog.current=null;if(!z.cacheContent){I=false;w=false}},O)}}};var F=function(R,P){var O=d(P);z.upfrontCallback.call({popup:g,hide:function(){E(0)},id:n,show:function(){y()}});g.each(function(){if(typeof this.popup!="undefined"){this.popup.hide()}});if(z.closeOthers){d(".aui-inline-dialog").each(function(){!this.popup.persistent&&this.popup.hide()})}x={target:O};if(!R){J={x:O.offset().left,y:O.offset().top}}else{J={x:R.pageX,y:R.pageY}}if(!u){clearTimeout(K)}A=true;var Q=function(){w=false;I=true;z.initCallback.call({popup:g,hide:function(){E(0)},id:n,show:function(){y()}});y()};if(!w){w=true;if(d.isFunction(r)){r(G,P,Q)}else{d.get(r,function(T,S,U){G.html(z.responseHandler(T,S,U));I=true;z.initCallback.call({popup:g,hide:function(){E(0)},id:n,show:function(){y()}});y()})}}clearTimeout(q);if(!u){y()}return false};g[0].popup=D();var w=false;var t=false;var s=function(){if(!t){d(z.container).append(g);t=true}};var o=d(B);if(z.onHover){if(z.useLiveEvents){if(o.selector){d(document).on("mousemove",o.selector,function(O){s();F(O,this)}).on("mouseout",o.selector,function(){E()})}else{AJS.log("Warning: inline dialog trigger elements must have a jQuery selector when the useLiveEvents option is enabled.")}}else{o.mousemove(function(O){s();F(O,this)}).mouseout(function(){E()})}}else{if(!z.noBind){if(z.useLiveEvents){if(o.selector){d(document).on("click",o.selector,function(O){s();if(M()){g.hide()}else{F(O,this)}return false}).on("mouseout",o.selector,function(){E()})}else{AJS.log("Warning: inline dialog trigger elements must have a jQuery selector when the useLiveEvents option is enabled.")}}else{o.click(function(O){s();if(M()){g.hide()}else{F(O,this)}return false}).mouseout(function(){E()})}}}var M=function(){return u&&z.closeOnTriggerClick};var H=function(){k();f()};var l=function(){C();N()};var i=false;var h=n+".inline-dialog-check";var k=function(){if(!i){d("body").bind("click."+h,function(P){var O=d(P.target);if(O.closest("#inline-dialog-"+n+" .contents").length===0){E(0)}});i=true}};var C=function(){if(i){d("body").unbind("click."+h)}i=false};var L=function(O){if(O.keyCode===27){E(0)}};var f=function(){d(document).on("keydown",L)};var N=function(){d(document).off("keydown",L)};g.show=function(P,O){if(P){P.stopPropagation()}s();if(z.noBind&&!(B&&B.length)){F(P,O===undefined?P.target:O)}else{F(P,B)}};g.hide=function(){E(0)};g.refresh=function(){if(u){D().reset()}};g.getOptions=function(){return z};return g};function c(g){var f=d(g);var h=d.extend({left:0,top:0},f.offset());return{left:h.left,top:h.top,width:f.outerWidth(),height:f.outerHeight()}}function b(h,j,t,f){var m=AJS.$.isFunction(f.offsetX)?f.offsetX(h,j,t,f):f.offsetX;var l=AJS.$.isFunction(f.offsetY)?f.offsetY(h,j,t,f):f.offsetY;var q=AJS.$.isFunction(f.arrowOffsetX)?f.arrowOffsetX(h,j,t,f):f.arrowOffsetX;var p=AJS.$.isFunction(f.arrowOffsetY)?f.arrowOffsetY(h,j,t,f):f.arrowOffsetY;var s=f.container.toLowerCase()!=="body";var g=AJS.$(f.container);var o=s?AJS.$(f.container).parent():AJS.$(window);var r=s?g.offset():{left:0,top:0};var k=s?o.offset():{left:0,top:0};var i=j.target;var u=i.offset();var n=i[0].getBBox&&i[0].getBBox();return{screenPadding:10,arrowMargin:5,window:{top:k.top,left:k.left,scrollTop:o.scrollTop(),scrollLeft:o.scrollLeft(),width:o.width(),height:o.height()},scrollContainer:{width:g.width(),height:g.height()},trigger:{top:u.top-r.top,left:u.left-r.left,width:n?n.width:i.outerWidth(),height:n?n.height:i.outerHeight()},dialog:{width:h.width(),height:h.height(),offset:{top:l,left:m}},arrow:{height:h.find(".arrow").outerHeight(),offset:{top:p,left:q}}}}function e(f,p,G,r){var n=b(f,p,G,r);var j=n.screenPadding;var k=n.window;var t=n.trigger;var D=n.dialog;var i=n.arrow;var z=n.scrollContainer;var E={top:t.top-k.scrollTop,left:t.left-k.scrollLeft};var A=Math.floor(t.height/2);var v=Math.floor(D.height/2);var u=Math.floor(i.height/2);var C=E.left-D.offset.left-j;var H=z.width-E.left-t.width-D.offset.left-j;var B=C>=D.width;var h=H>=D.width;var l=!h&&B?"e":"w";var o=E.top+A-u;var q=k.height-o-i.height;j=Math.min(j,o-n.arrowMargin);j=Math.min(j,q-n.arrowMargin);var g=E.top+A;var x=Math.max(g-j,0);var F=Math.max(k.height-g-j,0);var y=v-D.offset.top>x;var m=v+D.offset.top>F;var w;var s;if(y){w={top:k.scrollTop+j,left:l==="w"?t.left+t.width+D.offset.left:t.left-D.width-D.offset.left};s={top:(t.top+A)-(w.top+u)}}else{if(m){w={top:k.scrollTop+k.height-D.height-j,left:l==="w"?t.left+t.width+D.offset.left:t.left-D.width-D.offset.left};s={top:(t.top+A)-(w.top+u)}}else{w={top:t.top+A-v+D.offset.top,left:l==="w"?t.left+t.width+D.offset.left:t.left-D.width-D.offset.left};s={top:v-u+i.offset.top}}}return{gravity:l,popupCss:w,arrowCss:s}}function a(g,o,z,s){var x=AJS.$.isFunction(s.offsetX)?s.offsetX(g,o,z,s):s.offsetX;var v=AJS.$.isFunction(s.offsetY)?s.offsetY(g,o,z,s):s.offsetY;var m=AJS.$.isFunction(s.arrowOffsetX)?s.arrowOffsetX(g,o,z,s):s.arrowOffsetX;var l=AJS.$.isFunction(s.arrowOffsetY)?s.arrowOffsetY(g,o,z,s):s.arrowOffsetY;var f=c(window);var p=c(o.target);var y=c(g);var j=c(g.find(".aui-inline-dialog-arrow"));var i=p.left+p.width/2;var u=(window.pageYOffset||document.documentElement.scrollTop)+f.height;var k=10;y.top=p.top+p.height+~~v;y.left=p.left+~~x;var r=f.width-(y.left+y.width+k);j.left=i-y.left+~~m;j.top=-(j.height/2);var n=p.top>y.height;var h=(y.top+y.height)<u;var q=(!h&&n)||(n&&s.gravity==="s");if(q){y.top=p.top-y.height-(j.height/2);j.top=y.height}if(s.isRelativeToMouse){if(r<0){y.right=k;y.left="auto";j.left=z.x-(f.width-y.width)}else{y.left=z.x-20;j.left=z.x-y.left}}else{if(r<0){y.right=k;y.left="auto";var w=f.width-y.right;var t=w-y.width;j.right="auto";j.left=i-t-j.width/2}else{if(y.width<=p.width/2){j.left=y.width/2;y.left=i-y.width/2}}}return{gravity:q?"s":"n",displayAbove:q,popupCss:{left:y.left,top:y.top,right:y.right},arrowCss:{left:j.left,top:j.top,right:j.right}}}AJS.CustomInlineDialog.opts={onTop:false,responseHandler:function(g,f,h){return g},closeOthers:true,isRelativeToMouse:false,addActiveClass:true,onHover:false,useLiveEvents:false,noBind:false,fadeTime:100,persistent:false,hideDelay:10000,showDelay:0,width:300,offsetX:0,offsetY:10,arrowOffsetX:0,arrowOffsetY:0,container:"body",cacheContent:true,displayShadow:true,autoWidth:false,gravity:"n",closeOnTriggerClick:false,preHideCallback:function(){return true},hideCallback:function(){},initCallback:function(){},upfrontCallback:function(){},calculatePositions:function(f,i,j,h){h=h||{};var g=h.gravity==="w"?e:a;return g(f,i,j,h)},getArrowPath:function(f){if(f.gravity==="s"){return"M0,8L8,16,16,8"}else{return"M0,8L8,0,16,8"}},getArrowAttributes:function(){return{fill:"#fff",stroke:"#ccc"}}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:space-page-picker', location = '/js/space-page-picker.js' */
(function(i,c){var t={conf_all:"All spaces",conf_favorites:"Favourite spaces",conf_global:"Site spaces",conf_personal:"Personal spaces",conf_current:"Current space"};var b={data:null,suggestCategories:null};var v="SPACE-PAGE-TRIGGER-VALUE";var f={placeholder:"Select a space or page",multiple:true,formatInputTooShort:function(){return "Start typing to search"},formatResult:function(G,I,L){if(G.children){I.addClass("space-page-picker-result-category");return i.fn.select2.defaults.formatResult.apply(this,arguments)}else{if(G.id){I.attr("title",G.text);I.addClass("space-page-picker-result-label-with-icon");var F=i("<span/>").addClass(G.className+" item-text").html(i.fn.select2.defaults.formatResult.apply(this,arguments));var K=(G.subText)?i("<span/>").addClass("space-name").html(G.subText):i("");var H=i("<span/>").attr(s(G.id),G.id).append(F).append(K);var J=i("<span/>").append(H);return J}else{I.addClass(G.className);return i.fn.select2.defaults.formatResult.apply(this,arguments)}}},formatSelection:function(G,H){H.addClass("space-page-picker-selected-item");H.attr("title",G.text);var F=i("<span/>").attr(s(G.id),G.id).addClass(G.className+" item-text").html(i.fn.select2.defaults.formatSelection.apply(this,arguments));H.append(F)},escapeMarkup:function(F){return F},formatResultCssClass:function(F){return(F.children||F.id)?"":"select2-result-space-page-separator"},containerCssClass:"space-page-picker-container",dropdownCssClass:"space-page-picker-drop"};var B=function(F,H){var G=F.data("select2").opts.manualInit;if(G===true){return}d(F.val(),F,H)};function r(H,G,F){var I=_.map(H,function(J){return G[J]});return(F)?I:((I.length>0)?I[0]:null)}var l=function(F){var G;if(F.suggestCategories){var H={text:"Suggested categories",children:_.map(F.suggestCategories,function(I){return o(I)})}}return function(J){if(G){J.callback(G);return}var I=[];G={results:[]};if(x(F)){var L=i.getJSON(AJS.contextPath()+"/rest/recentlyviewed/1.0/recent/spaces").done(function(M){var N=(H)?[H]:[];(M.length>0)&&N.push({text:"Suggested spaces",children:_.map(M,function(O){return m(O.key,_.escape(O.name),null,true)})});(N.length>0)&&(G.results=G.results.concat(N))}).fail(function(){AJS.debug("Couldn't fetch recent spaces");var M=(H)?[H]:[];(M.length>0)&&(G.results=G.results.concat(M))});I.push(L)}if(j(F)){var K=i.getJSON(AJS.contextPath()+"/rest/recentlyviewed/1.0/recent/pages",{noTrashedContent:true}).done(function(M){if(M.length>0){G.results.push({text:"Suggested pages",children:_.map(M,function(N){return h(N.id,_.escape(N.title),_.escape(N.space),"content-type-page",true)})})}}).fail(function(){AJS.debug("Couldn't fetch recent pages")});I.push(K)}i.when.apply(i,_.map(I,function(N){var M=i.Deferred();N.always(function(){M.resolve()});return M})).done(function(){if(G.results.length===0){G.results=[{text:"",children:[]}]}J.callback(G)})}};var w=function(F){var G="";if(!F||F.length===2&&F.indexOf("space")>=0&&F.indexOf("page")>=0){G="type=spacedesc&type=personalspacedesc&type=page"}else{if(F.length===1&&F[0]==="space"){G="type=spacedesc&type=personalspacedesc"}else{if(F.length===1&&F[0]==="page"){G="type=page"}else{return}}}return window.Select2.query.ajax({url:AJS.contextPath()+"/rest/quicknav/1/search?"+G,data:function(H,I){return{query:H,maxPerCategory:25}},quietMillis:250,results:function(K,O){var N=K.contentNameMatches;if(N.length<=1){return{results:[]}}else{var P=[];var I=function(Q){return E(Q.spaceKey,Q.spaceName,Q.id,Q.name,Q.className)};for(var L=0;L<N.length-1;L++){var M=[];for(var J=0;J<N[L].length;J++){var H=I(N[L][J]);if(H){M.push(H)}}if(M.length>0){P=P.concat(M);P.push({id:"",text:"",subText:"",className:"",disabled:true})}}return{results:[{text:"Search results",children:P}]}}}})};var p=function(G){var F=w(G.contentType);var H=l(G);return function(I){if(I.term.length<2){H(I)}else{F(I)}}};function s(F){return(F.indexOf("page:")===0)?"data-item-id":"data-item-key"}function m(F,I,G,H){G=(G)?G:((F.indexOf("~")===0)?"content-type-personalspacedesc":"content-type-spacedesc");return e("space",F,I,"",G,H)}function o(F){var G=t[F];return e("space-cat",F,G,"","content-type-space-category",G)}function h(J,I,F,G,H){return e("page",J,I,F,G,H)}function e(L,I,K,H,G,J){var F=y(L,I);K=(!K)?I:K;G=(J)?G:(G+" content-not-found");return{id:F,text:K,subText:H,className:G,disabled:(J?false:true)}}function C(F){return"space-cat:"+F}function a(F){return"space:"+F}function D(F){return"page:"+F}function E(J,G,K,H,I){var F;if(I==="content-type-spacedesc"||I==="content-type-personalspacedesc"){F=m(J,G,I,true)}else{if(I==="content-type-page"){F=h(K,H,G,I,true)}}return F}function y(){var F=Array.prototype.slice.apply(arguments);return F.join(":")}function x(F){return((!F.contentType||F.contentType.length===0||F.contentType.indexOf("space")>=0)&&F.showRecentlyViewedSpaces!==false)}function j(F){return((!F.contentType||F.contentType.length===0||F.contentType.indexOf("page")>=0)&&F.showRecentlyViewedPages!==false)}function n(G,F){var H=q("SpaceCat",G,F.inputSpaceCatId,(F.inputSpaceCatName)?F.inputSpaceCatName:F.inputSpaceCatId);return u(G,H.id,H.name)}function g(G,F){var H=q("Space",G,F.inputSpaceId,(F.inputSpaceName)?F.inputSpaceName:F.inputSpaceId);return u(G,H.id,H.name)}function z(G,F){var H=q("Page",G,F.inputPageId,(F.inputPageName)?F.inputPageName:F.inputPageId);return u(G,H.id,H.name)}function q(J,H,K,G){var F;if(!K){F=H.attr("id");if(!F){return null}K=F+J}if(!G){var I=H.attr("name")||F;G=I+J}return{id:K,name:G}}function u(G,I,F){var H=i("#"+I);if(H.length===0){H=i(Confluence.UI.Components.templates.hiddenField({id:I,name:F}));G.after(H)}return H}function k(G,I,H){if(!G){return}var F=_.filter(I,function(J){return J.indexOf(H)===0});F=_.map(F,function(J){return J.substring(H.length,J.length)});G.val(F.join(","))}function A(M,H,I,F){I=(I)?(_.isArray(I)?I:I.split(",")):[];F=(F)?F.split(","):[];var L=_.union(I,F);var G=_.map(L,function(O){return H+O});var J=M.val();var N=J?J.split(","):[];var K=_.union(N,G);if(K.length>0){M.val(K.join(","))}}c.build=function(G){var F=_.extend({},b,f,G);if(!G.data){F=_.extend({},{initSelection:B,query:p(F)},F)}var H=i(F.orgElement);if(!H||H.length!==1){return F}if(!H.val()&&!F.manualInit){H.val(v)}H.addClass("select2-input");return F};c.setValue=function(G,F){d(G,F,function(H){F.auiSelect2("data",H)})};function d(P,G,S){var U=G.data("select2").opts;var Q=U.placeholder||G.data("placeholder");var K=n(G,U);var M=g(G,U);var I=z(G,U);G.on("change",function(V){k(K,V.val,"space-cat:");k(M,V.val,"space:");k(I,V.val,"page:")});G.val("");var T=(G["0"].tagName==="SELECT")?(G.context.multiple):(U.multiple);var N=[];var R=[];var L=[];var F={};var H=(P)?P.split(","):[];H=_.filter(H,function(V){var W=V.split(":");if(W.length===2){return true}else{if(W.length<0||W.length>=3||(W.length===1&&(W[0]!==v&&W[0]!==Q))){AJS.debug("Error value: "+W)}}});P=H.join(",");G.val(P);A(G,"space-cat:",U.spaceCatKeys,(K)?K.val():"");A(G,"space:",U.spaceKeys,(M)?M.val():"");A(G,"page:",U.pageIds,(I)?I.val():"");P=G.val();H=(P)?P.split(","):[];k(K,H,"space-cat:");k(M,H,"space:");k(I,H,"page:");if(H.length===0){return}_.each(H,function(V,W){var Z=V.split(":");if(Z.length===2){var Y=Z[0];var X=Z[1];if(Y==="space-cat"){N.push(X)}else{if(Y==="space"){R.push(X)}else{if(Y==="page"){L.push(X)}}}}});_.each(N,function(V){F[C(V)]=o(V)});var O=[];if(R.length>0){var J=i.getJSON(AJS.contextPath()+"/rest/prototype/1/space",{spaceKey:R}).done(function(X){var V=[];_.each(X.space,function(Y){F[a(Y.key)]=m(Y.key,_.escape(Y.name),null,true);V.push(Y.key)});var W=_.difference(R,V);_.each(W,function(Y){F[a(Y)]=m(Y,Y,null,false)})}).fail(function(){AJS.debug("Couldn't resolve spaceKeys:",R);_.each(R,function(V){F[a(V)]=m(V,V,null,false)})});O.push(J)}_.each(L,function(V){var W=i.getJSON(AJS.contextPath()+"/rest/api/content/"+V,{expand:"space"}).done(function(X){F[D(X.id)]=h(X.id,_.escape(X.title),_.escape(X.space.name),"content-type-page",true)}).fail(function(){AJS.debug("Couldn't resolve pageId:",V);F[D(V)]=h(V,V,"","content-type-page",false)});O.push(W)});i.when.apply(i,_.map(O,function(W){var V=new i.Deferred();W.always(function(){V.resolve()});return V.promise()})).done(function(){S(r(H,F,T))})}}(AJS.$,window.Confluence.UI.Components.SpacePagePicker));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:space-page-picker', location = '/soy/space-page-picker.soy' */
// This file was automatically generated from space-page-picker.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.UI == 'undefined') { Confluence.UI = {}; }
if (typeof Confluence.UI.Components == 'undefined') { Confluence.UI.Components = {}; }
if (typeof Confluence.UI.Components.templates == 'undefined') { Confluence.UI.Components.templates = {}; }


Confluence.UI.Components.templates.hiddenField = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<input type="hidden" id="', soy.$$escapeHtml(opt_data.id), '" name="', soy.$$escapeHtml(opt_data.name), '" />');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:task-report-blueprint-resources', location = 'templates/task-report-blueprint.soy' */
// This file was automatically generated from task-report-blueprint.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.InlineTasks == 'undefined') { Confluence.InlineTasks = {}; }
if (typeof Confluence.InlineTasks.Report == 'undefined') { Confluence.InlineTasks.Report = {}; }
if (typeof Confluence.InlineTasks.Report.Templates == 'undefined') { Confluence.InlineTasks.Report.Templates = {}; }


Confluence.InlineTasks.Report.Templates.taskReportBlueprintForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ol class="report-types" id="task-report-types"><li class="template" id="team-task-report"><span class="template-preview team-task-report-icon"></span><div class="template-meta"><div class="template-name">', soy.$$escapeHtml("Assigned to my team"), '</div><div class="template-description">', soy.$$escapeHtml("Show tasks assigned to specific people"), '</div></div></li><li class="template" id="location-task-report"><span class="template-preview location-task-report-icon"></span><div class="template-meta"><div class="template-name">', soy.$$escapeHtml("In my project"), '</div><div class="template-description">', soy.$$escapeHtml("Show tasks created in specific spaces and pages"), '</div></div></li><li class="template" id="custom-task-report"><span class="template-preview custom-task-report-icon"></span><div class="template-meta"><div class="template-name">', soy.$$escapeHtml("Custom"), '</div><div class="template-description">', soy.$$escapeHtml("Create your own report"), '</div></div></li></ol>');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.reportByTeamForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="report-by-team-form" class="aui"><fieldset><div class="field-group"><label for="task-report-page-title">', soy.$$escapeHtml("Title"), '<span class="aui-icon icon-required">required</span></label><input id="task-report-page-title" class="text long-field" type="text" name="title" placeholder="', soy.$$escapeHtml("Title of your task report"), '"/><div class="error hidden"></div></div><div class="field-group"><label for="task-report-team-picker">', soy.$$escapeHtml("Assigned to"), '<span class="aui-icon icon-required">required</span></label><input id="task-report-team-picker" class="text select2-input long-field autocomplete-multiuser" type="text" name="teamMembers" placeholder="', soy.$$escapeHtml("Only show tasks assigned to these people"), '" /><div class="error hidden"></div></div><div class="field-group"><div class="checkbox"><input class="checkbox" type="checkbox" name="completed" id="task-report-completed-cb"><label for="task-report-completed-cb">', soy.$$escapeHtml("Include completed tasks"), '</label></div></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.reportByLocationForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="report-by-location-form" class="aui"><fieldset><div class="field-group"><label for="task-report-page-title">', soy.$$escapeHtml("Title"), '<span class="aui-icon icon-required">required</span></label><input id="task-report-page-title" class="text long-field" type="text" name="title" placeholder="', soy.$$escapeHtml("Title of your task report"), '"/><div class="error hidden"></div></div><div class="field-group"><label for="task-report-location-picker">', soy.$$escapeHtml("Created in"), '<span class="aui-icon icon-required">required</span></label><input id="task-report-location-picker" class="text select2-input long-field" type="text" name="locations" placeholder="', soy.$$escapeHtml("Select task locations"), '"/><div class="error hidden"></div></div><div class="field-group"><label for="task-report-label-picker">', soy.$$escapeHtml("Labels"), '</label><input id="task-report-label-picker" class="text select2-input long-field" type="text" name="labels" placeholder="', soy.$$escapeHtml("Only show tasks on pages with these labels"), '"/></div><div class="field-group"><div class="checkbox"><input class="checkbox" type="checkbox" name="completed" id="task-report-completed-cb"><label for="task-report-completed-cb">', soy.$$escapeHtml("Include completed tasks"), '</label></div></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.assigneeParam = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.userKeys) {
    output.append('<ac:parameter ac:name="assignees">');
    var keyList48 = opt_data.userKeys;
    var keyListLen48 = keyList48.length;
    for (var keyIndex48 = 0; keyIndex48 < keyListLen48; keyIndex48++) {
      var keyData48 = keyList48[keyIndex48];
      output.append('<ri:user ri:userkey="', soy.$$escapeHtml(keyData48), '" />');
    }
    output.append('</ac:parameter>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.creatorParam = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.userKeys) {
    output.append('<ac:parameter ac:name="creators">');
    var keyList58 = opt_data.userKeys;
    var keyListLen58 = keyList58.length;
    for (var keyIndex58 = 0; keyIndex58 < keyListLen58; keyIndex58++) {
      var keyData58 = keyList58[keyIndex58];
      output.append('<ri:user ri:userkey="', soy.$$escapeHtml(keyData58), '" />');
    }
    output.append('</ac:parameter>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.macroParam = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.value) ? '<ac:parameter ac:name="' + soy.$$escapeHtml(opt_data.name) + '">' + soy.$$escapeHtml(opt_data.value) + '</ac:parameter>' : '');
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.teamReportContent = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p><ac:structured-macro ac:name="tasks-report-macro"><!-- assignee-->');
  Confluence.InlineTasks.Report.Templates.assigneeParam({userKeys: opt_data.assignees}, output);
  output.append('<!-- status--><ac:parameter ac:name="status">incomplete</ac:parameter></ac:structured-macro></p>');
  if (opt_data.showCompletedTasks) {
    output.append('<ac:structured-macro ac:name="expand"><ac:parameter ac:name="title">', soy.$$escapeHtml("Completed tasks"), '</ac:parameter><ac:rich-text-body><p><ac:structured-macro ac:name="tasks-report-macro"><!-- assignee-->');
    Confluence.InlineTasks.Report.Templates.assigneeParam({userKeys: opt_data.assignees}, output);
    output.append('<!-- status--><ac:parameter ac:name="status">complete</ac:parameter></ac:structured-macro></p></ac:rich-text-body></ac:structured-macro>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.locationReportContent = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p><ac:structured-macro ac:name="tasks-report-macro"><!-- space-->');
  Confluence.InlineTasks.Report.Templates.macroParam({name: 'spaces', value: opt_data.spaceKeys}, output);
  output.append('<!-- pages-->');
  Confluence.InlineTasks.Report.Templates.macroParam({name: 'pages', value: opt_data.pageIds}, output);
  output.append('<!-- labels-->');
  Confluence.InlineTasks.Report.Templates.macroParam({name: 'labels', value: opt_data.labels}, output);
  output.append('<!-- status--><ac:parameter ac:name="status">incomplete</ac:parameter></ac:structured-macro></p>');
  if (opt_data.showCompletedTasks) {
    output.append('<ac:structured-macro ac:name="expand"><ac:parameter ac:name="title">', soy.$$escapeHtml("Completed tasks"), '</ac:parameter><ac:rich-text-body><p><ac:structured-macro ac:name="tasks-report-macro"><!-- space-->');
    Confluence.InlineTasks.Report.Templates.macroParam({name: 'spaces', value: opt_data.spaceKeys}, output);
    output.append('<!-- pages-->');
    Confluence.InlineTasks.Report.Templates.macroParam({name: 'pages', value: opt_data.pageIds}, output);
    output.append('<!-- labels-->');
    Confluence.InlineTasks.Report.Templates.macroParam({name: 'labels', value: opt_data.labels}, output);
    output.append('<!-- status--><ac:parameter ac:name="status">complete</ac:parameter></ac:structured-macro></p></ac:rich-text-body></ac:structured-macro>');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.InlineTasks.Report.Templates.customReportContent = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p><span class="text-placeholder">', soy.$$escapeHtml("Edit the Task Report macro to customise your report."), '</span></p><ac:structured-macro ac:name="tasks-report-macro">');
  if (opt_data.creators) {
    Confluence.InlineTasks.Report.Templates.creatorParam({userKeys: opt_data.creators}, output);
  }
  output.append('</ac:structured-macro>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:task-report-blueprint-resources', location = 'js/task-report-bp.js' */
(function(d){var c;function e(t){t.addClass("selected").siblings().removeClass("selected");AJS.trigger("selected.task-report-types",t)}function i(w,v){AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.report_blueprint.clicked"});var u=d("#task-report-types");var t=u.find(".template");t.first().addClass("selected");t.click(function(){e(d(this))}).dblclick(function(){d(".create-dialog-create-button:visible").click()});u.attr("tabindex",0).keydown(function(z){if(z.keyCode==38||z.keyCode==40){z.preventDefault();var x=u.find(".selected"),y;if(z.keyCode==38){y=x.prev().length?x.prev():t.last()}else{if(z.keyCode==40){y=x.next().length?x.next():t.first()}}e(y)}});u.focus();AJS.bind("selected.task-report-types",function(y,x){if(d(x).is("#custom-task-report")){p("Create")}else{p("Next")}});p("Next")}function f(v,u){var t=u.$container.find(".selected").attr("id");if(t==="team-task-report"){u.nextPageId="teamTaskReportId";AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.report_team.clicked"})}else{if(t==="location-task-report"){u.nextPageId="locationTaskReportId";AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.report_project.clicked"})}else{if(t==="custom-task-report"){c.getSubmissionRestPath=function(){AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.report_custom.clicked"});return"/rest/create-dialog/1.0/content-blueprint/create-draft"};g(u,"custom-task-report-template")}else{return false}}}}function a(u,t){o()}function m(w,v){var t=d("#report-by-team-form");b(t);var u=true;u=r(d("#task-report-team-picker"),"Assignee is required.")&&u;u=s(v.wizardData.spaceKey)&&u;u?g(v,"team-task-report-template"):h(t);AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.report_team.created"});return u}function n(u,t){k(d("#task-report-location-picker"),t.wizardData.spaceKey);q(d("#task-report-label-picker"));o()}function j(w,v){var t=d("#report-by-location-form");b(t);var u=true;u=r(d("#task-report-location-picker"),"A space or page is required.")&&u;u=s(v.wizardData.spaceKey)&&u;if(u){g(v,"location-task-report-template")}else{h(t)}AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.report_project.created"});return u}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-inline-tasks:task-report-blueprint-item",function(t){t.on("post-render.selectTaskReportId",i);t.on("submit.selectTaskReportId",f);t.on("post-render.teamTaskReportId",a);t.on("submit.teamTaskReportId",m);t.on("post-render.locationTaskReportId",n);t.on("submit.locationTaskReportId",j);c=t});function b(t){t.find(".error").addClass("hidden").empty()}function s(v){var t=d("#task-report-page-title");var u=Confluence.Blueprint.validateTitle(t,v);if(!u){t.siblings(".error").removeClass("hidden")}return u}function r(t,u){var v=d.trim(t.val());if(!v&&u){l(t,u)}return !!v}function h(u){var t=u.find("div.error:not(.hidden)").first();var v=t.siblings("input").eq(0);if(v.hasClass("select2-offscreen")){v.select2("focus")}else{v.focus()}}function g(t,u){t.pageData.contentTemplateKey=u}function l(v,u){var t=v.siblings(".error");t.html(u);t.removeClass("hidden");return u}function q(t){t.auiSelect2(Confluence.UI.Components.LabelPicker.build())}function k(u,t){u.auiSelect2(Confluence.UI.Components.SpacePagePicker.build({spaceKeys:[t],orgElement:u}))}function p(t){d(".create-dialog-create-button:visible").text(t)}function o(){var v;var u=d("#task-report-completed-cb");var t=d("label[for=task-report-completed-cb]").add(u);t.mousedown(function(){v=true});d(".dialog-wizard-page-main").on("mouseup",function(w){if(!t.is(w.target)&&v){u.click()}v=false})}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-knowledge-base:space-kb-web-resource', location = 'js/kb-space-dialog-wizard.js' */
AJS.bind("blueprint.wizard-register.ready",function(){function a(d,c){c.pageData.ContentPageTitle=c.pageData.name;return Confluence.SpaceBlueprint.CommonWizardBindings.submit(d,c)}function b(d,c){c.soyRenderContext.atlToken=AJS.Meta.get("atl-token");c.soyRenderContext.showSpacePermission=false}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-knowledge-base:kb-blueprint-item",function(c){c.on("submit.kbSpaceId",a);c.on("pre-render.kbSpaceId",b);c.on("post-render.kbSpaceId",Confluence.SpaceBlueprint.CommonWizardBindings.postRender)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-knowledge-base:space-kb-web-resource', location = 'soy/space.soy' */
// This file was automatically generated from space.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.SpaceBlueprints == 'undefined') { Confluence.SpaceBlueprints = {}; }
if (typeof Confluence.SpaceBlueprints.KnowledgeBase == 'undefined') { Confluence.SpaceBlueprints.KnowledgeBase = {}; }


Confluence.SpaceBlueprints.KnowledgeBase.dialogForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="kb-space-form" class="common-space-form aui">');
  Confluence.Templates.Blueprints.CreateSpace.createSpaceFormFields({showSpacePermission: false, fieldErrors: opt_data.fieldErrors, name: opt_data.name, spaceKey: opt_data.spaceKey}, output);
  output.append('<fieldset><div class="field-group"><label for="kb-space-desc">', soy.$$escapeHtml("Description"), '</label><textarea id="kb-space-desc" class="textarea long-field" rows="3" type="text" name="description" placeholder="', soy.$$escapeHtml("What is this knowledge base for?"), '"></textarea></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.SpaceBlueprints.KnowledgeBase.livesearchMacro = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:structured-macro ac:name="livesearch"><ac:parameter ac:name="additional">page excerpt</ac:parameter><ac:parameter ac:name="placeholder">', soy.$$escapeHtml("Search for a solution"), '</ac:parameter>', (opt_data.spaceKey) ? '<ac:parameter ac:name="spaceKey"><ri:space ri:space-key="' + soy.$$escapeHtml(opt_data.spaceKey) + '"/></ac:parameter>' : '', '<ac:parameter ac:name="type">page</ac:parameter><ac:parameter ac:name="size">large</ac:parameter></ac:structured-macro>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:label-picker', location = '/js/label-picker.js' */
(function(d,a,b){var f=/[:;,\.\?&\[\(\)#\^\*@!<>\]]/g;var c=function(i){var j=a.uniq(i.match(f));return j.join(" ")};var h=function(i){var j=a.map(i.contentNameMatches[0],function(k){return{id:k.name,text:k.name}});return a.sortBy(j,function(k){return k.text.toLowerCase()})};var e=function(i){return function(j){return d.extend({query:j},i)}};var g={placeholder:"Add labels",noMatches:this.placeholder,multiple:true,minimumInputLength:1,maximumSelectionSize:20,tokenSeparators:[" ",","],formatInputTooShort:function(j,i){return "Start typing to search for a label"},formatSelectionTooBig:function(i){return AJS.format("You can only input {0} labels",i)},formatResult:function(i){return Confluence.UI.Components.LabelPicker.templates.labelResult({label:{labelName:i.text,isNew:i.isNew}})},formatNoMatches:function(j){var i=c(j);if(i){return Confluence.UI.Components.LabelPicker.templates.labelInvalid({inputValue:j,invalidCharacters:i})}return this.noMatches},createSearchChoice:function(j){if(!j){return null}var i=c(j);if(i){return null}return{id:j,text:j,isNew:true}},ajax:{data:e(),dataType:"json",url:Confluence.getContextPath()+"/labels/autocompletelabel.action",results:function(i){return{results:h(i)}},quietMillis:300},dropdownCssClass:"labels-dropdown",containerCssClass:"labels-autocomplete",initSelection:function(i,l){var k=i.val().split(",");var j=a.map(k,function(m){return{id:m,text:m}});l(j)}};b.build=function(j){var i=d.extend({},g,j);if(j&&j.queryOpts){i.ajax.data=e(j.queryOpts);delete i.queryOpts}return i}}(AJS.$,_,window.Confluence.UI.Components.LabelPicker));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:label-picker', location = '/soy/label-picker.soy' */
// This file was automatically generated from label-picker.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.UI == 'undefined') { Confluence.UI = {}; }
if (typeof Confluence.UI.Components == 'undefined') { Confluence.UI.Components = {}; }
if (typeof Confluence.UI.Components.LabelPicker == 'undefined') { Confluence.UI.Components.LabelPicker = {}; }
if (typeof Confluence.UI.Components.LabelPicker.templates == 'undefined') { Confluence.UI.Components.LabelPicker.templates = {}; }


Confluence.UI.Components.LabelPicker.templates.labelResult = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.label.isNew) ? soy.$$escapeHtml(AJS.format("\x22{0}\x22 - add a new label",opt_data.label.labelName)) : soy.$$escapeHtml(opt_data.label.labelName));
  return opt_sb ? '' : output.toString();
};


Confluence.UI.Components.LabelPicker.templates.labelInvalid = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var inputValueHtml__soy9 = new soy.StringBuilder('<b>', soy.$$escapeHtml(opt_data.inputValue), '</b>');
  inputValueHtml__soy9 = inputValueHtml__soy9.toString();
  var invalidCharactersHtml__soy13 = new soy.StringBuilder('<b>', soy.$$escapeHtml(opt_data.invalidCharacters), '</b>');
  invalidCharactersHtml__soy13 = invalidCharactersHtml__soy13.toString();
  output.append(AJS.format("{0} contains invalid characters {1}",inputValueHtml__soy9,invalidCharactersHtml__soy13));
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-knowledge-base:kb-article-resources', location = 'soy/kb-articles.soy' */
// This file was automatically generated from kb-articles.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Plugin == 'undefined') { Confluence.Blueprints.Plugin = {}; }
if (typeof Confluence.Blueprints.Plugin.KnowledgeBaseArticle == 'undefined') { Confluence.Blueprints.Plugin.KnowledgeBaseArticle = {}; }


Confluence.Blueprints.Plugin.KnowledgeBaseArticle.wizardPage = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="kb-article-wizard-page-form" class="aui"><fieldset><div class="field-group"><label for="kb-article-title">', soy.$$escapeHtml("Name"), '<span class="aui-icon icon-required">', soy.$$escapeHtml("$WIZARD_FORM_FIELD_REQUIRED_I18N"), '</span></label><input id="kb-article-title" class="text  long-field" type="text" name="title" title="title" placeholder="', soy.$$escapeHtml("Title of your article."), '" maxlength="255"><div class="error"></div></div><div class="field-group"><label>', soy.$$escapeHtml("Labels"), '</label><input id="kb-article-labels" class="text select2-input long-field" type="text" name="labelsString" title="labelsString" placeholder="', soy.$$escapeHtml("Topics this article covers (e.g. \x22printer\x22)."), '"><div class="error"></div></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Plugin.KnowledgeBaseArticle.contentbylabelMacro = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:structured-macro ac:name="contentbylabel"><ac:parameter ac:name="showLabels">false</ac:parameter><ac:parameter ac:name="max">5</ac:parameter><ac:parameter ac:name="sort">modified</ac:parameter><ac:parameter ac:name="reverse">true</ac:parameter><ac:parameter ac:name="labels">', soy.$$escapeHtml(opt_data.labels), '</ac:parameter><ac:parameter ac:name="showSpace">false</ac:parameter><ac:parameter ac:name="spaces"><ri:space ri:space-key="', soy.$$escapeHtml(opt_data.spaceKey), '" /></ac:parameter><ac:parameter ac:name="type">page</ac:parameter></ac:structured-macro>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Plugin.KnowledgeBaseArticle.jiraIssuesMacro = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:structured-macro ac:name="jira"><ac:parameter ac:name="key">', soy.$$escapeHtml(opt_data.jiraIssueKey), '</ac:parameter><ac:parameter ac:name="serverId">', soy.$$escapeHtml(opt_data.jiraServerId), '</ac:parameter></ac:structured-macro>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-knowledge-base:kb-article-resources', location = 'js/kb-articles-dialog-wizard.js' */
AJS.toInit(function(c){function a(i,g){var h=g.$container;var f=c("#kb-article-labels",h);f.auiSelect2(Confluence.UI.Components.LabelPicker.build({separator:" ",queryOpts:{spaceKey:g.wizardData.spaceKey}}))}function d(j,h){var i=j,e=i.find("#kb-article-title"),g=c.trim(e.val()),f;i.find(".error").html("");if(!g){f="Title is required."}else{if(!Confluence.Blueprint.canCreatePage(h,g)){f="A page with this name already exists."}}if(f){e.focus().siblings(".error").html(f);return false}return true}function b(g,f){return d(f.$container,f.wizardData.spaceKey)}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-knowledge-base:kb-how-to-item",function(e){e.on("post-render.kb-how-to-wizard",a);e.on("submit.kb-how-to-wizard",b)});Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-knowledge-base:kb-troubleshooting-item",function(e){e.on("post-render.kb-troubleshooting-wizard",a);e.on("submit.kb-troubleshooting-wizard",b)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:common-template-resources', location = 'com/atlassian/confluence/plugins/blueprint/common/soy/common-templates.soy' */
// This file was automatically generated from common-templates.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Common == 'undefined') { Confluence.Blueprints.Common = {}; }
if (typeof Confluence.Blueprints.Common.Index == 'undefined') { Confluence.Blueprints.Common.Index = {}; }


Confluence.Blueprints.Common.Index.detailsSummaryMacro = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:macro ac:name="detailssummary"><ac:parameter ac:name="label">', soy.$$escapeHtml(opt_data.label), '</ac:parameter><ac:parameter ac:name="spaces">', soy.$$escapeHtml(opt_data.spaces), '</ac:parameter><ac:parameter ac:name="firstcolumn">', soy.$$escapeHtml(opt_data.firstcolumn), '</ac:parameter><ac:parameter ac:name="headings">', soy.$$escapeHtml(opt_data.headings), '</ac:parameter><ac:parameter ac:name="blankTitle">', soy.$$escapeHtml(opt_data.blankTitle), '</ac:parameter><ac:parameter ac:name="blankDescription">', soy.$$escapeHtml(opt_data.blankDescription), '</ac:parameter><ac:parameter ac:name="contentBlueprintId">', soy.$$escapeHtml(opt_data.contentBlueprintId), '</ac:parameter><ac:parameter ac:name="blueprintModuleCompleteKey">', soy.$$escapeHtml(opt_data.blueprintModuleCompleteKey), '</ac:parameter><ac:parameter ac:name="createButtonLabel">', soy.$$escapeHtml(opt_data.createButtonLabel), '</ac:parameter></ac:macro>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Common.Index.createFromTemplateMacro = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:macro ac:name="create-from-template"><ac:parameter ac:name="blueprintModuleCompleteKey">', soy.$$escapeHtml(opt_data.moduleKey), '</ac:parameter><ac:parameter ac:name="buttonLabel">', soy.$$escapeHtml(opt_data.buttonLabel), '</ac:parameter><ac:parameter ac:name="spaceKey">', soy.$$escapeHtml(opt_data.spaceKey), '</ac:parameter><ac:parameter ac:name="templateName">', soy.$$escapeHtml(opt_data.templateName), '</ac:parameter></ac:macro>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:file-list-resources', location = 'com/atlassian/confluence/plugins/filelist/soy/templates.soy' */
// This file was automatically generated from templates.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.FileList == 'undefined') { Confluence.Templates.FileList = {}; }


Confluence.Templates.FileList.dialogForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="file-list-form" class="aui"><fieldset><div class="field-group"><label for="file-list-page-title">', soy.$$escapeHtml("Name"), '<span class="aui-icon icon-required"> required</span></label><input id="file-list-page-title" class="text long-field" type="text" name="title" placeholder="', soy.$$escapeHtml("Title of your file list"), '" maxlength="255"><div class="error"></div></div><div class="field-group"><label for="file-list-page-description">', soy.$$escapeHtml("Description"), '</label><textarea id="file-list-page-description" class="textarea long-field" name="description" rows="6" placeholder="', soy.$$escapeHtml("Description which will appear at the top of file list"), '"></textarea></div><div class="field-group"><label for="file-list-restrictions">', soy.$$escapeHtml("Restrictions"), '</label><input id="file-list-restrictions" class="text long-field autocomplete-multiuser" type="text" name="viewPermissionsUsers" placeholder="', soy.$$escapeHtml("Restrict to users"), '"></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:file-list-resources', location = 'com/atlassian/confluence/plugins/filelist/js/create-file-list-listener.js' */
(function(b){function c(h,g){var d=h.find("#file-list-page-title"),f=b.trim(d.val()),e;if(!f){e="Name is required."}else{if(!Confluence.Blueprint.canCreatePage(g,f)){e="A page with this name already exists."}}if(e){d.focus().siblings(".error").html(e);return false}return true}function a(d,e){return c(e.$container,e.wizardData.spaceKey)}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-business-blueprints:file-list-item",function(d){d.on("submit.file-list-page1",a)})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:meeting-notes-resources', location = 'com/atlassian/confluence/plugins/meetingnotes/soy/how-to.soy' */
// This file was automatically generated from how-to.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Meeting == 'undefined') { Confluence.Blueprints.Meeting = {}; }
if (typeof Confluence.Blueprints.Meeting.Notes == 'undefined') { Confluence.Blueprints.Meeting.Notes = {}; }


Confluence.Blueprints.Meeting.Notes.howTo = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<h1>', soy.$$escapeHtml("With meeting notes you can..."), '</h1><ol class="howto-steps"><li class="howto-step"><div><h3>', soy.$$escapeHtml("Crowd-source your agenda"), '</h3><p>', soy.$$escapeHtml("Distribute an agenda and keep meetings focused."), '</p></div></li><li class="howto-step"><div><h3>', soy.$$escapeHtml("Capture meeting minutes"), '</h3><p>', soy.$$escapeHtml("Take notes and make them available to everyone."), '</p></div></li><li class="howto-step"><div><h3>', soy.$$escapeHtml("Create and assign tasks"), '</h3><p>', soy.$$escapeHtml("Assign action items for attendees to work on afterward."), '</p></div></li></ol>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:meeting-notes-resources', location = 'com/atlassian/confluence/plugins/meetingnotes/soy/user-mention.soy' */
// This file was automatically generated from user-mention.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Meeting == 'undefined') { Confluence.Templates.Meeting = {}; }
if (typeof Confluence.Templates.Meeting.Notes == 'undefined') { Confluence.Templates.Meeting.Notes = {}; }


Confluence.Templates.Meeting.Notes.userMention = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.username) ? '<li><p><ac:link><ri:user ri:username="' + soy.$$escapeHtml(opt_data.username) + '" /></ac:link></p></li><li><p><ac:placeholder ac:type="mention">' + soy.$$escapeHtml("@mention a person to add them as an attendee and they will be notified.") + '</ac:placeholder></p></li>' : '<li><p><ac:placeholder ac:type="mention">' + soy.$$escapeHtml("@mention a person to add them as an attendee and they will be notified.") + '</ac:placeholder></p></li>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:decisions-resources', location = 'com/atlassian/confluence/plugins/decisions/soy/decisions-templates.soy' */
// This file was automatically generated from decisions-templates.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Decisions == 'undefined') { Confluence.Blueprints.Decisions = {}; }


Confluence.Blueprints.Decisions.dialogForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="decisions-form" class="aui"><fieldset><div class="field-group"><label for="decisions-status">', soy.$$escapeHtml("Status"), '</label><select class="select long-field" id="decisions-status" name="status"><option value="GREY">', soy.$$escapeHtml("Not started"), '</option><option value="YELLOW">', soy.$$escapeHtml("In progress"), '</option><option value="GREEN">', soy.$$escapeHtml("Decided"), '</option></select></div><div class="field-group"><label for="decisions-page-title">', soy.$$escapeHtml("Decision"), '<span class="aui-icon icon-required"> required</span></label><input id="decisions-page-title" class="text long-field" type="text" name="title" placeholder="', soy.$$escapeHtml("What are you deciding?"), '" maxlength="255"><div class="error"></div></div><div class="field-group"><label for="decisions-owner">', soy.$$escapeHtml("Owner"), '</label><input id="decisions-owner" type="text" class="text long-field autocomplete-multiuser" name="owner" placeholder="', soy.$$escapeHtml("Who should make the final decision?"), '" data-autofill-user="true"></div><div class="field-group"><label for="decisions-stakeholders">', soy.$$escapeHtml("Stakeholders"), '</label><input id="decisions-stakeholders" class="text long-field autocomplete-multiuser" type="text" name="stakeholders" placeholder="', soy.$$escapeHtml("Who needs to help make this decision?"), '"></div><div class="field-group"><label for="decisions-due-date">', soy.$$escapeHtml("Due date"), '</label><input id="decisions-due-date" class="datepicker-field date-field text" type="text" name="due-date" size="10" autocomplete="off"></div><div class="field-group"><label for="decisions-background">', soy.$$escapeHtml("Background"), '</label><textarea id="decisions-background" class="textarea long-field" rows="3" name="background" placeholder="', soy.$$escapeHtml("What details are important in making this decision?"), '"></textarea></div><div class="field-group"><label for="decisions-final-decision">', soy.$$escapeHtml("Outcome"), '</label><textarea id="decisions-final-decision" class="textarea long-field" rows="3" name="final-decision" placeholder="', soy.$$escapeHtml("What did you decide?"), '"></textarea></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Decisions.mentionXml = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var nameList35 = opt_data.names;
  var nameListLen35 = nameList35.length;
  for (var nameIndex35 = 0; nameIndex35 < nameListLen35; nameIndex35++) {
    var nameData35 = nameList35[nameIndex35];
    output.append('<ac:link><ri:user ri:username="', soy.$$escapeHtml(nameData35), '" /></ac:link>&nbsp;');
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Decisions.mentionsPlaceholder = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:placeholder ac:type="mention">', soy.$$escapeHtml(opt_data.placeholderText), '</ac:placeholder>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Decisions.placeholder = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:placeholder>', soy.$$escapeHtml(opt_data.placeholderText), '</ac:placeholder>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Decisions.statusTemplate = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:macro ac:name="status"><ac:parameter ac:name="title">', soy.$$escapeHtml(opt_data.status), '</ac:parameter><ac:parameter ac:name="colour">', soy.$$escapeHtml(opt_data.statusColour), '</ac:parameter></ac:macro>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:decisions-resources', location = 'com/atlassian/confluence/plugins/decisions/js/create-decisions-listener.js' */
(function(c){function d(i,h){var e=i.find("#decisions-page-title"),g=c.trim(e.val()),f;if(!g){f="Decision is required."}else{if(!Confluence.Blueprint.canCreatePage(h,g)){f="A page with this name already exists."}}if(f){e.focus().siblings(".error").html(f);return false}return true}function a(e,f){return d(f.$container,f.wizardData.spaceKey)}function b(e,f){c("#decisions-due-date").datepicker({dateFormat:"yy-mm-dd"});c("#decisions-status").on("change",function(){var h=c("#decisions-final-decision");var g=c("label[for=decisions-final-decision]");if(c(this).find(":selected").val()=="GREEN"){h.css({display:"inline"});g.css({display:"inline"})}else{h.css({display:"none"});g.css({display:"none"})}})}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-business-blueprints:decisions-blueprint-item",function(e){e.on("post-render.decisions-page1",b);e.on("submit.decisions-page1",a)})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-resources', location = 'com/atlassian/confluence/plugins/sharelinks/soy/sharelinks-templates.soy' */
// This file was automatically generated from sharelinks-templates.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Sharelinks == 'undefined') { Confluence.Blueprints.Sharelinks = {}; }


Confluence.Blueprints.Sharelinks.dialogForm = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<form action="#" method="post" id="sharelinks-form" class="aui"><fieldset><div class="field-group"><label for="sharelinks-url">', soy.$$escapeHtml("Link"), '<span class="aui-icon icon-required"> required</span></label><input id="sharelinks-url" class="text long-field" type="text" name="url" placeholder="', soy.$$escapeHtml("Paste a link to any website"), '"/><div class="error"></div></div><div class="field-group"><label for="sharelinks-title">', soy.$$escapeHtml("Title"), '<span class="aui-icon icon-required"> required</span></label><input id="sharelinks-title" class="text long-field" type="text" name="title" title="title" placeholder="', soy.$$escapeHtml("Title of the page"), '" maxlength="255"><div class="error"></div></div><div class="field-group"><label for="sharelinks-label">', soy.$$escapeHtml("Labels"), '</label><input id="sharelinks-label" class="text select2-input long-field" type="text" name="label" placeholder="', soy.$$escapeHtml("Suggest a topic"), '" /></div><div class="field-group"><label for="sharelinks-sharewith">', soy.$$escapeHtml("Share with"), '</label><input id="sharelinks-sharewith" class="text long-field autocomplete-multiuser" type="text" name="sharewith" placeholder="', soy.$$escapeHtml("Share this page with users"), '"/></div><div class="field-group"><label for="sharelinks-comment">', soy.$$escapeHtml("Comment"), '</label><textarea id="sharelinks-comment" class="textarea long-field" rows="4" type="text" name="comment" placeholder="', soy.$$escapeHtml("Share your thoughts about this link"), '"></textarea></div></fieldset></form>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.previewLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="sharelinks-preview">');
  if (opt_data.linkMetaData.title) {
    output.append('<h3 class="sharelinks-preview-title">', soy.$$escapeHtml(opt_data.linkMetaData.title), '</h3>');
    if (opt_data.linkMetaData.imageURL) {
      output.append('<div class="sharelinks-preview-image"><img src="', soy.$$escapeHtml(opt_data.linkMetaData.imageURL), '"/></div>');
    } else {
      var noImagePreviewContent__soy37 = new soy.StringBuilder();
      Confluence.Blueprints.Sharelinks.noImagePreview(null, noImagePreviewContent__soy37);
      noImagePreviewContent__soy37 = noImagePreviewContent__soy37.toString();
      output.append(noImagePreviewContent__soy37);
    }
    output.append((opt_data.linkMetaData.description) ? '<p>' + soy.$$escapeHtml(opt_data.linkMetaData.description) + '</p>' : '');
  } else {
    var previewUnavailableContent__soy47 = new soy.StringBuilder();
    Confluence.Blueprints.Sharelinks.previewUnavailable(null, previewUnavailableContent__soy47);
    previewUnavailableContent__soy47 = previewUnavailableContent__soy47.toString();
    output.append(previewUnavailableContent__soy47);
  }
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.previewVideoLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="sharelinks-preview"><h3 class="sharelinks-preview-title">', soy.$$escapeHtml(opt_data.linkMetaData.title), '</h3><div class="sharelinks-preview-video">');
  if (opt_data.linkMetaData.imageURL) {
    output.append('<span class="sharelinks-preview-image"><img src="', soy.$$escapeHtml(opt_data.linkMetaData.imageURL), '"/><span class="sharelinks-preview-camera-icon sharelinks-camera-with-image"></span></span>');
  } else {
    output.append('<div>');
    var noImagePreviewContent__soy63 = new soy.StringBuilder();
    Confluence.Blueprints.Sharelinks.noImagePreview(null, noImagePreviewContent__soy63);
    noImagePreviewContent__soy63 = noImagePreviewContent__soy63.toString();
    output.append(noImagePreviewContent__soy63, '<span class="sharelinks-preview-camera-icon sharelinks-camera-with-no-image"></span></div>');
  }
  output.append('</div>', (opt_data.linkMetaData.description) ? '<p>' + soy.$$escapeHtml(opt_data.linkMetaData.description) + '</p>' : '', '</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.previewLoading = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="sharelinks-preview-loading"><span class="aui-icon aui-icon-wait"></span>&nbsp;', soy.$$escapeHtml("Loading preview\u2026"), '</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.metaDataHtml = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="sharelinks-link-meta-data"><ac:macro ac:name="panel"><ac:rich-text-body>', (opt_data.linkMetaData.imageURL) ? '<h3><ac:image ac:align="right"><ri:url ri:value=\'' + soy.$$escapeHtml(opt_data.linkMetaData.imageURL) + '\' /></ac:image></h3>' : '', '<p><ac:image ac:width=\'16\'><ri:url ri:value="', soy.$$escapeHtml(opt_data.faviconURL), '" /></ac:image>&nbsp;<a href="', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '">', soy.$$escapeHtml(opt_data.linkMetaData.excerptedURL), '</a></p>', (opt_data.linkMetaData.description) ? '<blockquote><p>' + soy.$$escapeHtml(opt_data.descriptionMessage) + '</p></blockquote>' : '<p style="text-align: left;"><span style="color: rgb(128,128,128);"><em>' + soy.$$escapeHtml(opt_data.descriptionMessage) + '</em></span></p>', '<p><strong><a href="', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '">', soy.$$escapeHtml("Open link"), '</a></strong></p></ac:rich-text-body></ac:macro></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.previewError = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="sharelinks-preview">');
  var previewUnavailableContent__soy109 = new soy.StringBuilder();
  Confluence.Blueprints.Sharelinks.previewUnavailable(null, previewUnavailableContent__soy109);
  previewUnavailableContent__soy109 = previewUnavailableContent__soy109.toString();
  output.append(previewUnavailableContent__soy109, '</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.videoMetaDataHtml = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ac:macro ac:name="panel"><ac:rich-text-body><ac:macro ac:name="section"><ac:rich-text-body><ac:macro ac:name="column"><ac:parameter ac:name="width">50%</ac:parameter><ac:rich-text-body><p><ac:image ac:width=\'16\'><ri:url ri:value="', soy.$$escapeHtml(opt_data.faviconURL), '" /></ac:image>&nbsp;<a href="', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '">', soy.$$escapeHtml(opt_data.linkMetaData.excerptedURL), '</a></p>', (opt_data.linkMetaData.description) ? '<blockquote><p>' + soy.$$escapeHtml(opt_data.linkMetaData.description) + '</p></blockquote>' : '', '<p><strong><a href="', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '">', soy.$$escapeHtml("Open link"), '</a></strong></p></ac:rich-text-body></ac:macro><ac:macro ac:name="column"><ac:parameter ac:name="width">50%</ac:parameter><ac:rich-text-body><p>', (opt_data.isSupportedMediaDomain) ? '<ac:macro ac:name="widget"><ac:parameter ac:name="url">' + soy.$$escapeHtml(opt_data.linkMetaData.sourceURL) + '</ac:parameter><ac:parameter ac:name="width">350</ac:parameter><ac:parameter ac:name="height">240</ac:parameter></ac:macro>' : '<ac:image ac:width="300"><ri:url ri:value="' + soy.$$escapeHtml(opt_data.linkMetaData.imageURL) + '" /></ac:image>', '</p></ac:rich-text-body></ac:macro></ac:rich-text-body></ac:macro></ac:rich-text-body></ac:macro>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.twitterMetaDataHtml = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.linkMetaData.description) {
    output.append('<div class="sharelinks-twitter-content"><p><ac:image ac:width=\'16\'><ri:url ri:value="', soy.$$escapeHtml(opt_data.faviconURL), '" /></ac:image>&nbsp;<a href="', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '">', soy.$$escapeHtml(opt_data.linkMetaData.excerptedURL), '</a></p><p><ac:macro ac:name="widget"><ac:parameter ac:name="url">', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '</ac:parameter></ac:macro></p><p><strong><a href="', soy.$$escapeHtml(opt_data.linkMetaData.sourceURL), '">', soy.$$escapeHtml("Open link"), '</a></strong></p></div>');
  } else {
    Confluence.Blueprints.Sharelinks.metaDataHtml(opt_data, output);
  }
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.bookmarkletGuideOnWizard = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var bookmarkletLinkParam__soy163 = new soy.StringBuilder();
  Confluence.Blueprints.SharelinksUrlMacro.bookmarkletLink(opt_data, bookmarkletLinkParam__soy163);
  bookmarkletLinkParam__soy163 = bookmarkletLinkParam__soy163.toString();
  output.append('<p>', bookmarkletLinkParam__soy163, '</p><p>', soy.$$escapeHtml("It will appear like this in your browser."), '</p><div class="bookmarklet-guide-picture"></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.bookmarkletGuide = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var bookmarkletMacroParam__soy173 = new soy.StringBuilder('<ac:macro ac:name="sharelinks-urlmacro"/>');
  bookmarkletMacroParam__soy173 = bookmarkletMacroParam__soy173.toString();
  output.append('<ac:macro ac:name="info"><ac:parameter ac:name="icon">false</ac:parameter><ac:rich-text-body><p><ac:emoticon ac:name="information" />&nbsp;', AJS.format("Tip: share a link from anywhere by dragging this button \u2192 {0} to your browser bookmarks toolbar. Once added to your toolbar, click it to share links with your team.",bookmarkletMacroParam__soy173), '</p></ac:rich-text-body></ac:macro>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.noImagePreview = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p class="image-unavailable"><span class="no-image-picture"></span>', soy.$$escapeHtml("No image available"), '</p>');
  return opt_sb ? '' : output.toString();
};


Confluence.Blueprints.Sharelinks.previewUnavailable = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<p class="link-unavailable"><span class="preview-unavailable-picture"></span>', soy.$$escapeHtml("Link preview unavailable"), '</p>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-resources', location = 'com/atlassian/confluence/plugins/sharelinks/js/sharelinks-creation-wizard.js' */
(function(i){var d=false;function g(s,r){var q=false;if(k(s,!q)){q=true}if(f(s,r,!q)){q=true}return !q}function k(u,q){var t=u.find("#sharelinks-url");var s=i.trim(t.val());var r="";if(!s){r="URL is required"}else{if(d){r="URL syntax is invalid"}}return j(t,r,q)}function f(w,u,s){var r=w.find("#sharelinks-title");var v=i.trim(r.val());var t="";if(!v){t="Title is required"}else{if(!Confluence.Blueprint.canCreatePage(u,v)){t="A page with this name already exists";var q=Confluence.Blueprints.Sharelinks.Analytics.errorTypes.value.duplicatedPage;Confluence.Blueprints.Sharelinks.Analytics.triggerErrorTypes(q)}}return j(r,t,s)}function j(s,r,q){s.siblings(".error").html(r);if(r&&q){s.focus()}return r}var p;function a(u,v){var s=g(v.$container,v.wizardData.spaceKey);if(s){var r=Confluence.Blueprints.Sharelinks.Analytics.submitData.value.noComment;var x=i("#sharelinks-comment").val();x=i.trim(x);if(x){r=Confluence.Blueprints.Sharelinks.Analytics.submitData.value.comment}Confluence.Blueprints.Sharelinks.Analytics.triggerSubmitData(r);var q=Confluence.Blueprints.Sharelinks.Analytics.submitData.value.noEditTitle;if(p!==i("#sharelinks-title").val()){q=Confluence.Blueprints.Sharelinks.Analytics.submitData.value.editTitle}Confluence.Blueprints.Sharelinks.Analytics.triggerSubmitData(q);var w=Confluence.Blueprints.Sharelinks.Analytics.submitData.value.noShare;var t=i("#sharelinks-sharewith").val();t=i.trim(t);if(t){w=Confluence.Blueprints.Sharelinks.Analytics.submitData.value.share}Confluence.Blueprints.Sharelinks.Analytics.triggerSubmitData(w)}v.wizardData.parentPageId=-1;return s}var e;function h(s,t){e="";i("#sharelinks-url").bind("paste",function(){setTimeout(function(){l(t.$container,t.wizardData.spaceKey,true)},0)});i("#sharelinks-url").change(function(){l(t.$container,t.wizardData.spaceKey,false)});i("#sharelinks-title").change(function(){if(i("#sharelinks-title").siblings(".error").html!=""){f(t.$container,t.wizardData.spaceKey,false)}});var u=i(".dialog-wizard-page-description,.create-dialog-page-description");var q=AJS.Meta.get("base-url")+"/plugins/sharelinksbookmarklet/bookmarklet.action";var r=Confluence.Blueprints.Sharelinks.bookmarkletGuideOnWizard({bookmarkletActionURL:q});i(r).appendTo(u);Confluence.Blueprints.Sharelinks.autocompleteMultiLabel.build(i("#sharelinks-label"));i(".create-dialog-sharelinks-page1 .sharelinks-urlmacro-button").click(function(){alert("Drag this link to your toolbar");return false})}function c(q,r){i.ajax({type:"get",dataType:"json",url:Confluence.getContextPath()+"/rest/sharelinks/1.0/can-create-comment",data:{spaceKey:r.wizardData.spaceKey},success:function(t){if(!t){var s=i("#sharelinks-comment");s.attr("disabled","disabled");s.attr("placeholder","Sorry, you don\'t have permission to add comments in this space")}}})}Confluence.Blueprint.setWizard("com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-blueprint-item",function(q){q.on("post-render.sharelinks-page1",h);q.on("post-render.sharelinks-page1",c);q.on("submit.sharelinks-page1",a)});function b(u){var y=255;var q=180;var t=o(u.title,y);var s=i("#sharelinks-title");s.val(t);s.removeClass("placeholded");var x=i.extend({},u);x.title=o(x.title,q);var w=Confluence.Blueprints.Sharelinks.Analytics.linkTypes.value.noContent;var r;if(u.videoURL){r=Confluence.Blueprints.Sharelinks.previewVideoLink({linkMetaData:x});w=Confluence.Blueprints.Sharelinks.Analytics.linkTypes.value.video}else{r=Confluence.Blueprints.Sharelinks.previewLink({linkMetaData:x});if(u.imageURL){w=Confluence.Blueprints.Sharelinks.Analytics.linkTypes.value.image}else{if(u.title){w=Confluence.Blueprints.Sharelinks.Analytics.linkTypes.value.noVideoImage}}}var v=i(".create-dialog-page-description,.dialog-wizard-page-description");v.empty();i(r).appendTo(v);Confluence.Blueprints.Sharelinks.Analytics.triggerLinkTypes(w)}function o(r,q){if(null!=r&&q<r.length){r=r.substring(0,q-1)+"\u2026"}return r}function m(r,q){r.attr("disabled","disabled");q.attr("disabled","disabled")}function n(r,q){r.removeAttr("disabled");q.removeAttr("disabled")}function l(z,w,s){var r=i("#sharelinks-url"),v=r.val(),q=i("#sharelinks-title");v=i.trim(v);if(v){var x=Confluence.getContextPath()+"/rest/sharelinks/1.0/link";if(v!==e){e=v;var t=i(".create-dialog-page-description,.dialog-wizard-page-description").empty();var y=Confluence.Blueprints.Sharelinks.previewLoading();var A=i(y).appendTo(t);m(r,q);i.ajax({type:"get",url:x,data:{url:v},success:function(B,C){A.remove();b(B);d=false;g(z,w);n(r,q)},error:function(E,B,D){n(r,q);if(400==E.status){A.remove();d=true;k(z,false)}else{A.remove();var C=Confluence.Blueprints.Sharelinks.previewError();i(C).appendTo(t);d=false;g(z,w)}}});var u;if(s){u=Confluence.Blueprints.Sharelinks.Analytics.inputTypes.value.pasteUrl}else{u=Confluence.Blueprints.Sharelinks.Analytics.inputTypes.value.typeUrl}Confluence.Blueprints.Sharelinks.Analytics.triggerInputTypes(u)}}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-resources', location = 'com/atlassian/confluence/plugins/sharelinks/js/sharelinks-analytics.js' */
Confluence.Blueprints.Sharelinks.Analytics={inputTypes:{name:"blueprints.sharelinks.input",value:{pasteUrl:{type:"paste-url"},typeUrl:{type:"type-url"}}},linkTypes:{name:"blueprints.sharelinks.link",value:{video:{link:"video"},image:{link:"image"},noVideoImage:{link:"no-video-image"},noContent:{link:"no-content"}}},errorTypes:{name:"blueprints.sharelinks.error",value:{duplicatedPage:{error:"page-duplicated"}}},submitData:{name:"blueprints.sharelinks.submit",value:{editTitle:{submit:"edit-title"},noEditTitle:{submit:"no-edit-title"},comment:{submit:"comment"},noComment:{submit:"no-comment"},share:{submit:"share"},noShare:{submit:"no-share"}}},triggerInputTypes:function(a){AJS.EventQueue=AJS.EventQueue||[];AJS.EventQueue.push({name:Confluence.Blueprints.Sharelinks.Analytics.inputTypes.name,properties:a})},triggerLinkTypes:function(a){AJS.EventQueue=AJS.EventQueue||[];AJS.EventQueue.push({name:Confluence.Blueprints.Sharelinks.Analytics.linkTypes.name,properties:a})},triggerErrorTypes:function(a){AJS.EventQueue=AJS.EventQueue||[];AJS.EventQueue.push({name:Confluence.Blueprints.Sharelinks.Analytics.errorTypes.name,properties:a})},triggerSubmitData:function(a){AJS.EventQueue=AJS.EventQueue||[];AJS.EventQueue.push({name:Confluence.Blueprints.Sharelinks.Analytics.submitData.name,properties:a})}};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-resources', location = 'com/atlassian/confluence/plugins/sharelinks/soy/sharelinks-label.soy' */
// This file was automatically generated from sharelinks-label.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Sharelinks == 'undefined') { Confluence.Blueprints.Sharelinks = {}; }


Confluence.Blueprints.Sharelinks.labelResult = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append((opt_data.label.isNew) ? soy.$$escapeHtml(AJS.format("\x22{0}\x22 - add a new topic",opt_data.label.labelName)) : soy.$$escapeHtml(opt_data.label.labelName));
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-resources', location = 'com/atlassian/confluence/plugins/sharelinks/js/sharelinks-label.js' */
Confluence.Blueprints.Sharelinks.autocompleteMultiLabel=(function(a){function b(c){c.auiSelect2(Confluence.UI.Components.LabelPicker.build({formatInputTooShort:function(){return "Start typing to search for a topic"},formatResult:function(d){return Confluence.Blueprints.Sharelinks.labelResult({label:{labelName:d.text,isNew:d.isNew}})}}))}return{build:b}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:application-header-administration-cog-resource', location = 'header/cog.js' */
var NavLinks=(function(a){a.ApplicationHeader=function(b){b.Cog=(function(){var c=function(){var d=AJS.$("#system-admin-menu-content");if(d.length>0){return d}var e=AJS.$("#admin-menu-link-content");if(e.length>0){return e}return AJS.$("#bamboo\\.global\\.header-admin\\.menu")};return{getDropdown:c}}());return b}(a.ApplicationHeader||{});return a}(NavLinks||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:administration-shortcuts-resources', location = 'adminshortcuts/adminshortcuts.soy' */
// This file was automatically generated from adminshortcuts.soy.
// Please don't edit this file by hand.

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.adminshortcuts == 'undefined') { navlinks.templates.adminshortcuts = {}; }


navlinks.templates.adminshortcuts.section = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  var param5 = new soy.StringBuilder('<ul class="aui-list-truncate">');
  var linkList7 = opt_data.links;
  var linkListLen7 = linkList7.length;
  for (var linkIndex7 = 0; linkIndex7 < linkListLen7; linkIndex7++) {
    var linkData7 = linkList7[linkIndex7];
    param5.append('<li><a href="', soy.$$escapeHtml(linkData7.link), '">', soy.$$escapeHtml(linkData7.label), '</a></li>');
  }
  param5.append('</ul>');
  aui.dropdown2.section({id: 'nl-remote-admin-section', label: "Other applications", content: param5.toString()}, output);
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:administration-shortcuts-resources', location = 'adminshortcuts/adminnavlinks.js' */
var NavLinks=(function(a){a.AdminShortcuts=(function(){var c=function(){return AJS.$.ajax({url:AJS.contextPath()+"/rest/menu/latest/admin",cache:false,dataType:"json"})};var b=function(){AJS.$("#nl-remote-admin-section").on("click","a",function(){NL.trackEvent("remoteAdminItemSelected",NL.getCurrentApplication(),$(this).attr("href"))})};return{render:function(){c().done(function(e){e=_.reject(e,function(f){return f.local===true});if(e.length){var d=navlinks.templates.adminshortcuts.section({links:e});a.ApplicationHeader.Cog.getDropdown().append(d);b()}})}}}());return a}(NavLinks||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:administration-shortcuts', location = 'adminshortcuts/adminshortcuts-cdn.js' */
AJS.toInit(function(){if(AJS.DarkFeatures&&AJS.DarkFeatures.isEnabled("rotp.admin.shortcuts")){NavLinks.AdminShortcuts.render()}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-projectshortcuts', location = 'projectshortcuts/projectshortcuts.soy' */
// This file was automatically generated from projectshortcuts.soy.
// Please don't edit this file by hand.

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.projectshortcuts == 'undefined') { navlinks.templates.projectshortcuts = {}; }


navlinks.templates.projectshortcuts.dialogContent = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  if (opt_data.localShortcuts && opt_data.localShortcuts.length > 0) {
    navlinks.templates.projectshortcuts.dialogContentShortcuts({shortcuts: opt_data.localShortcuts, listClass: 'projectshortcut-links'}, output);
  }
  if (opt_data.remoteShortcuts != null) {
    if (opt_data.remoteShortcuts.length > 0) {
      output.append('<h2 class="projectshortcuts-heading">Related Links</h2>');
      navlinks.templates.projectshortcuts.dialogContentShortcuts(soy.$$augmentData(opt_data.remoteShortcuts, {shortcuts: opt_data.remoteShortcuts, listClass: 'projectshortcut-links'}), output);
    }
  } else {
    navlinks.templates.projectshortcuts.dialogLoading(null, output);
  }
  return opt_sb ? '' : output.toString();
};


navlinks.templates.projectshortcuts.headingWrapper = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="project-dialog-header-wrapper"><div class="project-header"><img class="project-img" src="', soy.$$escapeHtml(opt_data.logoUrl), '"><h2 class="dialog-title">', soy.$$escapeHtml(opt_data.title), '</h2></div><div class="project-content-wrapper">', opt_data.contentHtml, '</div></div>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.projectshortcuts.dialogContentShortcuts = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<ul', (opt_data.listClass) ? ' class="' + soy.$$escapeHtml(opt_data.listClass) + '"' : '', '>');
  var shortcutList35 = opt_data.shortcuts;
  var shortcutListLen35 = shortcutList35.length;
  for (var shortcutIndex35 = 0; shortcutIndex35 < shortcutListLen35; shortcutIndex35++) {
    var shortcutData35 = shortcutList35[shortcutIndex35];
    output.append('<li', (shortcutIndex35 == shortcutListLen35 - 1) ? ' class="last"' : '', '>');
    navlinks.templates.projectshortcuts.dialogContentShortcut(shortcutData35, output);
    output.append('</li>');
  }
  output.append('</ul>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.projectshortcuts.dialogContentShortcut = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="', soy.$$escapeHtml(opt_data.link), '"', (opt_data.tooltip) ? ' title="' + soy.$$escapeHtml(opt_data.tooltip) + '"' : '', '>', soy.$$escapeHtml(opt_data.label), '</a>');
  return opt_sb ? '' : output.toString();
};


navlinks.templates.projectshortcuts.dialogLoading = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="projectshortcuts-loading">', (opt_data != null && opt_data.text) ? soy.$$escapeHtml(opt_data.text) : '', '</div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-projectshortcuts', location = 'projectshortcuts/projectshortcuts.js' */
(function(e,g){var i,k={},m="key",b="name",j="entity-type";function f(s){var n=e(this),o=n.data(m),q=n.data(b),p=n.data(j);if(typeof o==="undefined"){return}s.preventDefault();i=new AJS.Dialog({width:600,keypressListener:function(u){if(u.which==jQuery.ui.keyCode.ESCAPE){i.remove()}},id:"project-shortcuts-dialog"}).addCancel("Close",function(){i.remove()}).addPanel("",navlinks.templates.projectshortcuts.headingWrapper({title:q,logoUrl:h(),contentHtml:navlinks.templates.projectshortcuts.dialogLoading({text:"Retrieving links…"})})).show();c(i);if(!k[o]){k[o]={entity:{title:q},localShortcuts:null,remoteShortcuts:null};d(AJS.contextPath()+"/rest/project-shortcuts/1.0/local/"+o,{entityType:p}).done(t);d(AJS.contextPath()+"/rest/project-shortcuts/1.0/remote/"+o,{entityType:p}).done(r).fail(function(){var u=i.getCurrentPanel().body.find(".project-content-wrapper");u.find(".projectshortcuts-loading").remove();AJS.messages.error(u,{body:"Could not retrieve remote project shortcuts",closeable:false});c(i)})}else{l(k[o])}function t(u){k[o].localShortcuts=u.shortcuts;l(k[o])}function r(u){k[o].remoteShortcuts=u.shortcuts;l(k[o])}}function h(){return e(".project-shortcut-dialog-trigger img").attr("src")}function l(n){if(n.localShortcuts){i.getCurrentPanel().html(navlinks.templates.projectshortcuts.headingWrapper({title:n.entity.title,logoUrl:h(),contentHtml:navlinks.templates.projectshortcuts.dialogContent(n)}));c(i)}}function a(p){var o=210;if(!p||p.length<=o){return p}var n=o;while(n>0&&p.charAt(n)!=" "){n--}if(n==0){n=o}p=p.substring(0,n);if(p.length>=n){p=p+"..."}return p}function c(n){var q=n.popup.element,p=q.find(".dialog-panel-body"),o=q.find(".dialog-components");p.height("auto");q.height(o.outerHeight()-1);e(".aui-shadow").remove()}function d(n,o){return e.ajax({url:n,cache:false,data:o,dataType:"json"})}e(document).on("click",".project-shortcut-dialog-trigger",f)}(jQuery,window.NL=(window.NL||{})));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:atlassian-ui-popup-display-controller', location = 'popups/DisplayController.js' */
AJS.Popups=AJS.Popups||{};AJS.Popups.DisplayController=function(){var c=[];var a=false;var b=false;AJS.toInit(function(){setTimeout(function(){AJS.Popups.DisplayController.render()},0)});return{request:function(d){c.push(d);if(a&&b===false){this.render()}},render:function(){c.sort(function(e,d){return e.weight-d.weight});a=true;if(c.length!==0){b=true;c[0].show()}}}}();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacemenu-resources', location = 'js/space-menu.js' */
AJS.toInit(function(a){var d=a(Confluence.Templates.BrowseSpaces.spacesLink());a("#space-directory-link").replaceWith(a(d));var b=a("#space-menu-link"),c=function(e){a("#space-menu-link-content").html(e.template);AJS.trigger("spacemenu-loaded");a("#create-space-header").click(function(){AJS.trigger("analytics",{name:"create-space-from-header"});Confluence.SpaceBlueprint.Dialog.launch();return false})};b.click(function(){if(!a("#space-menu-link-content .aui-dropdown2-section").length){a.ajax({url:Confluence.getContextPath()+"/rest/ia/1.0/spacesmenu",type:"GET",dataType:"json",cache:false,success:c})}return false});a("#space-menu-link-content").on("aui-dropdown2-show",function(){AJS.trigger("analytics",{name:"open-space-menu"})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacemenu-resources', location = 'soy/space-menu.soy' */
// This file was automatically generated from space-menu.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.BrowseSpaces == 'undefined') { Confluence.Templates.BrowseSpaces = {}; }


Confluence.Templates.BrowseSpaces.spacesLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a id="space-menu-link" class="aui-nav-link aui-dropdown2-trigger" href="#" aria-haspopup="true" aria-owns="space-menu-link-content" title="', soy.$$escapeHtml("Spaces"), '"><span class="browse">', soy.$$escapeHtml("Spaces"), '</span><span class="aui-icon-dropdown"></span></a><div id="space-menu-link-content" class="aui-dropdown2 aui-style-default aui-dropdown2-in-header" aria-hidden="false"></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:space-ia-analytics', location = 'js/space-ia-analytics.js' */
(function(d){var c=RegExp("(.+[?&])src=.+?(&.+|$)");var e;if(AJS.Confluence.Analytics&&AJS.Confluence.Analytics.setAnalyticsSource){e=AJS.Confluence.Analytics.setAnalyticsSource}else{e=function(h,i){if(b()){_.each(h,function(j){d(j).attr("href",g(d(j).attr("href"),i))})}}}function g(h,j){if(h&&(h.charAt(0)!="#")){var i=c.exec(h);if(!i){if(h.indexOf("?")>-1){h=h+"&src="+j}else{h=h+"?src="+j}}else{h=i[1]+"src="+j+i[2]}}return h}function b(){var h=d(document.getElementsByTagName("script"));var i=false;h.each(function(k,j){if(d(j).attr("src")&&d(j).attr("src").indexOf("google-analytics.com/ga.js")!=-1){i=true;return false}});return i}function f(){var i=d(".acs-side-bar a:not(.external_link a, #acs-configure-link)");e(i,"sidebar");var h=d(".quick-links-section li:not(.external_link) a");e(h,"spaceshortcut");var j=d(".ia-secondary-container a:not(.more-children-link)");if(d(".ia-secondary-container").data("tree-type")=="pages"){e(j,"contextnavchildmode")}else{if(d(".ia-secondary-container").data("tree-type")=="page-tree"){e(j,"contextnavpagetreemode")}else{e(j,"contextnav")}}}function a(h){return function(){AJS.trigger("analytics",{name:"space-ia-nav",data:{linkType:h}})}}AJS.bind("sidebar.exit-configure-mode",f);AJS.bind("sidebar.flyout-triggered",function(i,h){a("flyout-triggered."+h.flyout)()});AJS.bind("spacemenu-loaded",function(){e(d("#space-menu-link-content a"),"spacemenu")});AJS.bind("sidebar.spacetools-loaded",function(){e(d("#inline-dialog-space-tools a:not(.configure-sidebar)"),"spacetools")});AJS.bind("pagetree-children-loaded",f);AJS.toInit(function(h){h(".ia-secondary-container .more-children-link").click(a("context-nav.more-children"));f()})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.adaptavist.confluence.contentFormattingMacros:clickable-resources', location = 'js/clickable.js' */
jQuery(function(a){a(".clickable").live("click",function(c){if(a(c.target).closest("a[href]").length===0&&a(c.target).closest(".clickable").length===1){var b=a(this).attr("href")||a("a[href]:first",this).attr("href");if(b){location.href=b}}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.analytics.analytics-client:js-events', location = 'js/store-1.3.1.js' */
(function(){var l={},h=window,k=h.document,c="localStorage",n="globalStorage",d="__storejs__",g;l.disabled=false;l.set=function(e,o){};l.get=function(e){};l.remove=function(e){};l.clear=function(){};l.transact=function(e,o){var p=l.get(e);if(typeof p=="undefined"){p={}}o(p);l.set(e,p)};l.serialize=function(e){return JSON.stringify(e)};l.deserialize=function(e){if(typeof e!="string"){return undefined}return JSON.parse(e)};function b(){try{return(c in h&&h[c])}catch(e){return false}}function m(){try{return(n in h&&h[n]&&h[n][h.location.hostname])}catch(e){return false}}if(b()){g=h[c];l.set=function(e,o){if(o===undefined){return l.remove(e)}g.setItem(e,l.serialize(o))};l.get=function(e){return l.deserialize(g.getItem(e))};l.remove=function(e){g.removeItem(e)};l.clear=function(){g.clear()}}else{if(m()){g=h[n][h.location.hostname];l.set=function(e,o){if(o===undefined){return l.remove(e)}g[e]=l.serialize(o)};l.get=function(e){return l.deserialize(g[e]&&g[e].value)};l.remove=function(e){delete g[e]};l.clear=function(){for(var e in g){delete g[e]}}}else{if(k.documentElement.addBehavior){var j,f;try{f=new ActiveXObject("htmlfile");f.open();f.write('<script>document.w=window<\/script><iframe src="/favicon.ico"></frame>');f.close();j=f.w.frames[0].document;g=j.createElement("div")}catch(i){g=k.createElement("div");j=k.body}function a(e){return function(){var p=Array.prototype.slice.call(arguments,0);p.unshift(g);j.appendChild(g);g.addBehavior("#default#userData");g.load(c);var o=e.apply(l,p);j.removeChild(g);return o}}l.set=a(function(p,e,o){if(o===undefined){return l.remove(e)}p.setAttribute(e,l.serialize(o));p.save(c)});l.get=a(function(o,e){return l.deserialize(o.getAttribute(e))});l.remove=a(function(o,e){o.removeAttribute(e);o.save(c)});l.clear=a(function(q){var o=q.XMLDocument.documentElement.attributes;q.load(c);for(var p=0,e;e=o[p];p++){q.removeAttribute(e.name)}q.save(c)})}}}try{l.set(d,d);if(l.get(d)!=d){l.disabled=true}l.remove(d)}catch(i){l.disabled=true}if(typeof module!="undefined"){module.exports=l}else{if(typeof define==="function"&&define.amd){define(l)}else{this.store=l}}})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.analytics.analytics-client:js-events', location = 'js/atlassian-analytics.js' */
(function(f){var j=AJS.$.ajax;var h="atlassian-analytics";var e=typeof AJS.contextPath=="function"?AJS.contextPath():typeof AJS.Confluence!="undefined"?AJS.Confluence.getContextPath():window.contextPath!=null?window.contextPath:"";var d=null;var m=null;var c=null;var b="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(t){var s=Math.random()*16|0,q=t=="x"?s:(s&3|8);return q.toString(16)});var a=function(){var q="unknown";if(document.body.id=="jira"){q="jira"}else{if(document.body.id=="com-atlassian-confluence"){q="confluence"}}m=h+"."+q;c=m+".lock"};var o=function(){if(store.get(c)){return false}store.set(c,b);return(store.get(c)===b)};var k=function(){store.set(c,null)};var g=function(){var r=[],t,u,q,s;if(AJS.EventQueue.length==0){return}r=store.get(m)||r;for(q=0,s=AJS.EventQueue.length;q<s;++q){u=AJS.EventQueue[q];if(u.name){t={name:u.name,properties:u.properties,time:u.time||0};r.push(t)}}AJS.EventQueue.length=0;store.set(m,r)};var l=function(){var r;if(!o()){return}g();r=store.get(m);if(r&&r.length){store.remove(m);k();var s=new Date().getTime();for(var q=0;q<r.length;q++){if(r[q].time>0){r[q].timeDelta=r[q].time-s}else{r[q].timeDelta=q-r.length}delete r[q].time}d=j({type:"POST",url:e+"/rest/analytics/1.0/publish/bulk",data:JSON.stringify(r),contentType:"application/json",dataType:"json"});d.fail(function(){AJS.EventQueue.concat(r);g()})}else{k()}};var n=function(){if(d&&!(d.state()==="resolved"||d.state()==="rejected")){d.abort()}};AJS.EventQueue=AJS.EventQueue||[];var i=Array.prototype.push;AJS.EventQueue.push=function(q){q.time=new Date().getTime();i.call(AJS.EventQueue,q)};AJS.toInit(function(){a();setTimeout(l,500);setInterval(l,5000);p()});f(window).unload(function(){n();g()});AJS.Analytics={triggerPrivacyPolicySafeEvent:function(q,r){AJS.EventQueue.push({name:q,properties:r})}};AJS.bind("analytics",function(q,r){AJS.EventQueue.push({name:r.name,properties:r.data})});AJS.bind("analyticsEvent",function(q,r){AJS.EventQueue.push({name:r.name,properties:r.data})});var p=function(){if(window.location.pathname.indexOf("/secure/admin/ViewApplicationProperties")>-1){AJS.$("[data-property-id='analytics-enabled']").remove()}else{if(window.location.pathname.indexOf("/secure/admin/EditApplicationProperties")>-1){var r=AJS.$(":contains(Enable Atlassian analytics)");if(r.size()>0){var q=r[r.size()-2];if(q){q.remove()}}}}}}(AJS.$));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.analytics.analytics-client:policy-update', location = 'js/policy-update.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/js/request-access.js' */
AJS.toInit(function(e){var b=AJS.Meta.get("page-id"),c=e("#page-restricted-container"),a=AJS.Meta.get("remote-user"),d=e("#page-restricted-container button");if(c.length){e("#breadcrumbs").hide();e("#title-text.with-breadcrumbs").hide();if(d.length){AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.request.access.to.page.view",data:{pageId:b,requestAccessUser:a}})}}d.click(function(){AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.request.access.to.page",data:{pageId:b,requestAccessUser:a}});d.attr("aria-disabled","true");var f,g=e(Confluence.Request.Access.loading({}));d.replaceWith(g);e.ajax({url:Confluence.getContextPath()+"/rest/request-access/latest/page/restriction/"+b,success:function(h){f=e(Confluence.Request.Access.result({success:true,recipient:h}));c.removeClass("page-restricted");c.addClass("access-requested")},error:function(h,i){f=e(Confluence.Request.Access.result({success:false}))},complete:function(){g.replaceWith(f);Confluence.Binder.userHover()}})})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/js/grant-access.js' */
AJS.toInit(function(d){var a=AJS.Meta.get("page-id"),f=AJS.Meta.get("remote-user"),h=j("username"),e=j("userFullName");var c=e.split("+");e=c.join(" ");var g=d("#system-content-items");var k=d("#content-metadata-page-restrictions").is(":visible");if(!g.length||!k||!j("grantAccess")){return}var b=d(Confluence.Request.Access.loading());var i=AJS.InlineDialog(g,"grantAccessDialog",function(m,l,n){m.css({padding:"20px"}).html(Confluence.Grant.Access.dialog({requestAccessUsername:h,requestAccessUserFullName:e}));m.on("click",".aui-button.grant-access",function(q){q.stopPropagation();var p=m.find(".actions-result");p.replaceWith(b);AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.grant.access.to.page",data:{pageId:a,grantAccessUser:f,requestAccessUser:h}});var o="",r=true;d.ajax({url:Confluence.getContextPath()+"/rest/request-access/latest/page/restriction/"+a,type:"POST",contentType:"application/json; charset=utf-8",data:h,success:function(t,u,s){if(s.status==202){o="Access was already granted to the user."}else{o="Access was granted, a notification to the user will be sent."}},error:function(s){r=false;if(s.status==412){o="Access was granted, but there is not a mail server configured so the notification could not be sent."}else{if(s.status==502){o="Access was granted, but an unexpected error happened while sending the notification."}else{o="Sorry, there was an unexpected error while granting access."}}},complete:function(s){b.replaceWith(d(Confluence.Grant.Access.result({success:r,message:o})));setTimeout(function(){i.hide()},4000)}})});m.on("click",".aui-button.deny-access",function(o){AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.deny.access.to.page",data:{pageId:a,grantAccessUser:f,requestAccessUser:h}});i.hide()});n();return false},{offsetY:2,offsetX:0,width:350,hideDelay:null,noBind:true,hideCallback:function(){setTimeout(i.hide(),5000)}});i.show();function j(l){l=l.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");var n=new RegExp("[\\?&]"+l+"=([^&#]*)"),m=n.exec(location.search);return m==null?"":decodeURIComponent(m[1].replace(/\+/g," "))}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/templates/soy/request-access.soy' */
// This file was automatically generated from request-access.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Request == 'undefined') { Confluence.Request = {}; }
if (typeof Confluence.Request.Access == 'undefined') { Confluence.Request.Access = {}; }


Confluence.Request.Access.result = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div id="request-access">');
  if (opt_data.success) {
    var usernameLink__soy6 = new soy.StringBuilder();
    Confluence.Request.Access.usernameLink({user: opt_data.recipient}, usernameLink__soy6);
    usernameLink__soy6 = usernameLink__soy6.toString();
    output.append('<span class="aui-icon aui-icon-small aui-iconfont-approve" data-unicode="UTF+E005" original-title=""></span><p class="title">', AJS.format("Your request has been sent to {0}. If approved you will receive an email shortly.",usernameLink__soy6), '</p>');
  } else {
    output.append('<span class="aui-icon aui-icon-small aui-iconfont-error" data-unicode="UTF+E011" original-title=""></span><p class="title">', soy.$$escapeHtml("Your request for access has not been sent. Contact your space admin."), '</p>');
  }
  output.append('</div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Request.Access.usernameLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="', soy.$$escapeHtml("/wiki"), '/display/~', soy.$$escapeUri(opt_data.user.name), '" class="url fn confluence-userlink" title data-username="', soy.$$escapeHtml(opt_data.user.name), '">', soy.$$escapeHtml(opt_data.user.fullName), '</a>');
  return opt_sb ? '' : output.toString();
};


Confluence.Request.Access.loading = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class=\'aui-icon aui-icon-wait\'>', soy.$$escapeHtml("Loading, please wait"), '</span>"');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/templates/soy/grant-access.soy' */
// This file was automatically generated from grant-access.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Grant == 'undefined') { Confluence.Grant = {}; }
if (typeof Confluence.Grant.Access == 'undefined') { Confluence.Grant.Access = {}; }


Confluence.Grant.Access.dialog = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="grant-access-dialog">');
  var usernameLink__soy4 = new soy.StringBuilder();
  Confluence.Grant.Access.usernameLink({username: opt_data.requestAccessUsername, userFullName: opt_data.requestAccessUserFullName}, usernameLink__soy4);
  usernameLink__soy4 = usernameLink__soy4.toString();
  output.append('<h2 class="grant-access-title">', AJS.format("{0} requested access to view the page",usernameLink__soy4), '</h2><p class="grant-access-message">', soy.$$escapeHtml("Grant access to the page, or deny it explicitly."), '</p><div class="actions-result"><button class="aui-button grant-access">', soy.$$escapeHtml("Grant access"), '</button><button class="aui-button aui-button-link deny-access">', soy.$$escapeHtml("Deny"), '</button><div></div>');
  return opt_sb ? '' : output.toString();
};


Confluence.Grant.Access.result = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<span class="aui-icon aui-icon-small aui-iconfont-', (opt_data.success) ? 'approve' : 'error', '" data-unicode="UTF+E011" original-title=""></span><p class="title">', soy.$$escapeHtml(opt_data.message), '</p>');
  return opt_sb ? '' : output.toString();
};


Confluence.Grant.Access.usernameLink = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<a href="', soy.$$escapeHtml("/wiki"), '/display/~', soy.$$escapeHtml(opt_data.username), '" class="url fn" title data-username="', soy.$$escapeHtml(opt_data.username), '">', soy.$$escapeHtml(opt_data.userFullName), '</a>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
