function initOL(obj) {
  if(!dojo.byId(obj.olId.overlay)) {
    var type = "";
    if (typeof(obj.ol.type) == "undefined" || obj.ol.type == "") {
      type = "ibm_overlay";
    } else {
      type = obj.ol.type;
    }
    if (type == 'rating') {
      var overlayPopWindow = dojo.create("div", {"class": "ibm-common-overlay", "role":"alert", "aria-describedby":"rating_feedback_card_description", style: "width:"+obj.olSize.widthText+";height:"+obj.olSize.heightText}, dojo.body());
      overlayPopWindow.id = obj.olId.overlay;
      var overlayTitle = dojo.create("div", {"class": "ibm-head"}, overlayPopWindow, "last");     
      overlayPopWindow.innerHTML += '<iframe id="'+obj.olId.iframe+'" name="Rating Feedback Card" title="Rating Feedback Card" src="'+obj.url+'"style="width:'+obj.olSize.widthText+';height:'+obj.olSize.heightText+'">';
    } else {      
      var overlayPopWindow = dojo.create("div", {"class": "ibm-common-overlay", "role":"alert", "aria-describedby": type + "_description", style: "width:"+obj.olSize.widthText+";height:"+obj.olSize.heightText}, dojo.body());
      overlayPopWindow.id = obj.olId.overlay;
      var overlayTitle = dojo.create("div", {"class": "ibm-head"}, overlayPopWindow, "last");     
      overlayPopWindow.innerHTML += '<iframe id="'+obj.olId.iframe+'" name="'+type+'" title="'+type+'" src="'+obj.url+'"style="width:'+obj.olSize.widthText+';height:'+obj.olSize.heightText+'">';
    }
    
  }    
}
function showOL(pars, obj) {
  var urlParameters = "";
  var url = ""
  if(!dojo.byId(obj.olId.overlay)) {
    initOL(obj);
  }
  if (obj.ol.type == 'rating') {
    urlParameters = urlEncoding(pars + "&content=" + obj.ol.content + "&ID="+ obj.ol.ID) + "&pageURL=" + ecurl(window.location.href) + "&url=" + ecurl(window.location.href);
    url = obj.url + "?" + urlParameters;  
  } else {
    if (typeof(pars) != "undefined" && pars != "") {
      urlParameters = urlEncoding(pars);
      url = obj.url + "?" + urlParameters;  
    } else {
      url = obj.url;
    }
  }
  
  dojo.byId(obj.olId.iframe)? dojo.byId(obj.olId.iframe).src = url:console.log("iframe hasn't been initialized");
  ibmweb.overlay.show(obj.olId.overlay);
}
function ecurl(value) {
  return encodeURIComponent(value);
}
function urlEncoding(urlPars) {
  if (urlPars != "" && urlPars.indexOf("=") != -1) {
    if (urlPars.indexOf("&") != -1) {
      var parsList = urlPars.split("&");
      var encodedPars = "";
      for (var i = 0; i < parsList.length; i++) {
        if (parsList[i].indexOf("=") != -1 && parsList[i].indexOf("url") == -1) {
          if (encodedPars == "") {
            encodedPars += parsList[i].split("=")[0] + "=" + ecurl(parsList[i].split("=")[1]);
          } else {
            encodedPars += "&" + parsList[i].split("=")[0] + "=" + ecurl(parsList[i].split("=")[1]);            
          }
        } else if (parsList[i].indexOf("=") != -1 && parsList[i].indexOf("url") != -1) {
          if (encodedPars == "") {
            encodedPars += parsList[i].split("=")[0] + "=" + parsList[i].split("=")[1];
          } else {
            encodedPars += "&" + parsList[i].split("=")[0] + "=" + parsList[i].split("=")[1];
          }
        }            
      }
      return encodedPars;
    } else {
      return urlPars.split("=")[0] + "=" + ecurl(urlPars.split("=")[1]);
    }
  } else {    
    return "";
  }  
}