//>>built
define("dojo/request",["./request/default!"],function(a){return a});