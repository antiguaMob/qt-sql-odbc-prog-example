
    var legal_href    = "lib/control.jsp";
    var legal_reqStr;
    var legal_winName = "Terms and conditions.";

    var legal_height = "700";
    
    var legal_width   = "570";
    var legal_window;
    var browserName = navigator.appName;
    var udfobj;

    //var popupBlocked  = false;
    
    function legalverify(anchor) {
        if (browserName != "Microsoft Internet Explorer"){
            udfobj = undefined;
        } else {
            udfobj = "undefined";
        }
        
        if(null != anchor.href && anchor.href != udfobj) {
            req_Str = anchor.href;
            if (req_Str.toLowerCase().indexOf(".ibm.") == -1 || req_Str.toLowerCase().indexOf(".htm") != -1) {
                return true;
            }
        } else {
	    	req_Str = anchor;
	    	isDD = true;
        }

        if (legal_accept == true) {
            if (isDD == true) {
                ddRequest2(req_Str);
                isDD = false;
                return false;
            } else {
                return true;
            }
        }
        
        
        legal_window = window.open ('' ,'legal_winName','height='+legal_height+',width='+legal_width+',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=auto,resizable=yes');
        if (legal_window != null){
            legal_window.location = legal_href+"?loc="+doc_loc+"&amp;rs="+rs;
            legal_window.focus();
            return false;
        }
        else { 
            //popupBlocked = true; on IE 
            //alert ("Pop-up block");
            if (req_Str != null && isDD == false) {
                urlstr = legal_href+"?loc="+doc_loc+"&amp;rs="+rs+"&amp;blockFTP"+"/*"+req_Str; 
                urlRedirect(urlstr);
                window.focus();
                return false;
            
            }else if(req_Str != null && isDD == true) {
                urlstr = legal_href+"?loc="+doc_loc+"&amp;rs="+rs+"&amp;blockDD"+"/*"+req_Str;
                urlRedirect(urlstr);
                window.focus();
                return false;
            }else {
                alert("Invalid !");
                return false;
            }    
            //return false;
        }
    }
	
    /*
     * function readme:
     *		@common:common variable
     * 		@agree:agree to open or download file.
     * 		@disgree:disgree to open or download file.
     */
    // @agree
    function agree() {
        var url=location.search;
        if (url.indexOf("block") == -1 ) {             
            //* for popup window 
            opener.legal_accept = true;
            if (opener.isDD == true) {		
                opener.ddRequest2(opener.req_Str);
            } else {
                window.status = "opening FTP window...";
                opener.location = opener.req_Str;
            }
            opener.isDD = false;	
            this.close();
            return false;
        }
        else {
            //* for full page window
            var startIndex=url.indexOf("/*");
            var req_Str = url.substring(startIndex+2);
            
            legal_accept = true;
            //for DD link
            if ( url.indexOf("blockDD") != -1 ) {
                isDD = true;
                ddRequest2(req_Str); 
              
            } else {
            //for FTP link    
                window.status = "opening FTP window...";
                urlRedirect(req_Str);
                window.status = "";
            }
           
        }
    }
	
	/* The javascript will not be used for CR#447  
    // @disgree
    function disagree() {
        alert(legal_warning);
        var url=location.href;
        if (url.indexOf("block") == -1 ) {  
            //* for popup window 
            opener.isDD = false;
            this.close();
            return false;
        }
        else {                      
            //* for full page window
            if (self.history.length > 0) {
                window.history.back();
            }else{
                urlRedirect("http://www.ibm.com/us/");
            }
        }
    }
    */
 
    // @URL redirect
    function urlRedirect (url) {
        if (url != null && url !="" ) {
            window.location = url;
        }    
    }    