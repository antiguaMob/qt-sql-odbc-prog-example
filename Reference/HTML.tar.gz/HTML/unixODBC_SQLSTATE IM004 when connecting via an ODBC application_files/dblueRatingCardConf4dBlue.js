var dBlueRatingCard = {
  ccid: "60968",
  ol:{
    content: 'IBM',
    ID: 'eSupportRatingComment',
    type: 'rating'
  },
  olId:{
    overlay: "ibm-rating-overlay",
    iframe: "ibm-rating-overlay-iframe",
  },
  olSize: {
    widthText: "570px",
    heightText: "400px"
  },
  text: {
    title: "IBM dBlue Rating Card",
    reratedTitle: "Please make sure the new rated value you would like update.",
    commentBox: "Click to begin (comments optional)"
  },
  url: "https://www-01.ibm.com/support/5starfeedback/fiveStarFeedbackCardContentdBlue.html"
};