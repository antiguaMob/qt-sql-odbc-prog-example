
/**
 * Truncater.js - v1.0.2 - 2012-08-28
 * Truncates text to the specified number of lines.
 * Copyright (c) 2012, International Business Machines, Inc.<b> 
 * All rights reserved.
 * Author: John Pisello (jpisello@us.ibm.com)
 * Uses JavaScript Debug, by Ben Alman.
 */ 
 
/*
 * JavaScript Debug - v0.4 - 6/22/2010
 * http://benalman.com/projects/javascript-debug-console-log/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 * 
 * With lots of help from Paul Irish!
 * http://paulirish.com/
 */
// adapted for dBlue content suggestion widget from source in SupportPortal JS library

require(["dojo/ready","dojo/_base/lang","dojo/dom","dojo/dom-construct","dojo/dom-geometry","dojo/dom-attr","dojo/dom-class","dojo/dom-style","dojo/query"],
function(ready,lang,dom,domConstruct,domGeometry,domAttr,domClass,domStyle,query) {
    ready(function() {


window.textTruncater = {
    _version: "0.9_20141215",
    // Options for the truncater.
    options: {
        defWhitespace: 'normalize', // normalize [default]: trim leading/trailing whitespace & collapse internal runs to a single space when determining element text; 'preserve': do not normalize whitespace when determining element text.
        defMaxLines: 1,             // Default number of lines to truncate to. Override with 'data-maxlines' HTML attribute.
        defTolerance: 0.25,         // Distance (in lines, positive or negative) within which the truncated element's height is considered equal to the target height (helps account for minor layout differences across browsers). Override with 'data-tolerance' attribute in HTML.
        truncInd: '&nbsp;&hellip;'  // String appended to a truncated element to indicate that truncation has occurred.
    },
    
    truncate: function truncate (selector, context) {
        /**
         * @private
         * measureEltTextHeight
         * Returns text height measurements needed to truncate the element to the desired number of lines.
         * @param node: The node representing the element to be truncated.
         * @param maxlines: The number of lines to truncate the element's text to.
         * @return An object containing the following fields:
         *  - lineHeightPx: The height in pixels of one line of text. (Assumes no inline elements modify the text height).
         *  - targetHeightPx: The target height in pixels of the truncated text.
         *  - vertPaddingPx: The sum of top and bottom padding, in pixels, in the element.
         */
        'use strict';
        var measureEltTextHeight = function measureEltTextHeight (node, maxLines) {
            // Note: we avoid the CSS line-height property, which may be "normal" or "inherit",
            //      or otherwise not give the calculated value in pixels (in *some* browsers).
            // a. Clone the target element and move it offscreen via negative left margin.
            //    Then append it to the target element's parent so it inherits any styles needed. 
            var clone, t, vertPaddingPx, lineHeightPx, l, targetHeightPx;
            clone = lang.clone(node);
            domStyle.set(clone, 'marginLeft', -9999);
            if (!!node.parentNode) {
                domConstruct.place(clone, node.parentNode);
            }
            // b. Change the clone's text so it contains one line of content. 
            t = "A";
            clone.innerHTML = t;
            // c. Grab the clone's contentBox height, which includes top and bottom padding. Then remove
            //    that padding and measure the height again. This is the line height, and the 
            //    difference from the previous measurement is the vertical padding.
            vertPaddingPx = domGeometry.getContentBox(clone).h;   // Not the final value...
            domStyle.set(clone, {'paddingTop': 0, 'paddingBottom': 0});
            lineHeightPx = domGeometry.getContentBox(clone).h; 
            vertPaddingPx -= lineHeightPx;
            // d. Change the clone's text so it contains the desired number of lines of content.
            for (l = maxLines - 1; l > 0; l -= 1) { // Already have one line of text.
                t += '<br/>A';
            }
            clone.innerHTML = t;
            // e. Measure the clone's contentBox height to get the target height. Then remove it from the DOM.
            targetHeightPx = domGeometry.getContentBox(clone).h; 
            lineHeightPx = targetHeightPx / maxLines;
            domConstruct.destroy(clone);
            return ({ 'lineHeightPx': lineHeightPx, 'targetHeightPx': targetHeightPx, 'vertPaddingPx': vertPaddingPx });
        }, // end of measureEltTextHeight().
        
        getNodeContentData = function getNodeContentData (node) {
            var nodeTextHtml, whitespace, 
                nodeText = '', 
                tagStartPos = -1,
                tagEndPos = -1,
                tagText = '',
                tagData = [],
                accumTagLen = 0,    // Adjustment between character positions in full HTML vs. stripped text.
                emptyTagsRegexp = /^<(br|img|input|hr|area|base|col|link|meta|param)/i;
            
            nodeTextHtml = node.innerHTML;  
            whitespace = domAttr.get(node, 'data-whitespace') || window.textTruncater.options.defWhitespace || 'normalize';
            if ('normalize' === whitespace.toLowerCase()) { 
                nodeTextHtml = nodeTextHtml.trim().replace(/\s+/g, ' ');
            }
            tagStartPos = nodeTextHtml.indexOf('<');
            while (tagStartPos > -1) {
                tagEndPos = nodeTextHtml.indexOf('>', tagStartPos);
                tagText = "<" 
                        + nodeTextHtml.substring(tagStartPos + 1, tagEndPos).trim().replace(/\s+/g, ' ')
                        + ">";
                tagData[tagData.length] = { 'tag': tagText, 'position': tagStartPos - accumTagLen };
                accumTagLen += tagText.length; 
                tagStartPos = nodeTextHtml.indexOf('<', tagStartPos + tagText.length);
            } // end of while loop over all tags in the node's innerHTML.
            // Remove HTML tags from the text.
            nodeText = nodeTextHtml.replace(/<[^>]*>/g, '');
            // Return the object containing the 
            return ({ 
                'html': nodeTextHtml,
                'text': nodeText, 
                'textLength': nodeText.length, 
                'tagData': tagData, 
                "_tagsRestoredTo": -1, 
                '_tagStack': null, 
                '_accumTagLen': 0, 
                '_rebuiltHtmlUnclosed': '',
                'rebuildHtmlTo': function rebuildHtmlTo (endPos) {
                    // Check bounds.
                    var t = 0,  // tagData index
                        p = 0,  // Position in the stripped text
                        q = 0,  // Miscellaneous position/index variable.
                        td = null,
                        tag = '',
                        html = '',
                        tagStack = [],
                        accumTagLen = 0,
                        tagsRestoredTo = 0;
                        
                    if (endPos > this.textLength) {
                        endPos = this.textLength;
                    }
                    // See if we can shortcut the rebuild. The requirement is to not remove any tags we've already added to the HTML.
                    // 1) We've rebuilt the HTML previously, and
                    // 2) Our new target position (endPos) is greater than the position of the last tag added.
                    // Can't shortcut the process; rebuild the HTML from scratch.
                    while (t < this.tagData.length && this.tagData[t].position < endPos) {
                        td = this.tagData[t];
                        html += this.text.substring(p, td.position);
                        html += td.tag;
                        accumTagLen += td.tag.length;
                        if (td.tag.charAt(1) === '/') {
                            // pop closer off the stack.
                            tag = tagStack.pop();
                        } else if (td.tag.charAt(td.tag.length - 2) !== '/'
                                && !td.tag.match(emptyTagsRegexp)) {
                            // push closing tag onto the stack.
                            q = td.tag.indexOf(" ");
                            tag = "</" + td.tag.substring(1, (q > 0 ? q : td.tag.length - 1)) + ">";
                            tagStack.push(tag); 
                        }
                        tagsRestoredTo = p = td.position;
                        t += 1;
                    } // end of while loop over tags and text.
                    // Add any remaining text after the last tag to the HTML.
                    if (endPos >= tagsRestoredTo) {
                        html += this.text.substring(tagsRestoredTo, endPos);
                    }
                    // Store the unclosed HTML to help the shortcut logic (if needed).
                    this._rebuiltHtmlUnclosed = html;
                    // Append any remaining closing tags on the stack to the HTML, preserving the stack for future runs.
                    q = tagStack.length - 1;
                    while (q >= 0) {
                        html += tagStack[q];
                        q -= 1;
                    }
                    // Preserve tag info for later runs.
                    this._tagStack = tagStack;
                    this._tagsRestoredTo = tagsRestoredTo;
                    this._accumTagLen = accumTagLen;
                    return html;
                } // end of rebuildHtmlTo().
            });
        }; // end of getNodeContentData().
        
        
        query(selector, context).forEach(
            function truncateNode (node, i) {
                // Get the target number of lines for the truncated text.
                var maxLines, tolerance, eth, eltTextHeightPx, heightDiff, 
                    ncd, truncAfterChars, nodeText, nextSpacePos, curTruncHtml;
                    
                maxLines = parseInt(domAttr.get(node, 'data-maxlines'), 10) || window.textTruncater.options.defMaxLines || 1; 
                tolerance = parseFloat(domAttr.get(node, 'data-tolerance')) || window.textTruncater.options.defTolerance || 0.25; 
                // 1. Calculate the line height and desired element height:
                eth = measureEltTextHeight(node, maxLines);
                tolerance *= eth.lineHeightPx;  
                // 2. Calculate the actual height of the element's full text, and check whether we need to truncate at all.
                eltTextHeightPx = domGeometry.getContentBox(node).h - eth.vertPaddingPx;  
                heightDiff = eltTextHeightPx - eth.targetHeightPx;  
                if (heightDiff <= tolerance) {
                    return;
                }
                // 3. Store the original text and its length.
                ncd = getNodeContentData(node);
                // 4. Guess where to truncate based on text length (assumes an average character width).
                truncAfterChars = Math.floor(ncd.textLength / (eltTextHeightPx / eth.lineHeightPx) * maxLines); 
                // 5. Start the truncation at the next word boundary.
                nodeText = ncd.text;
                nextSpacePos = nodeText.indexOf(" ", truncAfterChars);  
                if (nextSpacePos < 0) { 
                    nextSpacePos = truncAfterChars;
                }
                node.innerHTML = ncd.rebuildHtmlTo(nextSpacePos) + window.textTruncater.options.truncInd;
                // a. Calculate the new text height.
                eltTextHeightPx = domGeometry.getContentBox(node).h - eth.vertPaddingPx;  
                // b. Fine-tune the truncation.
                heightDiff = eltTextHeightPx - eth.targetHeightPx;  
                if (heightDiff > tolerance && nextSpacePos > 0) {
                    // Still too big. Back up one word at a time until it fits.
                    do {
                        nextSpacePos = nodeText.lastIndexOf(" ", nextSpacePos - 1); 
                        if (nextSpacePos > 0) {
                            node.innerHTML = ncd.rebuildHtmlTo(nextSpacePos) + window.textTruncater.options.truncInd;
                            eltTextHeightPx = domGeometry.getContentBox(node).h - eth.vertPaddingPx;  
                            heightDiff = eltTextHeightPx - eth.targetHeightPx;  
                        } else {
                            node.innerHTML = ncd.rebuildHtmlTo(truncAfterChars) + window.textTruncater.options.truncInd;
                        }
                    } while (nextSpacePos > 0 && heightDiff > tolerance);
                } else {
                    // Not too big: try to add more words and still stay within the target height.
                    do {
                        curTruncHtml = node.innerHTML;
                        nextSpacePos = nodeText.indexOf(" ", nextSpacePos + 1);
                        if (nextSpacePos < ncd.textLength && nextSpacePos > 0) { 
                            node.innerHTML = ncd.rebuildHtmlTo(nextSpacePos) + window.textTruncater.options.truncInd;
                            // Is it too big?
                            eltTextHeightPx = domGeometry.getContentBox(node).h - eth.vertPaddingPx;  
                            heightDiff = eltTextHeightPx - eth.targetHeightPx;  
                        }
                    } while (nextSpacePos > 0 && heightDiff <= 0);
                    if (heightDiff > tolerance) {
                        node.innerHTML = curTruncHtml;
                    }
                }   // end of block to try to fine-tune the truncation.
            } // end of truncateNode function.
        ); // end of .forEach().
    } // end of truncate function.
};

    });
});

