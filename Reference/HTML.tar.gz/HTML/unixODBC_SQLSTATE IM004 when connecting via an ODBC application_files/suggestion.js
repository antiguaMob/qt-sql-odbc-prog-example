define([
        "dojo/_base/declare",
        "dojo/dom-class", 
        "dojo/dom-attr",
        "dojo/query",
        "dijit/_WidgetBase", 
        "dijit/_TemplatedMixin", 
        "dojo/text!./templates/suggestion.html",
        ],
    function(declare, domClass, domAttr, query, _WidgetBase, _TemplatedMixin, template) {
    
        return declare([_WidgetBase, _TemplatedMixin], {
            // These typically map to whatever you're passing to the constructor
            documentTitle: "",
            documentUrl: "",
            documentAbstract: "",
            isEntitled: "",
            weight: "",

            templateString: template,
            
            postCreate: function(){
                this.inherited(arguments);
                this._setLinkClass();
             },
            
            _setLinkClass: function () {
                var linkClass = this._calculateLinkClass();
                if (linkClass != "") {
                    domClass.add(this.docLinkNode, linkClass);
                }
            },
            
            _calculateLinkClass: function () {
                var linkClass = "";
                
                if (this.isEntitled === "Y") linkClass = 'ibm-password-link';
                else linkClass = 'ibm-forward-link';
                
                return linkClass;
            },
            
            _widget_displayLink:function() {    
                ibmweb.util.statsHelper({'ibmEV' : 'CSTWidget', 'ibmEvAction' : window.location.href, 'ibmEvGroup' : 'Electronic Support', 'ibmEvName': this.documentTitle, 'ibmEvLinkTitle': this.documentAbstract,'ibmEvSection': "Content Suggestion Widget",'ibmEvTarget': this.documentUrl });
            },
        });      
    }
);
