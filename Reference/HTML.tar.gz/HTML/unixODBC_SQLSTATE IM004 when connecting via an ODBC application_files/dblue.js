require(["dojo/ready"], function(ready){
	ready(function(){
		//dblue00007191
	//	var tabCon = dojo.query("div.ibm-dyn-tabs");
	//	if (tabCon.length > 0) {
	//	    tabCon.removeClass("ibm-dyn-tabs").addClass("ibm-dyntabs");
	//	    dojo.query("ul.ibm-tabs li a",tabCon[0]).forEach(function(item){
	//	        var id = item.href.substr(1);
	//	        dojo.query("div#"+id,tabCon[0]).addClass("ibm-tabs-content");
	//	    });
	//	    dojo['require']('ibmweb.dyntabs');
	//	    ibmweb.queue.push(function(){
	//	        return dojo._hasResource["ibmweb.dyntabs"];
	//	        },
	//	        function(){
	//	            ibmweb.dyntabs.init();
	//	        }
	//	    );
	//	}
		
		//dblue00007186
	//	dojo.query('.ibm-dblue-delete').forEach(function(){
	//		dojo.query('.ibm-dblue-delete').next('br').next('br').remove();
	//		dojo.query('.ibm-dblue-delete').next('br').remove();
	//		dojo.query('.ibm-dblue-delete').remove();
	//	});
		
	//	dojo.query('.ibm-data-table').forEach(function(){
	//		dojo.query('.ibm-data-table').attr('border', '0');
	//	});

		//dblue00007229
	//	dojo.query('#ibm-content-main ul li').attr('type', 'disc').removeAttr('type');

		//dblue00007204
	//	if (dojo.query('#ibm-content-main .ibm-container.ibm-alternate')){
	//		dojo.query('#ibm-content-main .ibm-container.ibm-alternate').html("<br>" + dojo.query('#ibm-content-main .ibm-container.ibm-alternate').innerHTML());
	//	};
		
		//dblue00007213
	//	var countImage = 0;
	//	dojo.query('img').forEach(function(){
	//		if (dojo.attr(dojo.query('img')[countImage], 'width') > 516) {
	//			dojo.addClass(dojo.query('img')[countImage], "ibm-image");
	//			dojo.attr(dojo.query('img')[countImage], 'width', '516');
	//			dojo.attr(dojo.query('img')[countImage], 'height', 'auto');
	//			dojo.place("<a target=\"_blank\" href=\"" + dojo.attr(dojo.query('img')[countImage], 'src') + "\"><img class=\"ibm-image-smaller\" src=\"" + dojo.attr(dojo.query('img')[countImage], 'src') + "\" width=\"516\" height=\"auto\"></a>", dojo.query('img')[countImage], "after");
	//			dojo.query('.ibm-image').orphan();
	//		};
	//		countImage++;
	//	});

		//dblue00007206
	//	dojo.query('.ibm-tab-section.ibm-text').parent('.ibm-container').forEach(function(){
	//		var tabSectionTextContent = "";
	//		tabSectionTextContent = dojo.query('.ibm-tab-section.ibm-text').innerHTML();
	//		dojo.query('.ibm-tab-section.ibm-text').parent('.ibm-container').removeAttr('class').addClass('ibm-tab-section').addClass('ibm-text').add;
	//		dojo.query('.ibm-tab-section.ibm-text').empty();
	//		dojo.query('.ibm-tab-section.ibm-text').html(tabSectionTextContent);
	//	});
		
		//dblue00007309
	//	dojo.query('ol li').removeAttr('type');
	//	dojo.query('ol').removeAttr('type');
	//	
	//	//dblue00007195
	//	dojo.query('ol[type="a"]').addClass('ibm-alpha-list');
	//	dojo.query('ol[type="i"]').addClass('ibm-roman-list');
		
		//dblue00007215

		expend();
		adjustTdWidth();
		dblue00007188();
		dblue00008769();
		// dojo.query("#hideImage").style("display", "none");
		if (dojo.query("#ibm-translation-form p script").length > 1) {
			var translationSrc = dojo.query("#ibm-translation-form p script")[1].src;
			var transPars = dojo.queryToObject(translationSrc.split("?")[1]);
			if (dojo.cookie("IBMISP") && dojo.cookie("IBMISS") && (typeof(transPars.corr) == "undefined" || transPars.corr != "1")) {
				switchNFluentCorr(translationSrc, transPars);
			}
		}
	});
});
 
//dblue0007234
function expend() {
	try{
		dojo.query('#ibm-content-main .ibm-container-body .ibm-twisty-trigger').forEach(function(node,index){
			node.onclick=function() {
				if(node.className=="ibm-twisty-trigger ibm-twisty-trigger-closed"){
					dojo.query('#ibm-content-main .ibm-container-body .ibm-twisty-trigger').at(index).siblings(".ibm-twisty-body").style("display", "block");
					node.className="ibm-twisty-trigger";
					//node.setAttribute("class","ibm-twisty-trigger");  IE doesn't support
				}else{
					dojo.query('#ibm-content-main .ibm-container-body .ibm-twisty-trigger').at(index).siblings(".ibm-twisty-body").style("display", "none");
					node.setAttribute("class","ibm-twisty-trigger ibm-twisty-trigger-closed");
					node.className="ibm-twisty-trigger ibm-twisty-trigger-closed";
				}
			}
		});
	}catch(e){
		alert(e);
	}
	
	try{
		dojo.query('#ibm-content-main .ibm-container .ibm-show-hide h2 a').forEach(function(node,index) {
			node.onclick=function() {
				dojo.query("#ibm-content-main .ibm-container .ibm-show-hide").children(".ibm-container-body").style("display", "none");
				
				dojo.query("#ibm-content-main .ibm-container .ibm-show-hide .ibm-container-body").style("height", "");
				dojo.query('#ibm-content-main .ibm-container .ibm-show-hide h2 a').removeClass();
				
				node.className="ibm-show-active";
				dojo.query("#ibm-content-main .ibm-container .ibm-show-hide .ibm-container-body").at(index).style("display", "block");  
			 }
		});
	}catch(e) {
		alert(e);
	}
}

function adjustTdWidth() {
	try{
		dojo.query('#ibm-content table.ibm-data-table colgroup col').forEach(function(colEle) {
			colEle.width="";
		});
		// Restrict the width of each TD to 400px. added by Jerome
		dojo.query('#ibm-content table').forEach(function(table) {
			dojo.query("td", table).forEach(function(td) {
				if (td.width > 400) {
					td.width = 400;
				}
			})
		})
	}catch(e){
		alert(e);
	}
}

//added by evan
function dblue00007188() {
	dojo.query('.tempIbmShowHide').forEach(function(node) {
		dojo.query('.tempIbmShowHide').removeAttr('class').addClass('ibm-container').addClass('ibm-show-hide');
		//node.className = "ibm-container ibm-show-hide";
	});
	
	if (dojo.query('#ibm-content-main .ibm-container .ibm-show-hide h2 a.ibm-show-hide-link')!='') {
		dojo.query('a#ibm-sibebar-dlf').forEach(function(node,index) {
			if (dojo.isIE) {
				node.onclick=function() {
					//alert(node.className);
					if (node.className!="") {
						dojo.query("#ibm-sidebar-ratepage div.ibm-container-body").style("display", "none");
						node.className="";
					} else {
						dojo.query("#ibm-sidebar-ratepage div.ibm-container-body").style("display", "block");
						node.className="ibm-show-active";
					}
					dojo.query("#ibm-sidebar-ratepage div.ibm-container-body").style("height", "auto");
				}
			} else {
				node.onclick = function() {
					//alert(node.className);
					if (node.className=="") {
						dojo.query("#ibm-sidebar-ratepage div.ibm-container-body").style("display", "none");
						node.className="";
					} else {
						dojo.query("#ibm-sidebar-ratepage div.ibm-container-body").style("display", "block");
						node.className="ibm-show-active";
					}
					dojo.query("#ibm-sidebar-ratepage div.ibm-container-body").style("height", "auto");
				}
			}
		});
	}
	
	dojo.query(".ibm-container .ibm-show-hide .ibm-container-body").style("display", "none");
	try {
		dojo.query('#ibm-content-main .ibm-container .ibm-show-hide h2 a.ibm-show-hide-link').forEach(function(node,index) {
			node.className="";
			node.href="#show-hide";
		});
		dojo.query('#ibm-content-main .ibm-container .ibm-show-hide h2 a').forEach(function(node,index) {
			node.onclick = function() {
				dojo.query("#ibm-content-main .ibm-container .ibm-show-hide .ibm-container-body").style("display", "none");
				dojo.query("#ibm-content-main .ibm-container .ibm-show-hide .ibm-container-body").style("height", "");
				dojo.query('#ibm-content-main .ibm-container .ibm-show-hide h2 a').removeClass();
				node.className="ibm-show-active";
				dojo.query("#ibm-content-main .ibm-container .ibm-show-hide .ibm-container-body").at(index).style("display", "block");
			}
		});
	} catch(e) {
		alert(e);
	}
}

function dblue00008769() {
	if (dojo.query("[name=createForm]")[0] != null && dojo.query("[name=createForm] h2").html().indexOf("Subscribe") != -1) {
		dojo.place(dojo.query("[name=createForm]")[0], "ibm-content-sidebar", "last");
		dojo.query("[name=createForm] h2").html("Subscribe to this APAR");
		dojo.query("[name=createForm]").style("display", "block");
	}
	if (dojo.query("#ibm-subscribe-APAR")[0] != null) {
		var a,b = new Array();
		a = dojo.attr(dojo.query("#ibm-subscribe-APAR a")[0], "href").split('&');
		b = dojo.attr(dojo.query("#ibm-subscribe-APAR a")[1], "href").split('&');
		dojo.place(dojo.query("#ibm-subscribe-APAR")[0], "ibm-content-sidebar", "last");
		dojo.create("div", { id: "ibm-subscribe-APAR-from", innerHTML: "<form name=\"createForm\" method=\"GET\" action=\"" + a[0].replace("methodName=createNewSubscription", "") + "\" style=\"display: block\"><input type=\"hidden\" name=\"methodName\" value=\"createNewSubscription\" /><input type=\"hidden\" name=\"css_key\" value=\"apar\" /><input type=\"hidden\" name=\"categorytitle\" id=\"categorytitle\" value=\"" + a[2].replace("categorytitle=", "") + "\" /><input type=\"hidden\" name=\"categoryid\" id=\"categoryid\" value=\"" + a[3].replace("categoryid=", "") + "\" /><input type=\"hidden\" name=\"subname\" id=\"subname\" value=\"" + a[4].replace("subname=", "") + "\" /><input type=\"hidden\" name=\"severity\" id=\"severity\" value=\"" + a[5].replace("severity=", "") + "\" /><input type=\"hidden\" name=\"returnurl\" value=\"http://www.ibm.com/support/docview.wss?uid=" + a[10].replace("uid=", "") + "\" /><input type=\"hidden\" name=\"categoryurl\" id=\"categoryurl\" value=\"http://www.ibm.com/support/docview.wss?uid=" + a[10].replace("uid=", "") + "\" /><input type=\"hidden\" name=\"DOCTYPE\" id=\"DOCTYPE\" value=\"" + a[6].replace("DOCTYPE=", "") + "\" /><div class=\"ibm-container\"><h2 class=\"ibm-first\">Subscribe to this APAR</h2><div class=\"ibm-container-body\"><p>By subscribing, you receive periodic emails alerting you to the status of the APAR, along with a link to the fix after it becomes available. You can track this item individually or track all items by product.</p><dd><p><input name=\"subScrInput\" type=\"radio\" onclick=\"setParametersForAparSubscription_()\" checked=\"checked\" />Notify me when this APAR changes.</p></dd><dd><p><input name=\"subScrInput\" type=\"radio\" onclick=\"setParametersForComponentSubscription_()\" />Notify me when an APAR for this component changes.</p></dd><p><input class=\"ibm-btn-arrow-pri\" type=\"submit\" value=\"Subscribe\" /></p></div></div>"}, dojo.byId('ibm-content-sidebar'));
	}
	var wordWrap = function(bigString, m, b) {
		var i, j, s, r = bigString.toString().split("\n");
		if (m > 0) for(i in r) {
			for (s = r[i], r[i] = ""; s.length > m;
				j = (j = s.substr(0, m).match(/\S*$/)).input.length - j[0].length || m,
						r[i] += s.substr(0, j) + ((s = s.substr(j)).length ? b : "")
			);
				r[i] += s;
		}
		return r.join("\n");
	};
	
	if (dojo.query("[name=createForm] input[type=submit]")[0]!=null) {
		if (dojo.query("[name=createForm] input[type=submit]").attr("value")[0].length > 18) {
			var a = dojo.query("[name=createForm] input[type=submit]").attr("value");
			dojo.query("[name=createForm] input[type=submit]").attr("value", wordWrap(a, 18, "\n"));
		}
	}
}

function setParametersForAparSubscription_() {
	if (dojo.query("#ibm-subscribe-APAR")[0] != null) {
		var a = new Array();
		a = dojo.attr(dojo.query("#ibm-subscribe-APAR a")[0], "href").split('&');
		document.getElementById('categorytitle').value = a[2].replace("categorytitle=", "");
		document.getElementById('categoryid').value = a[3].replace("categoryid=", ""); 
		document.getElementById('subname').value = a[4].replace("subname=", "");
		document.getElementById('severity').value = a[5].replace("severity=", "");
		document.getElementById('DOCTYPE').value = a[6].replace("DOCTYPE=", "");
		document.getElementById('categoryurl').value = a[7].replace("categoryurl=", "") + "&" + a[8] + "&" + a[9] + "&" + a[10];
	}
}

function setParametersForComponentSubscription_() { 
	if (dojo.query("#ibm-subscribe-APAR")[0] != null) {
		var b = new Array();
		b = dojo.attr(dojo.query("#ibm-subscribe-APAR a")[1], "href").split('&');
		document.getElementById('categorytitle').value = b[2].replace("categorytitle=", "");
		document.getElementById('categoryid').value = b[3].replace("categoryid=", "");
		document.getElementById('subname').value = b[4].replace("subname=", "");
		document.getElementById('severity').value = b[5].replace("severity=", "");
		document.getElementById('DOCTYPE').value =  b[6].replace("DOCTYPE=", "");
		document.getElementById('categoryurl').value = b[8] + "&" + b[9];
	}
}

function switchNFluentCorr(url, obj) {
	try {
		if (typeof(obj.corr) == "undefined" || obj.corr != "1") {
			obj.corr = "1";
			var sURL = url.split("?")[0] + "?" + dojo.objectToQuery(obj);
			dojo.query("#ibm-translation-form fieldset p script")[1].src = sURL;
			var jsonpArgs = {
				url: sURL,
				callbackParamName: "callback",
				load: function(data) {
					console.log("Completely switch nfluent correction function to enable status.");
				},
				error: function(error) {
					console.log("An error occured when loading nfluent js script");
				}
			};
			dojo.io.script.get(jsonpArgs);
		}
	} catch(err) {
	}
}
