﻿dojo.ready(function(){
    dojo.query('#ibm-content-main .ibm-container p').forEach(function(node){
        if (!dojo.hasClass(node, 'ibm-form-elem-grp')) {
            dojo.toggleClass(node,'wordwrap');
        }
    });
    /*
    dojo.query('.ibm-container-body table td').forEach(function(node){
        dojo.toggleClass(node,'wordwrap');
    });
    
    var aEl = document.getElementsByTagName('td');
    var dEl,i;
    var sName = "wordwrap";
    var oReg =  new RegExp('(\\s|^)' + sName + '(\\s|$)');
    for(i=0;dEl = aEl[i];i++){
      if(dEl.className.match(oReg)){
        breakWord(dEl);
      }
    }
    
    dojo.query('.ibm-container-body table td').forEach(function(node){
        dojo.toggleClass(node,'wordwrap');
    });
    */
});

function breakWord(dEl){
    defaultBreakChar = 8203;
    defaultWordlen = 45;

    if(!dEl || dEl.nodeType !== 1){
      return false;
    } else if(dEl.currentStyle && typeof dEl.currentStyle.wordBreak === 'string'){
      breakWord = function(dEl){
        dEl.runtimeStyle.wordBreak = 'break-all';
        return true;
      }
      return breakWord(dEl);
    }else if(document.createTreeWalker){
      var trim = function(str){
        str = str.replace(/^\s\s*/, '');
        var ws = /\s/,
        i = str.length;
        while (ws.test(str.charAt(--i)));
        return str.slice(0, i + 1);
      }
      breakWord = function(dEl){
        var dWalker = document.createTreeWalker(dEl, NodeFilter.SHOW_TEXT, null, false);
        var node,s,c = String.fromCharCode(defaultBreakChar);
        while (dWalker.nextNode())
        {
          node = dWalker.currentNode;
          s = trim( node.nodeValue ).split('').join(c);
          node.nodeValue = s;
        }
        return true;
      }
      return breakWord(dEl);
    }else{
      return false;
    }
}