   // MLS-8.01 06-22-07
   var dd_winName = "tq01";
   var dd_href    = "/support/dldirector/tq04.html";
   var dd_height  = "250";  // no logo
   var dd_width   = "500";
   var dd_locale  = "";

   var ddBaseFAQ  = "http://www6.software.ibm.com/cgi-bin/dldir/doc/DDfaq?locale=";

   var ddCurLocale;
   var ddWindow;
   var ddReqStr   = "";
   var ddTry      = 0;
   var ddURL;

   var ddShowMsg = false;
   var ddMsgs = new Array(12);

   var ddMT_href = null;
   var ddMT_url  = null;
   var ddMT_lang = "";


   function ddRequest2( inReq ) { // open applet window
      ddReqStr = inReq;
      if (ddTry == -1) return;
      ddTry = -1;

      if (dd_href.indexOf("tq03i.html") >= 0 ||
          dd_href.indexOf("tq04i.html") >= 0) {
         dd_height = "250";  // with IBM logo
      }

      ddWindow = window.open (''  ,dd_winName,'height='+dd_height+',width='+dd_width+',toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes');
      ddWindow.focus();
      ddTry = 0;
      ddRequest3()
   }

   function ddRequest3() {  // load applet page, request file
      if (!ddWindow.closed && typeof ddWindow.dlFile == "undefined" && ddTry == 0) {
         ddMTParse();
         ddLoadMsgs();
      }
      // keep trying request (unless '0') while applet loads
      if (ddReqStr != '0' && ddTry++ < 200 && (typeof ddWindow.dlFile == "undefined" || !ddWindow.dlFile( ddReqStr ))) {
         setTimeout('ddRequest3()', (ddTry < 20 ? 200 : 1000));

      } else {
         ddTry = 0;
      }
   }

   function ddLoadMsgs() {  // use approprate locale

      ddMsgs[0]   = dd_locale;
      ddMsgs[1]   = null;
      ddMsgs[11]  = ddBaseFAQ + dd_locale; // locale-specific faq
      ddCurLocale = "en";                  // default English

      if (dd_locale.length > 0) {
         locIn  = new Array("fr_CA", "fr", "de", "es_MX", "es", "it", "nl", "pt_BR", "pt",    "ja");
         locOut = new Array("fr_CA", "fr", "de", "es_MX", "es", "it", "nl", "pt_BR", "pt_BR", "ja");
         for (ii = 0; ii < locIn.length && ddCurLocale == "en"; ii++) {
            if (dd_locale.indexOf( locIn[ii] ) == 0) {
               ddCurLocale = locOut[ii];  // match found
            }
         }
      }

      if (ddCurLocale == "en" && !ddShowMsg) {
         DDload();

      } else {  // load messages
         qString = "?hide"; // hide messages
         if (ddShowMsg) {
            qString = "";   // show messages
            ddTry = 200;
         }

         pathPos = ddURL.lastIndexOf('/');
         msgPath = (pathPos < 0 ? "" : ddURL.substring(0,pathPos+1));
         msgFile = msgPath+"dd/dldir_"+ddCurLocale+".html"+qString;
         //opera.postError("!1>>>>"+ddMT_href + msgFile + ddMT_lang);
         ddWindow.location.href = ddMT_href + msgFile + ddMT_lang;
      }
   }

   function DDload() {      // load DD (call from language page)
      //opera.postError("!2>>>>"+ddMT_href + ddURL + ddMT_lang);
      ddWindow.location.href = ddMT_href + ddURL + ddMT_lang;
   }

   function ddMTParse() {   // parse MT URL
      if (ddMT_href == null) { // 1st time only
         if (window.location.href.indexOf("url=") > 0) {
            var vars = window.location.search.substring(1).split("&");
            for (var ii=0 ;ii < vars.length; ii++) {
               var pair = vars[ii].split("=");
               if (pair[0] == "url") {
                  ddMT_url = pair[1];
                  if (ddMT_url.indexOf('?') > 0) {
                     ddMT_url = ddMT_url.substring(0,ddMT_url.indexOf('?')-1);
                  }
                  ddMT_url = ddMT_url.substring(0,ddMT_url.lastIndexOf('/')+1 );
               } else if (pair[0] == "language") {
                  ddMT_lang = "&ACCEPT_MT_DISCLAIMER=YES&language="+pair[1];
               }
            }
         }

         if (ddMT_url == null) {
            ddMT_href = "";
         } else {
            ddMT_href = window.location.protocol+"//"+window.location.host+window.location.pathname+"?url=";
         }
      }

      if (ddMT_url == null) {  // typical
         ddURL=dd_href;
      } else {                 // use MT server
         if (dd_href.charAt(0) != '/') {
            ddURL=ddMT_url+dd_href;
         } else {
            ddURL=ddMT_url.substring(0,ddMT_url.indexOf('/',8))+dd_href;
         }

         chkStr = ddMT_lang.substring(35).toLowerCase();
         if      (chkStr == "french") dd_locale = "fr";
         else if (chkStr == "german") dd_locale = "de";
         else if (chkStr == "italian") dd_locale = "it";
         else if (chkStr == "spanish") dd_locale = "es";
         else if (chkStr == "japanese") dd_locale = "ja";
         else if (chkStr == "portuguese") dd_locale = "pt";
//dd_locale = "en";
      }
   }
