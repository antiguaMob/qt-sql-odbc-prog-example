/*
 * expects to find one of these in the host document:
 * <div id="ibm-suggestions-widget" class="ibm-container"></div>
 */

var SP_ENV_MODE = "PRODUCTION"; // change this value from "TEST" to "PRODUCTION" before deploying to production
var SP_TEST_DB_FLAG = "N"; // change this to "N" for Production database (db issues still being worked)
var SP_SUGGESTION_LIMIT = 5;

require({
    packages : [ {
        name : "dblue",
        location : "/support/include/content-suggestions/js"
    }, ]
},["dojo/request/script", "dojo/request", "dojo/ready", "dojo/dom", "dojo/dom-class", "dojo/dom-construct", "dojo/_base/array", "dblue/widgets/suggestion", "dojo/json", "dojo/io-query"],
function(script,request,ready,dom,domClass,domConst,arrayUtil,suggestion,json,ioQuery) {
    ready(function() {
        
        var suggestionServiceTestUrl = "https://speqe1.dub.usoh.ibm.com/support/scsipublic/content-suggestion/get";
        var suggestionServiceProductionUrl = "https://www-945.ibm.com/support/scsipublic/content-suggestion/get";
        
        // make sure the URL has a "uid" parameter for the docid
        var uri = dojo.doc.location.search;
        var qry = uri.substring(uri.indexOf("?") + 1, uri.length);
        var q = ioQuery.queryToObject(qry);
        var docId = "#FAIL#"; 
        if( typeof q.uid !== "undefined" && q.uid !== null) docId=q.uid;
        if (docId === "#FAIL#") {
            console.log("expected UID in URL parameters, not found, so not displaying suggestions.");
            return;
        }
        
        var suggestionServiceUrl = (typeof SP_ENV_MODE !== "undefined" && SP_ENV_MODE === "TEST") ? suggestionServiceTestUrl : suggestionServiceProductionUrl;
        var limitTo = 5; //default
        if (typeof SP_SUGGESTION_LIMIT !== "undefined") limitTo = SP_SUGGESTION_LIMIT;
        
        //FIXME?: So far, the production side of this is not up and running. The testdb parameter is a hack to 
        //   return data from SP test system. This should not be used in Production
        var useTestDb = 'N';
        if (typeof SP_TEST_DB_FLAG !== "undefined" && SP_TEST_DB_FLAG === "Y") useTestDb = 'Y';
        
        //   console.log("content suggestion request to: " + suggestionServiceUrl + "/docuid="+ docId + " limitTo=" + limitTo + " testDB=" + useTestDb);
        
        
        script.get(suggestionServiceUrl, {
            jsonp: "callback",
            query: {
                docuid: docId,
                limit: limitTo,
                testdb: useTestDb,
                mediatype:"json",
            }
        }).then(function(SuggestedContent) {
            if (SuggestedContent !== undefined && SuggestedContent.contentSuggestion !== undefined && SuggestedContent.contentSuggestion !== "") {
                // Create our widget and place it
                var widgetNode = dom.byId("ibm-suggestions-widget"); // agreed up on name for target div, presumed to be appropriate class, e.g., ibm-container
                var container = domConst.place("<div class='ibm-container'></div>", widgetNode);
                domConst.place("<h2>"+ "Others also viewed..."+ "</h2>", container);
                var containerBody = domConst.place("<div class='ibm-container-body'></div>", container);
                var sugglist = domConst.place("<ul id='ibm-show-suggestions-list' class='ibm-link-list'></ul>", containerBody);
                
                arrayUtil.forEach(SuggestedContent.contentSuggestion, function(Item) {
                    var widget = new suggestion(Item);
                    widget.placeAt(sugglist);
                });
                // shorten any long titles to number of lines specified in template
                textTruncater.truncate(".ibm-text-truncate", "ibm-suggestions-widget");
            }
            else console.log("Webservice did not return a value");
        },
         function(err){
            console.log("An error occurred: " + err);
        });
    });
});