(function(jQuery){jQuery(document).ready(function(){
	jQuery("code").addClass("prettyprint");
	prettyPrint();
});}(jQuery));
