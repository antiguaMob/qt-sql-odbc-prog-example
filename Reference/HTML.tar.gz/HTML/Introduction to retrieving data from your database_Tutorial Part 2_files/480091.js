/** 
 * HubSpot Analytics Tracking Code Build Number 1.110
 * Copyright 2015 HubSpot, Inc.  http://www.hubspot.com
 */
var _hsq = _hsq || [];
var _paq = _paq || [];
