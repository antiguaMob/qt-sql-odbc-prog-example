/*Unica tracking*/
var enableTracking = false;
var enableAddTrackingAttr = true;
var gtsp = "DB_GTSP=";
var rtsp = "DB_RTSP=";
/*CR887 - Add Mobile app link*/
var enableMobileAppSection = true;
var IncludeMobileAppSectionInSearch = true;
/*
var mobileAppsectionContent = '<h2>Now available</h2>'
							+ '<div class="ibm-container-body"><a href="//www.redbooks.ibm.com/redbooks.nsf/pages/mobileapp?Open"><img src="/support/i/App172x99.jpg" width="159" height="99" alt="Redbooks mobile app" border="0"></a>'
							+ '<p>The new <a href="//www.redbooks.ibm.com/redbooks.nsf/pages/mobileapp?Open"><b>IBM Redbooks mobile app</b></a> provides on-the-go access to Redbooks publications, announcements, and social sites. '
							+ 'Available on both <a href="https://itunes.apple.com/bw/app/ibm-redbooks/id778694354"><b>iOS</b></a> and <a href="https://play.google.com/store/apps/details?id=com.ibm.homeScreen"><b>Android</b></a> mobile operating systems.</p>'
							+ '<p align="center"><a href="https://itunes.apple.com/bw/app/ibm-redbooks/id778694354"><img src="/support/i/badge_appstore_135x40.jpg" width="135" height="40" alt="App Store badge" border="0"></a></p>'
							+ '<p align="center"><a href="https://play.google.com/store/apps/details?id=com.ibm.homeScreen"><img src="/support/i/badge_google_play_129x45.jpg" width="129" height="45" alt="Google play badge" border="0"></a></p></div>';

var mobileAppsectionContentforSearch = '<h3>Now available</h3>'
									+ '<div class="ibm-container-body"><a href="//www.redbooks.ibm.com/redbooks.nsf/pages/mobileapp?Open"><img src="/support/i/App172x99.jpg" width="159" height="99" alt="Redbooks mobile app" border="0"></a>'
									+ '<p>The new <a href="//www.redbooks.ibm.com/redbooks.nsf/pages/mobileapp?Open"><b>IBM Redbooks mobile app</b></a> provides on-the-go access to Redbooks publications, announcements, and social sites. '
									+ 'Available on both <a href="https://itunes.apple.com/bw/app/ibm-redbooks/id778694354"><b>iOS</b></a> and <a href="https://play.google.com/store/apps/details?id=com.ibm.homeScreen"><b>Android</b></a> mobile operating systems.</p>'
									+ '<p align="center"><a href="https://itunes.apple.com/bw/app/ibm-redbooks/id778694354"><img src="/support/i/badge_appstore_135x40.jpg" width="135" height="40" alt="App Store badge" border="0"></a></p>'
									+ '<p align="center"><a href="https://play.google.com/store/apps/details?id=com.ibm.homeScreen"><img src="/support/i/badge_google_play_129x45.jpg" width="129" height="45" alt="Google play badge" border="0"></a></p></div>';
*/
var mobileAppsectionContent = '<h2>IBM Technical Support mobile app is now available!</h2>'
							+ '<div class="ibm-container-body">'
							+ '<p align="center"><a href="http://ibm.biz/its-ios"><img src="/support/i/Download_on_the_App_Store_Badge_US-UK_135x40.svg" alt="App Store badge" border="0"></a></p>'
							+ '<p align="center"><a href="https://play.google.com/store/apps/details?id=com.ibm.cio.technicalsupportmobileapp"><img alt="Get it on Google Play" src="/support/i/en_generic_rgb_wo_45.png"/></a></p>'
							+ '</div>';

var mobileAppsectionContentforSearch = '<h3>IBM Technical Support mobile app is now available!</h3>'
									+ '<div class="ibm-container-body">'
									+ '<p align="center"><a href="http://ibm.biz/its-ios"><img src="/support/i/Download_on_the_App_Store_Badge_US-UK_135x40.svg" alt="App Store badge" border="0"></a></p>'
									+ '<p align="center"><a href="https://play.google.com/store/apps/details?id=com.ibm.cio.technicalsupportmobileapp"><img alt="Get it on Google Play" src="/support/i/en_generic_rgb_wo_45.png"/></a></p>'
									+ '</div>';

function unica_tracking(url, type) {
	if (enableTracking) {
		if (type == "gtsp") {
			if (typeof(url) != "undefined" && url.indexOf("?") == -1) return url + "?" + gtsp;
			return url + "&" + gtsp;
		} else if (type == "rtsp") {
			if (typeof(url) != "undefined" && url.indexOf("?") == -1) return url + "?" + rtsp;
			return url + "&" + rtsp;
		} else {
			return url;
		}
	} else {
		return url;
	}
}

function createMobileAppSection() {
	dojo.query("#ibm-mobile-app-section")[0].innerHTML = mobileAppsectionContent;
	dojo.query("#ibm-mobile-app-section").style("display", "block");
}

require(["dojo/ready"], function(ready){
	ready(function(){
		/* Go to Support Portal widget for static page */
		if (typeof(dojo.query("#ibm-parent-link a")[0]) != "undefined" && typeof(dojo.query("#ibm-parent-link a").attr("href") != "undefined")) {
			var spUrl = dojo.cookie("spe_return_url");
			if (spUrl) {
				dojo.query("#ibm-parent-link a").attr("href", unica_tracking(spUrl,"rtsp")).text("Return to IBM Support Portal");
				if (enableAddTrackingAttr) {dojo.query("#ibm-parent-link a").attr("manual_cm_sp", "dBlue-_-dbrtsp-_-search");}
			} else {
				dojo.query("#ibm-parent-link a").attr("href", unica_tracking("http://www.ibm.com/support/","gtsp"));
				if (enableAddTrackingAttr) {dojo.query("#ibm-parent-link a").attr("manual_cm_sp", "dBlue-_-dbgtsp-_-docview");}
			}
		}
		/*CR887 - Add Mobile app link*/
		if (enableMobileAppSection && typeof(dojo.query("#ibm-mobile-app-section")[0]) != "undefined") {
			createMobileAppSection();
		}
	});
});