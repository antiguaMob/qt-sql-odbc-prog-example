/*
 * Send request to get the response of Watson Dialogs Query and display the response.
 */
require(["dojo/request/script", "dojo/ready"],
function(script,ready) {
	ready(function(script) {
		var queryWatsonDialogUrl = "/support/statuschecker.wss?action=QueryWatsonDialog";
		var dBlueSearch = "/support/search.wss?q=";
		if (WatsonDialogWidgetfor()=="docview") {
			var watsonDialogsWidget = dojo.byId('ibm-watson-dialog-widget');
			if (watsonDialogsWidget.innerHTML=="") {
				dojo.create("form", { innerHTML:"<label class=\"\" for=\"s\">Search all IBM support:</label>" +
                                                "<span class=\"ps_search_container\">" +
                                                "<input id=\"searchField\" type=\"text\" name=\"q\" maxlength=\"100\" title=\"Enter search term\">" +
                                                "<input title=\"Go\" id=\"searchButton\" value=\"Search\" type=\"image\" name=\"ibm-search\" class=\"ibm-btn-view\" alt=\"Go\" src=\"//www.ibm.com/i/v17/buttons/short-btn.gif\">" +
                                                "</span>" +
                                                "<div class=\"wd_result_container wd_result_width\" id=\"divWatsonContainer\" style=\"display: none;\">" +
                                                "<div id=\"divWatsonDialogue\" class=\"ps_ibm-content wd_result_width\" style=\"display: none;\">" +
                                                "<div id=\"divWatsonSpinner\" style=\"display: none;\">" +
                                                "<p class=\"ibm-spinner-large\" href=\"#\">&nbsp;</p>" +
                                                "</div>" +
                                                "<div id=\"divWatsonContent\" class=\"wd_content_div wd_ul\" style=\"display: none;\"></div>" +
                                                "<hr>" +
                                                "<p class=\"wd_search_link\">" +
                                                "<a class=\"ibm-forward-link\" href=\"#\" id=\"watsonNOTALink\">None of the above, continue with my search</a>" + 
                                                "</p>" +
                                                "</div>" +
                                                "</div>"}, watsonDialogsWidget);
				dojo.attr(dojo.query("#ibm-watson-dialog-widget form")[0], 'action', "javascript:void(0)");
				dojo.attr(dojo.query("#ibm-watson-dialog-widget form")[0], 'method', "post");
				dojo.attr(dojo.query("#ibm-watson-dialog-widget form")[0], 'onsubmit', "return false;");
				if (dojo.query("#ibm-suggestions-widget")[0]!=null) {
					dojo.query("#ibm-suggestions-widget").style("margin", "21px 0 0 0");
				}
			}
			dojo.connect( dojo.byId("watsonNOTALink"), "onclick", dojo.hitch(function(e) {
				var queryTerm = dojo.byId("searchField").value.trim();
				dojo.stopEvent(e);
				noneOfTheAboveLinkMetricEvent(queryTerm);
				window.location.href = dBlueSearch + queryTerm;
				hideWatsonContainer();
			}));
		} else {
			dojo.connect( dojo.byId("watsonNOTALink"), "onclick", dojo.hitch(function(e) {
				var queryTerm = dojo.byId("searchField").value.trim();
				dojo.stopEvent(e);
				noneOfTheAboveLinkMetricEvent(queryTerm);
				dojo.query("input#s")[0].value = queryTerm;
				dojo.byId('ibm-searchbox-button').click();
				hideWatsonContainer();
			}));
		}
		dojo.connect(dojo.byId("searchButton"), "onclick", function()
		{
			var queryTerm = dojo.byId("searchField").value.trim();
			if ( queryTerm.length>0 ) {
				hideWatsonContent();
				dojo.xhrPost({
				//dojo.io.script.get({
					load: function(response) {
						console.debug("[QueryWatsonDialogs] - The Response Data of QueryWatsonDialogs: " + response );
						var watsonData = dojo.fromJson(response);
						var contentDiv = dojo.byId( "divWatsonContent" );
						contentDiv.innerHTML = '';
						hideWatsonSpinner();
						if( watsonData.text ) {
							watsonText = new String(watsonData.text);
						}
						watsonText = watsonText.trim();
						if (WatsonDialogWidgetfor()=="docview") {
							if( watsonText.length>0 ) {
								contentDiv.innerHTML = watsonText;
							} else {
								var templateQueryTerm = dojo.byId("searchField").value.trim();
								if (templateQueryTerm.length>0) {
									window.location.href = dBlueSearch + templateQueryTerm;
									setTimeout(function() {
									hideWatsonContainer();
									}, 1000);
								}
							}
						} else {
							contentDiv.innerHTML = watsonText;
							if( watsonText.length<=0 ) {
								dojo.byId('ibm-searchbox-button').click();
								setTimeout(function() {
								hideWatsonContainer();
								}, 1000);
							}
						}
						var that=this;
						dojo.query( "#divWatsonContent a" ).forEach(function(node, index, arr){
							dojo.connect( node, "onclick", dojo.hitch(that,function(e){
								searchResultLinkMetricEvent( queryTerm, node.text, node.href );
							}));
						});
						displayResultsMetricEvent(queryTerm);
					},
					error: function(data) {
						console.error("[QueryWatsonDialogs] error: " + data);
					},
					timeout: 3000,
					sync: true,
					headers: {
						"Content-Type": "application/x-www-form-urlencoded"
					},
					callbackParamName: "callback",
					preventCache: true,
					handleAs: "text",
					content:{"q": queryTerm},
					url: queryWatsonDialogUrl
				});
				
				dojo.connect(dojo.body(), "onclick", dojo.hitch (function(e)
				{
					var watsonContainer = dojo.byId( "divWatsonContainer" );
					var watsonDialogDiv = dojo.byId( "divWatsonDialogue" );
					var s = dojo.byId( "searchField" );
					var targetNode = e.target;
					var targetNodeId = e.target.id;
					while (targetNode != null)
					{
						if ( targetNodeId == "divWatsonContainer" || targetNodeId == "divWatsonDialogue" || targetNodeId == "searchField" || targetNodeId == "searchButton" || targetNodeId == "ibm-searchbox-button" )
						{
							// target node is child so return, do not close layers
							return;
						}
						targetNode = targetNode.parentNode;
					}
					hideWatsonContainer();
				}));
			}
		});
	});
});

function hideWatsonSpinner() {
	dojo.query("#divWatsonSpinner").style("display", "none");
	dojo.query("#divWatsonContent").style("display", "block");
	dojo.query("#divWatsonNOTA").style("display", "block");
}

function hideWatsonContent() {
	dojo.query("#divWatsonSpinner").style("display", "block");
	dojo.query("#divWatsonContent").style("display", "none");
	dojo.query("#divWatsonDialogue").style("display", "block");
	dojo.query("#divWatsonContainer").style("display", "block");
}

function hideWatsonContainer() {
	dojo.query("#divWatsonSpinner").style("display", "none");
	dojo.query("#divWatsonNOTA").style("display", "block");
	dojo.query("#divWatsonContent").style("display", "none");
	dojo.query("#divWatsonDialogue").style("display", "none");
	dojo.query("#divWatsonContainer").style("display", "none");
}

function WatsonDialogWidgetfor() {
	if (typeof enableWatsonDialogWidget === "undefined") {
		return "docview";
	}
	return "search";
}

function displayResultsMetricEvent( queryText ) {
	ibmweb.util.statsHelper( {'ibmEV' : 'dialog-display',
		 'ibmEvAction' : window.location.href,
		 'ibmEvGroup' : 'dBlue',
		 'ibmEvName': queryText
	});
	console.debug("[QueryWatsonDialogs]: displayResultsMetricEvent( \"" + queryText + "\" );");
}

function noneOfTheAboveLinkMetricEvent( queryText ) {
	ibmweb.util.statsHelper( {'ibmEV' : 'dialog-search',
		 'ibmEvAction' : window.location.href,
		 'ibmEvGroup' : 'dBlue',
		 'ibmEvName': queryText
	});
	console.debug("[QueryWatsonDialogs]: noneOfTheAboveLinkMetricEvent( \"" + queryText + "\" );");
}

function searchResultLinkMetricEvent( queryText, linkTitle, linkUrl ) {
	ibmweb.util.statsHelper( {'ibmEV' : 'dialog-click',
		 'ibmEvAction' : window.location.href,
		 'ibmEvGroup' : 'dBlue',
		 'ibmEvName': queryText,
		 'ibmEvLinkTitle': linkTitle,
		 'ibmEvTarget' : linkUrl
	});
	console.debug("[QueryWatsonDialogs]: searchResultLinkMetricEvent( \"" + queryText + "\", \"" + linkTitle + "\", \"" + linkUrl + "\" );");
}