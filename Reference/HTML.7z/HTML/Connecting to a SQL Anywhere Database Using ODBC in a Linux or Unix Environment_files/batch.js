;try {
/* module-key = 'confluence.web.resources:page-loading-indicator', location = '/includes/js/page-loading-indicator.js' */
Confluence.PageLoadingIndicator=function(a){function b(){return $(".confluence-page-loading-blanket",a)}function d(){return $(".confluence-loading-indicator",a)}return{show:function(){0===b().length&&$(a).append(Confluence.Templates.pageLoadingIndicator());b().show();d().spin({lines:12,length:8,width:4,radius:10,trail:60,speed:1.5,color:"#F0F0F0"})},hide:function(){d().stop();b().hide()},showUntilResolved:function(a,c){this.show();a.always(_.bind(this.hide,this));c&&a.fail(function(){AJS.messages.error(".confluence-page-loading-errors",
{body:c})})},showUntilDialogVisible:function(a,c){var b=this,c=c||"An error has occurred connecting to the server. Please try again.";$(".aui-dialog:visible").length||b.show();a.fail(function(){b.hide();AJS.messages.error(".confluence-page-loading-errors",{body:c})});AJS.bind("show.dialog",function(){b.hide()})},destroy:function(){a.remove(".confluence-page-loading-blanket")}}};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:page-loading-indicator', location = '/includes/soy/page-loading-indicator.soy' */
// This file was automatically generated from page-loading-indicator.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }


Confluence.Templates.pageLoadingIndicator = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="confluence-page-loading-errors"></div><div class="confluence-page-loading-blanket aui-blanket" aria-hidden="false"><div class="confluence-loading-indicator"></div></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:deferred-loaders', location = '/includes/js/deferred-dialog-loader.js' */
AJS.$(function(){var c=Confluence.PageLoadingIndicator($("body"));_.each({userStatus:{resource:"confluence.userstatus:userstatus-resources",selector:"#create-user-status-link",event:"deferred.userstatus.click"},movePageDialogTools:{resource:"confluence.web.resources:page-move-resources",selector:"#action-move-page-dialog-link",event:"deferred.page-move.tools-menu"},movePageDialogEditor:{resource:"confluence.web.resources:page-move-resources",selector:"#rte-button-location",event:"deferred.page-move.editor"},
moveBlogDialogTools:{resource:"confluence.web.resources:page-move-resources",selector:"#action-move-blogpost-dialog-link",event:"deferred.blog-move.tools-menu"}},function(a){$("body").on("click",a.selector,function(d){var b=WRM.require("wr!"+a.resource,function(){AJS.trigger(a.event)});c.showUntilDialogVisible(b);b=a.resource+".requested";AJS.Analytics?AJS.Analytics.triggerPrivacyPolicySafeEvent(b):AJS.trigger("analyticsEvent",{name:b});d.preventDefault()})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:deferred-loaders', location = '/includes/js/page-permissions-deferred-loader.js' */
AJS.$(function(){var b=Confluence.PageLoadingIndicator($("body")),a=function(a){var c=WRM.require("wr!confluence.web.resources:page-permissions-editor",function(){AJS.trigger("deferred.page.permissions")});b.showUntilDialogVisible(c,"There was an error loading the page restrictions. Please try again later.");a.preventDefault()};AJS.$("body").on("click","#rte-button-restrictions,#action-page-permissions-link",a);AJS.bind("system-content-metadata.open-restrictions-dialog",a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.whatsnew:whats-new-resources', location = 'js/whats-new.js' */
AJS.toInit(function(d){var j=d("#whats-new-menu-link"),f,c,a,m,i,h,l=function(q){var o=!d(this).prop("checked");var n=AJS.Meta.get("context-path")+"/plugins/whatsnew/set.action";var p={isShownForUser:o};AJS.log("whatsnew > toggleDontShow > setting isShownForUser to: "+p.isShownForUser);AJS.safe.post(n,p,function(s,r){AJS.log("whatsnew > toggleDontShow > isShownForUser set to: "+s.isShownForUser)})},e=function(){if(!c){return}h&&clearTimeout(h);g();AJS.setVisible(c,true)},k=function(o){var n=new AJS.ConfluenceDialog({width:880,height:585,id:"whats-new-dialog",onCancel:function(){n.hide().remove();h&&clearTimeout(h)}});var q="What\u2019s New in Confluence {0}";var p=AJS.Meta.get("version-number").match(/^\d+\.\d+/);var s=AJS.format(q,p);n.addHeader(s);n.addPanel("default",Confluence.Templates.Whatsnew.dialogPanel());n.addCancel("Close",function(){n.hide().remove();h&&clearTimeout(h);return false});a=n.popup.element;if(AJS.Meta.get("remote-user")){n.page[n.curpage].buttonpanel.append(Confluence.Templates.Whatsnew.dialogTipPanel());a.find("#dont-show-whats-new").change(l).prop("checked",!o)}c=a.find("iframe");var r=AJS.Meta.get("whats-new-iframe-src-override");if(typeof(r)=="undefined"){r=j[0].href}c[0].src=r;c.load(e);m=a.find(".whats-new-timeout");return n},g=function(){if(i){i();i=null}f.addClass("hidden")},b=function(){var n=AJS.Meta.get("context-path")+"/plugins/whatsnew/get.action";d.getJSON(n,function(o){k(o.isShownForUser).show();f=a.find(".whats-new-throbber.hidden");f.removeClass("hidden");i=Raphael.spinner(f[0],80,"#666");h=setTimeout(function(){c=null;g();AJS.setVisible(m,true)},10000)})};j.click(function(n){n.preventDefault();d(this).removeClass("interactive");b()});AJS.Meta.getBoolean("show-whats-new")&&b()});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.whatsnew:whats-new-resources', location = 'templates/whats-new.soy' */
// This file was automatically generated from whats-new.soy.
// Please don't edit this file by hand.

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Whatsnew == 'undefined') { Confluence.Templates.Whatsnew = {}; }


Confluence.Templates.Whatsnew.dialogPanel = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="whats-new-dialog-text"><div class="whats-new-throbber hidden"></div><div class="whats-new-timeout hidden"><div class="aui-message warning"><p class="title"><span class="aui-icon icon-warning"></span><strong>', soy.$$escapeHtml("Oops."), '</strong></p><p>', soy.$$escapeHtml(AJS.format("We\u2019re having trouble downloading the \x3ca target\x3d\x22_blank\x22 href\x3d\x22{0}\x22\x3eWhat\u2019s New content\x3c/a\x3e from the Atlassian website. This may be because you have a slow internet connection or that no internet connection is available.","https://docs.atlassian.com/confluence/docs-57/whatsnew/full")), '</p><p><a target="_blank" href="$req.contextPath/contactadministrators.action">', soy.$$escapeHtml("Contact an administrator"), '</a> &raquo;</p></div></div></div><iframe id="whats-new-iframe" class="hidden" frameborder="0"></iframe>');
  return opt_sb ? '' : output.toString();
};


Confluence.Templates.Whatsnew.dialogTipPanel = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('<div class="dialog-tip"><input id="dont-show-whats-new" type="checkbox" name="dontshow"><label for="dont-show-whats-new" type="checkbox"><span class="checkbox-label">', soy.$$escapeHtml("Don\u2019t show again"), ' </span></label><span>', soy.$$escapeHtml("(Access from \u2018Help\u2019 menu)"), '</span></div>');
  return opt_sb ? '' : output.toString();
};

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.doctheme:splitter', location = 'doctheme/splitter-1.5.1/splitter.js' */
(function(c){c.fn.splitter=function(g){g=g||{};return this.each(function(){function n(f){f=e._posSplit+f[a.eventPos];a.outline?(f=Math.max(0,Math.min(f,b._DA-d._DA)),d.css(a.origin,f)):l(f)}function o(f){d.removeClass(a.activeClass);f=e._posSplit+f[a.eventPos];a.outline&&(m.remove(),m=null,l(f));j.css("-webkit-user-select","text");c(document).unbind("mousemove",n).unbind("mouseup",o)}function l(f){f=Math.max(e._min,b._DA-h._max,Math.min(f,e._max,b._DA-d._DA-h._min));d._DA=d[0][a.pxSplit];d.css(a.origin,
f).css(a.fixed,b._DF);e.css(a.origin,0).css(a.split,f).css(a.fixed,b._DF);h.css(a.origin,f+d._DA).css(a.split,b._DA-d._DA-f).css(a.fixed,b._DF);c.browser.msie||j.trigger("resize")}function k(a,b){for(var c=0,d=1;d<arguments.length;d++)c+=Math.max(parseInt(a.css(arguments[d]))||0,0);return c}var m,a=c.extend({activeClass:"active",pxPerKey:8,tabIndex:0,accessKey:""},{v:{keyLeft:39,keyRight:37,cursor:c.browser.msie?"e-resize":"ew-resize",splitbarClass:"vsplitbar",outlineClass:"voutline",type:"v",eventPos:"pageX",
origin:"left",split:"width",pxSplit:"offsetWidth",side1:"Left",side2:"Right",fixed:"height",pxFixed:"offsetHeight",side3:"Top",side4:"Bottom"},h:{keyTop:40,keyBottom:38,cursor:c.browser.msie?"n-resize":"ns-resize",splitbarClass:"hsplitbar",outlineClass:"houtline",type:"h",eventPos:"pageY",origin:"top",split:"height",pxSplit:"offsetHeight",side1:"Top",side2:"Bottom",fixed:"width",pxFixed:"offsetWidth",side3:"Left",side4:"Right"}}[(g.splitHorizontal?"h":g.splitVertical?"v":g.type)||"v"],g),b=c(this).css({position:"relative"}),
j=b.children().css({position:"absolute","-moz-outline-style":"none"}),e=c(j[0]),h=c(j[1]),i=c('<a href="javascript:void(0)"></a>').attr({accessKey:a.accessKey,tabIndex:a.tabIndex,title:a.splitbarClass}).bind(c.browser.opera?"click":"focus",function(){this.focus();d.addClass(a.activeClass)}).bind("keydown",function(b){b=b.which||b.keyCode;(b=b==a["key"+a.side1]?1:b==a["key"+a.side2]?-1:0)&&l(e[0][a.pxSplit]+b*a.pxPerKey,!1)}).bind("blur",function(){d.removeClass(a.activeClass)}),d=c(j[2]||"<div></div>").insertAfter(e).css("z-index",
4).append(i).attr({"class":a.splitbarClass,unselectable:"on"}).css({position:"absolute","user-select":"none","-webkit-user-select":"none","-khtml-user-select":"none","-moz-user-select":"none"}).bind("mousedown",function(b){a.outline&&(m=m||d.clone(!1).insertAfter(e));j.css("-webkit-user-select","none");d.addClass(a.activeClass);e._posSplit=e[0][a.pxSplit]-b[a.eventPos];c(document).bind("mousemove",n).bind("mouseup",o)});/^(auto|default|)$/.test(d.css("cursor"))&&d.css("cursor",a.cursor);d._DA=d[0][a.pxSplit];
b._PBF=c.boxModel?k(b,"border"+a.side3+"Width","border"+a.side4+"Width"):0;b._PBA=c.boxModel?k(b,"border"+a.side1+"Width","border"+a.side2+"Width"):0;e._pane=a.side1;h._pane=a.side2;c.each([e,h],function(){this._min=a["min"+this._pane]||k(this,"min-"+a.split);this._max=a["max"+this._pane]||k(this,"max-"+a.split)||9999;this._init=!0===a["size"+this._pane]?parseInt(c.curCSS(this[0],a.split)):a["size"+this._pane]});i=e._init;isNaN(h._init)||(i=b[0][a.pxSplit]-b._PBA-h._init-d._DA);if(a.cookie){c.cookie||
alert("jQuery.splitter(): jQuery cookie plugin required");var p=parseInt(c.cookie(a.cookie));isNaN(p)||(i=p);e.bind("resize",_.debounce(function(){var b=String(d.css(a.origin));c.cookie(a.cookie,b,{expires:a.cookieExpires||365,path:a.cookiePath||document.location.pathname})},300))}isNaN(i)&&(i=Math.round((b[0][a.pxSplit]-b._PBA-d._DA)/2));var q=function(a){var d=b.offset().top,e=c("#footer, #studio-footer").outerHeight(!0);e||(e=24);e=c(window).height()-e;b.css("height",Math.max(e-d-b._hadjust,b._hmin)+
"px");(!a||a.target==window)&&b.trigger("resize")};g.update=function(a){b._hadjust=k(b,"borderTopWidth","borderBottomWidth","marginBottom");b._hmin=Math.max(k(b,"minHeight"),20);a&&c(window).bind("resize",q);q()};a.anchorToWindow?g.update(!0):a.resizeToWidth&&!c.browser.msie&&c(window).bind("resize",function(){b.trigger("resize")});b.bind("resize",function(c,g){c.target==this&&(b._DF=b[0][a.pxFixed]-b._PBF,b._DA=b[0][a.pxSplit]-b._PBA,0>=b._DF||0>=b._DA||l(!isNaN(g)?g:!a.sizeRight&&!a.sizeBottom?
e[0][a.pxSplit]:b._DA-h[0][a.pxSplit]-d._DA))}).trigger("resize",[i])})}})(jQuery);window.placeFocus=function(){var c=document.getElementById("splitter-content");c&&0==AJS.$("#wysiwyg").length&&c.focus()};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.doctheme:splitter', location = 'doctheme/space-specific-quicknav.js' */
AJS.toInit(function(b){if(b("#com-atlassian-confluence").hasClass("theme-documentation")){var c=b("#quick-search-query"),e=c.closest("form"),d="true"===b("fieldset input[name='spaceSearch']",e).val()?b("#confluence-space-key").attr("content"):"";e.submit(function(){var a=c.val();0<=a.search(/all:/gi)&&c.val(b.trim(a.replace(/all:/gi,"")))});var f=AJS.defaultIfUndefined("Atlassian.SearchableApps.QuickNav",{defaultValue:Confluence.QuickNav});AJS.log("Applying doc-theme quick search");f.addDropDownPostProcess(function(a){d&&
(a=b("a.search-for",a),a.attr("href",a.attr("href")+"&where="+encodeURIComponent(d)))});f.setMakeParams(function(a){a={query:a};0<=a.query.search(/all:/gi)?(b("input[name='where']",e).val(""),a.query=b.trim(a.query.replace(/all:/gi,"")),a.query||(a.query="ALL")):d&&(a.spaceKey=d);return a});c.mouseover(function(){d&&c.attr("title",b("input[name='tooltip']",e).val())})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
