// Functions for TOC

if (typeof top.TOC.myCurrentElement=="undefined") {
	top.TOC.myCurrentElement = 0;
}
var isIE = false;


if (window.XMLHttpRequest) {
	if(document.epando){
			isIE = true; // IE7
		}else{
			isIE = false; //mozilla, safari, opera 9�etc
		}	
	} else {
	isIE = true; // IE6, older browsers
}




function exp(id) {
  var myElt=document.getElementById('p'+id);

  if (myElt) {
    // check current display state
    if (myElt.src.slice(myElt.src.lastIndexOf('/')+1) == 'minus.gif') {
      collapse(id);
    } else{
      expand(id);
    }
  }
}

function expand(id) {
  var myDoc= top.TOC.document;
  var myElt=myDoc.getElementById('s'+id);

  if (myElt) {
    with(myElt) {
      className='x';
      style.display=''; 
    }
    myDoc.getElementById('p'+id).src='minus.gif';
    myDoc.getElementById('b'+id).src='obook.gif';
  }
}

function collapse(id) {
  var myElt=document.getElementById('s'+id);

  if (myElt) {
    with(myElt) {
      className='x';
      style.display='none'; 
    }
    document.getElementById('p'+id).src='plus.gif';
    document.getElementById('b'+id).src='cbook.gif';
  }
}

function highlight(id) {
  var myElt=top.TOC.document.getElementById('a'+id);

  if (myElt) {
    // Clear background from active first
     if (top.TOC.myCurrentElement != 0) {
	var oldElement = top.TOC.document.getElementById('a'+top.TOC.myCurrentElement);
	oldElement.style.backgroundColor="white";
     } 
    top.TOC.myCurrentElement = id;
    
    myElt.hideFocus=true;
    
    if (isIE) {
	myElt.setActive();
    } else {
	 myElt.focus();   
    }
    myElt.style.backgroundColor="#DFE8F2";
    top.TOC.scrollTo(myElt.offsetLeft-48, myElt.offsetTop-(top.TOC.document.body.clientHeight/3));
  }
}

function loadTOC() {
  // check current page displayed in TOC window.  If not toc.htm, load it.
  if (!isTOCLoaded()) {
    top.TOC.location.href='toc.htm';
  }
}

function isTOCLoaded() {
  // return true, if toc.htm is loaded in TOC window.
  if (top.TOC) {
    var myPath=top.TOC.location.pathname;
    var myFile=myPath.substr(myPath.length-7);

    if (myFile == 'toc.htm') {
      return true;
    } else {
      return false; 
    }
  } else {
    return false;
  }
}

