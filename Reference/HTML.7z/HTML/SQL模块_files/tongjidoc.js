document.writeln("<script src=\"http://s13.cnzz.com/stat.php?id=3349935&web_id=3349935\" language=\"JavaScript\"></script>");
